package test_selfProtected;

/**
 * @SelfProtected
 */
public class D extends C {

}
