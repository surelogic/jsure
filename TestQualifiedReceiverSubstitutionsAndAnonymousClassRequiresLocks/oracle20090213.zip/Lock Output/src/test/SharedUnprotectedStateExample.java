package test;

import com.surelogic.Borrowed;
import com.surelogic.RegionLock;
import com.surelogic.SingleThreaded;

@RegionLock("Lock is this protects Instance")
public class SharedUnprotectedStateExample {
  private int[] array = new int[10];
  private Object object = new Object();

  @SingleThreaded
  @Borrowed("this")
  public SharedUnprotectedStateExample() {
    // do nothing
  }
  
  public synchronized String doStuff() {
    int sum = 0;
    for (int i = 0; i < array.length; i++) {
      sum += array[i];
    }
    
    return object.toString() + " " + sum;
  }
}
