package t;

import com.surelogic.Unique;

public class A { @Unique
	private Object o = new Object();
}
