package test;

import com.surelogic.InRegion;

public class C4 extends C2 {
  @InRegion("C")
  protected int k;
  
  @InRegion("F")
  protected int m;
}
