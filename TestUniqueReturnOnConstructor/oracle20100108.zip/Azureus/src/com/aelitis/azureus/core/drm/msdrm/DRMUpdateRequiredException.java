package com.aelitis.azureus.core.drm.msdrm;

public class DRMUpdateRequiredException extends Exception {
	
	public DRMUpdateRequiredException(String message) {
		super(message);
	}

}
