package test;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.surelogic.RegionLock;

@RegionLock("M1 is lockM1 protects m1")
public class Outer {
//	public final Lock lockM1 = new ReentrantLock();
	public final Object lockM1 = new Object();
	public int m1;

	public Outer() {
//		lockM1.lock();
		synchronized (lockM1) {
//		try {
			new Object() {
				{
					m1 = 10;
					new Object() {
						{
							m1 = 200;
						}
					};
				}
			};
//		} finally {
//			lockM1.unlock();
		}
	}
}
