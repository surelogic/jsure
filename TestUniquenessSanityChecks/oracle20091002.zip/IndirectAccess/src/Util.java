
public class Util {
  public static void copy(Object[] input, Object[] output) {}
  
  public static void process(Object[] array) {}
}
