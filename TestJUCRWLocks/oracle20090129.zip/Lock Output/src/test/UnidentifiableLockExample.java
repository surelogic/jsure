package test;

import com.surelogic.RegionLock;
import com.surelogic.RegionLocks;

@RegionLocks({
  @RegionLock("xLock is this protects x"),
  @RegionLock("yLock is lock protects y"),
  @RegionLock("sLock is class protects s")})
public class UnidentifiableLockExample {
  private final Object lock = new Object();
  
  private static int s;
  
  private int x;
  private int y;
  
  static {
    // Unidentifiable lock expression
    synchronized (UnidentifiableLockExample.class) {
      s = 100;
    }
  }
  
  // Unidentifiable lock expression
  public static synchronized int getS() {
    return UnidentifiableLockExample.s;
  }
  
  // Unidentifiable lock expression
  public synchronized int getX() {
    return x;
  }
  
  public void setX(final int v) {
    // Unidentifiable lock expression
    synchronized (this) {
      x = v;
    }
  }
  
  public int getY() {
    // Unidentifiable lock expression
    synchronized (lock) {
      return y;
    }
  }
  
  public void setY(final int v) {
    // Unidentifiable lock expression
    synchronized (lock) {
      y = v;
    }
  }
}
