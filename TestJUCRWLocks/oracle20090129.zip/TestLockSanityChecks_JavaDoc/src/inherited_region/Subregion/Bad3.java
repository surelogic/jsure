/* Created on Jun 12, 2005
 */
package inherited_region.Subregion;

/**
 * @TestResult is UNASSOCIATED: Cannot protect R because it has fields in a super class.
 * @RegionLock L is this protects R
 */
public class Bad3 extends BadRoot2 {

}
