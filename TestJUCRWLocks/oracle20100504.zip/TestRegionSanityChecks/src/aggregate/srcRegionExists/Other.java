package aggregate.srcRegionExists;

import com.surelogic.Region;

@Region("public FromOther")
public class Other {
  protected int fromOther;
  // Do nothing
}
