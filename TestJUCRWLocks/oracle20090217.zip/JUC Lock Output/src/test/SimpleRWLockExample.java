package test;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;

@RegionLock("L1 is lock protects Instance")
public class SimpleRWLockExample {
  public final ReadWriteLock lock = new ReentrantReadWriteLock(); 
  private int f;
  private int g;
  
  public int getF() {
    lock.readLock().lock();
    try {
      // Good
      return f;
    } finally {
      lock.readLock().unlock();
    }
  }
  
  public boolean setF(final int v) {
    if (lock.writeLock().tryLock()) {
      try {
        f = v;
      } finally {
        lock.writeLock().unlock();
      }
      return true;
    } else {
      return false;
    }
  }
  
  @RequiresLock("L1.writeLock()")
  public void doStuff() {
    // Good
    f = 0;
  }
  
  public void setG(final int v) {
    lock.readLock().lock();
    try {
      // Bad
      g = v;
    } finally {
      lock.readLock().unlock();
    }
  }
}
