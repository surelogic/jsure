package test;

public class NotJustAnyLockExample {
  public class Lock {
    public void lock() {}
    public void unlock() {}
  }

  public class ReaderWriterLock {
    public java.util.concurrent.locks.Lock readLock() { return null; }
    public java.util.concurrent.locks.Lock writeLock() { return null; }
  }

  
  
  private final ReaderWriterLock rwLock = new ReaderWriterLock();
  private final Lock lock = new Lock();

  
  
  private void doStuff() {
    // do stuff
  }
  
  public void test() {
    lock.lock();
    try {
      doStuff();
    } finally {
      lock.unlock();
    }
  }

  public void testRead() {
    rwLock.readLock().lock();
    try {
      doStuff();
    } finally {
      rwLock.readLock().unlock();
    }
  }
  
  public void testWrite() {
    rwLock.writeLock().lock();
    try {
      doStuff();
    } finally {
      rwLock.writeLock().unlock();
    }
  }
}
