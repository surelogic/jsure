package com.surelogic.common.jdbc;

public enum DatabaseType {

	derby, oracle

}
