package test;

import com.surelogic.RegionLock;

@RegionLock("L is lockFromC protects test.D:fromD")
public class C {
  public static final Object lockFromC = new Object();
}
