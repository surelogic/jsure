package wacky;

public class X {
  private int x;
  
  public X() {
    this(1);
  }
  
  public X(int v) {
    x = v;
  }
}
