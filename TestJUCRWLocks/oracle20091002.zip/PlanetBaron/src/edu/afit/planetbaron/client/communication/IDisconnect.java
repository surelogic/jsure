package edu.afit.planetbaron.client.communication;

/**
 * Interface implemented by classes that need to be notified if the connection
 * to the server is disconnected for some reason (including during a normal
 * shutdown).
 * 
 * @author T.J. Halloran
 */
public interface IDisconnect {
  /**
   * The server connected to the specified proxy has been disconnected.
   * <p>
   * The thread this callback is invoked from within will not be the thread
   * which asked for the message to be sent.
   * 
   * @param proxy
   *          the proxy that disconnected from the server.
   */
  void disconnected(ServerProxy proxy);
}
