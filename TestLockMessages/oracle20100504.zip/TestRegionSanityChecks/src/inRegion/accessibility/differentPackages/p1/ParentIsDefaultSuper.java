package inRegion.accessibility.differentPackages.p1;

public class ParentIsDefaultSuper extends DefaultSuper {
}
