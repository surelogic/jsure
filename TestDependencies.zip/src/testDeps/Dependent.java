package testDeps;

import com.surelogic.*;

public class Dependent extends Deponent {
	@RequiresLock("L") 
	protected void foo() {
		// Nothing to do		
	}
}
