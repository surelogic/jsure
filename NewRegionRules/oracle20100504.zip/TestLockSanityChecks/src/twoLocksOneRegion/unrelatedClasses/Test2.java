package twoLocksOneRegion.unrelatedClasses;

import com.surelogic.RegionLock;

@RegionLock("L2 is this protects Instance" /* is CONSISTENT */)
public class Test2 {

}
