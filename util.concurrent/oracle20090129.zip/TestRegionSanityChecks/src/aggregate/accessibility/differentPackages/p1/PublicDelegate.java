package aggregate.accessibility.differentPackages.p1;

import com.surelogic.Region;

@Region("public PublicAgg")
public class PublicDelegate {
}
