// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    label : Info (String)
 *    ":"
 *    stmt : IStatementNode
 * 
 */
public interface ILabeledStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getLabel();
  /**
   * @return A non-null node
   */
  public IStatementNode getStmt();
}

