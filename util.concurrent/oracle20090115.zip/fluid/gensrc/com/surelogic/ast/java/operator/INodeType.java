// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;


public interface INodeType {
}
