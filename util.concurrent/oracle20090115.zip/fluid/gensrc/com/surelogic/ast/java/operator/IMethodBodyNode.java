// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    block : IBlockStatementNode
 * 
 */
public interface IMethodBodyNode extends IOptMethodBodyNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IBlockStatementNode getBlock();
}

