// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    array : IExpressionNode
 *    "["
 *    index : IExpressionNode
 *    "]"
 * 
 */
public interface IArrayRefExpressionNode extends IPrimaryExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getArray();
  /**
   * @return A non-null node
   */
  public IExpressionNode getIndex();
}

