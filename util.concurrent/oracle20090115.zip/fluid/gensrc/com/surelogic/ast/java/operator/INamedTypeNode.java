// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    type : Info (String)
 * 
 * Binds to the type represented by ISourceRefTypeBinding
 */
public interface INamedTypeNode extends IClassTypeNode, IImportNameNode, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the NamedType
   */
  public ISourceRefType resolveType();

  /**
   * @return A non-null String
   */
  public String getType();
}

