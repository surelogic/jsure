// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "long"
 * 
 */
public interface ILongTypeNode extends IIntegralTypeNode { 
  public BaseNodeType getNodeType();
}

