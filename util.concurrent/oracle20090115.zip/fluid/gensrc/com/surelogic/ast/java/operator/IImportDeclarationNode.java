// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "import"
 *    item : IImportNameNode
 *    <>
 *    ";"
 * 
 */
public interface IImportDeclarationNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IImportNameNode getItem();
}

