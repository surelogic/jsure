// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 */
public interface IForInitNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
}

