package com.surelogic.common.jdbc;

public interface Result extends Iterable<Row> {

}
