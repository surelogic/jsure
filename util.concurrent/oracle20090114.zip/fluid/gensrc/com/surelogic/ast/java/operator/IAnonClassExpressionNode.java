// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    alloc : INewExpressionNode
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * Computes the value of the 'id' attribute
 * 
 * Synthesizes a method to compute the arguments
 */
public interface IAnonClassExpressionNode extends IAllocationCallExpressionNode, ITypeDeclarationNode, ISourceRefType { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public INewExpressionNode getAlloc();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassBodyDeclarationNode> getBodyList();
}

