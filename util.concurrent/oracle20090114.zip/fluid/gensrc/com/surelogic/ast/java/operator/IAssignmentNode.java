// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * AssignmentNode is a supertype of several different assignment nodes.
 *        If you are looking for the node that we normally associate with
 *        assignment, you are probably looking for AssignExpressionNode.
 * 
 * This is an abstract node (i.e., never instantiated)

 */
public interface IAssignmentNode extends IJavaOperatorNode, IStatementExpressionNode { 
  public BaseNodeType getNodeType();
}

