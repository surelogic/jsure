// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    <?>
 *    object : IExpressionNode
 *    <>
 *    "."
 *    <>
 *    </?>
 *    method : Info (String)
 *    <>
 *    argsList : List<IExpressionNode>
 * 
 */
public interface INonPolymorphicMethodCallNode extends IMethodCallNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

