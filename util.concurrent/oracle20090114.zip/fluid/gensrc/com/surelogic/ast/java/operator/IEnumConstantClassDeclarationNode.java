// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    id : Info (String)
 *    argsList : List<IExpressionNode> or null
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * 
 * Binds to the type represented by ITypeBinding
 */
public interface IEnumConstantClassDeclarationNode extends IEnumConstantDeclarationNode, IVariableBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the EnumConstantClassDeclaration
   */
  public IType resolveType();

  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassBodyDeclarationNode> getBodyList();
}

