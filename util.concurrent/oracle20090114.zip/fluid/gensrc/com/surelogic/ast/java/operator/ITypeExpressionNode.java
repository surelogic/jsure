// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * A static reference to a type.
 * This expression is legal in only a few situations:
 * <ul>
 *    <li> As the object for method calls.
 *    <li> As the object for field refs.
 * </ul>
 * 
 * Syntax:
 *    type : IReturnTypeNode
 * 
 */
public interface ITypeExpressionNode extends IPrimaryExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IReturnTypeNode getType();
}

