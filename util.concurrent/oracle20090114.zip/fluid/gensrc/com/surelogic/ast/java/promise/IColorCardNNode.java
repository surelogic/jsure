// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "n"
 * 
 */
public interface IColorCardNNode extends IColorCardChoiceNode { 
  public PromiseNodeType getNodeType();
}

