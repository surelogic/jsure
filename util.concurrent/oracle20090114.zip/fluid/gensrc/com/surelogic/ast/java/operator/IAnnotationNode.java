// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "@"
 *    id : Info (String)
 * 
 * Binds this name to IAnnotationBinding
 */
public interface IAnnotationNode extends IElementValueNode, IHasBinding { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IAnnotationBinding resolveBinding();

  /**
   * @return A non-null String
   */
  public String getId();
}

