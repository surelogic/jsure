// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "double"
 * 
 */
public interface IDoubleTypeNode extends IFloatingPointTypeNode { 
  public BaseNodeType getNodeType();
}

