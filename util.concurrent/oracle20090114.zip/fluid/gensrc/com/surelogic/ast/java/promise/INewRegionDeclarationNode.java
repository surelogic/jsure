// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A declaration of a named region specific to a class.
 * A region extends a parent region (usually *).
 * 
 * Syntax:
 *    modifiers : Modifiers (int)
 *    id : Info (String)
 *    "extends"
 *    parent : IRegionSpecificationNode
 * 
 */
public interface INewRegionDeclarationNode extends IRegionDeclarationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null int
   */
  public int getModifiers();
  /**
   * @return A non-null node
   */
  public IRegionSpecificationNode getParent();
}

