// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    token : Info (String)
 * 
 */
public interface IIntLiteralNode extends IPrimLiteralNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getToken();
}

