// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Require a Thread Color (or colors)
 * 
 * Syntax:
 *    "colorConstraint"
 *    cSpec : IColorSpecNode
 * 
 */
public interface IColorRequireNode extends IColoringAnnotationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IColorSpecNode getCSpec();
}

