// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A declaration or renaming of a region specific to a class.
 * @see NewRegionDeclaration
 * @see RegionMapping
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 */
public interface IRegionDeclarationNode extends IPromiseDeclarationNode { 
  public PromiseNodeType getNodeType();
}

