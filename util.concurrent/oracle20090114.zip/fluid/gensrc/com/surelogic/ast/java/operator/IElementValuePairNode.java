// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    id : Info (String)
 *    "="
 *    value : IElementValueNode
 * 
 */
public interface IElementValuePairNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getId();
  /**
   * @return A non-null node
   */
  public IElementValueNode getValue();
}

