// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    mods : Modifiers (int)
 *    pkg : Comment (String)
 *    ":"
 *    type : Info (String)
 *    ":"
 *    "new"
 *    sigList : List<ITypeNode>
 *    throwsCList : List<ITypeNode>
 * 
 */
public interface IConstructorDeclPatternNode extends IPromiseTargetNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null int
   */
  public int getMods();
  /**
   * @return A non-null String
   */
  public String getPkg();
  /**
   * @return A non-null String
   */
  public String getType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeNode> getSigList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeNode> getThrowsCList();
}

