// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * A very special form of call: legal only as the first statement expression
 * of a constructor.  The object must be "this" or "super".  The type
 * actuals are for  polymorphism of the constructor, not the class in
 * which the constructor is defined.  These types are already defined by the
 * "extends" clause of the class.
 * 
 * Syntax:
 *    typeArgsList : List<IReferenceTypeNode>
 *    object : IConstructionObjectNode
 *    argsList : List<IExpressionNode>
 *    <>
 * 
 */
public interface IPolymorphicConstructorCallNode extends IConstructorCallNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IReferenceTypeNode> getTypeArgsList();
  /**
   * @return A non-null node
   */
  public IConstructionObjectNode getObject();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

