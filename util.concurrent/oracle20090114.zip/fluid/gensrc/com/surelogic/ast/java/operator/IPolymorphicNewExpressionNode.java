// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "new"
 *    typeArgsList : List<IReferenceTypeNode>
 *    type : IClassTypeNode
 *    argsList : List<IExpressionNode>
 * 
 */
public interface IPolymorphicNewExpressionNode extends INewExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IReferenceTypeNode> getTypeArgsList();
  /**
   * @return A non-null node
   */
  public IClassTypeNode getType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

