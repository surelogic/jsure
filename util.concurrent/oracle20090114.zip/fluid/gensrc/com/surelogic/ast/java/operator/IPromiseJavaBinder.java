// Generated code.  Do *NOT* edit!
/**
 * Interface for resolving Java bindings and the like
 * <p>
 * Contains one resolve() method for each kind of name/call
 */
package com.surelogic.ast.java.operator;

import java.util.*;
import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

public interface IPromiseJavaBinder extends IBaseJavaBinder {
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IQualifiedRegionNameNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IRegionBinding resolve(IQualifiedRegionNameNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IRegionSpecificationNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IRegionBinding resolve(IRegionSpecificationNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(ITypeDeclPatternNode node);

  /**
   * Gets the binding(s) matching to the type of the TypeDeclPattern
   * @return Any type binding objects that match the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public Iterable<ISourceRefType> resolveType(ITypeDeclPatternNode e);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IRegionNameNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IRegionBinding resolve(IRegionNameNode node);
}
