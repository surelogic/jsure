// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    pkg : Info (String)
 *    <>
 *    "."
 *    <>
 *    "*"
 * 
 */
public interface IDemandNameNode extends IImportNameNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getPkg();
}

