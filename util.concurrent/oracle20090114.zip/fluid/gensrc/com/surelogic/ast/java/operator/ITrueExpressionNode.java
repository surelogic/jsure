// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "true"
 * 
 */
public interface ITrueExpressionNode extends IBooleanLiteralNode { 
  public BaseNodeType getNodeType();
}

