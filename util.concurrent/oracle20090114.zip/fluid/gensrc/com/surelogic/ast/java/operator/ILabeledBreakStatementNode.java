// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "break"
 *    id : Info (String)
 *    <semi>
 *    ";"
 * 
 */
public interface ILabeledBreakStatementNode extends ISomeBreakStatementNode { 
  public BaseNodeType getNodeType();
}

