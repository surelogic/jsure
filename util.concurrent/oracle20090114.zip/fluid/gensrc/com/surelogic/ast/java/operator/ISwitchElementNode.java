// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    label : ISwitchLabelNode
 *    stmtsList : List<IStatementNode>
 * 
 */
public interface ISwitchElementNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ISwitchLabelNode getLabel();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IStatementNode> getStmtsList();
}

