// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

/**
 */
@SuppressWarnings("deprecation")
public class DescendingBaseVisitor<T> implements IBaseNodeVisitor<T> {
  protected final T defaultValue;

  public DescendingBaseVisitor(T defaultVal) {
    defaultValue = defaultVal;
  }

  public DescendingBaseVisitor() {
    this(null);
  }

  public T doAccept(IJavaOperatorNode node) {
    if (node == null) { return defaultValue; }
    return node.accept(this);
  }

  /**
   */
  public T combineResults(T before, T next) {
    return (next == null) ? before : next;
  }

  public T visit(ILabeledBreakStatementNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IAssignExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IUnsignedRightShiftExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IParameterizedTypeNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBase()));
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IWildcardExtendsTypeNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getLower()));
    return rv;
  }
  public T visit(IUnnamedPackageDeclarationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IBoxExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IAndExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IFieldRefNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getObject()));
    return rv;
  }
  public T visit(IFloatLiteralNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IElementValuePairNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getValue()));
    return rv;
  }
  public T visit(ITypedDemandNameNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(IStaticDemandNameNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(ISubExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IDemandNameNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IAssertMessageStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getAssertion()));
    rv = combineResults(rv, doAccept(n.getMessage()));
    return rv;
  }
  public T visit(IArrayCreationExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBase()));
    for(IJavaOperatorNode c : n.getAllocatedList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getInit()));
    return rv;
  }
  public T visit(INotExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(ISuperRootNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCompUnit()));
    return rv;
  }
  public T visit(IInterfaceDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getExtensionsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IDoStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getLoop()));
    rv = combineResults(rv, doAccept(n.getCond()));
    return rv;
  }
  public T visit(IBreakStatementNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(ICharLiteralNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IVarArgsExpressionNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getArgList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ISuperExpressionNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(INullLiteralNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IWhileStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCond()));
    rv = combineResults(rv, doAccept(n.getLoop()));
    return rv;
  }
  public T visit(ICompilationUnitNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getPkg()));
    for(IJavaOperatorNode c : n.getImpsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getDeclsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ILabeledStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getStmt()));
    return rv;
  }
  public T visit(IExprStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getExpr()));
    return rv;
  }
  public T visit(IFloatTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(ISimpleEnumConstantDeclarationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IMulExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(ICastExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    rv = combineResults(rv, doAccept(n.getExpr()));
    return rv;
  }
  public T visit(INoMethodBodyNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(INotEqExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(ICatchClauseNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getParam()));
    rv = combineResults(rv, doAccept(n.getBody()));
    return rv;
  }
  public T visit(IThisExpressionNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IIntLiteralNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IAddExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IAnnotationDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IAssertStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getAssertion()));
    return rv;
  }
  public T visit(IMarkerAnnotationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IPolymorphicMethodCallNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getObject()));
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IOpAssignExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IEnumConstantDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IPolymorphicNewExpressionNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getType()));
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IElseClauseNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getElseStmt()));
    return rv;
  }
  public T visit(IElementValueArrayInitializerNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getValueList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ISwitchElementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getLabel()));
    for(IJavaOperatorNode c : n.getStmtsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(INestedInterfaceDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getExtensionsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IPackageRootNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getCompUnitList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IVoidReturnStatementNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IQualifiedSuperExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(INamedPackageDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IAnnotationElementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    rv = combineResults(rv, doAccept(n.getValue()));
    return rv;
  }
  public T visit(IFieldDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getType()));
    for(IJavaOperatorNode c : n.getVarsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IBlockStatementNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getStmtList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ISwitchBlockNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getElementList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IMethodBodyNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBlock()));
    return rv;
  }
  public T visit(ITypeDeclarationStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTypedec()));
    return rv;
  }
  public T visit(IShortTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IWildcardSuperTypeNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getUpper()));
    return rv;
  }
  public T visit(IClassInitializerNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBlock()));
    return rv;
  }
  public T visit(IXorExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IAnonClassExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getAlloc()));
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IForStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getInit()));
    rv = combineResults(rv, doAccept(n.getCond()));
    rv = combineResults(rv, doAccept(n.getUpdate()));
    rv = combineResults(rv, doAccept(n.getLoop()));
    return rv;
  }
  public T visit(IVariableDeclaratorNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getInit()));
    return rv;
  }
  public T visit(IEmptyStatementNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IParameterDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(IEnumConstantClassDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ILongTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IPostIncrementExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IUnboxExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(ISwitchStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getExpr()));
    rv = combineResults(rv, doAccept(n.getBlock()));
    return rv;
  }
  public T visit(ISynchronizedStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getLock()));
    rv = combineResults(rv, doAccept(n.getBlock()));
    return rv;
  }
  public T visit(IMinusExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IReturnStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getValue()));
    return rv;
  }
  public T visit(IStatementExpressionListNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getExprList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ILessThanExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(ITrueExpressionNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IIntTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IOuterObjectSpecifierNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getObject()));
    rv = combineResults(rv, doAccept(n.getCall()));
    return rv;
  }
  public T visit(IGreaterThanEqualExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IComplementExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IDivExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(INestedEnumDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getImplsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IDeclStatementNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getType()));
    for(IJavaOperatorNode c : n.getVarsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IOrExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(INormalAnnotationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getPairsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IEnumDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getImplsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IPostDecrementExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IForEachStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getVar()));
    rv = combineResults(rv, doAccept(n.getCollection()));
    rv = combineResults(rv, doAccept(n.getLoop()));
    return rv;
  }
  public T visit(IPolymorphicConstructorCallNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getObject()));
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IArrayRefExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getArray()));
    rv = combineResults(rv, doAccept(n.getIndex()));
    return rv;
  }
  public T visit(INonPolymorphicConstructorCallNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getObject()));
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IContinueStatementNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IAnnotationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IVariableUseExpressionNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IClassExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(ILeftShiftExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(ICompiledMethodBodyNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(ILabeledContinueStatementNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(ICaptureTypeNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getBoundsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IConditionalExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCond()));
    rv = combineResults(rv, doAccept(n.getIftrue()));
    rv = combineResults(rv, doAccept(n.getIffalse()));
    return rv;
  }
  public T visit(IInitializationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getValue()));
    return rv;
  }
  public T visit(IQualifiedThisExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(INamedTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IPlusExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IRemExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IEqExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IConstructorDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getParamsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getExceptionsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getBody()));
    return rv;
  }
  public T visit(IRightShiftExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(INonPolymorphicNewExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IDoubleTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IIfStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCond()));
    rv = combineResults(rv, doAccept(n.getThenPart()));
    rv = combineResults(rv, doAccept(n.getElsePart()));
    return rv;
  }
  public T visit(IGreaterThanExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IPreDecrementExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(ITypeExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(ITryStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBlock()));
    for(IJavaOperatorNode c : n.getCatchPartList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getFinallyPart()));
    return rv;
  }
  public T visit(INestedClassDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getExtension()));
    for(IJavaOperatorNode c : n.getImplsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IConditionalAndExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(ISingleElementAnnotationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getElt()));
    return rv;
  }
  public T visit(ITypeFormalNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getBoundsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IFinallyNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBody()));
    return rv;
  }
  public T visit(IFalseExpressionNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IBooleanTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IThrowStatementNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getValue()));
    return rv;
  }
  public T visit(IDefaultValueNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getValue()));
    return rv;
  }
  public T visit(IPreIncrementExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp()));
    return rv;
  }
  public T visit(IStaticImportNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(INonPolymorphicMethodCallNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getObject()));
    for(IJavaOperatorNode c : n.getArgsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IDefaultLabelNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IImportDeclarationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getItem()));
    return rv;
  }
  public T visit(IMethodDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getReturnType()));
    for(IJavaOperatorNode c : n.getParamsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getExceptionsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getBody()));
    return rv;
  }
  public T visit(IArrayInitializerNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getInitList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IVarArgsTypeNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBase()));
    return rv;
  }
  public T visit(IByteTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IOmittedMethodBodyNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(ICharTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IClassDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAnnosList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getExtension()));
    for(IJavaOperatorNode c : n.getImplsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IStringLiteralNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IStringConcatNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(IInstanceOfExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getValue()));
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(ILessThanEqualExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
  public T visit(ITypeRefNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBase()));
    return rv;
  }
  public T visit(IVoidTypeNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IArrayTypeNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBase()));
    return rv;
  }
  public T visit(IArrayLengthNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getObject()));
    return rv;
  }
  public T visit(IConstantLabelNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getExpr()));
    return rv;
  }
  public T visit(IConditionalOrExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getOp1()));
    rv = combineResults(rv, doAccept(n.getOp2()));
    return rv;
  }
}
