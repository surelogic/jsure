// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Grant a Thread Color (or colors)
 * 
 * Syntax:
 *    "grant"
 *    Zero or more of:
 *      colorList : List<IColorNameNode>
 *    Separated by:
 *      ","
 * 
 */
public interface IColorGrantNode extends IColoringAnnotationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IColorNameNode> getColorList();
}

