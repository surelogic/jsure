// Generated code.  Do *NOT* edit!
/**
 * Interfaces for Java AST nodes generated from .op files
 * <p>
 * Note: There should be only one active implementation of these interfaces during
 * the lifetime of a given JVM, unless otherwise specified for the implementation.
 * If this does not hold, there are no guarantees that internal invariants will
 * be satisfied
 * <p>
 * Note: These interfaces do not include any interfaces for mutation, and implementations
 * may assume that the ASTs cannot be changed
 * <pre>
 * </pre>
 */
package com.surelogic.ast.java.operator;

