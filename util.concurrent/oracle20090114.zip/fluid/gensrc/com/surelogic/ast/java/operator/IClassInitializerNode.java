// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    modifiers : Modifiers (int)
 *    block : IBlockStatementNode
 * 
 */
public interface IClassInitializerNode extends IClassBodyDeclarationNode { 
  public BaseNodeType getNodeType();
  public boolean isStatic();
  /**
   * @return A non-null node
   */
  public IBlockStatementNode getBlock();
}

