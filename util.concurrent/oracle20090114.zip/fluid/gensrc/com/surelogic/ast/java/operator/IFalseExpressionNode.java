// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "false"
 * 
 */
public interface IFalseExpressionNode extends IBooleanLiteralNode { 
  public BaseNodeType getNodeType();
}

