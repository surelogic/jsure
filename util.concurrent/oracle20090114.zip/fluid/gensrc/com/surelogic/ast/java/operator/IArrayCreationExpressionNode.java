// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "new"
 *    base : ITypeNode
 *    <>
 *    allocatedList : List<IExpressionNode>
 *    <>
 *    unallocated : DimInfo (int)
 *    <>
 *    init : IOptArrayInitializerNode
 * 
 */
public interface IArrayCreationExpressionNode extends IAllocationExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ITypeNode getBase();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getAllocatedList();
  /**
   * @return A non-null int
   */
  public int getUnallocated();
  /**
   * @return A node, or null
   */
  public IArrayInitializerNode getInit();
}

