// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * An explicit declaration of the receiver
 * @see MethodDeclaration
 * @see ClassBody
 * @see ConstructorDeclaration
 * 
 * Syntax:
 *    "this"
 * 
 */
public interface IReceiverDeclarationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

