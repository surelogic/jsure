// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    base : ITypeNode
 *    "..."
 * 
 */
public interface IVarArgsTypeNode extends IReferenceTypeNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ITypeNode getBase();
}

