// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.*;
import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A use of a named region.  Binding uses standard scoping
 * rules to determine which region is indicated.
 * 
 * Syntax:
 *    id : Info (String)
 * 
 * Binds this name to IRegionBinding
 */
public interface IRegionNameNode extends IRegionSpecificationNode, IHasBinding { 
  public PromiseNodeType getNodeType();
  public boolean bindingExists();

  public IRegionBinding resolveBinding();

}

