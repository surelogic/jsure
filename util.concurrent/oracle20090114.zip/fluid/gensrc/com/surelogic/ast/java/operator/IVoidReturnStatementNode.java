// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "return"
 *    <semi>
 *    ";"
 * 
 */
public interface IVoidReturnStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
}

