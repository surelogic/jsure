package test;

import com.surelogic.RegionLock;
import com.surelogic.ReturnsLock;

@RegionLock("L is this protects Instance")
public class ReturnsLockExample {
  protected int v;
  
  @ReturnsLock("L")
  private Object goodGetLock() {
    return this;
  }
  
  @ReturnsLock("L")
  private Object badGetLock() {
    return new Object();
  }
  
  public void doStuff() {
    synchronized (goodGetLock()) {
      v = 1; 
    }
    synchronized (badGetLock()) {
      v = 2;
    }
  }
}
