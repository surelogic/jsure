package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Container annotation for multiple {@link MapFields} annotations.  It is an error
 * for a class to have both a {@code MapsFields} and a {@code MapFields} annotation.
 */
@Documented
@Target(ElementType.TYPE)
public @interface MapsFields {
  /**
   * The {@link MapFields} annotations to apply to the class.
   */
  MapFields[] value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
