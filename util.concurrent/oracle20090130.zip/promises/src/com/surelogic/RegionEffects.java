package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares the regions that may be read or written during execution of this
 * method or constructor. Because writing implies the ability to read, regions
 * that may be both read and written by the method only need to be declared in
 * writes clause of the annotation.
 * 
 * <p>
 * If a method is without a <code>&#64;RegionEffect</code> annotation, then the method is
 * assumed to be annotated with <code>&#64;RegionEffect("Object:All")</code>. To declare
 * that a constructor/method has no visible effects write
 * <code>@code &#64;RegionEffects("none")</code>.
 */
@Documented
@Target({ElementType.METHOD, ElementType.CONSTRUCTOR})
public @interface RegionEffects {
  /**
   * This attribute is either {@code "none"} to indicate that the method/constructor
   * has no visible effects or divided into separate (and optional) reads and writes
   * clauses.  Each clause is a list of comma-separated targets describing
   * the regions that may be read/written.  The clauses are separated by a
   * semicolon.
   * 
   * <p>Examples
   * <pre>
   * &#64;RegionEffects("reads this:Instance; writes other:Instance")
   * &#64;RegionEffects("writes C:StaticRegion, any(D):Instance; reads this:Instance")
   * &#64;RegionEffects("reads this:Instance")
   * &#64;RegionEffects("writes this:Instance")
   * &#64;RegionEffects("none")
   * </pre>
   * 
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value =
   *   none /  ; No effects
   *   readsEffect [";" writesEffect] /
   *   writesEffect [";" readsEffect]
   * 
   * readsEffect = "reads" effectsSpecification
   * 
   * writesEffect = "writes" effectsSpecification
   * 
   * effectsSpecification = "nothing" / effectSpecification *("," effectSpecification)
   *   
   * effectSpecification =
   *   simpleEffectExpression ":" simpleRegionSpecification /
   *   IDENTIFIER   ; region of "this"
   * 
   * simpleEffectExpression =
   *   "any" "(" namedType ")" /    ; any instance
   *   namedType "." "this" /       ; qualified this expression
   *   namedType /                  ; class name 
   *   simpleExpression             ; parameter name
   * 
   * namedType = IDENTIFIER *("." IDENTIFIER)
   * 
   * simpleExpression = "this" / IDENTIFIER
   * 
   * simpleRegionSpecification = IDENTIFIER / "[" "]"  ; Region of the class being annotated
   * 
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
