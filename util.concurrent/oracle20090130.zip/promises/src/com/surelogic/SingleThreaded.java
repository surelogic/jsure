package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Marker annotation that indicates that the object created by the constructor
 * is only operated on by the thread that invoked the constructor.  This 
 * knowledge allows fields of the newly create object to be accessed without
 * the normally required locking within the body of the constructor.
 */
@Documented
@Target(ElementType.CONSTRUCTOR)
public @interface SingleThreaded {
  // Marker annotation
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
