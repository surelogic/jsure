package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Container annotation for multiple {@link Region} annotations.  It is an error
 * for a class to have both a {@code Regions} and a {@code Region} annotation.
 */
@Documented
@Target(ElementType.TYPE)
public @interface Regions {
  /**
   * The {@link Region} annotations to apply to the class.
   */
  Region[] value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
