package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * A convenience annotation for declaration at the class-level that many fields 
 * of the class should be mapped into a single region of the class.  This
 * can be more concise than {@link InRegion}, although at the price of moving
 * information about the fields into annotations about the class.  For example,
 * the following use of {@code MapFields}
 * 
 * <pre>
 * &#64;Region("public Region")
 * &#64;MapFields("f1, f2, f3 into Region")
 * public class C {
 *   private int f1;
 *   private int f2;
 *   private int f3;
 *   ...
 * }
 * </pre>
 * 
 * is equivalent to the following use of {@code InRegion}
 * 
 * <pre>
 * &#64;Region("public Region")
 * public class C {
 *   &#64;InRegion("Region") private int f1;
 *   &#64;InRegion("Region") private int f2;
 *   &#64;InRegion("Region") private int f3;
 *   ...
 * }
 * </pre>
 * 
 * <p>To apply
 * more than one {@code MapFields} annotation to a class the {@link MapsFields} annotation.  It is an error
 * for a class to have both a {@code MapFields} and a {@code MapsFields} annotation.
 * 
 * @see MapsFields
 * @see InRegion
 * @see Aggregate
 */
@Documented
@Target(ElementType.TYPE)
public @interface MapFields {
  /**
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = regionSpecifications "into" regionSpecification
   * 
   * regionSpecifications = regionSpecification *("," regionSpecification)
   * 
   * regionSpecification = simpleRegionSpecificaion / qualifiedRegionName
   * 
   * simpleRegionSpecification = IDENTIFIER / "[" "]"  ; Region of the class being annotated
   * 
   * qualifedRegionName = 
   *   IDENTIFIER *("." IDENTIFIER) : IDENTIFER  ; Static region from the named, optionally qualified, class
   *
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
