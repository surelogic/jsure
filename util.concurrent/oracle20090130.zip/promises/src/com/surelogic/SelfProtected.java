package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

import net.jcip.annotations.ThreadSafe;

/**
 * Marker annotation that indicates that the annotated type protects itself.
 * That is, it is safe to call any two methods from the class simultaneously 
 * from different threads.  This annotation does not imply anything about how
 * the class is implemented.  Of course, it also does not imply that a
 * sequence of calls to methods of this class are atomic.  It is a the responsibility
 * of the caller to insure that such call sequences execute atomically.  <em>This
 * annotation is not checked</em>; rather it is used to quiet warnings that 
 * would otherwise be raised when accessing an object through a field protected
 * by a lock.
 * 
 * @see ThreadSafe
 */
@Documented
@Target(ElementType.TYPE)
public @interface SelfProtected {
  // Marker annotation
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
