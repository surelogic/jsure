package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares that regions of <em>the object referenced by this field</em> are
 * to be mapped or "aggregated" into regions of the object that contains the
 * field.  It is an error if the field is not also annotated with {@link Unique}.
 */
@Documented
@Target(ElementType.FIELD)
public @interface Aggregate {
  /**
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = regionMapping *("," regionMapping)
   * 
   * regionMapping = simpleRegionSpecification "into" regionSpecification
   * 
   * regionSpecification = simpleRegionSpecificaion / qualifiedRegionName
   * 
   * simpleRegionSpecification = IDENTIFIER / "[" "]"  ; Region of the class being annotated
   * 
   * qualifedRegionName = 
   *   IDENTIFIER *("." IDENTIFIER) : IDENTIFER  ; Static region from the named, optionally qualified, class
   *
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   *
   * <p>In {@code A into B}, the first RegionSpecification is relative to the object referenced by the field; the second is 
   * relative to the object that contains the field.   
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
