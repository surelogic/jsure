package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares that the object returned by this method is the named lock.
 * This allows the representation of the lock to be concealed from clients 
 * of the object, but still makes the lock accessible to them.  It is an error 
 * if the return type of the annotated method is a primitive type.
 */
@Documented
@Target(ElementType.METHOD)
public @interface ReturnsLock {
  /**
   * The name of the lock returned by the annotated method.  The value of this
   * attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = lockSpecification
   * 
   * lockSpecification = qualifiedLockSpecification / simpleLockSpecification
   * 
   * simpleLockSpecification = simpleLockName ["." ("readLock" / "writeLock")]
   * 
   * qualifiedLockSpecification = qualifiedLockName ["." ("readLock" / "writeLock")]
   * 
   * simpleLockName = IDENTIFIER  ; Lock from the receiver (same as "this:IDENTIFIER")
   * 
   * qualifiedLockName = parameterLockName / typeQualifiedLockName / innerClassLockName
   * 
   * parameterLockName = simpleExpression ":" IDENTIFIER  ; Lock from a method/constructor parameter
   * 
   * simpleExpression = "this" / IDENTIFER  ; Receiver or parameter name
   * 
   * typeQualifiedLockName = typeExpression ":" IDENTIFIER  ; Static lock qualified by a class name
   * 
   * typeExpression = IDENTIFIER *("." IDENTIFIER)
   * 
   * innerClassLockName = namedType "." "this" ":" IDENTIFIER ; Lock from an enclosing instance
   * 
   * namedType = IDENTIFIER *("." IDENTIFIER)
   * 
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
