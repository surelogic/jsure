package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declare a new region lock in the annotated class.  Creates a new named 
 * lock that associates a particular lock object with a region of the class.
 * The region may only be accessed when the lock is held.  
 * 
 * <P>To declare
 * more than one lock for a class use the {@link RegionLocks} annotation.  It is an error
 * for a class to have both a {@code RegionLocks} and a {@code RegionLock} annotation.
 * 
 * <p>The named lock is a Java object  If the object's type implements 
 * {@code java.util.concurrent.locks.Lock} then the lock object must be used 
 * according to the protocol of the {@code Lock} interface.  Otherwise, the 
 * object must be used as a Java intrinsic lock, i.e., with {@code synchronized}
 * blocks.
 * 
 * @see RegionLocks
 * @see PolicyLock
 */
@Documented
@Target(ElementType.TYPE)
public @interface RegionLock {
  /**
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = IDENTIFIER "is" lockExpression "protects" regionName
   * 
   * lockExpression = simpleLockExpression / qualifiedLockExpression
   * 
   * simpleLockExpression = 
   *   "class" /              ; the Class object referenced by the "class" pseudo-field of the annotated class
   *   "this" /               ; the instance itself
   *   "this" "." IDENTIFIER  ; the object referenced by the named field
   * 
   * qualifiedLockExpression = 
   *   namedType "." "CLASS" /            ; the Class object referenced by the "class" pseudo-field of a named class
   *   namedType "." "THIS" /             ; a named enclosing instance
   *   namedType "." IDENTIFIER /         ; a named static field
   *   namedType "." THIS "." IDENTIFIER  ; a named field of an enclosing instance
   * 
   * namedType = IDENTIFIER *("." IDENTIFIER)
   * 
   * regionName = IDENTIFIER
   * 
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
