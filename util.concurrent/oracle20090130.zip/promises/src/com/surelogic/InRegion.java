package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Indicates that the annotated field is mapped into the named abstract region.
 * 
 * @see Aggregate
 * @see MapFields
 */
@Documented
@Target(ElementType.FIELD)
public @interface InRegion {
  /**
   * The value of this attribute indicates the abstract region that is the 
   * superregion of the annotated field.  The value of this attribute must
   * conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = regionSpecification
   * 
   * regionSpecification = simpleRegionSpecificaion / qualifiedRegionName
   * 
   * simpleRegionSpecification = IDENTIFIER / "[" "]"  ; Region of the class being annotated
   * 
   * qualifedRegionName = 
   *   IDENTIFIER *("." IDENTIFIER) : IDENTIFER  ; Static region from the named, optionally qualified, class
   *
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
