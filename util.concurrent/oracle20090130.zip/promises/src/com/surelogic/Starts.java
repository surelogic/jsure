package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Indicates what threads, if any, are started, i.e., by 
 * {@link Thread#start()}, during the
 * execution of the method or constructor. Presently this annotation has only
 * one legal form, {@code @Starts("nothing")}, that indicates that the
 * method/constructor does not cause any threads to be started. It is 
 * an error if {@link #value} is not {@code "nothing"}.
 */
@Documented
@Target( { ElementType.CONSTRUCTOR, ElementType.METHOD })
public @interface Starts {
  /**
   * Must be {@code "nothing"}. Additional values are reserved for future use.
   * 
   * <p>The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = "nothing"
   * </pre>
   */
  public String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
