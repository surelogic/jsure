package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Container annotation for multiple {@link PolicyLock} annotations.  It is an error
 * for a class to have both a {@code PolicyLocks} and a {@code PolicyLock} annotation.
 */
@Documented
@Target(ElementType.TYPE)
public @interface PolicyLocks {
  /**
   * The {@link PolicyLock} annotations to apply to the class.
   */
  PolicyLock[] value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
