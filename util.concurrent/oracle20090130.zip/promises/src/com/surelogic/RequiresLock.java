package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares that the method/constructor assumes that the caller holds the 
 * named locks.  Analysis of the method/constructor proceeds as if the named
 * locks were held; call sites of the method are scrutinized to determine if the
 * precondition is satisfied.
 * 
 * <p>The list of locks is allowed to be empty, in which case it means that the
 * method/constructor does not require any locks to be held by the caller.
 */
@Documented
@Target({ElementType.METHOD, ElementType.CONSTRUCTOR})
public @interface RequiresLock {
  /**
   * A comma-separated list of zero or more lock names. 
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = lockSpecification *("," lockSpecification)
   * 
   * lockSpecification = qualifiedLockSpecification / simpleLockSpecification
   * 
   * simpleLockSpecification = simpleLockName ["." ("readLock" / "writeLock")]
   * 
   * qualifiedLockSpecification = qualifiedLockName ["." ("readLock" / "writeLock")]
   * 
   * simpleLockName = IDENTIFIER  ; Lock from the receiver (same as "this:IDENTIFIER")
   * 
   * qualifiedLockName = parameterLockName / typeQualifiedLockName / innerClassLockName
   * 
   * parameterLockName = simpleExpression ":" IDENTIFIER  ; Lock from a method/constructor parameter
   * 
   * simpleExpression = "this" / IDENTIFER  ; Receiver or parameter name
   * 
   * typeQualifiedLockName = typeExpression ":" IDENTIFIER  ; Static lock qualified by a class name
   * 
   * typeExpression = IDENTIFIER *("." IDENTIFIER)
   * 
   * innerClassLockName = namedType "." "this" ":" IDENTIFIER ; Lock from an enclosing instance
   * 
   * namedType = IDENTIFIER *("." IDENTIFIER)
   * 
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
