package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Indicates that the parameter or receiver, in the case of an annotated
 * method/constructor, does not receive any new aliases during execution
 * of the method.  That is, {@link Unique} values can be safely passed to 
 * the parameter or receiver with the guarantee that they will still be unique
 * when the method returns.
 * 
 * <p>It is an error to use this annotation on a method whose return type is primitive.  
 * It is an error to use this annotation on a parameter whose type is primitive.
 */
@Documented
@Target({ ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.PARAMETER })
public @interface Borrowed {
  /**
   * When annotating a constructor or a method, this attribute 
   * must be {@code "this"} to clarify the intent that it is the receiver 
   * that is borrowed.  It is an error if the attribute is not {@code "this"}
   * in this case.
   * 
   * <p>This attribute is not used when annotating a parameter; it is an an error
   * for the value to be anything other than the empty string when annotating
   * a parameter.
   * 
   * 
   * <p>The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = ["this"] ; See above comments
   * </pre>
   */
  String value() default "";
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
