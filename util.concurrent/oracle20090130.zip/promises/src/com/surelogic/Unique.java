package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Indicates that the parameter, receiver, return value, or field is unique.
 * 
 * <p>
 * It is an error to annotate a method return value if the return type is
 * primitive. It is an error to annotate a parameter if the parameter's type is
 * primitive.
 * 
 * @see NotUnique
 */
@Documented
@Target( { ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER })
public @interface Unique {
  /**
   * When annotating a method, this attribute is used to disambiguate whether
   * the annotation refers to the method's receiver, the method's return value,
   * or both.  The value is comma separated list of tokens, and has the
   * following set of legal values (ignoring white space issues):
   * <ul>
   * <li>{@code ""}
   * <li>{@code "this"}
   * <li>{@code "return"}
   * <li>{@code "this, return"}
   * <li>{@code "return, this"}
   * </ul>
   * 
   * <p>The values are interpreted thusly
   * <ul>
   * <li>If the list contains the value {@code "this"}, it indicates the
   * receiver is unique.
   * <li>If the list contains the value {@code "return"}, or is if the list
   * is of length zero, it indicates the return value is unique.
   * <li>If the list contains both {@code "this"} and {@code "return"},
   * it indicates that both the receiver and the return value are unique.
   * </ul>
   * 
   * <p>This attribute is not used when annotating a parameter or a field: the
   * attribute value must be the empty string in these cases. 
   * 
   * <p>The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = [("this" ["," "return"]) / ("return" ["," "this"])] ; See above comments
   * </pre>
   */
  String value() default "";
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
