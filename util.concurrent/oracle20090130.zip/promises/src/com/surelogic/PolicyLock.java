package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares a new policy lock in the annotated class. Creates a new named lock
 * represented a particular lock object.
 * 
 * <P>
 * To declare more than one policy lock for a class use the {@link PolicyLocks}
 * annotation. It is an error for a class to have both a {@code PolicyLocks} and
 * a {@code PolicyLock} annotation.
 * 
 * <p>
 * The named lock is a Java object If the object's type implements
 * {@code java.util.concurrent.locks.Lock} then the lock object must be used
 * according to the protocol of the {@code Lock} interface. Otherwise, the
 * object must be used as a Java intrinsic lock, i.e., with {@code synchronized}
 * blocks.
 * 
 * @see RegionLock
 * @see PolicyLocks
 */
@Documented
@Target(ElementType.TYPE)
public @interface PolicyLock {
  /**
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = IDENTIFIER "is" lockExpression
   * 
   * lockExpression = simpleLockExpression / qualifiedLockExpression
   * 
   * simpleLockExpression = 
   *   "class" /              ; the Class object referenced by the "class" pseudo-field of the annotated class
   *   "this" /               ; the instance itself
   *   "this" "." IDENTIFIER  ; the object referenced by the named field
   * 
   * qualifiedLockExpression = 
   *   namedType "." "CLASS" /            ; the Class object referenced by the "class" pseudo-field of a named class
   *   namedType "." "THIS" /             ; a named enclosing instance
   *   namedType "." IDENTIFIER /         ; a named static field
   *   namedType "." THIS "." IDENTIFIER  ; a named field of an enclosing instance
   * 
   * namedType = IDENTIFIER *("." IDENTIFIER)
   * 
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
