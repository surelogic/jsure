package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares a new abstract region of state for the annotated class.  To declare
 * more than one region for a class use the {@link Regions} annotation.  It is an error
 * for a class to have both a {@code Regions} and a {@code Region} annotation.
 * 
 * @see Regions
 * @see InRegion
 * @see Aggregate
 * @see MapFields
 */
@Documented
@Target(ElementType.TYPE)
public @interface Region {
  /**
   * The value of this attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = accessModifiers IDENTIFIER ["extends" regionSpecification]
   *   
   * accessModifiers = ["public" / "protected" / "private"] [static]
   * 
   * regionSpecification = simpleRegionSpecificaion / qualifiedRegionName
   * 
   * simpleRegionSpecification = IDENTIFIER / "[" "]"  ; Region of the class being annotated
   * 
   * qualifedRegionName = 
   *   IDENTIFIER *("." IDENTIFIER) : IDENTIFER  ; Static region from the named, optionally qualified, class
   *
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   * 
   * <p>As in Java, if neither {@code public}, {@code protected}, or 
   * {@code private} is declared then the region has default visibility; if
   * {@code static} is not declared the region is an instance region.
   * 
   * <p>If no explicit "extends" clause is provided the region extends from 
   * region {@code Instance} if it is an instance region, or {@code All} if it
   * is a static region.
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
