package com.surelogic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Declares that the parameter is the named lock of another parameter.
 * For example,
 * <pre>
 *   public void method(final C p1, final &#64;IsLock("p1.Lock") Object lock) { ... }
 * </pre>
 * declares that parameter {@code lock} can be used when the lock {@code Lock}
 * for the object referenced by {@code p1} is required.  It is an error
 * if the annotated field is not {@code final}.  The parameter named in the 
 * annotation must also be {@code final}.   
 * 
 * <p><em>Analysis does not currently make use of this annotation.</em>
 */
@Documented
@Target(ElementType.PARAMETER)
public @interface IsLock {
  /**
   * The name of the lock represented by the parameter. The value of this
   * attribute must conform to the following grammar (in 
   * <a href="http://www.ietf.org/rfc/rfc4234.txt">Augmented Backus&ndash;Naur
   * Form</a>):
   * <pre>
   * value = simpleLockSpecification
   * 
   * simpleLockSpecification = simpleLockName ["." ("readLock" / "writeLock")]
   * 
   * simpleLockName = IDENTIFIER  ; Lock from the receiver (same as "this:IDENTIFIER")
   * 
   * IDENTIFIER = Legal Java Identifier
   * </pre>
   */
  String value();
  
  /**
   * When {@code true}, indicates that this annotation has priority over any
   * annotations that apply to the same node that originate from scoped promises.
   */
  boolean override() default true;
}
