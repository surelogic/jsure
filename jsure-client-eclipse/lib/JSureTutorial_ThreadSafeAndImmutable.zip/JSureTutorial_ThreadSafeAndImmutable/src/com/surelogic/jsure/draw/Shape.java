package com.surelogic.jsure.draw;

import java.util.List;

public interface Shape {

	/**
	 * Gets the bounds of this shape.
	 * 
	 * @return a list containing four points: top-left point, top-right point,
	 *         bottom-right point, and bottom-left point.
	 * 
	 * @throws IllegalArgumentException
	 *             if something goes wrong.
	 */
	List<Point> getBounds();

	/**
	 * Gets the outline of this shape.
	 * 
	 * @return the outline of this shape, which should include at least three
	 *         points.
	 * 
	 * @throws IllegalArgumentException
	 *             if something goes wrong.
	 */
	List<Point> getOutline();
}
