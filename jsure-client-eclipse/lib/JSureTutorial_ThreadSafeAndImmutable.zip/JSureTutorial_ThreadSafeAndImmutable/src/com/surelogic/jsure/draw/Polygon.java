package com.surelogic.jsure.draw;

import java.util.ArrayList;
import java.util.List;

public class Polygon implements Shape {

	public Polygon() {
		// callers use add to add points
	}

	private final Object lock = new Object();

	private final List<Point> outline = new ArrayList<Point>();

	public void add(Point value) {
		if (value != null) {
			synchronized (lock) {
				outline.add(value);
			}
		}
	}

	public List<Point> getBounds() {
		synchronized (lock) {
			if (outline.size() < 3)
				throw new IllegalArgumentException();
			Point top = null, bottom = null, right = null, left = null;
			boolean first = true;
			for (Point p : outline) {
				if (first) {
					top = bottom = right = left = p;
				} else {
					if (p.x < left.x)
						left = p;
					if (p.x > right.x)
						right = p;
					if (p.y < bottom.y)
						bottom = p;
					if (p.y > top.y)
						top = p;
				}
			}
			final ArrayList<Point> result = new ArrayList<Point>();
			result.add(Point.getInstance(left.getX(), top.getY()));
			result.add(Point.getInstance(right.getX(), top.getY()));
			result.add(Point.getInstance(right.getX(), bottom.getY()));
			result.add(Point.getInstance(left.getX(), bottom.getY()));
			return result;
		}
	}

	public List<Point> getOutline() {
		synchronized (lock) {
			if (outline.size() < 3)
				throw new IllegalArgumentException();
			return new ArrayList<Point>(outline);
		}
	}
}
