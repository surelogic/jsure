package graphics;

import com.surelogic.NonNull;

public class Rectangle {
  private @NonNull Point topLeft;
  private @NonNull Point bottomRight;
  
  private int perimeter;
  
  
  
  /**
   * Caller responsibility to insure that the points really are
   * top-left and bottom-right.  Origin (0, 0) is the top-left corner
   * of the canvas.
   */
  private Rectangle(Point topLeft, Point bottomRight) {
    this.topLeft = topLeft;
    this.bottomRight = bottomRight;
    computePerimeter();
  }
  
  /**
   * Copy constructor.
   */
  public Rectangle(Rectangle other) {
    copyFrom(other);
  }
  
  
  
  /**
   * Factory method that insures the top-left, bottom-right invariant
   * is maintained.
   */
  public static Rectangle create(Point p1, Point p2) {
    int x1 = p1.getX();
    int x2 = p2.getX();
    int y1 = p1.getY();
    int y2 = p2.getY();
    
    int left;
    int right;
    if (x1 < x2) {
      left = x1;
      right = x2;
    } else {
      left = x2;
      right = x1;
    }
    
    int top;
    int bottom;
    if (y1 < y2) {
      top = y1;
      bottom = y2;
    } else {
      top = y2;
      bottom = y1;
    }
    
    return new Rectangle(new Point(left, top), new Point(right, bottom));
  }
  
  
  
  public void copyFrom(Rectangle other) {
    topLeft = other.topLeft;
    bottomRight = other.bottomRight;
    perimeter = other.perimeter;
  }
  
  public void translate(int dx, int dy) {
    topLeft = topLeft.translate(dx, dy);
    bottomRight = bottomRight.translate(dx, dy);
  }
  
  public void stretch(int dw, int dh) {
    bottomRight = bottomRight.translate(dw, dh);
    computePerimeter();
  }
  
  public void setTopleft(Point newCorner) {
    if (!newCorner.isAboveLeftOf(bottomRight)) {
      throw new IllegalArgumentException();
    }
    topLeft = newCorner;
    computePerimeter();
  }
  
  public void setBottomRight(Point newCorner) {
    if (!topLeft.isAboveLeftOf(newCorner)) {
      throw new IllegalArgumentException();
    }
    bottomRight = newCorner;
    computePerimeter();
  }
  
  private void computePerimeter() {
    int width = bottomRight.getX() - topLeft.getX();
    int height = bottomRight.getY() - topLeft.getY();
    perimeter = (width + height) << 1;
  }
  
  
  
  public Point getTopLeft() {
    return topLeft;
  }

  public Point getBottomRight() {
    return bottomRight;
  }

  public int getPerimeter() {
    return perimeter;
  }
}

