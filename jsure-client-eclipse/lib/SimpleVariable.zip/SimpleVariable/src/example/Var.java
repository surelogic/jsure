package example;

import com.surelogic.RegionEffects;

public class Var {
  private int value = 0;
  
  @RegionEffects("writes this:Instance")
  public void set(final int v) {
    value = v;
  }
  
  @RegionEffects("reads this:Instance")
  public int get() {
    return value;
  }
  
  public int getAndSet(final int v) {
    final int old = value;
    value = v;
    return old;
  }
  
  public void swap(final Var other) {
    final int otherVal = other.getAndSet(this.value);
    this.set(otherVal);
  }
}
