package unique;

import com.surelogic.Borrowed;

public class Util {
  public static int sum(@Borrowed final int[] array) {
    int sum = 0;
    for (final int v : array) {
      sum += v;
    }
    return sum;
  }
  
  public static int nonBorrowedSum(final int[] array) {
    int sum = 0;
    for (final int v : array) {
      sum += v;
    }
    return sum;
  }
}
