package com.surelogic.unique;

import com.surelogic.Unique;

public class EffectsAndUniqueness {
	@Unique
	private int[] values;

	public EffectsAndUniqueness(final int[] input) {
		values = new int[input.length];
		for (int i = 0; i < input.length; i++) {
			values[i] = input[i];
		}
	}

	public int doStuff1() {
		return Util.sum(values);
	}

	// Not only a problem with borrowed parameters
	public int doStuff2() {
		int sum;
		// Need try-catch to ensure that we restore values to a defined value.
		try {
			sum = Util.nonBorrowedSum(values);
			return sum;
		} finally {
			values = new int[0];
		}
	}
}
