package com.surelogic.advanced;

import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.RegionEffects;

/* Declare a new public static abstract region S */
@Region("public static S")
public class StaticState {
	/* Declare that the field is a subregion of the abstract region S */
	@InRegion("S")
	public static int staticField = 1;

	@RegionEffects("reads S")
	public static int getStaticField() {
		return staticField;
	}

	@RegionEffects("reads Static")
	public static int getStaticFieldAnotherWay() {
		return staticField;
	}
}