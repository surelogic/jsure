package com.surelogic.advanced;

import com.surelogic.Borrowed;
import com.surelogic.RegionEffects;
import com.surelogic.Unique;

public class UndoableAdvancedVar extends AdvancedVar {
	/* This field is implicitly a subregion of Instance */
	private int lastValue = 0;

	@RegionEffects("none")
	@Unique("return")
	public UndoableAdvancedVar(final int v) {
		super(v);
	}

	/*
	 * The declared effects can be no greater than the declared effects of the
	 * overridden method. But because we have added an additional field to the
	 * Instance region, we can modify it too.
	 */
	@RegionEffects("writes Instance")
	@Borrowed("this")
	public void set(final int v) {
		lastValue = value;
		value = v;
	}

	/*
	 * This is a new method not present in the super class so it may be freely
	 * annotated.
	 */
	@RegionEffects("writes Instance")
	@Borrowed("this")
	public void undo() {
		final int temp = value;
		value = lastValue;
		lastValue = temp;
	}
}
