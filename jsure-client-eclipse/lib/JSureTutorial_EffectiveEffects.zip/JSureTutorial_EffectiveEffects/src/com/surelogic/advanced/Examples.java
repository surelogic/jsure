package com.surelogic.advanced;

import com.surelogic.RegionEffects;
import com.surelogic.Unique;

@SuppressWarnings("unused")
public class Examples {
	public static int staticField = 0;

	public int i;

	private AdvancedVar var;

	@Unique
	private AdvancedVar uniqueVar;

	private int[] array;

	@Unique
	private final int[] uniqueArray = new int[10];

	@RegionEffects("none")
	public Examples() {
		super();
	}

	/*
	 * Effects on primitive types are not reported. So we don't care that 'a'
	 * and 'b' are used, but we do report that the field 'i' of the receiver is
	 * affected. Furthermore, 'i' is a public field, so we can explicit mention
	 * it in the annotation on a public method.
	 */
	@RegionEffects("reads i")
	public int m1(int a, int b) {
		return a * (this.i + b);
	}

	/*
	 * Effects on newly created objects are not interesting to the caller of the
	 * method, and do not need to be reported.
	 */
	@RegionEffects("reads inVar:Instance")
	public static AdvancedVar m2(final AdvancedVar inVar, final int delta) {
		final AdvancedVar outVar = new AdvancedVar(inVar.get());
		outVar.inc(delta);
		return outVar;
	}

	/*
	 * Declaring both read and write clauses. The object referenced by
	 * 'this.var' is unknown to the caller, so we have to declare that the
	 * method could write the 'Instance' region of any Var object.
	 */
	@RegionEffects("reads Instance; writes any(AdvancedVar):Instance")
	public void m3(final int delta) {
		this.var.inc(delta);
	}

	/*
	 * Looks like the above, but the in this case the field 'uniqueVar' is
	 * annotated with @Unique: the field is known declared to (and separately
	 * assured to) be the only field that refers to the object that it
	 * references. In this case, the state of the referenced Var object is
	 * considered to be part of the 'uniqueVar' field itself. So writing to the
	 * Var object via the inc() method creates the effect
	 * "writes this:uniqueVar".
	 * 
	 * Also, in this case we can use a private field in the annotation because
	 * the method is declared to be private.
	 */
	@RegionEffects("writes this:uniqueVar")
	private void m4(final int delta) {
		this.uniqueVar.inc(delta);
	}

	/*
	 * Arrays are objects, and accessing their elements is like accessing the
	 * fields of objects. Like m5(), we have to declare that we don't know which
	 * object is being modified by the method.
	 * 
	 * Also, it doesn't matter whether the "writes" or "reads" clause comes
	 * first.
	 */
	@RegionEffects("writes any(java.lang.Object):Instance; reads Instance")
	public void m5(final int v) {
		for (int i = 0; i < array.length; i++) {
			array[i] = v;
		}
	}

	/*
	 * The array is uniquely referenced, and thus aggregated. In this case, the
	 * field 'uniqueArray' is final, so the regions of the array object are
	 * aggregated directly into the 'Instance' region of the receiver.
	 */
	@RegionEffects("writes Instance")
	public void m6(final int v) {
		for (int i = 0; i < uniqueArray.length; i++) {
			uniqueArray[i] = v;
		}
	}

	/*
	 * Effects on static fields must also be declared. This method affects two
	 * static fields, the field 'staticField' of the class Examples, and the
	 * field 'staticField' of the class StaticState. Both have the same name,
	 * but are distinct regions in the effects system.
	 */
	@RegionEffects("reads staticField, com.surelogic.advanced.StaticState:staticField")
	public static int m7() {
		return staticField + StaticState.staticField;
	}

	/*
	 * Like the above, but with a different annotation. The field 'staticField'
	 * in the class StaticState, is declared to be a subregion of the abstract
	 * region 'S'. So we can make a more general effect declaration.
	 */
	@RegionEffects("reads staticField, com.surelogic.advanced.StaticState:S")
	public static int m8() {
		return staticField + StaticState.staticField;
	}

	/*
	 * Like the above, but with a different annotation. The field 'staticField'
	 * in the class StaticState, is defined to be within the predefined 'Static'
	 * region. So we can make a more general effect declaration.
	 */
	@RegionEffects("reads staticField, com.surelogic.advanced.StaticState:Static")
	public static int m9() {
		return staticField + StaticState.staticField;
	}

	protected class Inner {
		private int vv;

		@RegionEffects("none")
		public Inner(int v) {
			this.vv = v;
		}

		/*
		 * Effects on outer objects (referenced by qualified receivers) must be
		 * declared.
		 */
		@RegionEffects("reads com.surelogic.advanced.Examples.this:i, this:Instance")
		public int sum() {
			return Examples.this.i + this.vv;
		}
	}

	/*
	 * Although methods can be specific in describing their effects on outer
	 * objects, it is hard to make use of these effects at the call site. Here
	 * we have to declare that this method may read from any Example object
	 * because given a reference to an object that is an instance of a nested
	 * class, we have no way to know what are the outer objects of the instance.
	 * We do not have to report the effect on the instance of Inner because that
	 * object is known to be created local to the annotated method.
	 * 
	 * This lack of precision hasn't been a problem yet. If it becomes one, it
	 * is possible to use a local data flow analysis to sometimes recover some
	 * of the outer object information. For example, in this case, it is not
	 * difficult to use flow analysis to discover that 'i' refers to an object
	 * created by the expression "e. new Inner(0)", then recursively discover
	 * that 'e' originates from "new Examples()", and deduce that the
	 * "Examples.this" argument of the sum() method is really the object
	 * returned by "new Examples()". In this case, we would also ignore any
	 * effects on this locally created object.
	 */
	@RegionEffects("reads any(com.surelogic.advanced.Examples):i")
	public static int useInnerClass() {
		Examples e = new Examples();
		Inner i = e.new Inner(0);
		return i.sum();
	}
}
