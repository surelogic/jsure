package com.surelogic.advanced;

import com.surelogic.Borrowed;
import com.surelogic.RegionEffects;
import com.surelogic.Unique;

/* Basically like SimpleVariable, so nothing new to say here. */
public class AdvancedVar {
	protected int value;

	@RegionEffects("none")
	@Unique("return")
	public AdvancedVar(final int v) {
		value = v;
	}

	@RegionEffects("reads Instance")
	@Borrowed("this")
	public int get() {
		return value;
	}

	@RegionEffects("writes Instance")
	@Borrowed("this")
	public void set(final int v) {
		value = v;
	}

	@RegionEffects("writes Instance")
	@Borrowed("this")
	public void inc(final int v) {
		set(value + v);
	}
}
