package com.surelogic.jsure.planetbaron.server;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.surelogic.PolicyLock;
import com.surelogic.PolicyLocks;
import com.surelogic.jsure.planetbaron.util.ConciseFormatter;

/**
 * Marshals going from one turn in the game to the next, a cyclic barrier. All
 * client handler threads that are playing the game register with this class by
 * calling <code>incrementPlayerCount()</code>. Threads then call
 * <code>awaitNextTurn()</code> to block until all players are ready for the
 * next turn (waiting at the barrier).
 * <p>
 * Pattern extracted from Doug Lea's
 * <code>java.util.concurrent.CyclicBarrier</code> (which does not support
 * changing the number of parties waiting at the barrier dynamically).
 * 
 * @author T.J. Halloran
 * @see java.util.concurrent.CyclicBarrier
 */
@PolicyLocks({ @PolicyLock("BarrierLock is f_barrierLock"),
		@PolicyLock("AwaitLock is f_awaitLock") })
public final class TurnCyclicBarrier extends Thread {

	private static final Logger LOG = ConciseFormatter.getLogger("server");

	/**
	 * Creates a new <tt>TurnCyclicBarrier</tt> that will trip when the number
	 * of parties (threads) are waiting upon it, and which will execute the
	 * given barrier action when the barrier is tripped, performed by the last
	 * thread entering the barrier.
	 * 
	 * @param barrierAction
	 *            the command to execute when the barrier is tripped, or
	 *            <code>null</code> if there is no action.
	 */
	public TurnCyclicBarrier(Runnable barrierAction) {
		f_barrierAction = barrierAction;
	}

	private volatile boolean f_shutdownRequested = false;

	private final Object f_barrierLock = new Object();

	private final Object f_awaitLock = new Object();

	/**
	 * The total number of players registered with the barrier.
	 */
	private volatile int f_playerCount = 0;

	/**
	 * The number of players currently waiting at the barrier.
	 */
	private volatile int f_atTurnCyclicBarrierCount = 0;

	/**
	 * An optional action
	 */
	private final Runnable f_barrierAction;

	/**
	 * A separate thread of execution to manage the barrier.
	 */
	@Override
	public void run() {
		while (true) {
			synchronized (f_awaitLock) {
				try {
					/*
					 * Check before we wait that we have any client handler
					 * threads still working on the current turn.
					 */
					if (f_playerCount == 0
							|| f_atTurnCyclicBarrierCount < f_playerCount) {
						f_awaitLock.wait();
					}
				} catch (InterruptedException e) {
					LOG.log(Level.INFO,
							"strange interrupt waiting at the Turn barrier", e);
				}
			}
			if (f_shutdownRequested) {
				return; // bail out...the server is shutting down
			}
			synchronized (f_barrierLock) {
				if (f_playerCount > 0
						&& f_atTurnCyclicBarrierCount >= f_playerCount) {
					// output a warning if ">" had to be used (indicates a bug)
					if (f_atTurnCyclicBarrierCount > f_playerCount) {
						if (!f_shutdownRequested) { // normal during a barrier
													// shutdown
							LOG.log(Level.WARNING, "(atTurnCyclicBarrierCount="
									+ f_atTurnCyclicBarrierCount
									+ ") > (playerCount'" + f_playerCount
									+ ") in "
									+ "Turn.run()...please file a bug report");
						}
					}
					// all active players are ready for the next turn
					if (f_barrierAction != null)
						f_barrierAction.run();
					// reset our barrier counter
					f_atTurnCyclicBarrierCount = 0;
					f_barrierLock.notifyAll(); // wake up all the client
												// handlers
				}
			}
		}
	}

	/**
	 * Indicates a new client handler thread is playing. Should be called when a
	 * "connect" is successful.
	 */
	public void incrementPlayerCount() {
		synchronized (f_barrierLock) {
			synchronized (f_awaitLock) {
				f_playerCount++;
				f_awaitLock.notify();
			}
		}
	}

	/**
	 * Indicates a client handler thread which was playing has stopped. Should
	 * be called when a "disconnect"
	 */
	public void decrementPlayerCount() {
		synchronized (f_barrierLock) {
			synchronized (f_awaitLock) {
				f_playerCount--;
				f_awaitLock.notify();
			}
		}
	}

	/**
	 * Called by client handler threads when their player is ready to go on to
	 * the next turn. This will block until every player is awaiting the next
	 * turn.
	 */
	public void awaitNextTurn() {
		synchronized (f_barrierLock) {
			synchronized (f_awaitLock) {
				f_atTurnCyclicBarrierCount++;
				f_awaitLock.notify();
			}
			try {
				f_barrierLock.wait();
			} catch (InterruptedException e) {
				/*
				 * Ignore this exception. We interrupt the thread (client
				 * handlers call this method) when a shutdown is requested. This
				 * avoids delaying the shutdown until the end of a turn.
				 */
			}
		}
	}

	/**
	 * Causes this thread to die as quickly as possible (if it has not already).
	 * The method does not wait for the death to occur it simply notes the
	 * request (which will be processed) and returns. This method also removes
	 * the barrier from the static list associated with the class.
	 */
	public void shutdown() {
		f_shutdownRequested = true;
		synchronized (f_barrierLock) {
			synchronized (f_awaitLock) {
				f_awaitLock.notify(); // wake up Turn thread!
			}
		}
	}
}
