package com.surelogic.jsure.planetbaron.server;

import java.util.LinkedList;
import java.util.List;

import com.surelogic.PolicyLock;
import com.surelogic.jsure.planetbaron.game.*;
import com.surelogic.jsure.planetbaron.protocol.*;
import com.surelogic.jsure.planetbaron.util.Common;

@PolicyLock("OneAtATime is CommandVisitor.class")
public final class CommandVisitor extends ASTVisitorWithResult<ServerResponse> {

	private final ClientHandler f_chThread;

	public CommandVisitor(ServerResponse defaultResponse,
			ClientHandler clientHandlerThread) {
		super(defaultResponse);
		assert clientHandlerThread != null;
		f_chThread = clientHandlerThread;
	}

	@Override
	public void endVisit(Go node) {
		if (!f_chThread.hasAssociatedPlayer()) {
			setResult(new ProtocolError("not playing"));
		} else {
			/*
			 * Wait for other players
			 */
			Server.getInstance().getBarrier().awaitNextTurn();

			List<Report> reports = new LinkedList<Report>();
			for (Planet p : GameMap.getInstance().getPlanets()) {
				if (p.isSendingReport()) {
					reports.add(new PlanetReport(p));
				}
			}
			for (Ship s : GameMap.getInstance().getShips()) {
				if (s.isSendingReport()) {
					reports.add(new ShipReport(s));
				}
			}
			setResult(new GameStateUpdate(reports));
		}
	}

	@Override
	public void endVisit(Ls node) {
		StringBuilder output = new StringBuilder();
		output.append(String.format("C%19s | %10s | %10s | %10s" + Common.NL,
				"SHIP NAME", "LOCATION", "MOVING TO", "% MOVED"));
		output.append("---------------------+------------+---"
				+ "---------+-----------" + Common.NL);
		for (Ship s : GameMap.getInstance().getShips()) {
			String from = "";
			String togo = "";
			if (s.isMoving()) {
				from = s.getDestination().toString();
				togo = String.format("%.2f", s.getPercentageMoved());

			}
			output.append(String.format(
					"%20s | %10s | %10s | %10s" + Common.NL, s.getName(), s
							.getLocation().toString(), from, togo));
		}
		setResult(new ConsoleOnly(output.toString()));
	}

	@Override
	public void endVisit(Lt node) {
		StringBuilder output = new StringBuilder();
		List<ClientHandler> chl = Server.getInstance().getClientHandlerList();
		output.append(String.format("C%10s | %20s | %10s" + Common.NL,
				"THREAD ID", "PLAYER NAME", "STATE"));
		output.append("------------+----------------------+-----------"
				+ Common.NL);
		for (ClientHandler ch : chl) {
			output.append(String.format(
					"%s%10d | %20s | %10s" + Common.NL,
					(f_chThread == ch ? "*" : " "),
					ch.getId(),
					ch.getAssociatedPlayerName(),
					(ch.isAlive() ? (ch.getAssociatedPlayerName().length() == 0 ? "connected"
							: "playing")
							: "dead")));
		}
		setResult(new ConsoleOnly(output.toString()));
	}

	@Override
	public void endVisit(MoveShip node) {
		if (!f_chThread.hasAssociatedPlayer()) {
			setResult(new ProtocolError("not playing"));
		} else {
			Location destination = node.getDestination();
			Player p = GameMap.getInstance().getPlayer(node.getName());
			Ship s = GameMap.getInstance().getShip(p);
			if (s != null) {
				if (s.getLocation().equals(destination)) {
					setResult(new ProtocolError("unable to execute command \""
							+ node + "\" because \"" + s.getName()
							+ "\" is already at " + s.getLocation()));
				}
				s.moveTo(destination);
				setResult(new Ok());
			}
		}
	}

	@Override
	public void endVisit(Play node) {
		if (f_chThread.hasAssociatedPlayer()) {
			setResult(new ProtocolError("already playing"));
		} else {
			/*
			 * It is important to allow only one connection at a time as the
			 * check if a player is already associated to a thread and
			 * connecting it to that thread must be atomic. Otherwise a race
			 * between two new threads trying to connect to the same player
			 * could occur.
			 */
			synchronized (CommandVisitor.class) { // one at a time please
				Player associatedPlayer;
				if (GameMap.getInstance().isPlayer(node.getPlayerName())) {
					associatedPlayer = GameMap.getInstance().getPlayer(
							node.getPlayerName());
				} else {
					associatedPlayer = GameMap.getInstance().createPlayer(
							node.getPlayerName());
				}
				// check if this player is already connected to a client
				for (ClientHandler ch : Server.getInstance()
						.getClientHandlerList()) {
					if (ch.getAssociatedPlayer() == associatedPlayer) {
						setResult(new ProtocolError("player identity in use"));
						return;
					}
				}
				f_chThread.setAssociatedPlayer(associatedPlayer);
				// ensure that the player has a ship
				if (!GameMap.getInstance().isShip(associatedPlayer)) {
					GameMap.getInstance().createShip(associatedPlayer,
							Location.getRandomInstance());
				}
				// build response
				List<Report> reports = new LinkedList<Report>();
				reports.add(new MapSizeReport(GameMap.getInstance().getWidth(),
						GameMap.getInstance().getHeight()));
				reports.add(new ShipVelocityReport(Common.SHIP_VELOCITY_mSQ));
				for (Planet p : GameMap.getInstance().getPlanets()) {
					reports.add(new PlanetReport(p));
				}
				for (Ship s : GameMap.getInstance().getShips()) {
					reports.add(new ShipReport(s));
				}
				setResult(new GameStateUpdate(reports));
			}
		}
	}

	@Override
	public void endVisit(Quit node) {
		f_chThread.requestShutdown();
		setResult(new OkNoResponse());
	}

	@Override
	public void endVisit(Shutdown node) {
		// signals the server to begin an orderly shutdown
		Server.getInstance().requestShutdown();
		setResult(new OkNoResponse());
	}
}
