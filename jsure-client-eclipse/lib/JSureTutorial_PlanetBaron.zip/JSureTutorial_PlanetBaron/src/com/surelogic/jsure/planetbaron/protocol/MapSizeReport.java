package com.surelogic.jsure.planetbaron.protocol;

public final class MapSizeReport extends Report {

	private final int f_width;

	private final int f_height;

	public MapSizeReport(int width, int height) {
		f_width = width;
		f_height = height;
	}

	public int getWidth() {
		return f_width;
	}

	public int getHeight() {
		return f_height;
	}

	@Override
	public void accept(ASTVisitor v) {
		v.preVisit(this);
		v.visit(this);
		v.endVisit(this);
		v.postVisit(this);
	}

	@Override
	public String toString() {
		return "map size " + f_width + "x" + f_height;
	}
}
