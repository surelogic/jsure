package com.surelogic.jsure.planetbaron.protocol;

/**
 * A visitor for abstract syntax trees which stores a result.
 * 
 * @param <T>
 *            the type of the visitor's result.
 */
public abstract class ASTVisitorWithResult<T> extends ASTVisitor {

	private T f_result;

	/**
	 * Constructs an instance of the visitor.
	 * 
	 * @param defaultValue
	 *            a default or initial value for the visitor's result.
	 */
	public ASTVisitorWithResult(T defaultValue) {
		f_result = defaultValue;
	}

	/**
	 * Returns the result of this visitor.
	 * 
	 * @return the visitor's result.
	 */
	public final T getResult() {
		return f_result;
	}

	/**
	 * Sets the result of this visitor.
	 * 
	 * @param value
	 *            the visitor's result.
	 */
	public final void setResult(T value) {
		f_result = value;
	}
}
