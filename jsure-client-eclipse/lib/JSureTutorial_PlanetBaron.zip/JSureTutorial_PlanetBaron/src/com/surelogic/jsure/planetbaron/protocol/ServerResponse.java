package com.surelogic.jsure.planetbaron.protocol;

public abstract class ServerResponse extends ASTNode {
}
