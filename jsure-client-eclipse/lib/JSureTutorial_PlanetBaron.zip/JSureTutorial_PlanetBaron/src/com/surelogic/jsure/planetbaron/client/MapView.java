package com.surelogic.jsure.planetbaron.client;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JComponent;

import com.surelogic.Assume;
import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.RegionLock;
import com.surelogic.RegionLocks;
import com.surelogic.Regions;
import com.surelogic.RequiresLock;
import com.surelogic.Unique;
import com.surelogic.jsure.planetbaron.game.EndOfTurnObserver;
import com.surelogic.jsure.planetbaron.game.GameMap;
import com.surelogic.jsure.planetbaron.game.Location;
import com.surelogic.jsure.planetbaron.game.Planet;
import com.surelogic.jsure.planetbaron.game.Player;
import com.surelogic.jsure.planetbaron.game.Ship;
import com.surelogic.jsure.planetbaron.util.Common;

/**
 * This is a visual component that draws the player map (the upper-left panel
 * within the player user interface). It also accepts input from the player in
 * the form of mouse movement and clicks.
 * 
 * @author T.J. Halloran
 */
@Regions({ @Region("private CursorLocationState"),
		@Region("private PlayerProxyState") })
@RegionLocks({
		@RegionLock("CursorLocationState is m_cursorLocationLock protects CursorLocationState"),
		@RegionLock("PlayerProxyLock is m_playerProxyTargetLock protects PlayerProxyState") })
public final class MapView extends JComponent implements MouseListener,
		MouseMotionListener, EndOfTurnObserver {

	private static final long serialVersionUID = 3258413945475118128L;

	private static final Color GRID_COLOR = new Color(0, 50, 0);

	private static final Color MOVEMENT_TRAIL_COLOR = new Color(50, 50, 0);

	private static final int BORDER = 5;

	private static final int SQUARE_SIZE = 40;

	private int m_mapHeight = Common.LOGICAL_MAP_HEIGHT * SQUARE_SIZE;

	private int m_mapWidth = Common.LOGICAL_MAP_WIDTH * SQUARE_SIZE;

	/**
	 * The current location of the box cursor. Requires a lock on
	 * m_cursorLocationLock.
	 */
	@InRegion("CursorLocationState")
	private Location m_cursorLocation = null;

	/**
	 * Used to avoid lots of reports if the user moves the mouse pointer around
	 * within one single map location. Requires a lock on m_cursorLocationLock.
	 * 
	 * @see #mouseMoved(MouseEvent)
	 */
	@InRegion("CursorLocationState")
	private Location m_lastReportedLocation = null;

	/**
	 * Protects access to m_cursorLocation and m_lastReportedLocation
	 */
	private final Object m_cursorLocationLock = new Object();

	/**
	 * Constructs a new instance of this component.
	 */
	public static MapView getInstance() {
		final MapView result = new MapView();
		result.setDoubleBuffered(true);
		result.setOpaque(true);
		result.addMouseListener(result);
		result.addMouseMotionListener(result);
		GameMap.getInstance().register(result);
		return result;
	}

	@Unique("return")
	@Assume("@Unique(return) for new() in JComponent")
	private MapView() {
	}

	/**
	 * Callback interface to monitor logical map location cursor movements.
	 * 
	 * @see MapView#registerCursorListener(CursorListener)
	 */
	public interface CursorListener {
		void cursorMoved(Location l);
	}

	/**
	 * Set of cursor listeners registered with this map.
	 */
	private Set<CursorListener> cursorListenerSet = new HashSet<CursorListener>();

	/**
	 * Utility method to notify cursor listeners the cursor location has
	 * changed.
	 * 
	 * @param l
	 *            the new location of the cursor
	 */
	private void notifyCursorListeners(Location l) {
		for (CursorListener cursorListener : cursorListenerSet) {
			cursorListener.cursorMoved(l);
		}
	}

	/**
	 * Registers an object to be called back by this map each time the player
	 * moves the logical map location cursor. As the player slides the mouse
	 * around the map the location of the cursor square moves. The callback
	 * registered via this method informs an object of those changes.
	 * 
	 * @param cursorListener
	 *            the object to callback when the logical cursor moves
	 */
	public void registerCursorListener(CursorListener cursorListener) {
		if (cursorListener == null)
			throw new IllegalArgumentException(
					"a cursor listener cannot be null");
		cursorListenerSet.add(cursorListener);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		final int height = getHeight();
		final int width = getWidth();

		// fill the entire component with black
		g.setColor(Color.black);
		g.fillRect(0, 0, width, height);

		drawGridOutline(g);

		for (Ship s : GameMap.getInstance().getShips()) {
			synchronized (s) {
				drawShipMovementTrail(g, s);
			}
		}
		for (Planet p : GameMap.getInstance().getPlanets()) {
			synchronized (p) {
				drawPlanet(g, p);
			}
		}
		drawCursor(g);
		for (Ship s : GameMap.getInstance().getShips()) {
			synchronized (s) {
				drawShip(g, s);
			}
		}
	}

	private void drawGridOutline(Graphics g) {
		g.setColor(GRID_COLOR);
		g.drawRect(BORDER, BORDER, m_mapWidth, m_mapHeight);
		for (int logicalColumn = 1; logicalColumn < Common.LOGICAL_MAP_WIDTH; logicalColumn++) {
			g.drawLine(BORDER + logicalColumn * SQUARE_SIZE, BORDER, BORDER
					+ logicalColumn * SQUARE_SIZE, m_mapHeight + BORDER);
		}
		for (int logicalRow = 1; logicalRow < Common.LOGICAL_MAP_HEIGHT; logicalRow++) {
			g.drawLine(BORDER, BORDER + logicalRow * SQUARE_SIZE, m_mapWidth
					+ BORDER, BORDER + logicalRow * SQUARE_SIZE);

		}
	}

	private void drawCursor(Graphics g) {
		int x;
		int y;
		synchronized (m_cursorLocationLock) {
			if (m_cursorLocation == null) {
				return;
			} else {
				x = m_cursorLocation.getX();
				y = m_cursorLocation.getY();
			}
		}
		g.setColor(Color.white);
		x = BORDER + ((x - 1) * SQUARE_SIZE) + 1;
		y = BORDER + ((y - 1) * SQUARE_SIZE) + 1;
		g.drawRect(x, y, SQUARE_SIZE - 2, SQUARE_SIZE - 2);
	}

	@RequiresLock("p:ThingLock.readLock()")
	private void drawPlanet(Graphics g, final Planet p) {
		int x = p.getLocation().getX();
		int y = p.getLocation().getY();
		Player owner = p.getOwner();
		x = BORDER + ((x - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2 - 16);
		y = BORDER + ((y - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2 - 16);

		Image planet;
		if (owner == null) {
			// nobody controls the planet
			planet = PlayerUI.m_planet1Image;
		} else {
			// assume another player controls the planet
			planet = PlayerUI.m_planet2Image;
			String ownerId = owner.getName();
			final PlayerProxy playerProxyTarget;
			synchronized (m_playerProxyTargetLock) {
				playerProxyTarget = m_playerProxyTarget;
			}
			if (playerProxyTarget != null) {
				if (playerProxyTarget.getplayerIdentity().equals(ownerId)) {
					// this player controls the planet
					planet = PlayerUI.m_planet3Image;
				}
			}
		}
		g.drawImage(planet, x, y, this);
	}

	@RequiresLock("s:ThingLock.readLock()")
	private void drawShipMovementTrail(Graphics g, final Ship s) {
		if (s.isMoving()) {
			int x = s.getLocation().getX();
			int y = s.getLocation().getY();
			x = BORDER + ((x - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			y = BORDER + ((y - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			int xd = s.getDestination().getX();
			int yd = s.getDestination().getY();
			xd = BORDER + ((xd - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			yd = BORDER + ((yd - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			g.setColor(MOVEMENT_TRAIL_COLOR);
			g.drawLine(x, y, xd, yd);
		}
	}

	@RequiresLock("s:ThingLock.readLock()")
	private void drawShip(Graphics g, final Ship s) {
		int x = s.getLocation().getX();
		int y = s.getLocation().getY();
		if (s.isMoving()) {
			x = BORDER + ((x - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			y = BORDER + ((y - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			int xd = s.getDestination().getX();
			int yd = s.getDestination().getY();
			xd = BORDER + ((xd - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			yd = BORDER + ((yd - 1) * SQUARE_SIZE) + (SQUARE_SIZE / 2);
			double percentageMoved = s.getPercentageMoved();
			x = x + (int) ((double) (xd - x) * percentageMoved);
			y = y + (int) ((double) (yd - y) * percentageMoved);
			x = x - 8; // center the image
			y = y - 8;
		} else {
			x = BORDER + ((x - 1) * SQUARE_SIZE) + (SQUARE_SIZE - 17);
			y = BORDER + ((y - 1) * SQUARE_SIZE) + 1;
		}
		g.drawImage(PlayerUI.m_shipImage, x, y, this);
		g.setColor(Color.yellow);
		g.drawString(s.getName(), x, y - 2);
	}

	// get*Size() methods need for the layout manager

	private Dimension m_size = new Dimension(m_mapWidth + (BORDER * 2),
			m_mapHeight + (BORDER * 2));

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(m_size); // defensive copy
	}

	@Override
	public Dimension getMaximumSize() {
		return new Dimension(m_size); // defensive copy
	}

	@Override
	public Dimension getMinimumSize() {
		return new Dimension(m_size); // defensive copy
	}

	/**
	 * Translates a X pixel into a logical map location.
	 * 
	 * @param x
	 *            the pixel
	 * @return the logical map location
	 */
	private int computeLogicalX(int x) {
		int logicalX = ((x - BORDER) / SQUARE_SIZE) + 1;
		logicalX = (logicalX < 1 ? 1
				: (logicalX > Common.LOGICAL_MAP_WIDTH ? Common.LOGICAL_MAP_WIDTH
						: logicalX));
		return logicalX;
	}

	/**
	 * Translates a Y pixel into a logical map location.
	 * 
	 * @param y
	 *            the pixel
	 * @return the logical map location
	 */
	private int computeLogicalY(int y) {
		int logicalY = ((y - BORDER) / SQUARE_SIZE) + 1;
		logicalY = (logicalY < 1 ? 1
				: (logicalY > Common.LOGICAL_MAP_HEIGHT ? Common.LOGICAL_MAP_HEIGHT
						: logicalY));
		return logicalY;
	}

	/**
	 * Sets the map cursor location (the square which follows the mouse).
	 * 
	 * @param l
	 *            the new cursor location, may be <code>null</code> for none.
	 */
	private void setCursorLocation(Location l) {
		synchronized (m_cursorLocationLock) {
			m_cursorLocation = l;
			notifyCursorListeners(l);
		}
	}

	@InRegion("PlayerProxyState")
	private PlayerProxy m_playerProxyTarget = null;

	private final Object m_playerProxyTargetLock = new Object();

	/**
	 * Sets the current target of map input requests (currently only a request
	 * to move a ship).
	 * 
	 */
	public void setPlayerProxyTarget(PlayerProxy target) {
		synchronized (m_playerProxyTargetLock) {
			m_playerProxyTarget = target;
		}
	}

	/**
	 * Directs our ship to move to the specified location unless the ship is
	 * already moving in which case the command is ignored.
	 * 
	 * @param l
	 *            the map location to move our ship to.
	 */
	private void notifyPlayerProxyTargetOfMoveRequest(Location l) {
		synchronized (m_playerProxyTargetLock) {
			if (m_playerProxyTarget != null) {
				m_playerProxyTarget.moveShipTo(l);
			}
		}
	}

	// "MouseListener" callback methods (we only use two of them)

	public void mouseClicked(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			int logicalX = computeLogicalX(e.getX());
			int logicalY = computeLogicalY(e.getY());
			notifyPlayerProxyTargetOfMoveRequest(Location.getInstance(logicalX,
					logicalY));
			repaint();
		}
	}

	public void mousePressed(MouseEvent e) {
		// do nothing
	}

	public void mouseReleased(MouseEvent e) {
		// do nothing
	}

	public void mouseEntered(MouseEvent e) {
		// do nothing
	}

	public void mouseExited(MouseEvent e) {
		// do nothing
	}

	public void mouseDragged(MouseEvent e) {
		// do nothing
	}

	public void mouseMoved(MouseEvent e) {
		int logicalX = computeLogicalX(e.getX());
		int logicalY = computeLogicalY(e.getY());
		Location l = Location.getInstance(logicalX, logicalY);
		synchronized (m_cursorLocationLock) {
			boolean cursorHasMoved = m_lastReportedLocation == null
					|| !m_lastReportedLocation.equals(l);
			if (cursorHasMoved) {
				m_lastReportedLocation = l;
				setCursorLocation(l);
				repaint();
			}
		}
	}

	public void endOfTurn(GameMap map) {
		synchronized (m_cursorLocationLock) {
			/*
			 * Ensure the last reported location is not null
			 */
			if (m_lastReportedLocation != null) {
				setCursorLocation(m_lastReportedLocation);
			}
		}
	}

	/**
	 * Updates the map dimensions in response to connecting to a server.
	 * 
	 * @param h
	 *            The new height of the map in rows.
	 * @param w
	 *            The new width of the map in columns.
	 */
	public void updateMapDimensions(int h, int w) {
		m_mapHeight = h * SQUARE_SIZE;
		m_mapWidth = w * SQUARE_SIZE;
		m_size = new Dimension(m_mapWidth + (BORDER * 2), m_mapHeight
				+ (BORDER * 2));
		setSize(m_size);
	}
}
