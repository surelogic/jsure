package com.surelogic.jsure.planetbaron.server;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.surelogic.PolicyLock;
import com.surelogic.ReferenceObject;
import com.surelogic.jsure.planetbaron.game.Player;
import com.surelogic.jsure.planetbaron.protocol.*;
import com.surelogic.jsure.planetbaron.util.Common;
import com.surelogic.jsure.planetbaron.util.ConciseFormatter;

/**
 * Handles network communication, via a dedicated socket, with a single game
 * client.
 * <p>
 * TODO: discuss thread policy of this class (i.e., in relation to Server).
 * 
 * @author T.J. Halloran
 */
@PolicyLock("ClientHandler is this")
@ReferenceObject
public final class ClientHandler extends Thread {

	private static final Logger LOG = ConciseFormatter.getLogger("server");

	private static final String GO_COMMAND_TEXT = new Go().toString();

	/**
	 * The client connection this thread talks to.
	 */
	private final Socket f_socket;

	/**
	 * Handle to the game player the interaction with this client represents. A
	 * value of <code>null</code> means that this client handler is not yet
	 * connected to the game with an identity.
	 */
	private volatile Player f_player = null;

	/**
	 * <code>false</code> if the server is running, <code>true</code> if the
	 * server is trying to shutdown. When this field is set to <code>true</code>
	 * this thread should complete as quickly as possible and exit. This field
	 * is volatile because it is intended to set by the main thread and read
	 * from within this thread. Once this field is set to <code>true</code> it
	 * should never again be set to <code>false</code> (i.e., it is monotonic
	 * toward <code>true</code>).
	 */
	private volatile boolean f_shutdownRequested = false;

	public ClientHandler(Socket clientSocket) {
		setThreadName();
		f_socket = clientSocket;
	}

	/**
	 * Causes this client handler thread to die as quickly as possible (if it
	 * has not already). This method does not wait for the thread to die, it
	 * simply notes the request, which will be processed as soon as possible,
	 * and returns.
	 */
	public void requestShutdown() {
		f_shutdownRequested = true;
		try {
			this.interrupt(); // wake up if waiting to go to the next turn
			f_socket.close();
		} catch (IOException e) {
			LOG.log(Level.SEVERE,
					"unknown failure closing down a client handler socket", e);
		}
	}

	/**
	 * The main loop of the client handler thread. The client handler receives
	 * commands from clients and dispatches the commands to be processed.
	 */
	@Override
	public void run() {
		LOG.info("client handler thread started");
		try {
			// create input and output connections
			BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(f_socket.getInputStream()));
			BufferedWriter outputStream = new BufferedWriter(
					new OutputStreamWriter(f_socket.getOutputStream()));
			sendResponse(outputStream, Common.serverWelcomeMessage);
			while (!f_shutdownRequested) {
				String nextLine = inputStream.readLine(); // blocks
				if (nextLine == null) {
					/*
					 * This condition appears to occur when the client abruptly
					 * terminates its connection to the server (I found no
					 * documentation to support this, however). To make the
					 * server behave normally when an abrupt termination occurs,
					 * we need to "pretend" we received a quit command.
					 */
					nextLine = new Quit().toString();
				}
				// process the command
				ServerResponse result = new ProtocolError("unknown"); // default
				try {
					/*
					 * Parse the command we received from the client and process
					 * it using a visitor-based analysis (used to determine the
					 * command's semantics).
					 */
					ServerCommand sc = ProtocolFacade
							.parseServerCommand(nextLine);
					CommandVisitor a = new CommandVisitor(result, this);
					synchronized (this) { // protecting "player" use
						sc.accept(a);
						result = a.getResult();
					}
				} catch (Exception e) {
					result = new ProtocolError(e.getMessage()); // TODO:
																// multiple
																// lines
				}
				if (f_shutdownRequested)
					continue; // check if we should bail, i.e., not send a
								// response

				if (!(result instanceof OkNoResponse)) {
					sendResponse(outputStream, result.toString());
				}
				/*
				 * Log all commands, except go commands (lots of these).
				 */
				if (!nextLine.equals(GO_COMMAND_TEXT)) {
					LOG.info("\""
							+ nextLine
							+ "\" processed "
							+ result.getClass().getSimpleName()
							+ (result instanceof ProtocolError ? " ["
									+ ((ProtocolError) result).getMessage()
									+ "]" : "") + " from "
							+ getThreadGameIdentity());
				}
			}
		} catch (SocketException e) {
			// Ignore, this is normal behavior during a shutdown (i.e., another
			// thread has called socket.close() via our shutdown() method)
		} catch (IOException e) {
			LOG.log(Level.SEVERE, "general I/O failure on socket to "
					+ getThreadGameIdentity(), e);
		}
		removeAssociatedPlayer();
		LOG.info("client handler " + getThreadGameIdentity()
				+ " thread ending normally");
	}

	/**
	 * Sends the provided response String followed by a newline to the given
	 * output steam. Then {@link BufferedWriter#flush()} is called on the output
	 * steam.
	 * 
	 * @param outputStream
	 *            the stream to output to.
	 * @param response
	 *            the data to write to the stream.
	 */
	private void sendResponse(BufferedWriter outputStream, String response) {
		try {
			outputStream.write(response + "\n\r");
			outputStream.flush();
		} catch (IOException e) {
			LOG.log(Level.SEVERE, "failure sending response to "
					+ getThreadGameIdentity(), e);
		}
	}

	/**
	 * Sets the name of this thread to a meaningful name as an aid in debugging.
	 */
	private void setThreadName() {
		setName("server-" + getThreadGameIdentity());
	}

	/**
	 * Utility routine to identify the client this client handler is connected
	 * to.
	 * 
	 * @return The player identity this thread handles or the thread's unique
	 *         numeric identifier.
	 */
	public String getThreadGameIdentity() {
		synchronized (this) {
			return "ch" + getId()
					+ (f_player == null ? "" : " (" + f_player.getName() + ")");
		}
	}

	/**
	 * Sets the game player this client handler is associated with.
	 * 
	 * @param player
	 *            the game player the interaction with this client represents
	 */
	public void setAssociatedPlayer(Player player) {
		synchronized (this) {
			this.f_player = player;
			Server.getInstance().getBarrier().incrementPlayerCount();
			setThreadName();
		}
	}

	/**
	 * Returns <code>true</code> if this client handler thread has a player
	 * object associated with it, <code>false</code> otherwise.
	 * 
	 * @return <code>true</code> if this client handler thread has a player
	 *         object associated with it, <code>false</code> otherwise.
	 */
	public boolean hasAssociatedPlayer() {
		synchronized (this) {
			return this.f_player != null;
		}
	}

	/**
	 * Returns the player object associated with this client handler.
	 * 
	 * @return a reference to the player object associated with this client
	 *         handler, or <code>null</code> if none
	 */
	public Player getAssociatedPlayer() {
		/*
		 * This getter method is intended not to be synchronized on "this".
		 * During a connect command the connecting thread checks to see if the
		 * player it is trying to associate itself to is already associated with
		 * another thread. Acquiring a lock on "this" causes this connecting
		 * thread to block until the end of the turn if any thread has issued a
		 * "go" command.
		 * 
		 * To mitigate this situation the "player" field is declared volatile.
		 * And we further note that the check within in CommandConnect is a
		 * simple "==" operation.
		 */
		return f_player;
	}

	/**
	 * Used to remove the player object currently associated with this client
	 * handler thread.
	 */
	public void removeAssociatedPlayer() {
		/*
		 * Ensure setting the field to null and decrementing the player count in
		 * the TurnCyclicBarrier are atomic.
		 */
		synchronized (this) {
			if (f_player != null) {
				f_player = null;
				Server.getInstance().getBarrier().decrementPlayerCount();
			}
		}
	}

	/**
	 * Gets the player name associated with this client handler.
	 * 
	 * @return the player name associated with this client handler, or "" if
	 *         none.
	 */
	public String getAssociatedPlayerName() {
		if (f_player != null)
			return f_player.getName();
		else
			return "";
	}
}
