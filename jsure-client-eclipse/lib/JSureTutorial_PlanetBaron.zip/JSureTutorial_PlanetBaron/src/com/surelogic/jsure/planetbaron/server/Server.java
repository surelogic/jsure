package com.surelogic.jsure.planetbaron.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.surelogic.jsure.planetbaron.game.GameMap;
import com.surelogic.jsure.planetbaron.util.Common;
import com.surelogic.jsure.planetbaron.util.ConciseFormatter;

/**
 * The main program / class for the PlanetBaron game server. This class is a
 * singleton, use {@link #getInstance()} to obtain a reference.
 * <p>
 * This server listens on a port (8693 is the default) and answers requests from
 * clients (players). The server's main thread (starting from
 * {@link #main(String[])} in this class) only accepts incoming client
 * connections. Once a client has connected a new {@link ClientHandler} thread
 * is started to interact with that particular client.
 * <p>
 * Server shutdown is initiated when a "shutdown" command is received by one of
 * the {@link ClientHandler} threads. The {@link CommandVisitor} class invokes
 * {@link #requestShutdown()} to start the server shutdown process. This method,
 * which is invoked in the context of a {@link ClientHandler} thread, uses a
 * flag to signal the main thread to stop accepting connections, signal all the
 * {@link ClientHandler} threads to exit, and exit.
 * <p>
 * The socket code in this class was patterned after example code from: William
 * Grosso, <i>Java RMI </i>. O'Reilly &amp; Associates, Inc. 2002.
 * 
 * @author T.J. Halloran
 */
public final class Server {

	/**
	 * The main program of the PlanetBaron server.
	 * 
	 * @param args
	 *            operating system command line parameters passed to this
	 *            program.
	 */
	public static void main(String[] args) {
		getInstance().startListening(Common.DEFAULT_PORT);
	}

	private static final Server INSTANCE = new Server();

	/**
	 * Obtains a reference the sole <code>Server</code> object.
	 * 
	 * @return the singleton instance of this class.
	 */
	public static Server getInstance() {
		return INSTANCE;
	}

	private Server() {
		GameMap.getInstance().generateRandomGalaxy();
		Thread.currentThread().setName("server-main");
		getBarrier().setName("turn-barrier");
		getBarrier().start();
	}

	private static final Logger LOG = ConciseFormatter.getLogger("server");

	/**
	 * <code>false</code> if the server is accepting connections,
	 * <code>true</code> if the server is trying to shutdown. This field is
	 * volatile because it is intended to set in a {@link ClientHandler} thread
	 * and read by the main thread. Once this field is set to <code>true</code>
	 * it should never again be set to <code>false</code> (i.e., it is monotonic
	 * toward <code>true</code>).
	 */
	private volatile boolean f_shutdownRequested = false;

	/**
	 * The socket this game server is listening on.
	 */
	private ServerSocket f_socket;

	/**
	 * Holds the list of threads started to handle clients. Used to cleanly
	 * shutdown the server.
	 */
	private final CopyOnWriteArrayList<ClientHandler> f_clientHandlerThreadList = new CopyOnWriteArrayList<ClientHandler>();

	/**
	 * The cyclic barrier for game turns.
	 */
	private final TurnCyclicBarrier f_barrier = new TurnCyclicBarrier(
			new Runnable() {
				/**
				 * Each time the barrier action is triggered we want to advance
				 * the server's game state one turn.
				 */
				public void run() {
					GameMap.getInstance().endCurrentTurn();
				}
			});

	public TurnCyclicBarrier getBarrier() {
		return f_barrier;
	}

	/**
	 * Loops listening for client connections to this game.
	 * 
	 * @param port
	 *            port the game server listens on.
	 */
	private void startListening(int port) {
		// start listening on a port
		try {
			f_socket = new ServerSocket(port);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, "unable to listen on port " + port, e);
			System.exit(1);
		}
		LOG.info("PlanetBaron game server listening for clients on port "
				+ port + " and playing on a "
				+ GameMap.getInstance().getWidth() + "x"
				+ GameMap.getInstance().getHeight() + " map");

		// until told to shutdown, listen for and handle client connections
		while (!f_shutdownRequested) {
			try {
				Socket client = f_socket.accept(); // wait for a client
													// connection
				ClientHandler newClientHandlerThread = new ClientHandler(client);
				f_clientHandlerThreadList.add(newClientHandlerThread);
				newClientHandlerThread.start(); // start the handler thread
			} catch (SocketException e) {
				/*
				 * ignore, this is normal behavior during a shutdown, i.e.,
				 * another thread has called gameSocket.close() via our
				 * requestShutdown() method.
				 */
			} catch (IOException e) {
				LOG.log(Level.SEVERE,
						"failure listening for client connections " + port, e);
			}
		}
		// shutdown the server
		LOG.info("directing all client handler threads to exit...");
		shutdownAllClientHandlerThreads();
		getBarrier().shutdown();
		LOG.info("PlanetBaron game server shutdown complete");
	}

	/**
	 * Signals all client handler threads that they should finish up and die as
	 * quickly as possible, then waits for them to complete. This method is used
	 * during a server shutdown to ensure that all the client handler threads
	 * terminate in an orderly manner.
	 */
	private void shutdownAllClientHandlerThreads() {
		// direct all the client handlers to shutdown
		for (ClientHandler clientHandlerThread : f_clientHandlerThreadList) {
			clientHandlerThread.requestShutdown();
		}

		// check that each client handler thread has died
		for (ClientHandler clientHandlerThread : f_clientHandlerThreadList) {
			while (clientHandlerThread.isAlive()) {
				try {
					clientHandlerThread.join();
				} catch (InterruptedException e) {
					// ignore, we ensure that the thread has died in the
					// loop guard
				}
			}
		}
	}

	/**
	 * Causes the game server to shutdown. This method does not wait for the
	 * shutdown to occur, it simply notes the request, which will be processed
	 * by the main thread listening for client connections later, and returns.
	 */
	public void requestShutdown() {
		f_shutdownRequested = true;
		try {
			f_socket.close();
		} catch (IOException e) {
			LOG.log(Level.SEVERE,
					"unknown failure closing down the game server ServerSocket",
					e);
		}
	}

	/**
	 * Obtains a copy of the client handler list at the time this call was made.
	 * 
	 * @return a copy of server's client handler list.
	 */
	public List<ClientHandler> getClientHandlerList() {
		return new ArrayList<ClientHandler>(f_clientHandlerThreadList);
	}
}
