package com.surelogic.util.logging;

/**
 * This class is for demonstration purposes.
 */
public class Grumble {
    public Filter getFilter() {
	return Logger.getAnonymousLogger().filter;
    }
}
