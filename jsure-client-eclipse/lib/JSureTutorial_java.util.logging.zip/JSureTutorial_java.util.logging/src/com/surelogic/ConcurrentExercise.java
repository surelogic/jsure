package com.surelogic;

import java.util.concurrent.CountDownLatch;
import com.surelogic.util.logging.Filter;
import com.surelogic.util.logging.Level;
import com.surelogic.util.logging.LogRecord;
import com.surelogic.util.logging.Logger;

public class ConcurrentExercise {
    final static int THREADCOUNT = 6;
    final CountDownLatch latch = new CountDownLatch(THREADCOUNT);

    public static void main(String[] args) {
	ConcurrentExercise l = new ConcurrentExercise();
	for (int i = 0; i < THREADCOUNT; i++)
	    l.go();
    }

    void go() {
	Thread t = new Thread() {
	    /**
	     * We are going to get the "Foo" logger then toggle it between a
	     * value and null. After a few tries we should get:
	     * 
	     * <pre>
	     * Exception in thread "Thread-1" java.lang.NullPointerException
	     * 	at com.surelogic.util.logging.Logger.log(Logger.java:409)
	     * 	at com.surelogic.util.logging.Logger.doLog(Logger.java:445)
	     * 	at com.surelogic.util.logging.Logger.log(Logger.java:469)
	     * 	at com.surelogic.ConcurrentExercise$1.run(ConcurrentExercise.java:38)
	     * </pre>
	     */
	    @Override
	    public void run() {
		latch.countDown();
		final Logger l = Logger.getLogger("Foo");
		final Filter lf = new Filter() {
		    public boolean isLoggable(LogRecord record) {
			return true;
		    }
		};
		for (int t = 0; t < 500; t++) {
		    l.setFilter(null);
		    l.log(Level.WARNING, "This is a test");
		    l.setFilter(lf);
		    l.log(Level.WARNING, "This is a test");
		}
	    }
	};
	t.start();
    }
}
