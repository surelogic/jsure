package com.aelitis.azureus.core.drm.msdrm;

public class LicenseAquisitionException extends Exception {
	
	public LicenseAquisitionException(String message) {
		super(message);
	}

}
