package java.util.logging;

import java.util.*;

/**
 * @author wls
 */
public class Grumble {

    private SimpleFormatter sf;

    public Grumble() {
	sf = new SimpleFormatter();
    }

    public Date getDate() {
	return null;
    }

}
