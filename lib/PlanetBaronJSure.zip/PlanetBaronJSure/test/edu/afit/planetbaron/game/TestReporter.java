package edu.afit.planetbaron.game;

import junit.framework.TestCase;

public class TestReporter extends TestCase {

  public void testPlanet() {
    GameMap m = GameMap.getInstance();
    Planet p1 = m.createPlanet("p1", Location.getInstance(1, 1));
    Planet p2 = m.createPlanet("p2", Location.getInstance(2, 2));
    Player player1 = m.createPlayer("player1");
    Player player2 = m.createPlayer("player2");
    p1.setOwner(player1); // change owner
    // no report yet
    assertFalse(p1.isSendingReport());
    assertFalse(p2.isSendingReport());
    m.endCurrentTurn(); // p1 needs to report owner change
    assertTrue(p1.isSendingReport());
    assertFalse(p2.isSendingReport());
    m.endCurrentTurn();
    // no reports needed
    assertFalse(p1.isSendingReport());
    assertFalse(p2.isSendingReport());
    p1.setOwner(player1); // same owner no report
    m.endCurrentTurn();
    assertFalse(p1.isSendingReport());
    assertFalse(p2.isSendingReport());
    p1.setOwner(player2);
    p2.setOwner(player1);
    assertFalse(p1.isSendingReport());
    assertFalse(p2.isSendingReport());
    m.endCurrentTurn(); // p1 and p2 need to report owner change
    assertTrue(p1.isSendingReport());
    assertTrue(p2.isSendingReport());
  }

  public void testShip() {
    GameMap m = GameMap.getInstance();
    Player player1 = m.createPlayer("player1");
    Player player2 = m.createPlayer("player2");
    Ship s1 = m.createShip(player1, Location.getInstance(1, 1));
    Ship s2 = m.createShip(player2, Location.getInstance(5, 5));
    s1.moveTo(Location.getRandomInstance());
    // no report yet
    assertFalse(s1.isSendingReport());
    assertFalse(s2.isSendingReport());
    m.endCurrentTurn(); // p1 needs to report owner change
    assertTrue(s1.isSendingReport());
    assertFalse(s2.isSendingReport());
    m.endCurrentTurn();
    // no reports needed
    assertFalse(s1.isSendingReport());
    assertFalse(s2.isSendingReport());
    s2.moveTo(Location.getInstance(1, 1));
    while (s2.isMoving())
      m.endCurrentTurn();
    assertTrue(s2.justArrived());
    assertFalse(s1.justArrived());
  }

  protected void tearDown() throws Exception {
    GameMap.getInstance().reset();
  }
}
