package edu.afit.planetbaron.protocol;

public abstract class ServerResponse extends ASTNode {
}
