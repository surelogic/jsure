package edu.afit.planetbaron.protocol;

import edu.afit.planetbaron.game.Location;

public final class MoveShip extends ServerCommand {

  private final StringLiteral f_name;

  private final LocationLiteral f_destination;

  public MoveShip(StringLiteral name, LocationLiteral destination) {
    assert name != null && destination != null;
    f_name = name;
    f_name.setParent(this);
    f_destination = destination;
    f_destination.setParent(this);
  }

  public MoveShip(String name, Location destination) {
    this(new StringLiteral(name), new LocationLiteral(destination));
  }

  public String getName() {
    return f_name.getValue();
  }

  public Location getDestination() {
    return f_destination.getLocation();
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    if (v.visit(this)) {
      f_name.accept(v);
      f_destination.accept(v);
    }
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return "moveship " + f_name + " to " + f_destination;
  }
}
