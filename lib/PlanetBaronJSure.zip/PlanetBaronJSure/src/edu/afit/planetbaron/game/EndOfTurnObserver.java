package edu.afit.planetbaron.game;

/**
 * A class can implement the <code>EndOfTurnObserver</code> interface when it
 * wants to be informed when a turn ends for a game map. A class registers with
 * the {@link GameMap#register(EndOfTurnObserver)} method.
 * 
 * @author T.J. Halloran
 */
public interface EndOfTurnObserver {

  /**
   * Called at the end of each game turn.
   * 
   * @param map
   *          the observed game map.
   */
  void endOfTurn(GameMap map);
}
