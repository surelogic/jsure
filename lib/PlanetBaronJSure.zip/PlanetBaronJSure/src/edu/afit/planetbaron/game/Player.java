package edu.afit.planetbaron.game;

/**
 * This class represents a logical player within the game.
 * 
 * @author T.J. Halloran
 */
public final class Player extends Thing {

  /**
   * The immutable name for this player.
   */
  private final String f_name;

  /**
   * Constructs a new player. Only intended to be called from {@link GameMap}.
   * 
   * @param name
   *          the name of this player
   * @see GameMap#getPlayer(String)
   */
  Player(GameMap map, String name) {
    super(map);
    f_name = name;
  }

  /**
   * Gets this player's name.
   * 
   * @return this players name
   */
  public String getName() {
    return f_name; // immutable
  }
}