package com.surelogic.jsure.planetbaron.protocol;

import com.surelogic.jsure.planetbaron.protocol.parser.ParseException;
import com.surelogic.jsure.planetbaron.protocol.parser.ProtocolParser;

/**
 * The common interface to all protocol parsing algorithms. The context of this
 * pattern is set by the {@link ProtocolFacade#parse(String, ParseStrategy)}
 * method.
 * 
 * @author T.J. Halloran
 * 
 * @param <T>
 *            the resulting type from the parse this strategy invokes.
 */
public interface ParseStrategy<T> {

	/**
	 * 
	 * @param parser
	 *            the protocol parser to call.
	 * @return result of the parsing operation implemented by this method.
	 * @throws ParseException
	 *             if parsing fails.
	 * 
	 * @see ProtocolFacade#parse(String, ParseStrategy)
	 */
	T parse(ProtocolParser parser) throws ParseException;
}
