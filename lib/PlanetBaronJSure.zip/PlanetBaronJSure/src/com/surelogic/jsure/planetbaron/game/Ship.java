package com.surelogic.jsure.planetbaron.game;

import java.util.logging.Level;

import com.surelogic.Borrowed;
import com.surelogic.RequiresLock;
import com.surelogic.SingleThreaded;
import com.surelogic.jsure.planetbaron.util.Common;


/**
 * Represents a ship on the game map.
 *
 * @author T.J. Halloran
 */
public final class Ship extends Reporter {

  /**
   * The owner of this ship.
   */
  private final Player f_owner;

  /**
   * The location of this ship. If the ship is moving then this location
   * represents the starting point of the movement.
   */
  private Location f_location;

  /**
   * <code>true</code> if this ship arrived at its destination during this
   * turn, <code>false</code> otherwise.
   */
  private boolean f_arrived_thisTurn = false;

  /**
   * <code>true</code> if this ship arrived at its destination during the last
   * game turn, <code>false</code> otherwise. Essentially, the value of
   * {@link #f_arrived_thisTurn} is copied into this field when
   * {@link #doTurn()} is invoked during a turn.
   */
  private boolean f_arrived_lastTurn = false;

  /**
   * <code>true</code> if the ship is in transit between two locations,
   * <code>false</code> otherwise.
   */
  private boolean f_isMoving = false;

  /**
   * The number of turns this ship has been moving. This value is used for
   * communication so that calls to <code>move()</code> can be duplicated on
   * client machines as a new player connects to the game. Valid only if
   * <code>m_isMoving</code> is <code>true</code>.
   */
  private int f_turnsMoving = 0;

  /**
   * Percentage, between 0 and 1, the ship has moved. For example, a value of
   * 0.45 indicates that the ship is 45% of the way to the destination. Valid
   * only if <code>m_isMoving</code> is <code>true</code>.
   */
  private double f_percentageMoved = 0.0;

  /**
   * The distance between <code>m_currentLocation</code> and
   * <code>m_destination</code> in game map logical units. Valid only if
   * <code>m_isMoving</code> is <code>true</code>.
   */
  private double f_moveDistance = 0.0;

  /**
   * The destination this ship is moving toward. Valid only if
   * <code>m_isMoving</code> is <code>true</code>.
   */
  private Location f_destination = null;

  /**
   * Constructs a new ship at the given location on the game map. Only intended
   * to be called from {@link GameMap}.
   *
   * @param map
   *          the containing game map.
   * @param owner
   *          the owner of this ship.
   * @param location
   *          the initial location of the ship.
   * @param destination
   *          the destination this ship is moving to, or <code>null</code> if
   *          it is not moving.
   * @param turnsMoving
   *          the number of turns this ship has been moving to its destination
   *          (ignored if the ship is not moving).
   */
  @SingleThreaded
  @Borrowed("this")
  Ship(GameMap map, Player owner, Location location, Location destination,
      int turnsMoving) {
    super(map);
    assert owner != null && location != null;
    f_owner = owner;
    f_location = location;
    if (destination != null) {
      moveTo(destination, turnsMoving);
    } else {
      takeOverPlanetAt(f_location);
    }
  }

  /**
   * Returns the player who owns this ship. Since all ships must be owned this
   * will not be <code>null</code>.
   *
   * @return the owner of this ship.
   */
  public Player getOwner() {
    return f_owner; // immutable
  }

  /**
   * Returns the name of this ship. The name of a ship is the same as the name
   * of its owner.
   *
   * @return the name of this ship.
   */
  public String getName() {
    return f_owner.getName();
  }

  /**
   * Returns the location of this ship. If the ship is currently moving then the
   * returned location represents the starting point of the movement.
   *
   * @return the location of this ship.
   * @see #isMoving()
   */
  public Location getLocation() {
    f_lock.readLock().lock();
    try {
      return f_location;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Directs this ship to move to a new location on the game map. This movement
   * is not immediate, it occurs across several turns.
   *
   * @param destination
   *          the destination of the movement.
   * @throws IllegalStateException
   *           if this method is invoked on a ship that is already moving.
   * @see #isMoving()
   * @see #getPercentageMoved()
   * @see #getTurnsMoving()
   */
  public void moveTo(Location destination) {
    if (isMoving())
      throw new IllegalStateException(
          "a moving ship can't change its destination");

    if (f_location.equals(destination)) {
      LOG.log(Level.WARNING,
          "ignored attempt to move ship to its current location");
    } else {
      f_lock.writeLock().lock();
      try {
        f_isMoving = true;
        f_turnsMoving = 0;
        f_destination = destination;
        f_moveDistance = f_location.distanceTo(f_destination);
        f_percentageMoved = 0.0;
        sendReport(); // OK to invoked holding a write lock
      } finally {
        f_lock.writeLock().unlock();
      }
    }
  }


  /**
   * Directs this ship to move to a new location on the game map. This movement
   * is not immediate, it occurs across several turns.
   *
   * @param destination
   *          the destination of the movement.
   * @param turnsMoving
   *          the number of turns this ship has been moving to its destination..
   * @throws IllegalStateException
   *           if this method is invoked on a ship that is already moving.
   * @see #isMoving()
   * @see #getPercentageMoved()
   * @see #getTurnsMoving()
   */
  public void moveTo(Location destination, int turnsMoving) {
    f_lock.writeLock().lock();
    try {
      moveTo(destination);
      for (int i = 0; i < turnsMoving; i++)
        move();
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Returns <code>true</code> if this ship is moving, <code>false</code>
   * otherwise.
   *
   * @return <code>true</code> if this ship is moving, <code>false</code>
   *         otherwise.
   */
  public boolean isMoving() {
    f_lock.readLock().lock();
    try {
      return f_isMoving;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns the number of turns this ship has been moving. This value allows
   * calls to <code>move()</code> can be duplicated on client machines as a
   * new player connects to the game. This value is only valid if the ship is
   * moving.
   *
   * @return the number of turns this ship has been moving.
   * @see #isMoving()
   */
  public int getTurnsMoving() {
    f_lock.readLock().lock();
    try {
      return f_turnsMoving;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns the percentage, between 0 and 1, this ship has moved toward its
   * destination. This value is only valid if the ship is moving.
   *
   * @return the percentage, between 0 and 1, this ship has moved toward its
   *         destination.
   * @see #isMoving()
   */
  public double getPercentageMoved() {
    f_lock.readLock().lock();
    try {
      return f_percentageMoved;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns the distance in map squares that this ship has moved toward its
   * destination. This value is only valid if the ship is moving.
   *
   * @return the distance in map squares this ship has moved toward its
   *         destination.
   * @see #isMoving()
   */
  public double getDistanceMoved() {
    f_lock.readLock().lock();
    try {
      return f_percentageMoved * f_moveDistance;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns the destination of this moving ship. This value is only valid if
   * the ship is moving.
   *
   * @return the destination of this moving ship, or <code>null</code> if the
   *         ship is not moving.
   */
  public Location getDestination() {
    f_lock.readLock().lock();
    try {
      return f_destination;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  public void doTurn() {
    f_lock.writeLock().lock();
    try {
      super.doTurn(); // OK to invoked holding a write lock
      move(); // once per turn
      f_arrived_lastTurn = f_arrived_thisTurn;
      f_arrived_thisTurn = false;
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Returns <code>true</code> if this ship just arrived at its destination,
   * <code>false</code> if it did not. This method should only be invoked
   * <i>after</i> {@link #doTurn()} has been invoked on this object for the
   * turn. The result of this method remains stable until {@link #doTurn()} is
   * invoked during the next turn.
   *
   * @return <code>true</code> if this ship just arrived at its destination
   *         this turn, <code>false</code> if it did not.
   */
  public boolean justArrived() {
    f_lock.readLock().lock();
    try {
      return f_arrived_lastTurn;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Causes the ship to move toward its destination. Invoked once per turn. If
   * the ship is not moving, this operation has no effect.
   * <p>
   * Requires a write lock to be held when this method is invoked.
   */
  @RequiresLock("ThingLock.writeLock()")
  private void move() {
    if (f_isMoving) {
      f_percentageMoved = ((f_percentageMoved * f_moveDistance) + Common.SHIP_VELOCITY)
          / f_moveDistance;
      f_turnsMoving++;
      if (f_percentageMoved >= 1.0) {
        // destination has been reached
        f_arrived_thisTurn = true;
        f_isMoving = false;
        f_turnsMoving = 0;
        f_location = f_destination;
        f_destination = null;
        f_percentageMoved = 0.0;
        f_moveDistance = 0.0;
        // OK, can we take over a planet?
        takeOverPlanetAt(f_location);
      }
    }
  }

  /**
   * Takes over the planet at the given location. If a planet does not exist at
   * the specified location then the method does nothing.
   *
   * @param l
   *          the location of the planet.
   */
  @Borrowed("this")
  private void takeOverPlanetAt(Location l) {
    Planet p = getMap().getPlanetAt(l);
    if (p != null) {
      p.setOwner(f_owner);
    }
  }
}
