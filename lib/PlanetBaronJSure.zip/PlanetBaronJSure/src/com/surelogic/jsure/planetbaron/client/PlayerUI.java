package com.surelogic.jsure.planetbaron.client;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.text.JTextComponent;

import com.surelogic.jsure.planetbaron.client.PlayerProxy.IPlayerListener;
import com.surelogic.jsure.planetbaron.client.communication.IDisconnect;
import com.surelogic.jsure.planetbaron.client.communication.ServerProxy;
import com.surelogic.jsure.planetbaron.game.*;
import com.surelogic.jsure.planetbaron.util.Common;
import com.surelogic.jsure.planetbaron.util.ConciseFormatter;


/**
 * The main program for the player user interface. This is a SWING application.
 * 
 * @author T.J. Halloran
 */
public final class PlayerUI extends JFrame implements IDisconnect,
    EndOfTurnObserver {

  public static void main(String[] args) {
    new PlayerUI();
  }

  private static final long serialVersionUID = 3690199823823745328L;

  private static final Logger LOG = ConciseFormatter.getLogger("server");

  static public Toolkit m_toolkit = Toolkit.getDefaultToolkit();

  static public final Image m_shipImage = m_toolkit.getImage(Object.class
      .getResource("/media/ship.png"));

  static public final Image m_ship0Image = m_toolkit.getImage(Object.class
      .getResource("/media/ship0.png"));

  static public final Image m_planet0Image = m_toolkit.getImage(Object.class
      .getResource("/media/planet0.png"));

  static public final Image m_planet1Image = m_toolkit.getImage(Object.class
      .getResource("/media/planet1.png"));

  static public final Image m_planet2Image = m_toolkit.getImage(Object.class
      .getResource("/media/planet2.png"));

  static public final Image m_planet3Image = m_toolkit.getImage(Object.class
      .getResource("/media/planet3.png"));

  static public final ImageIcon m_shipImageIcon = new ImageIcon(m_shipImage);

  static public final ImageIcon m_ship0ImageIcon = new ImageIcon(m_ship0Image);

  static public final ImageIcon m_planet0ImageIcon = new ImageIcon(
      m_planet0Image);

  static public final ImageIcon m_planet1ImageIcon = new ImageIcon(
      m_planet1Image);

  static public final ImageIcon m_planet2ImageIcon = new ImageIcon(
      m_planet2Image);

  static public final ImageIcon m_planet3ImageIcon = new ImageIcon(
      m_planet3Image);

  /**
   * Default game server to contact. This can be changed by setting its
   * associated property, <code>fleetbaron.defaultGameServer</code>.
   */
  public static final String DEFAULT_GAME_SERVER = System.getProperty(
      "fleetbaron.defaultGameServer", "localhost");

  Socket m_serverSocket = null;

  ServerProxy m_serverProxy = null;

  PlayerProxy m_playerProxy = null;

  volatile boolean m_connectedToGameServer = false;

  FocusListener m_selectOnFocus = new FocusListener() {

    public void focusGained(FocusEvent e) {
      ((JTextComponent) e.getSource()).selectAll();
    }

    public void focusLost(FocusEvent e) {
    }
  };

  // map viewer panel

  MapView m_mapView = new MapView();

  JScrollPane m_scroll = new JScrollPane(m_mapView);

  // status panel (on right side)

  JPanel m_statusPanel = new JPanel();

  TitledBorder m_scanBorder = BorderFactory.createTitledBorder(BorderFactory
      .createEtchedBorder(EtchedBorder.LOWERED), "Scan:");

  JLabel m_scanLocation = new JLabel("(1,5)");

  JLabel m_planetImageLabel = new JLabel(m_planet0ImageIcon,
      SwingConstants.CENTER);

  JLabel m_planetName = new JLabel("Foo III");

  JLabel m_planetOwner = new JLabel("Tom");

  JLabel m_shipImageLabel = new JLabel(m_ship0ImageIcon, SwingConstants.CENTER);

  JTextArea m_shipsInOrbitTextArea = new JTextArea("");

  TitledBorder m_shipInfoBorder = BorderFactory.createTitledBorder(
      BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Ship:");

  JLabel m_myShipImageLabel = new JLabel(m_shipImageIcon, SwingConstants.CENTER);

  JLabel m_myShipCurrentLocation = new JLabel("(5,5)");

  JLabel m_myShipDestination = new JLabel("none");

  TitledBorder m_gameMessagesBorder = BorderFactory.createTitledBorder(
      BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Messages:");

  JTextArea m_gameMessagesTextArea = new JTextArea("");

  // connection panel (at bottom)

  JPanel m_connectionPanel = new JPanel();

  JLabel m_hostLabel = new JLabel("Host:");

  JTextField m_hostField = new JTextField();

  JLabel m_portLabel = new JLabel("Port:");

  JTextField m_portField = new JTextField();

  JLabel m_playerLabel = new JLabel("Player:");

  JTextField m_playerField = new JTextField();

  JButton m_connectDisconnectButton = new JButton("Connect");

  public PlayerUI() {
    super("FleetBaron");

    // set the icon for the application
    this.setIconImage(m_shipImage);

    // map viewer panel

    m_mapView.registerCursorListener(new MapView.CursorListener() {
      public void cursorMoved(Location l) {
        setScanInformation(l);
      }
    });
    m_scroll.setBorder(BorderFactory.createTitledBorder(BorderFactory
        .createEtchedBorder(EtchedBorder.LOWERED), "Map:"));
    getContentPane().add(m_scroll, BorderLayout.CENTER);

    GridBagConstraints c;

    // status panel (on right side 3 rows):

    m_statusPanel.setLayout(new GridBagLayout());
    GridBagConstraints sidePanelc = new GridBagConstraints();
    // keep the status panel at least 300 pixels wide
    m_statusPanel.add(Box.createHorizontalStrut(300));

    // side panel: 1st row: scan status
    JPanel p0 = new JPanel();
    p0.setBorder(m_scanBorder);
    p0.setLayout(new GridBagLayout());
    c = new GridBagConstraints();
    c.gridx = c.gridy = 0;
    c.insets = new Insets(5, 5, 5, 5);
    c.anchor = GridBagConstraints.CENTER;
    c.weightx = 0;
    c.fill = GridBagConstraints.HORIZONTAL;
    p0.add(new JLabel("Scanning:"), c);
    c.gridx = 1;
    c.weightx = 1;
    p0.add(m_scanLocation, c);
    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 2;
    p0.add(m_planetImageLabel, c);
    c.gridx = 0;
    c.gridy = 2;
    c.gridwidth = 1;
    c.weightx = 0;
    p0.add(new JLabel("Planet:"), c);
    c.gridx = 1;
    c.weightx = 1;
    p0.add(m_planetName, c);
    c.gridx = 0;
    c.gridy = 3;
    c.weightx = 0;
    p0.add(new JLabel("Owner:"), c);
    c.gridx = 1;
    c.weightx = 1;
    p0.add(m_planetOwner, c);
    c.gridx = 0;
    c.gridy = 4;
    c.gridwidth = 2;
    p0.add(m_shipImageLabel, c);
    JPanel p01 = new JPanel();
    p01.setBorder(BorderFactory.createTitledBorder(BorderFactory
        .createEtchedBorder(EtchedBorder.LOWERED), "Ships in orbit:"));
    p01.setLayout(new GridBagLayout());
    c = new GridBagConstraints();
    c.weightx = c.weighty = 1;
    c.fill = GridBagConstraints.BOTH;
    m_shipsInOrbitTextArea.setEditable(false);
    p01.add(new JScrollPane(m_shipsInOrbitTextArea), c);
    c.gridx = 0;
    c.gridy = 5;
    c.gridwidth = 2;
    c.weighty = 1;
    c.fill = GridBagConstraints.BOTH;
    p0.add(p01, c);
    sidePanelc.gridx = sidePanelc.gridy = 0;
    sidePanelc.weightx = 1;
    sidePanelc.weighty = 0.2;
    sidePanelc.fill = GridBagConstraints.BOTH;
    m_statusPanel.add(p0, sidePanelc);

    // side panel: 2nd row: your ship status
    JPanel p1 = new JPanel();
    p1.setBorder(m_shipInfoBorder);
    p1.setLayout(new GridBagLayout());
    c = new GridBagConstraints();
    c.gridx = c.gridy = 0;
    c.insets = new Insets(5, 5, 5, 5);
    c.anchor = GridBagConstraints.CENTER;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridwidth = 1;
    c.weightx = 0;
    p1.add(new JLabel("Current location:"), c);
    c.gridx = 1;
    c.weightx = 1;
    p1.add(m_myShipCurrentLocation, c);
    c.gridx = 0;
    c.gridy = 1;
    c.weightx = 0;
    p1.add(new JLabel("Destination:"), c);
    c.gridx = 1;
    c.weightx = 1;
    p1.add(m_myShipDestination, c);
    c.gridx = 0;
    c.gridy = 2;
    c.gridwidth = 2;
    p1.add(m_myShipImageLabel, c);
    sidePanelc.gridy = 1;
    sidePanelc.weighty = 0;
    m_statusPanel.add(p1, sidePanelc);

    // side panel: 3rd row: game messages
    JPanel p2 = new JPanel();
    p2.setBorder(BorderFactory.createTitledBorder(BorderFactory
        .createEtchedBorder(EtchedBorder.LOWERED), "Messages:"));
    p2.setLayout(new GridBagLayout());
    c = new GridBagConstraints();
    c.weightx = c.weighty = 1;
    c.fill = GridBagConstraints.BOTH;
    m_gameMessagesTextArea.setEditable(false);
    JScrollPane messagesScrollPane = new JScrollPane(m_gameMessagesTextArea);
    messagesScrollPane
        .setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
    messagesScrollPane
        .setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
    p2.add(messagesScrollPane, c);
    sidePanelc.gridy = 2;
    sidePanelc.weighty = 0.5;
    m_statusPanel.add(p2, sidePanelc);
    getContentPane().add(m_statusPanel, BorderLayout.EAST);

    // connection panel (at bottom)
    // Host: [___] Port: [___] Player: [___] [Connect]

    m_connectionPanel.setLayout(new GridBagLayout());
    c = new GridBagConstraints();
    c.gridx = c.gridy = 0;
    c.insets = new Insets(10, 5, 10, 5);
    c.anchor = GridBagConstraints.CENTER;
    c.weightx = 0;
    m_connectionPanel.add(m_hostLabel, c);
    c.gridx = 1;
    c.weightx = 0.5;
    c.fill = GridBagConstraints.HORIZONTAL;
    m_hostField.setText(DEFAULT_GAME_SERVER);
    m_hostField.addFocusListener(m_selectOnFocus);
    m_connectionPanel.add(m_hostField, c);
    c.gridx = 2;
    c.weightx = 0;
    c.fill = GridBagConstraints.NONE;
    m_connectionPanel.add(m_portLabel, c);
    c.gridx = 3;
    c.weightx = 0.5;
    c.fill = GridBagConstraints.HORIZONTAL;
    m_portField.setText(Common.DEFAULT_PORT + "");
    m_portField.addFocusListener(m_selectOnFocus);
    m_connectionPanel.add(m_portField, c);
    c.gridx = 4;
    c.weightx = 0;
    c.fill = GridBagConstraints.NONE;
    m_connectionPanel.add(m_playerLabel, c);
    c.gridx = 5;
    c.weightx = 0.5;
    c.fill = GridBagConstraints.HORIZONTAL;
    m_playerField.addFocusListener(m_selectOnFocus);
    m_connectionPanel.add(m_playerField, c);
    c.gridx = 6;
    c.weightx = 0;
    c.fill = GridBagConstraints.NONE;
    m_connectDisconnectButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (m_connectedToGameServer) {
          // user pressed button to disconnect
          m_serverProxy.shutdown(); // will callback our
          // disconnectCallback()
        } else {
          if (!m_playerField.getText().equals("")) {
            setConnectionPanelEnabled(false);
            connectToServer();
          } else {
            JOptionPane.showMessageDialog(PlayerUI.this,
                "A player name must be entered", "Empty Player NameLiteral",
                JOptionPane.ERROR_MESSAGE);
          }
        }
      }
    });
    m_connectionPanel.add(m_connectDisconnectButton, c);
    getContentPane().add(m_connectionPanel, BorderLayout.SOUTH);
    setConnectionPanelEnabled(true);

    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    addWindowListener(new WindowAdapter() {

      public void windowClosed(WindowEvent e) {
        LOG.info("window closing...shutting down connection with the server");
        if (m_serverProxy != null) {
          m_serverProxy.shutdown();
        }
        if (m_serverSocket != null) {
          try {
            m_serverSocket.close();
          } catch (IOException e1) {
            LOG.log(Level.WARNING, "problem closing socket to server", e);
          }
        }
        System.exit(0); // end the program
      }
    });

    GameMap.getInstance().register(this);

    pack();
    setVisible(true);
  }

  private void setScanInformation(Location l) {
    Planet p = GameMap.getInstance().getPlanetAt(l);
    String s1 = l.toString();
    m_scanLocation.setText(s1);
    if (p == null) {
      m_planetName.setText("");
      m_planetOwner.setText("");
      m_planetImageLabel.setIcon(m_planet0ImageIcon);
    } else {
      m_planetName.setText(p.getName());
      m_planetOwner
          .setText((p.getOwner() == null ? "" : p.getOwner().getName()));
      Player owner = p.getOwner();
      ImageIcon planetIcon;
      if (owner == null) {
        // nobody controls the planet
        planetIcon = PlayerUI.m_planet1ImageIcon;
      } else {
        // assume another player controls the planet
        planetIcon = PlayerUI.m_planet2ImageIcon;
        String ownerId = owner.getName();
        if (m_playerProxy != null) {
          if (m_playerProxy.getplayerIdentity().equals(ownerId)) {
            // this player controls the planet
            planetIcon = PlayerUI.m_planet3ImageIcon;
          }
        }
      }
      m_planetImageLabel.setIcon(planetIcon);
    }
    StringBuilder info = new StringBuilder();
    Set<Ship> ships = GameMap.getInstance().getShipsAt(l);
    if (ships.size() > 0) {
      m_shipImageLabel.setIcon(m_shipImageIcon);
      for (Ship s : ships) {
        info.append(s.getName());
        if (s.isMoving()) {
          info.append(" moving to " + s.getDestination());
        }
        info.append("\n");
      }
    } else {
      m_shipImageLabel.setIcon(m_ship0ImageIcon);
    }
    m_shipsInOrbitTextArea.setText(info.toString());
  }

  public void setMyShipInformation(Ship s) {
    if (s == null)
      return;
    m_myShipCurrentLocation.setText(s.getLocation().toString());
    m_myShipImageLabel.setIcon(m_shipImageIcon);
    if (s.isMoving()) {
      m_myShipDestination.setText(s.getDestination().toString());
    } else {
      m_myShipDestination.setText("");

    }
  }

  public void endOfTurn(GameMap map) {
    // TODO: need to fix output of messages to the status window
    // StringBuilder msgs = new StringBuilder(GameMap.getInstance()
    // .getPlayerNotificationMessage());
    StringBuilder msgs = new StringBuilder();
    if (!msgs.toString().equals("")) {
      msgs.append("    -------\n" + m_gameMessagesTextArea.getText());
      m_gameMessagesTextArea.setText(msgs.toString());
    }

    if (m_playerProxy != null) {
      String playerId = m_playerProxy.getplayerIdentity();
      Player p = GameMap.getInstance().getPlayer(playerId);
      Ship s = GameMap.getInstance().getShip(p);
      if (s != null)
        setMyShipInformation(s);
    }
  }

  /**
   * Attempts to connect to the game server with the information the user
   * entered into the <code>m_hostField</code> and <code>m_portField</code>
   * fields.
   */
  private void connectToServer() {
    String host = m_hostField.getText();
    String portString = m_portField.getText();
    try {
      int port = Integer.parseInt(portString);
      m_serverSocket = new Socket(host, port);
      m_serverProxy = new ServerProxy(m_serverSocket);
      m_serverProxy.register(this);
      m_connectedToGameServer = true;
      m_playerProxy = new PlayerProxy(m_playerField.getText(), m_serverProxy,
          this);
      m_playerProxy.registerPlayerListener(new IPlayerListener() {
        public void playerConnectedOK() {
          // now we are sure the player has been connected to the
          // server OK
          m_mapView.setPlayerProxyTarget(m_playerProxy);
          m_mapView.updateMapDimensions(Common.LOGICAL_MAP_HEIGHT,
              Common.LOGICAL_MAP_WIDTH);
          LOG.info("server proxy has been connected to "
              + m_serverSocket.getInetAddress() + ":"
              + m_serverSocket.getPort());
          SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              setTitle(m_playerProxy.getplayerIdentity() + " - FleetBaron");
              pack();
            }
          });
        }
      });
    } catch (UnknownHostException e) {
      LOG.log(Level.SEVERE, "unknown game server host", e);
      JOptionPane.showMessageDialog(this, "Game server \"" + host
          + "\" can't be located on the network", "Unknown Host",
          JOptionPane.ERROR_MESSAGE);
      setConnectionPanelEnabled(true);
    } catch (IOException e) {
      LOG.log(Level.SEVERE, "general I/O failure on game server socket", e);
      JOptionPane.showMessageDialog(this,
          "General I/O failure on game server socket"
              + "...the server may be down", "Server I/O Failure",
          JOptionPane.ERROR_MESSAGE);
      setConnectionPanelEnabled(true);
    } catch (NumberFormatException e) {
      LOG.log(Level.SEVERE, "user provided an invalid port number: \""
          + portString + "\"", e);
      JOptionPane.showMessageDialog(this, "Port \"" + portString
          + "\" is not a valid port number", "Invalid Port Number",
          JOptionPane.ERROR_MESSAGE);
      setConnectionPanelEnabled(true);
    }
  }

  /**
   * Callback to notify us that our server proxy has disconnected.
   */
  public void disconnected(ServerProxy proxy) {
    // note we are disconnected
    LOG.info("server proxy has been disconnected from the game server");
    m_connectedToGameServer = false;
    m_serverProxy = null;
    m_mapView.setPlayerProxyTarget(null); // disconnect the player proxy
    m_playerProxy.shutdown();
    m_playerProxy = null;
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        // reset our game
        GameMap.getInstance().reset();
        // set our panel state properly
        setConnectionPanelEnabled(true);
        PlayerUI.this.setTitle("FleetBaron"); // remove the player
        // name
        PlayerUI.this.getContentPane().repaint();
        JOptionPane.showMessageDialog(PlayerUI.this,
            "The game server has disconnected from this client",
            "Game Server Disconnected", JOptionPane.INFORMATION_MESSAGE);
      }
    });
  }

  /**
   * Utility method to set the state of the connection portion of the
   * application panel (at the bottom).
   * 
   * @param b
   *          <code>true</code> if the connection portion is enabled,
   *          <code>false</code> otherwise
   */
  private void setConnectionPanelEnabled(boolean b) {
    if (b) {
      m_connectDisconnectButton.setText("Connect");
      this.getRootPane().setDefaultButton(m_connectDisconnectButton);
    } else {
      m_connectDisconnectButton.setText("Disconnect");
    }
    m_hostLabel.setEnabled(b);
    m_hostField.setEnabled(b);
    m_portLabel.setEnabled(b);
    m_portField.setEnabled(b);
    m_playerLabel.setEnabled(b);
    m_playerField.setEnabled(b);
  }
}
