package com.surelogic.jsure.planetbaron.game;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.surelogic.Aggregate;
import com.surelogic.RegionLock;
import com.surelogic.Unique;
import com.surelogic.jsure.planetbaron.util.Common;


/**
 * Represents the game map and aggregates the game's players, ships, and
 * planets. This class is the gateway to the overall state of the game.
 * 
 * @author T.J. Halloran
 */
@RegionLock("MapLock is f_lock protects Instance")
public final class GameMap {
  /**
   * Protects the state of this object. This lock is used to protect the various
   * collections defined by this class, however, it is <i>not</i> used to
   * protect the state of the objects within those collections.
   */
  private final ReadWriteLock f_lock = new ReentrantReadWriteLock();

  /**
   * The immutable width of this game map.
   */
  private final int f_width;

  /**
   * The immutable height of this game map.
   */
  private final int f_height;

  /**
   * The set of all {@link Thing}s contained by this game map.
   */
  @Unique
  @Aggregate("Instance into Instance")
  private final Set<Thing> f_things = new HashSet<Thing>();

  /**
   * The set of end of turn observers registered with this game map.
   */
  @Unique
  @Aggregate("Instance into Instance")
  // JSURE: Added "final"
  private final Set<EndOfTurnObserver> f_endOfTurnObservers = new HashSet<EndOfTurnObserver>();

  private static final GameMap INSTANCE = new GameMap(Common.LOGICAL_MAP_WIDTH,
      Common.LOGICAL_MAP_WIDTH);

  /**
   * Obtains a reference the sole <code>GameMap</code> object.
   * 
   * @return the singleton instance of this class
   */
  public static GameMap getInstance() {
    return INSTANCE;
  }

  private GameMap(int width, int height) {
    f_width = width;
    f_height = height;
  }

  /**
   * Returns the width of the game map in map squares.
   * 
   * @return the width of the game map in map squares.
   */
  public int getWidth() {
    return f_width; // immutable
  }

  /**
   * Returns the height of the game map in map squares.
   * 
   * @return the height of the game map in map squares.
   */
  public int getHeight() {
    return f_height; // immutable
  }

  /**
   * Generates a random galaxy on the game map. Normally only called by the
   * server during its startup.
   */
  public void generateRandomGalaxy() {
    f_lock.writeLock().lock();
    try {
      for (int i = 0; i < Common.PLANET_COUNT; i++) {
        createPlanet(generateUniquePlanetName(),
            getRandomLocationWithoutAPlanet());
      }
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Directs all the contained things that implement the {@link TurnMutable}
   * interface to complete the current turn. All registered end of turn
   * observers are notified that the current turn has ended.
   * 
   * @see TurnMutable
   * @see EndOfTurnObserver
   */
  public void endCurrentTurn() {
    f_lock.writeLock().lock();
    try {
      for (Thing t : f_things) {
        if (t instanceof TurnMutable) {
          ((TurnMutable) t).doTurn();
        }
      }
      for (EndOfTurnObserver o : f_endOfTurnObservers) {
        o.endOfTurn(this);
      }
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Registers an end of turn observer to be notified at the conclusion of each
   * game turn.
   * 
   * @param observer
   *          the observing object.
   */
  public void register(EndOfTurnObserver observer) {
    assert observer != null;
    f_lock.writeLock().lock();
    try {
      f_endOfTurnObservers.add(observer);
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Returns the set of all players on this game map.
   * 
   * @return the set of all player on this game map.
   */
  public Set<Player> getPlayers() {
    Set<Player> results = new HashSet<Player>();
    f_lock.readLock().lock();
    try {
      for (Thing t : f_things) {
        if (t instanceof Player) {
          results.add((Player) t);
        }
      }
    } finally {
      f_lock.readLock().unlock();
    }
    return results;
  }

  /**
   * Returns <code>true</code> if a player with the specified name exists on
   * this game map, <code>false</code> otherwise.
   * 
   * @param name
   *          the name of the player.
   * @return <code>true</code> if a player with the specified name exists on
   *         this game map, <code>false</code> otherwise.
   */
  public boolean isPlayer(String name) {
    f_lock.readLock().lock();
    try {
      for (Player p : getPlayers()) {
        if (p.getName().equals(name))
          return true;
      }
      return false;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns a reference to the player with the specified name on this game map.
   * 
   * @param name
   *          the name of the player.
   * @return a reference to the player object.
   * @throws IllegalStateException
   *           if no such player exists.
   */
  public Player getPlayer(String name) {
    f_lock.readLock().lock();
    try {
      for (Player p : getPlayers()) {
        if (p.getName().equals(name))
          return p;
      }
    } finally {
      f_lock.readLock().unlock();
    }
    throw new IllegalStateException("no player \"" + name
        + "\" exists on the game map");
  }

  /**
   * Creates a new player on this game map.
   * 
   * @param name
   *          the name of the player.
   * @return a reference to the player object.
   * @throws IllegalStateException
   *           if a player with the specified name already exists.
   */
  public Player createPlayer(String name) {
    f_lock.writeLock().lock();
    try {
      if (isPlayer(name))
        throw new IllegalStateException("player \"" + name
            + "\" already exists on the game map");
      Player p = new Player(this, name);
      f_things.add(p);
      return p;
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Returns the set of all planets on this game map.
   * 
   * @return the set of all planets on this game map.
   */
  public Set<Planet> getPlanets() {
    Set<Planet> results = new HashSet<Planet>();
    f_lock.readLock().lock();
    try {
      for (Thing t : f_things) {
        if (t instanceof Planet) {
          results.add((Planet) t);
        }
      }
    } finally {
      f_lock.readLock().unlock();
    }
    return results;
  }

  /**
   * Returns <code>true</code> if a planet with the specified name exists on
   * this game map, <code>false</code> otherwise.
   * 
   * @param name
   *          the name of the planet.
   * @return <code>true</code> if a planet with the specified name exists on
   *         this game map, <code>false</code> otherwise.
   */
  public boolean isPlanet(String name) {
    f_lock.readLock().lock();
    try {
      for (Planet p : getPlanets()) {
        if (p.getName().equals(name))
          return true;
      }
      return false;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns a reference to the planet with the specified name on this game map.
   * 
   * @param name
   *          the name of the planet.
   * @return a reference to the planet object.
   * @throws IllegalStateException
   *           if no such planet exists.
   */
  public Planet getPlanet(String name) {
    f_lock.readLock().lock();
    try {
      for (Planet p : getPlanets()) {
        if (p.getName().equals(name))
          return p;
      }
    } finally {
      f_lock.readLock().unlock();
    }
    throw new IllegalStateException("no planet \"" + name
        + "\" exists on the game map");
  }

  /**
   * Returns a reference to the planet at the given location, or
   * <code>null</code> if none.
   * 
   * @param location
   *          the location to query.
   * @return a reference to the planet at the specified location, or
   *         <code>null</code> if none.
   */
  public Planet getPlanetAt(Location location) {
    f_lock.readLock().lock();
    try {
      for (Planet p : getPlanets()) {
        if (location == p.getLocation())
          return p;
      }
      return null;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Creates a new planet on this game map at the specified location.
   * 
   * @param name
   *          the name of the planet.
   * @param location
   *          the location of the planet.
   * @return a reference to the planet object.
   * @throws IllegalStateException
   *           if a planet exists with the specified name or if the specified
   *           location already contains a planet.
   */
  public Planet createPlanet(String name, Location location) {
    f_lock.writeLock().lock();
    try {
      if (isPlanet(name))
        throw new IllegalStateException("planet \"" + name
            + "\" already exists on the game map");
      if (getPlanetAt(location) != null)
        throw new IllegalStateException("a planet already exists at "
            + location);
      Planet p = new Planet(this, name, location);
      f_things.add(p);
      return p;
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Returns the set of all ships on this game map.
   * 
   * @return the set of all ships on this game map.
   */
  public Set<Ship> getShips() {
    Set<Ship> results = new HashSet<Ship>();
    f_lock.readLock().lock();
    try {
      for (Thing t : f_things) {
        if (t instanceof Ship) {
          results.add((Ship) t);
        }
      }
    } finally {
      f_lock.readLock().unlock();
    }
    return results;
  }

  /**
   * Returns <code>true</code> if a ship owned by the specified player exists
   * on this game map, <code>false</code> otherwise.
   * 
   * @param owner
   *          the owner of the ship.
   * @return <code>true</code> if a ship owned by the specified player exists
   *         on this game map, <code>false</code> otherwise.
   */
  public boolean isShip(Player owner) {
    f_lock.readLock().lock();
    try {
      for (Ship s : getShips()) {
        if (owner == s.getOwner())
          return true;
      }
      return false;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Returns a reference to the ship with the specified owner on this game map.
   * 
   * @param owner
   *          the owner of the ship.
   * @return a reference to the ship object.
   * @throws IllegalStateException
   *           if no ship owned by the specified player exists.
   */
  public Ship getShip(Player owner) {
    f_lock.readLock().lock();
    try {
      for (Ship s : getShips()) {
        if (owner == s.getOwner())
          return s;
      }
    } finally {
      f_lock.readLock().unlock();
    }
    throw new IllegalStateException("no ship owned by \"" + owner.getName()
        + "\" exists on the game map");
  }

  /**
   * Creates a new ship on this game map at the specified location.
   * 
   * @param owner
   *          the owner of this ship.
   * @param location
   *          the initial location of the ship.
   * @param destination
   *          the destination this ship is moving to, or <code>null</code> if
   *          it is not moving.
   * @param turnsMoving
   *          the number of turns this ship has been moving to its destination
   *          (ignored if the ship is not moving).
   * @return a reference to the ship object.
   * @throws IllegalStateException
   *           if a ship exists with the specified owner.
   */
  public Ship createShip(Player owner, Location location, Location destination,
      int turnsMoving) {
    f_lock.writeLock().lock();
    try {
      if (isShip(owner))
        throw new IllegalStateException("ship owned by \"" + owner.getName()
            + "\" already exists on the game map");
      Ship s = new Ship(this, owner, location, destination, turnsMoving);
      f_things.add(s);
      return s;
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Creates a new ship on this game map at the specified location.
   * 
   * @param owner
   *          the owner of this ship.
   * @param location
   *          the initial location of the ship.
   * @return a reference to the ship object.
   * @throws IllegalStateException
   *           if a ship exists with the specified owner.
   */
  public Ship createShip(Player owner, Location location) {
    return createShip(owner, location, null, 0);
  }

  /**
   * Returns the set of ships located at the specified location. This set may be
   * empty.
   * 
   * @param at
   *          the location to query
   * @return the set of ships at the given location (possibly empty)
   */
  public Set<Ship> getShipsAt(Location at) {
    Set<Ship> result = new HashSet<Ship>();
    f_lock.readLock().lock();
    try {
      for (Ship s : getShips()) {
        if (at == s.getLocation())
          result.add(s);
      }
    } finally {
      f_lock.readLock().unlock();
    }
    return result;
  }

  /**
   * Resets the entire state of the game map and all associated map objects.
   * Used to reset the entire state of the game.
   */
  public void reset() {
    f_lock.writeLock().lock();
    try {
      f_things.clear();
    } finally {
      f_lock.writeLock().unlock();
    }
  }

  /**
   * Returns a unique planet name generated using the names in
   * {@link Common#PLANET_NAMES}. This method adds a subscript if a particular
   * name is already been used, for example "Sol I" "Sol II" and "Sol III".
   * 
   * @return a unique planet name.
   * @see Common#PLANET_NAMES
   */
  private String generateUniquePlanetName() {
    while (true) {
      String proposedName = Common.PLANET_NAMES[Common.rand
          .nextInt(Common.PLANET_NAMES.length)];
      if (!isPlanet(proposedName))
        return proposedName;
      proposedName += " II";
      if (!isPlanet(proposedName))
        return proposedName;
      proposedName += "I";
      if (!isPlanet(proposedName))
        return proposedName;
    }
  }

  /**
   * Returns a random map location without a planet located at it. This method
   * is an infinite loop if the game is configured to have more planets than map
   * locations. To avoid this infinite loop the method only makes a finite
   * number of attempts to find an empty location.
   * 
   * @return a location without a planet on it.
   * @throws IllegalStateException
   *           if more than 1000 attempts to place the planet are made (likely
   *           indicator of an infinite loop).
   */
  private Location getRandomLocationWithoutAPlanet() {
    int fail_fast = 0; // avoid infinite loop
    Location proposedLocation;
    do {
      proposedLocation = Location.getRandomInstance();
      if (fail_fast++ > 1000) {
        throw new IllegalStateException(
            "getRandomLocationWithoutAPlanet() loop stopped..."
                + "do you have more planets than map locations?");
      }
    } while (getPlanetAt(proposedLocation) != null);
    return proposedLocation;
  }
}
