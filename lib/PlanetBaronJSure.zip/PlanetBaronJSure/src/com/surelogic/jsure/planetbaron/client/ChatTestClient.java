package com.surelogic.jsure.planetbaron.client;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.text.JTextComponent;

import com.surelogic.jsure.planetbaron.client.communication.IDisconnect;
import com.surelogic.jsure.planetbaron.client.communication.IResponse;
import com.surelogic.jsure.planetbaron.client.communication.ServerProxy;
import com.surelogic.jsure.planetbaron.protocol.ConsoleOnlyCommand;
import com.surelogic.jsure.planetbaron.protocol.ProtocolFacade;
import com.surelogic.jsure.planetbaron.protocol.ServerCommand;
import com.surelogic.jsure.planetbaron.protocol.ServerResponse;
import com.surelogic.jsure.planetbaron.util.Common;
import com.surelogic.jsure.planetbaron.util.ConciseFormatter;

/**
 * A simple client that allows the user to "chat"
 * 
 * @author T.J. Halloran
 */
public final class ChatTestClient extends JFrame implements IResponse,
		IDisconnect {

	public static void main(String[] args) {
		// run the application
		new ChatTestClient();
	}

	private static final long serialVersionUID = 3978144344198624565L;

	private static final Logger LOG = ConciseFormatter.getLogger("client");

	Socket f_serverSocket = null;

	ServerProxy f_proxy = null;

	volatile boolean f_connectedToGameServer = false;

	FocusListener f_selectOnFocus = new FocusListener() {

		public void focusGained(FocusEvent e) {
			((JTextComponent) e.getSource()).selectAll();
		}

		public void focusLost(FocusEvent e) {
		}
	};

	JLabel f_hostLabel = new JLabel("Host:");

	JTextField f_hostField = new JTextField();

	JLabel f_portLabel = new JLabel("Port:");

	JTextField f_portField = new JTextField();

	JButton f_connectDisconnectButton = new JButton("Connect");

	JLabel f_commandLabel = new JLabel("Enter command:");

	JTextField f_commandField = new JTextField();

	JButton f_sendButton = new JButton("Send");

	JScrollPane f_scroll;

	JTextArea f_serverResponsesTextArea = new JTextArea("");

	StringBuilder f_serverResponses = new StringBuilder();

	private ChatTestClient() {
		super("ChatTest - FleetBaron");

		// set the icon for the application
		ImageIcon image = new ImageIcon(this.getClass().getResource(
				"/media/ship.png"));
		this.setIconImage(image.getImage());

		// we'll use a fixed font for dialog entry and messages
		Font fixed = new Font("Courier", Font.PLAIN, 14);

		// setup the main application panel
		JPanel p1 = new JPanel();
		p1.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = c.gridy = 0;
		c.insets = new Insets(10, 5, 10, 5);
		c.anchor = GridBagConstraints.CENTER;
		// 1st row: Host: [___] Port: [___] [Connect]
		c.weightx = 0;
		p1.add(f_hostLabel, c);
		c.gridx = 1;
		c.weightx = 0.5;
		c.fill = GridBagConstraints.HORIZONTAL;
		f_hostField.setFont(fixed);
		f_hostField.setText("localhost");
		f_hostField.addFocusListener(f_selectOnFocus);
		p1.add(f_hostField, c);
		c.gridx = 2;
		c.weightx = 0;
		c.fill = GridBagConstraints.NONE;
		p1.add(f_portLabel, c);
		c.gridx = 3;
		c.weightx = 0.5;
		c.fill = GridBagConstraints.HORIZONTAL;
		f_portField.setFont(fixed);
		f_portField.setText(Common.DEFAULT_PORT + "");
		f_portField.addFocusListener(f_selectOnFocus);
		p1.add(f_portField, c);
		c.gridx = 4;
		c.weightx = 0;
		c.fill = GridBagConstraints.NONE;
		f_connectDisconnectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (f_connectedToGameServer) {
					// user pressed button to disconnect
					f_proxy.shutdown(); // will callback our
					// disconnectCallback()
				} else {
					setConnectionPanelEnabled(false);
					connectToServer();
				}
			}
		});
		p1.add(f_connectDisconnectButton, c);
		// 2nd row: Enter command: [____] [Send]
		c.gridy = 1;
		c.gridx = 0;
		c.weightx = 0;
		p1.add(f_commandLabel, c);
		c.gridx = 1;
		c.weightx = 1;
		c.gridwidth = 3;
		c.fill = GridBagConstraints.HORIZONTAL;
		p1.add(f_commandField, c);
		f_commandField.setFont(fixed);
		f_commandField.addFocusListener(f_selectOnFocus);
		c.gridx = 4;
		c.weightx = 0;
		c.fill = GridBagConstraints.NONE;
		p1.add(f_sendButton, c);
		f_sendButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String commandForServer = f_commandField.getText();
				f_commandField.setText(""); // clear input field on the screen

				if (f_proxy != null && !commandForServer.trim().equals("")) {
					LOG.info("sending command \"" + commandForServer + "\"");
					try {
						ServerCommand command = ProtocolFacade
								.parseServerCommand(commandForServer);
						if (!(command instanceof ConsoleOnlyCommand)) {
							f_proxy.sendCommand(command, ChatTestClient.this);
						} else {
							String msg = "\""
									+ commandForServer
									+ "\" does not have a response which can be parsed.";
							f_serverResponses.insert(0, msg);
							f_serverResponsesTextArea.setText(msg);
							SwingUtilities.invokeLater(new Runnable() {
								public void run() {
									f_serverResponsesTextArea.invalidate();
								}
							});
						}
					} catch (IllegalArgumentException e) {
						StringBuilder text = new StringBuilder();
						text
								.append("Invalid command to the game server (doesn't parse)\n"
										+ e.getMessage());
						f_serverResponses.insert(0, text.toString());
						f_serverResponsesTextArea.setText(text.toString());
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								f_serverResponsesTextArea.invalidate();
							}
						});
					}
				}
			}
		});
		getContentPane().add(p1, BorderLayout.NORTH);
		setConnectionPanelEnabled(true);
		setCommandPanelEnabled(false);

		JPanel p2 = new JPanel();
		p2.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED),
				"Last server response:"));
		p2.setLayout(new GridBagLayout());
		c = new GridBagConstraints();
		c.weightx = c.weighty = 1;
		c.fill = GridBagConstraints.BOTH;
		f_serverResponsesTextArea.setEditable(false);
		f_serverResponsesTextArea.setFont(fixed);
		f_scroll = new JScrollPane(f_serverResponsesTextArea);
		p2.add(f_scroll, c);
		getContentPane().add(p2, BorderLayout.CENTER);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		addWindowListener(new WindowAdapter() {

			public void windowClosed(WindowEvent e) {
				LOG
						.info("window closing...shutting down connection with the server");
				if (f_proxy != null) {
					f_proxy.shutdown();
				}
				if (f_serverSocket != null) {
					try {
						f_serverSocket.close();
					} catch (IOException e1) {
						LOG.log(Level.WARNING,
								"problem closing socket to server", e);
					}
				}
				System.exit(0); // end the program
			}
		});

		setSize(600, 500);
		setVisible(true);
	}

	/**
	 * Attempts to connect to the game server with the information the user
	 * entered into the <code>m_hostField</code> and <code>m_portField</code>
	 * fields.
	 */
	private void connectToServer() {
		String host = f_hostField.getText();
		String portString = f_portField.getText();
		try {
			int port = Integer.parseInt(portString);
			f_serverSocket = new Socket(host, port);
			f_proxy = new ServerProxy(f_serverSocket);
			f_proxy.register(this);
			f_connectedToGameServer = true;
			setCommandPanelEnabled(true);
			LOG.info("server proxy has been connected to "
					+ f_serverSocket.getInetAddress() + ":"
					+ f_serverSocket.getPort());
		} catch (UnknownHostException e) {
			LOG.log(Level.SEVERE, "unknown game server host", e);
			JOptionPane.showMessageDialog(this, "Game server \"" + host
					+ "\" can't be located on the network", "Unknown Host",
					JOptionPane.ERROR_MESSAGE);
			setConnectionPanelEnabled(true);
		} catch (IOException e) {
			LOG.log(Level.SEVERE, "general I/O failure on game server socket",
					e);
			JOptionPane.showMessageDialog(this,
					"General I/O failure on game server socket"
							+ "...the server may be down",
					"Server I/O Failure", JOptionPane.ERROR_MESSAGE);
			setConnectionPanelEnabled(true);
		} catch (NumberFormatException e) {
			LOG.log(Level.SEVERE, "user provided an invalid port number: \""
					+ portString + "\"", e);
			JOptionPane.showMessageDialog(this, "Port \"" + portString
					+ "\" is not a valid port number", "Invalid Port Number",
					JOptionPane.ERROR_MESSAGE);
			setConnectionPanelEnabled(true);
		}
	}

	/**
	 * Callback from the server proxy notifying us that our message was sent to
	 * the game server and that a reply has occurred.
	 * 
	 * @see ServerProxy
	 */
	public void responseCallback(String serverMessageSent,
			ServerResponse response) {

	}

	public void process(ServerProxy proxy, ServerCommand command,
			ServerResponse response) {
		StringBuilder text = new StringBuilder();
		text.append("message \"" + command + "\" sent OK to the game server\n");
		text.append("game server says \n" + response);
		f_serverResponses.insert(0, text.toString());
		f_serverResponsesTextArea.setText(text.toString());
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				f_serverResponsesTextArea.invalidate();
			}
		});
	}

	public void disconnected(ServerProxy proxy) {
		// note we are disconnected
		LOG.info("server proxy has been disconnected from the game server");
		f_connectedToGameServer = false;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				// set our panel state properly
				setConnectionPanelEnabled(true);
				setCommandPanelEnabled(false);
				JOptionPane.showMessageDialog(ChatTestClient.this,
						"The game server has disconnected from this client",
						"Game Server Disconnected",
						JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}

	/**
	 * Utility method to set the state of the connection portion of the
	 * application panel.
	 * 
	 * @param b
	 *            <code>true</code> if the connection portion is enabled,
	 *            <code>false</code> otherwise
	 */
	private void setConnectionPanelEnabled(boolean b) {
		if (b) {
			f_connectDisconnectButton.setText("Connect");
			this.getRootPane().setDefaultButton(f_connectDisconnectButton);
		} else {
			f_connectDisconnectButton.setText("Disconnect");
		}
		f_hostLabel.setEnabled(b);
		f_hostField.setEnabled(b);
		f_portLabel.setEnabled(b);
		f_portField.setEnabled(b);
	}

	/**
	 * Utility method to set the state of the game server command entry portion
	 * of the application panel.
	 * 
	 * @param b
	 *            <code>true</code> if the command portion is enabled,
	 *            <code>false</code> otherwise
	 */
	private void setCommandPanelEnabled(boolean b) {
		f_commandLabel.setEnabled(b);
		f_commandField.setEnabled(b);
		f_sendButton.setEnabled(b);
		if (b) {
			this.getRootPane().setDefaultButton(f_sendButton);
			f_commandField.requestFocus(); // we want to type a command
		} else {
			f_commandField.setText("");
		}
	}
}
