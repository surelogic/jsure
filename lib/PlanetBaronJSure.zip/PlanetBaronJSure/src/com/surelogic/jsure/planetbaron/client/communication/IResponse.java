package com.surelogic.jsure.planetbaron.client.communication;

import com.surelogic.jsure.planetbaron.protocol.ServerCommand;
import com.surelogic.jsure.planetbaron.protocol.ServerResponse;

/**
 * Interface implemented by classes that need to respond to commands sent to the
 * game server.
 * 
 * @author T.J. Halloran
 */
public interface IResponse {
  /**
   * Called after the server responds to a command to allow client processing of
   * the response.
   * <p>
   * The thread this callback is invoked from within will not be the thread
   * which asked for the message to be sent.
   * 
   * @param proxy
   *          the proxy that disconnected from the server.
   * @param command
   *          the command sent to the server.
   * @param response
   *          the server response.
   */
  void process(ServerProxy proxy, ServerCommand command, ServerResponse response);
}
