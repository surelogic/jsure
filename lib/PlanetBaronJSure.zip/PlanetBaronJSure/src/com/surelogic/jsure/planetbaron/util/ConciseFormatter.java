package com.surelogic.jsure.planetbaron.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.*;

/**
 * A more concise formatter usable by the java.util.logging API.
 * 
 * @author T.J. Halloran
 */
public final class ConciseFormatter extends Formatter {

  /**
   * Everyone can reuse the same instance of this formatter because the format()
   * method uses no instance state.
   */
  public static final ConciseFormatter INSTANCE = new ConciseFormatter();

  /**
   * A simple cache of loggers we have already configured.
   */
  public static final Map<String, Logger> nameToLogger = new HashMap<String, Logger>();

  /**
   * Find or create a logger for a named subsystem. If a logger has already been
   * created with the given name it is returned. Otherwise a new logger is
   * created. If a new logger is created its log level will be configured to use
   * a concise output format to the console (defined by this class) and it will
   * <i>not </i> send logging output to its parent's handlers. It will be
   * registered in the LogManager global namespace.
   * 
   * @param name
   *          name for the logger. This should be a dot-separated name and
   *          should normally be based on the package name or class name of the
   *          subsystem, such as java.net or javax.swing
   * @return a suitable Logger
   * @throws NullPointerException
   *           if the name is null
   */
  public static Logger getLogger(String name) {
    Logger resultLogger = nameToLogger.get(name); // lookup in cache
    if (resultLogger == null) {
      resultLogger = Logger.getLogger(name);
      resultLogger.setUseParentHandlers(false);
      Handler consoleHandler = new ConsoleHandler();
      consoleHandler.setFormatter(INSTANCE);
      resultLogger.addHandler(consoleHandler);
      nameToLogger.put(name, resultLogger); // add to cache
    }
    return resultLogger;
  }

  /**
   * Format the given log record and return the formatted string. The resulting
   * formatted String for a ConciseFormatter outputs single lines using the
   * following pattern:
   * <p>[ <i>LEVEL </i>" <i>thread name </i>"] <i>message </i>[
   * <i>package.class.method() <i>]
   * <p>
   * The Formatter.formatMessage() convenience method is used to localize and
   * format the message field.
   * 
   * @param record
   *          the log record to be formatted
   * @return the formatted log record
   */
  public String format(LogRecord record) {
    StringBuilder buf = new StringBuilder(1000);
    buf.append("[");
    buf.append(record.getLevel().getName());
    buf.append(" \"");
    buf.append(Thread.currentThread().getName());
    buf.append("\"] ");
    buf.append(formatMessage(record));
    buf.append(" [");
    buf.append(record.getSourceClassName());
    buf.append(".");
    buf.append(record.getSourceMethodName());
    buf.append("()]");
    buf.append('\n');
    Throwable t = record.getThrown();
    if (t != null) {
      StringWriter sw = new StringWriter();
      t.printStackTrace(new PrintWriter(sw));
      buf.append(sw.toString());
    }
    return buf.toString();
  }
}
