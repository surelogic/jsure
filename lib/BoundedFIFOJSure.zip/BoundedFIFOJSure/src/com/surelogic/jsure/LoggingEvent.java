package com.surelogic.jsure;

public class LoggingEvent {
  // This class is not interesting
}
