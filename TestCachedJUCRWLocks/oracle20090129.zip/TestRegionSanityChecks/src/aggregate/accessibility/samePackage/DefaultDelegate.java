package aggregate.accessibility.samePackage;

import com.surelogic.Region;

@Region("DefaultAgg")
public class DefaultDelegate {
}
