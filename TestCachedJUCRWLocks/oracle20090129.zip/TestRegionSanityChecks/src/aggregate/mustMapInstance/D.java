package aggregate.mustMapInstance;

public class D {
  protected int f1;
  protected int f2;
}
