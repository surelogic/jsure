package test;

import com.surelogic.AssumeFinal;
import com.surelogic.PolicyLock;

@PolicyLock("BadFinalLock is lock")
public class BadFinalPolicy {

	@AssumeFinal
	private Object lock;

	// Called only once at startup
	public void setLock(Object value) {
		lock = value;
	}

	public void tick() {
		synchronized (lock) {
			// do stuff
		}
	}
}
