package anotherPackage;

import testMethodRefs.HasRequiresLock;

public class UseMethod {
	static void main() {
		HasRequiresLock hsl = new HasRequiresLock();
		synchronized (hsl) {
			hsl.foo();
		}
	}
}
