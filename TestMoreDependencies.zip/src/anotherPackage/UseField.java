package anotherPackage;

import testFieldRefs.HasARegionDecl;

public class UseField extends HasARegionDecl {
	UseField() {
		field = this;
	}
}
