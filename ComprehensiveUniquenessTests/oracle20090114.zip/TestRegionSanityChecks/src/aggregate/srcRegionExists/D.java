package aggregate.srcRegionExists;

import com.surelogic.Region;

@Region("public FromD")
public class D extends C {
  protected int fromD;
  // Do nothing
}
