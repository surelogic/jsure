package test;

import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.Regions;

@Regions({
  @Region("public B"),
  @Region("public C"),
  @Region("public static S2"),
  @Region("public F extends S2")
})
public class C2 {
  @InRegion("S2")
  protected static int static3;
  
  @InRegion("B")
  protected int i;
  
  @InRegion("C")
  protected int j;
  
  @InRegion("F")
  protected int l;
}
