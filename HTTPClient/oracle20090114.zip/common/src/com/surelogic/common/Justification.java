package com.surelogic.common;

/**
 * Used to represent text justification in an IDE independent manner.
 */
public enum Justification {
	RIGHT, LEFT, CENTER
}
