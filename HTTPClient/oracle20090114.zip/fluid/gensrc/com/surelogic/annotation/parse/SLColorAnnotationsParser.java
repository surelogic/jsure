// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g 2008-09-25 15:48:57

package com.surelogic.annotation.parse;

import edu.cmu.cs.fluid.ir.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class SLColorAnnotationsParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "START_IMAGINARY", "TestResult", "QualifiedRegionName", "RegionSpecifications", "RegionName", "NamedType", "ColorName", "ColorSimpleNames", "ColorDeclaration", "ColorGrant", "ColorRevoke", "ColorIncompatible", "ColorNot", "ColorAnd", "ColorOr", "ColorExpr", "ColorImport", "ColorRename", "ColorCardSpec", "ColorizedRegion", "ColorCR", "ColorConstraint", "Color", "Transparent", "Nothing", "ModulePromise", "ModuleWrapper", "ModuleChoice", "VisClause", "NoVisClause", "Export", "BlockImport", "ExportTo", "OfNamesClause", "Names", "END_IMAGINARY", "COLORDECLARE", "COLOR", "COLORGRANT", "COLORREVOKE", "COLORCONSTRAINT", "COLORINCOMPATIBLE", "COLORRENAME", "COLORIMPORT", "COLORCARD", "COLORIZED", "COLORCONSTRAINEDREGIONS", "COLORTRANSPARENT", "MODULE", "VIS", "NOVIS", "EXPORT", "BLOCKIMPORT", "CONTAINS", "FROM", "OF", "TO", "INSTANCE", "IDENTIFIER", "LBRACKET", "RBRACKET", "LPAREN", "RPAREN", "FOR", "QUOTE", "STAR", "HexDigit", "LETTER", "JavaIDDigit", "ID", "'is'", "'&'", "':'", "'/*'", "'/**'", "'.'", "','", "'!'", "'|'", "'1'"
    };
    public static final int COLORREVOKE=43;
    public static final int ColorRename=21;
    public static final int HexDigit=70;
    public static final int ExportTo=36;
    public static final int START_IMAGINARY=4;
    public static final int T__80=80;
    public static final int COLORIMPORT=47;
    public static final int Names=38;
    public static final int ColorExpr=19;
    public static final int LBRACKET=63;
    public static final int INSTANCE=61;
    public static final int EXPORT=55;
    public static final int QualifiedRegionName=6;
    public static final int COLORIZED=49;
    public static final int ModuleWrapper=30;
    public static final int T__74=74;
    public static final int TO=60;
    public static final int ColorCR=24;
    public static final int ModuleChoice=31;
    public static final int NOVIS=54;
    public static final int COLORINCOMPATIBLE=45;
    public static final int Transparent=27;
    public static final int VIS=53;
    public static final int COLORCONSTRAINEDREGIONS=50;
    public static final int RBRACKET=64;
    public static final int MODULE=52;
    public static final int RPAREN=66;
    public static final int CONTAINS=57;
    public static final int LPAREN=65;
    public static final int COLORDECLARE=40;
    public static final int RegionName=8;
    public static final int Nothing=28;
    public static final int BlockImport=35;
    public static final int VisClause=32;
    public static final int Export=34;
    public static final int BLOCKIMPORT=56;
    public static final int ColorSimpleNames=11;
    public static final int COLORGRANT=42;
    public static final int COLORTRANSPARENT=51;
    public static final int ID=73;
    public static final int FROM=58;
    public static final int RegionSpecifications=7;
    public static final int OfNamesClause=37;
    public static final int ColorName=10;
    public static final int LETTER=71;
    public static final int Color=26;
    public static final int ColorNot=16;
    public static final int ColorizedRegion=23;
    public static final int T__78=78;
    public static final int ColorDeclaration=12;
    public static final int ColorConstraint=25;
    public static final int END_IMAGINARY=39;
    public static final int NoVisClause=33;
    public static final int T__79=79;
    public static final int ColorOr=18;
    public static final int ColorIncompatible=15;
    public static final int OF=59;
    public static final int NamedType=9;
    public static final int COLORCARD=48;
    public static final int ColorCardSpec=22;
    public static final int QUOTE=68;
    public static final int COLORRENAME=46;
    public static final int T__77=77;
    public static final int TestResult=5;
    public static final int JavaIDDigit=72;
    public static final int ColorImport=20;
    public static final int COLORCONSTRAINT=44;
    public static final int T__75=75;
    public static final int EOF=-1;
    public static final int COLOR=41;
    public static final int FOR=67;
    public static final int T__76=76;
    public static final int T__82=82;
    public static final int T__81=81;
    public static final int STAR=69;
    public static final int IDENTIFIER=62;
    public static final int T__83=83;
    public static final int ColorGrant=13;
    public static final int ModulePromise=29;
    public static final int ColorAnd=17;
    public static final int ColorRevoke=14;

    // delegates
    // delegators


        public SLColorAnnotationsParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SLColorAnnotationsParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SLColorAnnotationsParser.tokenNames; }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g"; }


    @Override
    protected void mismatch(IntStream input, int ttype, BitSet follow)
    	throws RecognitionException{
    	throw new MismatchedTokenException(ttype, input);
    }
    @Override
    public Object recoverFromMismatchedSet(IntStream input, RecognitionException e, BitSet follow)
    	throws RecognitionException{
    	reportError(e);
    	throw e;
    }

      IRNode context;
      
      void setContext(IRNode n) {
        context = n;
      }
      
      boolean isType(String prefix, Token id) { 
        return ParseUtil.isType(context, prefix, id.getText());
      }


    public static class testResult_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "testResult"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:137:1: testResult : ( 'is' IDENTIFIER '&' IDENTIFIER ':' -> ^( TestResult IDENTIFIER '&' IDENTIFIER ':' ) | 'is' IDENTIFIER ':' -> ^( TestResult IDENTIFIER ':' ) | 'is' IDENTIFIER '&' IDENTIFIER EOF -> ^( TestResult IDENTIFIER '&' IDENTIFIER ) | 'is' IDENTIFIER EOF -> ^( TestResult IDENTIFIER ) );
    public final SLColorAnnotationsParser.testResult_return testResult() throws RecognitionException {
        SLColorAnnotationsParser.testResult_return retval = new SLColorAnnotationsParser.testResult_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal1=null;
        Token IDENTIFIER2=null;
        Token char_literal3=null;
        Token IDENTIFIER4=null;
        Token char_literal5=null;
        Token string_literal6=null;
        Token IDENTIFIER7=null;
        Token char_literal8=null;
        Token string_literal9=null;
        Token IDENTIFIER10=null;
        Token char_literal11=null;
        Token IDENTIFIER12=null;
        Token EOF13=null;
        Token string_literal14=null;
        Token IDENTIFIER15=null;
        Token EOF16=null;

        Tree string_literal1_tree=null;
        Tree IDENTIFIER2_tree=null;
        Tree char_literal3_tree=null;
        Tree IDENTIFIER4_tree=null;
        Tree char_literal5_tree=null;
        Tree string_literal6_tree=null;
        Tree IDENTIFIER7_tree=null;
        Tree char_literal8_tree=null;
        Tree string_literal9_tree=null;
        Tree IDENTIFIER10_tree=null;
        Tree char_literal11_tree=null;
        Tree IDENTIFIER12_tree=null;
        Tree EOF13_tree=null;
        Tree string_literal14_tree=null;
        Tree IDENTIFIER15_tree=null;
        Tree EOF16_tree=null;
        RewriteRuleTokenStream stream_76=new RewriteRuleTokenStream(adaptor,"token 76");
        RewriteRuleTokenStream stream_74=new RewriteRuleTokenStream(adaptor,"token 74");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_75=new RewriteRuleTokenStream(adaptor,"token 75");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:142:3: ( 'is' IDENTIFIER '&' IDENTIFIER ':' -> ^( TestResult IDENTIFIER '&' IDENTIFIER ':' ) | 'is' IDENTIFIER ':' -> ^( TestResult IDENTIFIER ':' ) | 'is' IDENTIFIER '&' IDENTIFIER EOF -> ^( TestResult IDENTIFIER '&' IDENTIFIER ) | 'is' IDENTIFIER EOF -> ^( TestResult IDENTIFIER ) )
            int alt1=4;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==74) ) {
                int LA1_1 = input.LA(2);

                if ( (LA1_1==IDENTIFIER) ) {
                    switch ( input.LA(3) ) {
                    case 75:
                        {
                        int LA1_3 = input.LA(4);

                        if ( (LA1_3==IDENTIFIER) ) {
                            int LA1_6 = input.LA(5);

                            if ( (LA1_6==76) ) {
                                alt1=1;
                            }
                            else if ( (LA1_6==EOF) ) {
                                alt1=3;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 1, 6, input);

                                throw nvae;
                            }
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 1, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    case 76:
                        {
                        alt1=2;
                        }
                        break;
                    case EOF:
                        {
                        alt1=4;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 1, 2, input);

                        throw nvae;
                    }

                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:142:5: 'is' IDENTIFIER '&' IDENTIFIER ':'
                    {
                    string_literal1=(Token)match(input,74,FOLLOW_74_in_testResult495);  
                    stream_74.add(string_literal1);

                    IDENTIFIER2=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult497);  
                    stream_IDENTIFIER.add(IDENTIFIER2);

                    char_literal3=(Token)match(input,75,FOLLOW_75_in_testResult499);  
                    stream_75.add(char_literal3);

                    IDENTIFIER4=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult501);  
                    stream_IDENTIFIER.add(IDENTIFIER4);

                    char_literal5=(Token)match(input,76,FOLLOW_76_in_testResult503);  
                    stream_76.add(char_literal5);



                    // AST REWRITE
                    // elements: IDENTIFIER, IDENTIFIER, 75, 76
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 142:40: -> ^( TestResult IDENTIFIER '&' IDENTIFIER ':' )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:142:43: ^( TestResult IDENTIFIER '&' IDENTIFIER ':' )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_75.nextNode());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_76.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:143:5: 'is' IDENTIFIER ':'
                    {
                    string_literal6=(Token)match(input,74,FOLLOW_74_in_testResult523);  
                    stream_74.add(string_literal6);

                    IDENTIFIER7=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult525);  
                    stream_IDENTIFIER.add(IDENTIFIER7);

                    char_literal8=(Token)match(input,76,FOLLOW_76_in_testResult527);  
                    stream_76.add(char_literal8);



                    // AST REWRITE
                    // elements: 76, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 143:25: -> ^( TestResult IDENTIFIER ':' )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:143:28: ^( TestResult IDENTIFIER ':' )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_76.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:144:5: 'is' IDENTIFIER '&' IDENTIFIER EOF
                    {
                    string_literal9=(Token)match(input,74,FOLLOW_74_in_testResult543);  
                    stream_74.add(string_literal9);

                    IDENTIFIER10=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult545);  
                    stream_IDENTIFIER.add(IDENTIFIER10);

                    char_literal11=(Token)match(input,75,FOLLOW_75_in_testResult547);  
                    stream_75.add(char_literal11);

                    IDENTIFIER12=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult549);  
                    stream_IDENTIFIER.add(IDENTIFIER12);

                    EOF13=(Token)match(input,EOF,FOLLOW_EOF_in_testResult551);  
                    stream_EOF.add(EOF13);



                    // AST REWRITE
                    // elements: IDENTIFIER, 75, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 144:40: -> ^( TestResult IDENTIFIER '&' IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:144:43: ^( TestResult IDENTIFIER '&' IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_75.nextNode());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:145:5: 'is' IDENTIFIER EOF
                    {
                    string_literal14=(Token)match(input,74,FOLLOW_74_in_testResult569);  
                    stream_74.add(string_literal14);

                    IDENTIFIER15=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult571);  
                    stream_IDENTIFIER.add(IDENTIFIER15);

                    EOF16=(Token)match(input,EOF,FOLLOW_EOF_in_testResult573);  
                    stream_EOF.add(EOF16);



                    // AST REWRITE
                    // elements: IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 145:25: -> ^( TestResult IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:145:28: ^( TestResult IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "testResult"

    public static class testResultComment_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "testResultComment"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:148:1: testResultComment : ( '/*' | '/**' ) testResult -> testResult ;
    public final SLColorAnnotationsParser.testResultComment_return testResultComment() throws RecognitionException {
        SLColorAnnotationsParser.testResultComment_return retval = new SLColorAnnotationsParser.testResultComment_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal17=null;
        Token string_literal18=null;
        SLColorAnnotationsParser.testResult_return testResult19 = null;


        Tree string_literal17_tree=null;
        Tree string_literal18_tree=null;
        RewriteRuleTokenStream stream_77=new RewriteRuleTokenStream(adaptor,"token 77");
        RewriteRuleTokenStream stream_78=new RewriteRuleTokenStream(adaptor,"token 78");
        RewriteRuleSubtreeStream stream_testResult=new RewriteRuleSubtreeStream(adaptor,"rule testResult");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:149:3: ( ( '/*' | '/**' ) testResult -> testResult )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:149:5: ( '/*' | '/**' ) testResult
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:149:5: ( '/*' | '/**' )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==77) ) {
                alt2=1;
            }
            else if ( (LA2_0==78) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:149:6: '/*'
                    {
                    string_literal17=(Token)match(input,77,FOLLOW_77_in_testResultComment597);  
                    stream_77.add(string_literal17);


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:149:13: '/**'
                    {
                    string_literal18=(Token)match(input,78,FOLLOW_78_in_testResultComment601);  
                    stream_78.add(string_literal18);


                    }
                    break;

            }

            pushFollow(FOLLOW_testResult_in_testResultComment609);
            testResult19=testResult();

            state._fsp--;

            stream_testResult.add(testResult19.getTree());


            // AST REWRITE
            // elements: testResult
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 150:16: -> testResult
            {
                adaptor.addChild(root_0, stream_testResult.nextTree());

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "testResultComment"

    public static class qualifiedName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:153:1: qualifiedName : IDENTIFIER ( options {greedy=false; } : ( '.' IDENTIFIER ) )+ ;
    public final SLColorAnnotationsParser.qualifiedName_return qualifiedName() throws RecognitionException {
        SLColorAnnotationsParser.qualifiedName_return retval = new SLColorAnnotationsParser.qualifiedName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER20=null;
        Token char_literal21=null;
        Token IDENTIFIER22=null;

        Tree IDENTIFIER20_tree=null;
        Tree char_literal21_tree=null;
        Tree IDENTIFIER22_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:157:2: ( IDENTIFIER ( options {greedy=false; } : ( '.' IDENTIFIER ) )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:157:4: IDENTIFIER ( options {greedy=false; } : ( '.' IDENTIFIER ) )+
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER20=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName629); 
            IDENTIFIER20_tree = (Tree)adaptor.create(IDENTIFIER20);
            adaptor.addChild(root_0, IDENTIFIER20_tree);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:157:15: ( options {greedy=false; } : ( '.' IDENTIFIER ) )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==79) ) {
                    alt3=1;
                }
                else if ( (LA3_0==EOF||(LA3_0>=RPAREN && LA3_0<=FOR)||(LA3_0>=75 && LA3_0<=76)||LA3_0==80||LA3_0==82) ) {
                    alt3=2;
                }


                switch (alt3) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:157:43: ( '.' IDENTIFIER )
            	    {
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:157:43: ( '.' IDENTIFIER )
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:157:44: '.' IDENTIFIER
            	    {
            	    char_literal21=(Token)match(input,79,FOLLOW_79_in_qualifiedName643); 
            	    char_literal21_tree = (Tree)adaptor.create(char_literal21);
            	    adaptor.addChild(root_0, char_literal21_tree);

            	    IDENTIFIER22=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName645); 
            	    IDENTIFIER22_tree = (Tree)adaptor.create(IDENTIFIER22);
            	    adaptor.addChild(root_0, IDENTIFIER22_tree);


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedName"

    public static class simpleName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:160:1: simpleName : IDENTIFIER ;
    public final SLColorAnnotationsParser.simpleName_return simpleName() throws RecognitionException {
        SLColorAnnotationsParser.simpleName_return retval = new SLColorAnnotationsParser.simpleName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER23=null;

        Tree IDENTIFIER23_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:161:7: ( IDENTIFIER )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:161:9: IDENTIFIER
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER23=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleName666); 
            IDENTIFIER23_tree = (Tree)adaptor.create(IDENTIFIER23);
            adaptor.addChild(root_0, IDENTIFIER23_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleName"

    public static class name_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "name"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:164:1: name : IDENTIFIER ( '.' IDENTIFIER )* ;
    public final SLColorAnnotationsParser.name_return name() throws RecognitionException {
        SLColorAnnotationsParser.name_return retval = new SLColorAnnotationsParser.name_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER24=null;
        Token char_literal25=null;
        Token IDENTIFIER26=null;

        Tree IDENTIFIER24_tree=null;
        Tree char_literal25_tree=null;
        Tree IDENTIFIER26_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:165:2: ( IDENTIFIER ( '.' IDENTIFIER )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:166:4: IDENTIFIER ( '.' IDENTIFIER )*
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER24=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_name690); 
            IDENTIFIER24_tree = (Tree)adaptor.create(IDENTIFIER24);
            adaptor.addChild(root_0, IDENTIFIER24_tree);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:166:15: ( '.' IDENTIFIER )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==79) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:166:16: '.' IDENTIFIER
            	    {
            	    char_literal25=(Token)match(input,79,FOLLOW_79_in_name693); 
            	    char_literal25_tree = (Tree)adaptor.create(char_literal25);
            	    adaptor.addChild(root_0, char_literal25_tree);

            	    IDENTIFIER26=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_name695); 
            	    IDENTIFIER26_tree = (Tree)adaptor.create(IDENTIFIER26);
            	    adaptor.addChild(root_0, IDENTIFIER26_tree);


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "name"

    public static class qualifiedNamedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedNamedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:169:1: qualifiedNamedType : qualifiedName -> ^( NamedType qualifiedName ) ;
    public final SLColorAnnotationsParser.qualifiedNamedType_return qualifiedNamedType() throws RecognitionException {
        SLColorAnnotationsParser.qualifiedNamedType_return retval = new SLColorAnnotationsParser.qualifiedNamedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLColorAnnotationsParser.qualifiedName_return qualifiedName27 = null;


        RewriteRuleSubtreeStream stream_qualifiedName=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:173:2: ( qualifiedName -> ^( NamedType qualifiedName ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:173:4: qualifiedName
            {
            pushFollow(FOLLOW_qualifiedName_in_qualifiedNamedType711);
            qualifiedName27=qualifiedName();

            state._fsp--;

            stream_qualifiedName.add(qualifiedName27.getTree());


            // AST REWRITE
            // elements: qualifiedName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 173:18: -> ^( NamedType qualifiedName )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:173:21: ^( NamedType qualifiedName )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedType, "NamedType"), root_1);

                adaptor.addChild(root_1, stream_qualifiedName.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedNamedType"

    public static class simpleNamedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleNamedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:176:1: simpleNamedType : IDENTIFIER -> ^( NamedType IDENTIFIER ) ;
    public final SLColorAnnotationsParser.simpleNamedType_return simpleNamedType() throws RecognitionException {
        SLColorAnnotationsParser.simpleNamedType_return retval = new SLColorAnnotationsParser.simpleNamedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER28=null;

        Tree IDENTIFIER28_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:177:2: ( IDENTIFIER -> ^( NamedType IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:177:4: IDENTIFIER
            {
            IDENTIFIER28=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleNamedType732);  
            stream_IDENTIFIER.add(IDENTIFIER28);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 177:15: -> ^( NamedType IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:177:18: ^( NamedType IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedType, "NamedType"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleNamedType"

    public static class qualifiedRegionName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedRegionName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:180:1: qualifiedRegionName : ( qualifiedNamedType ':' IDENTIFIER -> ^( QualifiedRegionName qualifiedNamedType IDENTIFIER ) | simpleNamedType ':' IDENTIFIER -> ^( QualifiedRegionName simpleNamedType IDENTIFIER ) );
    public final SLColorAnnotationsParser.qualifiedRegionName_return qualifiedRegionName() throws RecognitionException {
        SLColorAnnotationsParser.qualifiedRegionName_return retval = new SLColorAnnotationsParser.qualifiedRegionName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal30=null;
        Token IDENTIFIER31=null;
        Token char_literal33=null;
        Token IDENTIFIER34=null;
        SLColorAnnotationsParser.qualifiedNamedType_return qualifiedNamedType29 = null;

        SLColorAnnotationsParser.simpleNamedType_return simpleNamedType32 = null;


        Tree char_literal30_tree=null;
        Tree IDENTIFIER31_tree=null;
        Tree char_literal33_tree=null;
        Tree IDENTIFIER34_tree=null;
        RewriteRuleTokenStream stream_76=new RewriteRuleTokenStream(adaptor,"token 76");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_qualifiedNamedType=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedNamedType");
        RewriteRuleSubtreeStream stream_simpleNamedType=new RewriteRuleSubtreeStream(adaptor,"rule simpleNamedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:181:2: ( qualifiedNamedType ':' IDENTIFIER -> ^( QualifiedRegionName qualifiedNamedType IDENTIFIER ) | simpleNamedType ':' IDENTIFIER -> ^( QualifiedRegionName simpleNamedType IDENTIFIER ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==IDENTIFIER) ) {
                int LA5_1 = input.LA(2);

                if ( (LA5_1==79) ) {
                    alt5=1;
                }
                else if ( (LA5_1==76) ) {
                    alt5=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 5, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:181:4: qualifiedNamedType ':' IDENTIFIER
                    {
                    pushFollow(FOLLOW_qualifiedNamedType_in_qualifiedRegionName752);
                    qualifiedNamedType29=qualifiedNamedType();

                    state._fsp--;

                    stream_qualifiedNamedType.add(qualifiedNamedType29.getTree());
                    char_literal30=(Token)match(input,76,FOLLOW_76_in_qualifiedRegionName754);  
                    stream_76.add(char_literal30);

                    IDENTIFIER31=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedRegionName756);  
                    stream_IDENTIFIER.add(IDENTIFIER31);



                    // AST REWRITE
                    // elements: IDENTIFIER, qualifiedNamedType
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 181:38: -> ^( QualifiedRegionName qualifiedNamedType IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:181:41: ^( QualifiedRegionName qualifiedNamedType IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedRegionName, "QualifiedRegionName"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedNamedType.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:182:4: simpleNamedType ':' IDENTIFIER
                    {
                    pushFollow(FOLLOW_simpleNamedType_in_qualifiedRegionName771);
                    simpleNamedType32=simpleNamedType();

                    state._fsp--;

                    stream_simpleNamedType.add(simpleNamedType32.getTree());
                    char_literal33=(Token)match(input,76,FOLLOW_76_in_qualifiedRegionName773);  
                    stream_76.add(char_literal33);

                    IDENTIFIER34=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedRegionName775);  
                    stream_IDENTIFIER.add(IDENTIFIER34);



                    // AST REWRITE
                    // elements: IDENTIFIER, simpleNamedType
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 182:35: -> ^( QualifiedRegionName simpleNamedType IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:182:38: ^( QualifiedRegionName simpleNamedType IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedRegionName, "QualifiedRegionName"), root_1);

                        adaptor.addChild(root_1, stream_simpleNamedType.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedRegionName"

    public static class regionSpecifications_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionSpecifications"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:185:1: regionSpecifications : regionSpecification ( ',' regionSpecification )* -> ^( RegionSpecifications ( regionSpecification )+ ) ;
    public final SLColorAnnotationsParser.regionSpecifications_return regionSpecifications() throws RecognitionException {
        SLColorAnnotationsParser.regionSpecifications_return retval = new SLColorAnnotationsParser.regionSpecifications_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal36=null;
        SLColorAnnotationsParser.regionSpecification_return regionSpecification35 = null;

        SLColorAnnotationsParser.regionSpecification_return regionSpecification37 = null;


        Tree char_literal36_tree=null;
        RewriteRuleTokenStream stream_80=new RewriteRuleTokenStream(adaptor,"token 80");
        RewriteRuleSubtreeStream stream_regionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:186:2: ( regionSpecification ( ',' regionSpecification )* -> ^( RegionSpecifications ( regionSpecification )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:186:4: regionSpecification ( ',' regionSpecification )*
            {
            pushFollow(FOLLOW_regionSpecification_in_regionSpecifications796);
            regionSpecification35=regionSpecification();

            state._fsp--;

            stream_regionSpecification.add(regionSpecification35.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:186:24: ( ',' regionSpecification )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==80) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:186:25: ',' regionSpecification
            	    {
            	    char_literal36=(Token)match(input,80,FOLLOW_80_in_regionSpecifications799);  
            	    stream_80.add(char_literal36);

            	    pushFollow(FOLLOW_regionSpecification_in_regionSpecifications801);
            	    regionSpecification37=regionSpecification();

            	    state._fsp--;

            	    stream_regionSpecification.add(regionSpecification37.getTree());

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);



            // AST REWRITE
            // elements: regionSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 186:51: -> ^( RegionSpecifications ( regionSpecification )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:186:54: ^( RegionSpecifications ( regionSpecification )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionSpecifications, "RegionSpecifications"), root_1);

                if ( !(stream_regionSpecification.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_regionSpecification.hasNext() ) {
                    adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                }
                stream_regionSpecification.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionSpecifications"

    public static class regionSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:189:1: regionSpecification : ( qualifiedRegionName | simpleRegionSpecification );
    public final SLColorAnnotationsParser.regionSpecification_return regionSpecification() throws RecognitionException {
        SLColorAnnotationsParser.regionSpecification_return retval = new SLColorAnnotationsParser.regionSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLColorAnnotationsParser.qualifiedRegionName_return qualifiedRegionName38 = null;

        SLColorAnnotationsParser.simpleRegionSpecification_return simpleRegionSpecification39 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:190:2: ( qualifiedRegionName | simpleRegionSpecification )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==IDENTIFIER) ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==76||LA7_1==79) ) {
                    alt7=1;
                }
                else if ( (LA7_1==EOF||LA7_1==80) ) {
                    alt7=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA7_0==LBRACKET) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:190:4: qualifiedRegionName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedRegionName_in_regionSpecification823);
                    qualifiedRegionName38=qualifiedRegionName();

                    state._fsp--;

                    adaptor.addChild(root_0, qualifiedRegionName38.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:191:4: simpleRegionSpecification
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleRegionSpecification_in_regionSpecification829);
                    simpleRegionSpecification39=simpleRegionSpecification();

                    state._fsp--;

                    adaptor.addChild(root_0, simpleRegionSpecification39.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionSpecification"

    public static class simpleRegionSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleRegionSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:194:1: simpleRegionSpecification : ( regionName | ( LBRACKET RBRACKET ) -> ^( RegionName LBRACKET RBRACKET ) );
    public final SLColorAnnotationsParser.simpleRegionSpecification_return simpleRegionSpecification() throws RecognitionException {
        SLColorAnnotationsParser.simpleRegionSpecification_return retval = new SLColorAnnotationsParser.simpleRegionSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token LBRACKET41=null;
        Token RBRACKET42=null;
        SLColorAnnotationsParser.regionName_return regionName40 = null;


        Tree LBRACKET41_tree=null;
        Tree RBRACKET42_tree=null;
        RewriteRuleTokenStream stream_LBRACKET=new RewriteRuleTokenStream(adaptor,"token LBRACKET");
        RewriteRuleTokenStream stream_RBRACKET=new RewriteRuleTokenStream(adaptor,"token RBRACKET");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:195:2: ( regionName | ( LBRACKET RBRACKET ) -> ^( RegionName LBRACKET RBRACKET ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==IDENTIFIER) ) {
                alt8=1;
            }
            else if ( (LA8_0==LBRACKET) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:195:4: regionName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_regionName_in_simpleRegionSpecification842);
                    regionName40=regionName();

                    state._fsp--;

                    adaptor.addChild(root_0, regionName40.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:196:4: ( LBRACKET RBRACKET )
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:196:4: ( LBRACKET RBRACKET )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:196:5: LBRACKET RBRACKET
                    {
                    LBRACKET41=(Token)match(input,LBRACKET,FOLLOW_LBRACKET_in_simpleRegionSpecification848);  
                    stream_LBRACKET.add(LBRACKET41);

                    RBRACKET42=(Token)match(input,RBRACKET,FOLLOW_RBRACKET_in_simpleRegionSpecification850);  
                    stream_RBRACKET.add(RBRACKET42);


                    }



                    // AST REWRITE
                    // elements: RBRACKET, LBRACKET
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 196:24: -> ^( RegionName LBRACKET RBRACKET )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:196:27: ^( RegionName LBRACKET RBRACKET )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionName, "RegionName"), root_1);

                        adaptor.addChild(root_1, stream_LBRACKET.nextNode());
                        adaptor.addChild(root_1, stream_RBRACKET.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleRegionSpecification"

    public static class regionName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:199:1: regionName : IDENTIFIER -> ^( RegionName IDENTIFIER ) ;
    public final SLColorAnnotationsParser.regionName_return regionName() throws RecognitionException {
        SLColorAnnotationsParser.regionName_return retval = new SLColorAnnotationsParser.regionName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER43=null;

        Tree IDENTIFIER43_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:200:2: ( IDENTIFIER -> ^( RegionName IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:200:4: IDENTIFIER
            {
            IDENTIFIER43=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_regionName872);  
            stream_IDENTIFIER.add(IDENTIFIER43);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 200:15: -> ^( RegionName IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:200:18: ^( RegionName IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionName, "RegionName"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionName"

    public static class colorName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:203:2: colorName : ( qualifiedName -> ^( ColorName qualifiedName ) | simpleName -> ^( ColorName simpleName ) );
    public final SLColorAnnotationsParser.colorName_return colorName() throws RecognitionException {
        SLColorAnnotationsParser.colorName_return retval = new SLColorAnnotationsParser.colorName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLColorAnnotationsParser.qualifiedName_return qualifiedName44 = null;

        SLColorAnnotationsParser.simpleName_return simpleName45 = null;


        RewriteRuleSubtreeStream stream_simpleName=new RewriteRuleSubtreeStream(adaptor,"rule simpleName");
        RewriteRuleSubtreeStream stream_qualifiedName=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:208:3: ( qualifiedName -> ^( ColorName qualifiedName ) | simpleName -> ^( ColorName simpleName ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==IDENTIFIER) ) {
                int LA9_1 = input.LA(2);

                if ( (LA9_1==79) ) {
                    alt9=1;
                }
                else if ( (LA9_1==EOF||(LA9_1>=RPAREN && LA9_1<=FOR)||LA9_1==75||LA9_1==80||LA9_1==82) ) {
                    alt9=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:208:5: qualifiedName
                    {
                    pushFollow(FOLLOW_qualifiedName_in_colorName898);
                    qualifiedName44=qualifiedName();

                    state._fsp--;

                    stream_qualifiedName.add(qualifiedName44.getTree());


                    // AST REWRITE
                    // elements: qualifiedName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 208:19: -> ^( ColorName qualifiedName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:208:22: ^( ColorName qualifiedName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorName, "ColorName"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:209:5: simpleName
                    {
                    pushFollow(FOLLOW_simpleName_in_colorName912);
                    simpleName45=simpleName();

                    state._fsp--;

                    stream_simpleName.add(simpleName45.getTree());


                    // AST REWRITE
                    // elements: simpleName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 209:17: -> ^( ColorName simpleName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:209:20: ^( ColorName simpleName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorName, "ColorName"), root_1);

                        adaptor.addChild(root_1, stream_simpleName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorName"

    public static class colorNames_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorNames"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:212:2: colorNames : colorName ( ',' colorName )* -> ( colorName )+ ;
    public final SLColorAnnotationsParser.colorNames_return colorNames() throws RecognitionException {
        SLColorAnnotationsParser.colorNames_return retval = new SLColorAnnotationsParser.colorNames_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal47=null;
        SLColorAnnotationsParser.colorName_return colorName46 = null;

        SLColorAnnotationsParser.colorName_return colorName48 = null;


        Tree char_literal47_tree=null;
        RewriteRuleTokenStream stream_80=new RewriteRuleTokenStream(adaptor,"token 80");
        RewriteRuleSubtreeStream stream_colorName=new RewriteRuleSubtreeStream(adaptor,"rule colorName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:213:3: ( colorName ( ',' colorName )* -> ( colorName )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:213:5: colorName ( ',' colorName )*
            {
            pushFollow(FOLLOW_colorName_in_colorNames936);
            colorName46=colorName();

            state._fsp--;

            stream_colorName.add(colorName46.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:213:15: ( ',' colorName )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==80) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:213:16: ',' colorName
            	    {
            	    char_literal47=(Token)match(input,80,FOLLOW_80_in_colorNames939);  
            	    stream_80.add(char_literal47);

            	    pushFollow(FOLLOW_colorName_in_colorNames941);
            	    colorName48=colorName();

            	    state._fsp--;

            	    stream_colorName.add(colorName48.getTree());

            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);



            // AST REWRITE
            // elements: colorName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 213:32: -> ( colorName )+
            {
                if ( !(stream_colorName.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_colorName.hasNext() ) {
                    adaptor.addChild(root_0, stream_colorName.nextTree());

                }
                stream_colorName.reset();

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorNames"

    public static class colorSimpleNames_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorSimpleNames"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:216:2: colorSimpleNames : simpleName ( ',' simpleName )* -> ( simpleName )+ ;
    public final SLColorAnnotationsParser.colorSimpleNames_return colorSimpleNames() throws RecognitionException {
        SLColorAnnotationsParser.colorSimpleNames_return retval = new SLColorAnnotationsParser.colorSimpleNames_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal50=null;
        SLColorAnnotationsParser.simpleName_return simpleName49 = null;

        SLColorAnnotationsParser.simpleName_return simpleName51 = null;


        Tree char_literal50_tree=null;
        RewriteRuleTokenStream stream_80=new RewriteRuleTokenStream(adaptor,"token 80");
        RewriteRuleSubtreeStream stream_simpleName=new RewriteRuleSubtreeStream(adaptor,"rule simpleName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:217:3: ( simpleName ( ',' simpleName )* -> ( simpleName )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:217:5: simpleName ( ',' simpleName )*
            {
            pushFollow(FOLLOW_simpleName_in_colorSimpleNames964);
            simpleName49=simpleName();

            state._fsp--;

            stream_simpleName.add(simpleName49.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:217:16: ( ',' simpleName )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==80) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:217:17: ',' simpleName
            	    {
            	    char_literal50=(Token)match(input,80,FOLLOW_80_in_colorSimpleNames967);  
            	    stream_80.add(char_literal50);

            	    pushFollow(FOLLOW_simpleName_in_colorSimpleNames969);
            	    simpleName51=simpleName();

            	    state._fsp--;

            	    stream_simpleName.add(simpleName51.getTree());

            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);



            // AST REWRITE
            // elements: simpleName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 217:34: -> ( simpleName )+
            {
                if ( !(stream_simpleName.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_simpleName.hasNext() ) {
                    adaptor.addChild(root_0, stream_simpleName.nextTree());

                }
                stream_simpleName.reset();

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorSimpleNames"

    public static class colorLit_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorLit"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:220:2: colorLit : ( colorNot -> colorNot | LPAREN colorNot RPAREN -> colorNot | colorName -> colorName | LPAREN colorName RPAREN -> colorName );
    public final SLColorAnnotationsParser.colorLit_return colorLit() throws RecognitionException {
        SLColorAnnotationsParser.colorLit_return retval = new SLColorAnnotationsParser.colorLit_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token LPAREN53=null;
        Token RPAREN55=null;
        Token LPAREN57=null;
        Token RPAREN59=null;
        SLColorAnnotationsParser.colorNot_return colorNot52 = null;

        SLColorAnnotationsParser.colorNot_return colorNot54 = null;

        SLColorAnnotationsParser.colorName_return colorName56 = null;

        SLColorAnnotationsParser.colorName_return colorName58 = null;


        Tree LPAREN53_tree=null;
        Tree RPAREN55_tree=null;
        Tree LPAREN57_tree=null;
        Tree RPAREN59_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_colorName=new RewriteRuleSubtreeStream(adaptor,"rule colorName");
        RewriteRuleSubtreeStream stream_colorNot=new RewriteRuleSubtreeStream(adaptor,"rule colorNot");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:225:3: ( colorNot -> colorNot | LPAREN colorNot RPAREN -> colorNot | colorName -> colorName | LPAREN colorName RPAREN -> colorName )
            int alt12=4;
            switch ( input.LA(1) ) {
            case 81:
                {
                alt12=1;
                }
                break;
            case LPAREN:
                {
                int LA12_2 = input.LA(2);

                if ( (LA12_2==IDENTIFIER) ) {
                    alt12=4;
                }
                else if ( (LA12_2==81) ) {
                    alt12=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 12, 2, input);

                    throw nvae;
                }
                }
                break;
            case IDENTIFIER:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:225:5: colorNot
                    {
                    pushFollow(FOLLOW_colorNot_in_colorLit998);
                    colorNot52=colorNot();

                    state._fsp--;

                    stream_colorNot.add(colorNot52.getTree());


                    // AST REWRITE
                    // elements: colorNot
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 225:14: -> colorNot
                    {
                        adaptor.addChild(root_0, stream_colorNot.nextTree());

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:226:5: LPAREN colorNot RPAREN
                    {
                    LPAREN53=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_colorLit1008);  
                    stream_LPAREN.add(LPAREN53);

                    pushFollow(FOLLOW_colorNot_in_colorLit1010);
                    colorNot54=colorNot();

                    state._fsp--;

                    stream_colorNot.add(colorNot54.getTree());
                    RPAREN55=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_colorLit1012);  
                    stream_RPAREN.add(RPAREN55);



                    // AST REWRITE
                    // elements: colorNot
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 226:28: -> colorNot
                    {
                        adaptor.addChild(root_0, stream_colorNot.nextTree());

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:227:5: colorName
                    {
                    pushFollow(FOLLOW_colorName_in_colorLit1022);
                    colorName56=colorName();

                    state._fsp--;

                    stream_colorName.add(colorName56.getTree());


                    // AST REWRITE
                    // elements: colorName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 227:15: -> colorName
                    {
                        adaptor.addChild(root_0, stream_colorName.nextTree());

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:228:5: LPAREN colorName RPAREN
                    {
                    LPAREN57=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_colorLit1032);  
                    stream_LPAREN.add(LPAREN57);

                    pushFollow(FOLLOW_colorName_in_colorLit1034);
                    colorName58=colorName();

                    state._fsp--;

                    stream_colorName.add(colorName58.getTree());
                    RPAREN59=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_colorLit1036);  
                    stream_RPAREN.add(RPAREN59);



                    // AST REWRITE
                    // elements: colorName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 228:29: -> colorName
                    {
                        adaptor.addChild(root_0, stream_colorName.nextTree());

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorLit"

    public static class colorNot_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorNot"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:231:2: colorNot : '!' colorName -> ^( ColorNot colorName ) ;
    public final SLColorAnnotationsParser.colorNot_return colorNot() throws RecognitionException {
        SLColorAnnotationsParser.colorNot_return retval = new SLColorAnnotationsParser.colorNot_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal60=null;
        SLColorAnnotationsParser.colorName_return colorName61 = null;


        Tree char_literal60_tree=null;
        RewriteRuleTokenStream stream_81=new RewriteRuleTokenStream(adaptor,"token 81");
        RewriteRuleSubtreeStream stream_colorName=new RewriteRuleSubtreeStream(adaptor,"rule colorName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:232:3: ( '!' colorName -> ^( ColorNot colorName ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:232:5: '!' colorName
            {
            char_literal60=(Token)match(input,81,FOLLOW_81_in_colorNot1055);  
            stream_81.add(char_literal60);

            pushFollow(FOLLOW_colorName_in_colorNot1057);
            colorName61=colorName();

            state._fsp--;

            stream_colorName.add(colorName61.getTree());


            // AST REWRITE
            // elements: colorName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 232:19: -> ^( ColorNot colorName )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:232:22: ^( ColorNot colorName )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorNot, "ColorNot"), root_1);

                adaptor.addChild(root_1, stream_colorName.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorNot"

    public static class colorAnd_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorAnd"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:234:2: colorAnd : ( colorLit ( '&' colorLit )+ -> ^( ColorAnd ( colorLit )+ ) | LPAREN colorLit ( '&' colorLit )+ RPAREN -> ^( ColorAnd ( colorLit )+ ) );
    public final SLColorAnnotationsParser.colorAnd_return colorAnd() throws RecognitionException {
        SLColorAnnotationsParser.colorAnd_return retval = new SLColorAnnotationsParser.colorAnd_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal63=null;
        Token LPAREN65=null;
        Token char_literal67=null;
        Token RPAREN69=null;
        SLColorAnnotationsParser.colorLit_return colorLit62 = null;

        SLColorAnnotationsParser.colorLit_return colorLit64 = null;

        SLColorAnnotationsParser.colorLit_return colorLit66 = null;

        SLColorAnnotationsParser.colorLit_return colorLit68 = null;


        Tree char_literal63_tree=null;
        Tree LPAREN65_tree=null;
        Tree char_literal67_tree=null;
        Tree RPAREN69_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_75=new RewriteRuleTokenStream(adaptor,"token 75");
        RewriteRuleSubtreeStream stream_colorLit=new RewriteRuleSubtreeStream(adaptor,"rule colorLit");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:235:3: ( colorLit ( '&' colorLit )+ -> ^( ColorAnd ( colorLit )+ ) | LPAREN colorLit ( '&' colorLit )+ RPAREN -> ^( ColorAnd ( colorLit )+ ) )
            int alt15=2;
            alt15 = dfa15.predict(input);
            switch (alt15) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:235:5: colorLit ( '&' colorLit )+
                    {
                    pushFollow(FOLLOW_colorLit_in_colorAnd1079);
                    colorLit62=colorLit();

                    state._fsp--;

                    stream_colorLit.add(colorLit62.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:235:14: ( '&' colorLit )+
                    int cnt13=0;
                    loop13:
                    do {
                        int alt13=2;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0==75) ) {
                            alt13=1;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:235:15: '&' colorLit
                    	    {
                    	    char_literal63=(Token)match(input,75,FOLLOW_75_in_colorAnd1082);  
                    	    stream_75.add(char_literal63);

                    	    pushFollow(FOLLOW_colorLit_in_colorAnd1084);
                    	    colorLit64=colorLit();

                    	    state._fsp--;

                    	    stream_colorLit.add(colorLit64.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt13 >= 1 ) break loop13;
                                EarlyExitException eee =
                                    new EarlyExitException(13, input);
                                throw eee;
                        }
                        cnt13++;
                    } while (true);



                    // AST REWRITE
                    // elements: colorLit
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 235:30: -> ^( ColorAnd ( colorLit )+ )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:235:33: ^( ColorAnd ( colorLit )+ )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorAnd, "ColorAnd"), root_1);

                        if ( !(stream_colorLit.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_colorLit.hasNext() ) {
                            adaptor.addChild(root_1, stream_colorLit.nextTree());

                        }
                        stream_colorLit.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:236:5: LPAREN colorLit ( '&' colorLit )+ RPAREN
                    {
                    LPAREN65=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_colorAnd1101);  
                    stream_LPAREN.add(LPAREN65);

                    pushFollow(FOLLOW_colorLit_in_colorAnd1103);
                    colorLit66=colorLit();

                    state._fsp--;

                    stream_colorLit.add(colorLit66.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:236:21: ( '&' colorLit )+
                    int cnt14=0;
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0==75) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:236:22: '&' colorLit
                    	    {
                    	    char_literal67=(Token)match(input,75,FOLLOW_75_in_colorAnd1106);  
                    	    stream_75.add(char_literal67);

                    	    pushFollow(FOLLOW_colorLit_in_colorAnd1108);
                    	    colorLit68=colorLit();

                    	    state._fsp--;

                    	    stream_colorLit.add(colorLit68.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt14 >= 1 ) break loop14;
                                EarlyExitException eee =
                                    new EarlyExitException(14, input);
                                throw eee;
                        }
                        cnt14++;
                    } while (true);

                    RPAREN69=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_colorAnd1112);  
                    stream_RPAREN.add(RPAREN69);



                    // AST REWRITE
                    // elements: colorLit
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 236:44: -> ^( ColorAnd ( colorLit )+ )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:236:47: ^( ColorAnd ( colorLit )+ )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorAnd, "ColorAnd"), root_1);

                        if ( !(stream_colorLit.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_colorLit.hasNext() ) {
                            adaptor.addChild(root_1, stream_colorLit.nextTree());

                        }
                        stream_colorLit.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorAnd"

    public static class colorOrElem_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorOrElem"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:239:2: colorOrElem : ( colorLit | colorAnd );
    public final SLColorAnnotationsParser.colorOrElem_return colorOrElem() throws RecognitionException {
        SLColorAnnotationsParser.colorOrElem_return retval = new SLColorAnnotationsParser.colorOrElem_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLColorAnnotationsParser.colorLit_return colorLit70 = null;

        SLColorAnnotationsParser.colorAnd_return colorAnd71 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:240:3: ( colorLit | colorAnd )
            int alt16=2;
            alt16 = dfa16.predict(input);
            switch (alt16) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:240:5: colorLit
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_colorLit_in_colorOrElem1135);
                    colorLit70=colorLit();

                    state._fsp--;

                    adaptor.addChild(root_0, colorLit70.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:241:5: colorAnd
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_colorAnd_in_colorOrElem1141);
                    colorAnd71=colorAnd();

                    state._fsp--;

                    adaptor.addChild(root_0, colorAnd71.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorOrElem"

    public static class colorOr_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorOr"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:244:2: colorOr : ( | colorOrElem ( '|' colorOrElem )+ -> ^( ColorOr ( colorOrElem )+ ) | LPAREN colorOrElem ( '|' colorOrElem )+ RPAREN -> ^( ColorOr ( colorOrElem )+ ) );
    public final SLColorAnnotationsParser.colorOr_return colorOr() throws RecognitionException {
        SLColorAnnotationsParser.colorOr_return retval = new SLColorAnnotationsParser.colorOr_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal73=null;
        Token LPAREN75=null;
        Token char_literal77=null;
        Token RPAREN79=null;
        SLColorAnnotationsParser.colorOrElem_return colorOrElem72 = null;

        SLColorAnnotationsParser.colorOrElem_return colorOrElem74 = null;

        SLColorAnnotationsParser.colorOrElem_return colorOrElem76 = null;

        SLColorAnnotationsParser.colorOrElem_return colorOrElem78 = null;


        Tree char_literal73_tree=null;
        Tree LPAREN75_tree=null;
        Tree char_literal77_tree=null;
        Tree RPAREN79_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_82=new RewriteRuleTokenStream(adaptor,"token 82");
        RewriteRuleSubtreeStream stream_colorOrElem=new RewriteRuleSubtreeStream(adaptor,"rule colorOrElem");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:245:3: ( | colorOrElem ( '|' colorOrElem )+ -> ^( ColorOr ( colorOrElem )+ ) | LPAREN colorOrElem ( '|' colorOrElem )+ RPAREN -> ^( ColorOr ( colorOrElem )+ ) )
            int alt19=3;
            alt19 = dfa19.predict(input);
            switch (alt19) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:246:3: 
                    {
                    root_0 = (Tree)adaptor.nil();

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:246:5: colorOrElem ( '|' colorOrElem )+
                    {
                    pushFollow(FOLLOW_colorOrElem_in_colorOr1164);
                    colorOrElem72=colorOrElem();

                    state._fsp--;

                    stream_colorOrElem.add(colorOrElem72.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:246:17: ( '|' colorOrElem )+
                    int cnt17=0;
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0==82) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:246:18: '|' colorOrElem
                    	    {
                    	    char_literal73=(Token)match(input,82,FOLLOW_82_in_colorOr1167);  
                    	    stream_82.add(char_literal73);

                    	    pushFollow(FOLLOW_colorOrElem_in_colorOr1169);
                    	    colorOrElem74=colorOrElem();

                    	    state._fsp--;

                    	    stream_colorOrElem.add(colorOrElem74.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt17 >= 1 ) break loop17;
                                EarlyExitException eee =
                                    new EarlyExitException(17, input);
                                throw eee;
                        }
                        cnt17++;
                    } while (true);



                    // AST REWRITE
                    // elements: colorOrElem
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 246:36: -> ^( ColorOr ( colorOrElem )+ )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:246:39: ^( ColorOr ( colorOrElem )+ )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorOr, "ColorOr"), root_1);

                        if ( !(stream_colorOrElem.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_colorOrElem.hasNext() ) {
                            adaptor.addChild(root_1, stream_colorOrElem.nextTree());

                        }
                        stream_colorOrElem.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:247:5: LPAREN colorOrElem ( '|' colorOrElem )+ RPAREN
                    {
                    LPAREN75=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_colorOr1186);  
                    stream_LPAREN.add(LPAREN75);

                    pushFollow(FOLLOW_colorOrElem_in_colorOr1188);
                    colorOrElem76=colorOrElem();

                    state._fsp--;

                    stream_colorOrElem.add(colorOrElem76.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:247:24: ( '|' colorOrElem )+
                    int cnt18=0;
                    loop18:
                    do {
                        int alt18=2;
                        int LA18_0 = input.LA(1);

                        if ( (LA18_0==82) ) {
                            alt18=1;
                        }


                        switch (alt18) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:247:25: '|' colorOrElem
                    	    {
                    	    char_literal77=(Token)match(input,82,FOLLOW_82_in_colorOr1191);  
                    	    stream_82.add(char_literal77);

                    	    pushFollow(FOLLOW_colorOrElem_in_colorOr1193);
                    	    colorOrElem78=colorOrElem();

                    	    state._fsp--;

                    	    stream_colorOrElem.add(colorOrElem78.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt18 >= 1 ) break loop18;
                                EarlyExitException eee =
                                    new EarlyExitException(18, input);
                                throw eee;
                        }
                        cnt18++;
                    } while (true);

                    RPAREN79=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_colorOr1197);  
                    stream_RPAREN.add(RPAREN79);



                    // AST REWRITE
                    // elements: colorOrElem
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 247:50: -> ^( ColorOr ( colorOrElem )+ )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:247:53: ^( ColorOr ( colorOrElem )+ )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorOr, "ColorOr"), root_1);

                        if ( !(stream_colorOrElem.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_colorOrElem.hasNext() ) {
                            adaptor.addChild(root_1, stream_colorOrElem.nextTree());

                        }
                        stream_colorOrElem.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorOr"

    public static class colorExpr_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorExpr"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:250:2: colorExpr : ( colorLit -> ^( ColorExpr colorLit ) | colorAnd -> ^( ColorExpr colorAnd ) | colorOr -> ^( ColorExpr colorOr ) );
    public final SLColorAnnotationsParser.colorExpr_return colorExpr() throws RecognitionException {
        SLColorAnnotationsParser.colorExpr_return retval = new SLColorAnnotationsParser.colorExpr_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLColorAnnotationsParser.colorLit_return colorLit80 = null;

        SLColorAnnotationsParser.colorAnd_return colorAnd81 = null;

        SLColorAnnotationsParser.colorOr_return colorOr82 = null;


        RewriteRuleSubtreeStream stream_colorOr=new RewriteRuleSubtreeStream(adaptor,"rule colorOr");
        RewriteRuleSubtreeStream stream_colorLit=new RewriteRuleSubtreeStream(adaptor,"rule colorLit");
        RewriteRuleSubtreeStream stream_colorAnd=new RewriteRuleSubtreeStream(adaptor,"rule colorAnd");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:251:3: ( colorLit -> ^( ColorExpr colorLit ) | colorAnd -> ^( ColorExpr colorAnd ) | colorOr -> ^( ColorExpr colorOr ) )
            int alt20=3;
            alt20 = dfa20.predict(input);
            switch (alt20) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:251:5: colorLit
                    {
                    pushFollow(FOLLOW_colorLit_in_colorExpr1222);
                    colorLit80=colorLit();

                    state._fsp--;

                    stream_colorLit.add(colorLit80.getTree());


                    // AST REWRITE
                    // elements: colorLit
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 251:14: -> ^( ColorExpr colorLit )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:251:17: ^( ColorExpr colorLit )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorExpr, "ColorExpr"), root_1);

                        adaptor.addChild(root_1, stream_colorLit.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:252:5: colorAnd
                    {
                    pushFollow(FOLLOW_colorAnd_in_colorExpr1236);
                    colorAnd81=colorAnd();

                    state._fsp--;

                    stream_colorAnd.add(colorAnd81.getTree());


                    // AST REWRITE
                    // elements: colorAnd
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 252:14: -> ^( ColorExpr colorAnd )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:252:17: ^( ColorExpr colorAnd )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorExpr, "ColorExpr"), root_1);

                        adaptor.addChild(root_1, stream_colorAnd.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:253:5: colorOr
                    {
                    pushFollow(FOLLOW_colorOr_in_colorExpr1250);
                    colorOr82=colorOr();

                    state._fsp--;

                    stream_colorOr.add(colorOr82.getTree());


                    // AST REWRITE
                    // elements: colorOr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 253:13: -> ^( ColorExpr colorOr )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:253:16: ^( ColorExpr colorOr )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorExpr, "ColorExpr"), root_1);

                        adaptor.addChild(root_1, stream_colorOr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorExpr"

    public static class nothing_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nothing"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:256:2: nothing : EOF -> ^( Nothing ) ;
    public final SLColorAnnotationsParser.nothing_return nothing() throws RecognitionException {
        SLColorAnnotationsParser.nothing_return retval = new SLColorAnnotationsParser.nothing_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF83=null;

        Tree EOF83_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:260:5: ( EOF -> ^( Nothing ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:260:7: EOF
            {
            EOF83=(Token)match(input,EOF,FOLLOW_EOF_in_nothing1278);  
            stream_EOF.add(EOF83);



            // AST REWRITE
            // elements: 
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 260:11: -> ^( Nothing )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:260:14: ^( Nothing )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Nothing, "Nothing"), root_1);

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "nothing"

    public static class colorTransparent_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorTransparent"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:263:2: colorTransparent : nothing EOF -> ^( Transparent nothing ) ;
    public final SLColorAnnotationsParser.colorTransparent_return colorTransparent() throws RecognitionException {
        SLColorAnnotationsParser.colorTransparent_return retval = new SLColorAnnotationsParser.colorTransparent_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF85=null;
        SLColorAnnotationsParser.nothing_return nothing84 = null;


        Tree EOF85_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_nothing=new RewriteRuleSubtreeStream(adaptor,"rule nothing");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:264:3: ( nothing EOF -> ^( Transparent nothing ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:264:5: nothing EOF
            {
            pushFollow(FOLLOW_nothing_in_colorTransparent1303);
            nothing84=nothing();

            state._fsp--;

            stream_nothing.add(nothing84.getTree());
            EOF85=(Token)match(input,EOF,FOLLOW_EOF_in_colorTransparent1305);  
            stream_EOF.add(EOF85);



            // AST REWRITE
            // elements: nothing
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 264:17: -> ^( Transparent nothing )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:264:20: ^( Transparent nothing )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Transparent, "Transparent"), root_1);

                adaptor.addChild(root_1, stream_nothing.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorTransparent"

    public static class colorDeclare_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorDeclare"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:267:2: colorDeclare : colorNames EOF -> ^( ColorDeclaration colorNames ) ;
    public final SLColorAnnotationsParser.colorDeclare_return colorDeclare() throws RecognitionException {
        SLColorAnnotationsParser.colorDeclare_return retval = new SLColorAnnotationsParser.colorDeclare_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF87=null;
        SLColorAnnotationsParser.colorNames_return colorNames86 = null;


        Tree EOF87_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorNames=new RewriteRuleSubtreeStream(adaptor,"rule colorNames");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:272:3: ( colorNames EOF -> ^( ColorDeclaration colorNames ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:272:5: colorNames EOF
            {
            pushFollow(FOLLOW_colorNames_in_colorDeclare1332);
            colorNames86=colorNames();

            state._fsp--;

            stream_colorNames.add(colorNames86.getTree());
            EOF87=(Token)match(input,EOF,FOLLOW_EOF_in_colorDeclare1334);  
            stream_EOF.add(EOF87);



            // AST REWRITE
            // elements: colorNames
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 272:20: -> ^( ColorDeclaration colorNames )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:272:23: ^( ColorDeclaration colorNames )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorDeclaration, "ColorDeclaration"), root_1);

                adaptor.addChild(root_1, stream_colorNames.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorDeclare"

    public static class colorGrant_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorGrant"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:275:2: colorGrant : colorNames EOF -> ^( ColorGrant colorNames ) ;
    public final SLColorAnnotationsParser.colorGrant_return colorGrant() throws RecognitionException {
        SLColorAnnotationsParser.colorGrant_return retval = new SLColorAnnotationsParser.colorGrant_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF89=null;
        SLColorAnnotationsParser.colorNames_return colorNames88 = null;


        Tree EOF89_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorNames=new RewriteRuleSubtreeStream(adaptor,"rule colorNames");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:276:3: ( colorNames EOF -> ^( ColorGrant colorNames ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:276:5: colorNames EOF
            {
            pushFollow(FOLLOW_colorNames_in_colorGrant1359);
            colorNames88=colorNames();

            state._fsp--;

            stream_colorNames.add(colorNames88.getTree());
            EOF89=(Token)match(input,EOF,FOLLOW_EOF_in_colorGrant1361);  
            stream_EOF.add(EOF89);



            // AST REWRITE
            // elements: colorNames
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 276:20: -> ^( ColorGrant colorNames )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:276:23: ^( ColorGrant colorNames )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorGrant, "ColorGrant"), root_1);

                adaptor.addChild(root_1, stream_colorNames.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorGrant"

    public static class colorRevoke_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorRevoke"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:279:2: colorRevoke : colorNames EOF -> ^( ColorRevoke colorNames ) ;
    public final SLColorAnnotationsParser.colorRevoke_return colorRevoke() throws RecognitionException {
        SLColorAnnotationsParser.colorRevoke_return retval = new SLColorAnnotationsParser.colorRevoke_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF91=null;
        SLColorAnnotationsParser.colorNames_return colorNames90 = null;


        Tree EOF91_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorNames=new RewriteRuleSubtreeStream(adaptor,"rule colorNames");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:280:3: ( colorNames EOF -> ^( ColorRevoke colorNames ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:280:5: colorNames EOF
            {
            pushFollow(FOLLOW_colorNames_in_colorRevoke1385);
            colorNames90=colorNames();

            state._fsp--;

            stream_colorNames.add(colorNames90.getTree());
            EOF91=(Token)match(input,EOF,FOLLOW_EOF_in_colorRevoke1387);  
            stream_EOF.add(EOF91);



            // AST REWRITE
            // elements: colorNames
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 280:20: -> ^( ColorRevoke colorNames )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:280:23: ^( ColorRevoke colorNames )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorRevoke, "ColorRevoke"), root_1);

                adaptor.addChild(root_1, stream_colorNames.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorRevoke"

    public static class colorIncompatible_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorIncompatible"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:283:1: colorIncompatible : colorNames EOF -> ^( ColorIncompatible colorNames ) ;
    public final SLColorAnnotationsParser.colorIncompatible_return colorIncompatible() throws RecognitionException {
        SLColorAnnotationsParser.colorIncompatible_return retval = new SLColorAnnotationsParser.colorIncompatible_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF93=null;
        SLColorAnnotationsParser.colorNames_return colorNames92 = null;


        Tree EOF93_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorNames=new RewriteRuleSubtreeStream(adaptor,"rule colorNames");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:284:2: ( colorNames EOF -> ^( ColorIncompatible colorNames ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:284:4: colorNames EOF
            {
            pushFollow(FOLLOW_colorNames_in_colorIncompatible1410);
            colorNames92=colorNames();

            state._fsp--;

            stream_colorNames.add(colorNames92.getTree());
            EOF93=(Token)match(input,EOF,FOLLOW_EOF_in_colorIncompatible1412);  
            stream_EOF.add(EOF93);



            // AST REWRITE
            // elements: colorNames
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 284:19: -> ^( ColorIncompatible colorNames )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:284:22: ^( ColorIncompatible colorNames )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorIncompatible, "ColorIncompatible"), root_1);

                adaptor.addChild(root_1, stream_colorNames.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorIncompatible"

    public static class color_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "color"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:287:1: color : colorExpr EOF -> ^( Color colorExpr ) ;
    public final SLColorAnnotationsParser.color_return color() throws RecognitionException {
        SLColorAnnotationsParser.color_return retval = new SLColorAnnotationsParser.color_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF95=null;
        SLColorAnnotationsParser.colorExpr_return colorExpr94 = null;


        Tree EOF95_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorExpr=new RewriteRuleSubtreeStream(adaptor,"rule colorExpr");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:291:2: ( colorExpr EOF -> ^( Color colorExpr ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:291:4: colorExpr EOF
            {
            pushFollow(FOLLOW_colorExpr_in_color1436);
            colorExpr94=colorExpr();

            state._fsp--;

            stream_colorExpr.add(colorExpr94.getTree());
            EOF95=(Token)match(input,EOF,FOLLOW_EOF_in_color1438);  
            stream_EOF.add(EOF95);



            // AST REWRITE
            // elements: colorExpr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 291:18: -> ^( Color colorExpr )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:291:21: ^( Color colorExpr )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Color, "Color"), root_1);

                adaptor.addChild(root_1, stream_colorExpr.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "color"

    public static class colorConstraint_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorConstraint"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:294:1: colorConstraint : colorExpr EOF -> ^( ColorConstraint colorExpr ) ;
    public final SLColorAnnotationsParser.colorConstraint_return colorConstraint() throws RecognitionException {
        SLColorAnnotationsParser.colorConstraint_return retval = new SLColorAnnotationsParser.colorConstraint_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF97=null;
        SLColorAnnotationsParser.colorExpr_return colorExpr96 = null;


        Tree EOF97_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorExpr=new RewriteRuleSubtreeStream(adaptor,"rule colorExpr");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:295:2: ( colorExpr EOF -> ^( ColorConstraint colorExpr ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:295:4: colorExpr EOF
            {
            pushFollow(FOLLOW_colorExpr_in_colorConstraint1458);
            colorExpr96=colorExpr();

            state._fsp--;

            stream_colorExpr.add(colorExpr96.getTree());
            EOF97=(Token)match(input,EOF,FOLLOW_EOF_in_colorConstraint1460);  
            stream_EOF.add(EOF97);



            // AST REWRITE
            // elements: colorExpr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 295:18: -> ^( ColorConstraint colorExpr )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:295:21: ^( ColorConstraint colorExpr )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorConstraint, "ColorConstraint"), root_1);

                adaptor.addChild(root_1, stream_colorExpr.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorConstraint"

    public static class colorImport_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorImport"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:298:1: colorImport : qualifiedName EOF -> ^( ColorImport qualifiedName ) ;
    public final SLColorAnnotationsParser.colorImport_return colorImport() throws RecognitionException {
        SLColorAnnotationsParser.colorImport_return retval = new SLColorAnnotationsParser.colorImport_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF99=null;
        SLColorAnnotationsParser.qualifiedName_return qualifiedName98 = null;


        Tree EOF99_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_qualifiedName=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:302:2: ( qualifiedName EOF -> ^( ColorImport qualifiedName ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:302:4: qualifiedName EOF
            {
            pushFollow(FOLLOW_qualifiedName_in_colorImport1483);
            qualifiedName98=qualifiedName();

            state._fsp--;

            stream_qualifiedName.add(qualifiedName98.getTree());
            EOF99=(Token)match(input,EOF,FOLLOW_EOF_in_colorImport1485);  
            stream_EOF.add(EOF99);



            // AST REWRITE
            // elements: qualifiedName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 302:22: -> ^( ColorImport qualifiedName )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:302:25: ^( ColorImport qualifiedName )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorImport, "ColorImport"), root_1);

                adaptor.addChild(root_1, stream_qualifiedName.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorImport"

    public static class colorRename_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorRename"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:305:1: colorRename : colorName FOR colorExpr -> ^( ColorRename colorName colorExpr ) ;
    public final SLColorAnnotationsParser.colorRename_return colorRename() throws RecognitionException {
        SLColorAnnotationsParser.colorRename_return retval = new SLColorAnnotationsParser.colorRename_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token FOR101=null;
        SLColorAnnotationsParser.colorName_return colorName100 = null;

        SLColorAnnotationsParser.colorExpr_return colorExpr102 = null;


        Tree FOR101_tree=null;
        RewriteRuleTokenStream stream_FOR=new RewriteRuleTokenStream(adaptor,"token FOR");
        RewriteRuleSubtreeStream stream_colorName=new RewriteRuleSubtreeStream(adaptor,"rule colorName");
        RewriteRuleSubtreeStream stream_colorExpr=new RewriteRuleSubtreeStream(adaptor,"rule colorExpr");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:306:2: ( colorName FOR colorExpr -> ^( ColorRename colorName colorExpr ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:306:4: colorName FOR colorExpr
            {
            pushFollow(FOLLOW_colorName_in_colorRename1505);
            colorName100=colorName();

            state._fsp--;

            stream_colorName.add(colorName100.getTree());
            FOR101=(Token)match(input,FOR,FOLLOW_FOR_in_colorRename1507);  
            stream_FOR.add(FOR101);

            pushFollow(FOLLOW_colorExpr_in_colorRename1509);
            colorExpr102=colorExpr();

            state._fsp--;

            stream_colorExpr.add(colorExpr102.getTree());


            // AST REWRITE
            // elements: colorName, colorExpr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 306:28: -> ^( ColorRename colorName colorExpr )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:306:31: ^( ColorRename colorName colorExpr )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorRename, "ColorRename"), root_1);

                adaptor.addChild(root_1, stream_colorName.nextTree());
                adaptor.addChild(root_1, stream_colorExpr.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorRename"

    public static class colorized_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorized"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:309:1: colorized : regionSpecifications EOF -> ^( ColorizedRegion regionSpecifications ) ;
    public final SLColorAnnotationsParser.colorized_return colorized() throws RecognitionException {
        SLColorAnnotationsParser.colorized_return retval = new SLColorAnnotationsParser.colorized_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF104=null;
        SLColorAnnotationsParser.regionSpecifications_return regionSpecifications103 = null;


        Tree EOF104_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_regionSpecifications=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecifications");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:310:2: ( regionSpecifications EOF -> ^( ColorizedRegion regionSpecifications ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:310:4: regionSpecifications EOF
            {
            pushFollow(FOLLOW_regionSpecifications_in_colorized1532);
            regionSpecifications103=regionSpecifications();

            state._fsp--;

            stream_regionSpecifications.add(regionSpecifications103.getTree());
            EOF104=(Token)match(input,EOF,FOLLOW_EOF_in_colorized1534);  
            stream_EOF.add(EOF104);



            // AST REWRITE
            // elements: regionSpecifications
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 310:29: -> ^( ColorizedRegion regionSpecifications )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:310:32: ^( ColorizedRegion regionSpecifications )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorizedRegion, "ColorizedRegion"), root_1);

                adaptor.addChild(root_1, stream_regionSpecifications.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorized"

    public static class colorConstrainedRegions_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorConstrainedRegions"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:314:1: colorConstrainedRegions : colorExpr FOR regionSpecifications EOF -> ^( ColorCR colorExpr regionSpecifications ) ;
    public final SLColorAnnotationsParser.colorConstrainedRegions_return colorConstrainedRegions() throws RecognitionException {
        SLColorAnnotationsParser.colorConstrainedRegions_return retval = new SLColorAnnotationsParser.colorConstrainedRegions_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token FOR106=null;
        Token EOF108=null;
        SLColorAnnotationsParser.colorExpr_return colorExpr105 = null;

        SLColorAnnotationsParser.regionSpecifications_return regionSpecifications107 = null;


        Tree FOR106_tree=null;
        Tree EOF108_tree=null;
        RewriteRuleTokenStream stream_FOR=new RewriteRuleTokenStream(adaptor,"token FOR");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorExpr=new RewriteRuleSubtreeStream(adaptor,"rule colorExpr");
        RewriteRuleSubtreeStream stream_regionSpecifications=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecifications");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:315:2: ( colorExpr FOR regionSpecifications EOF -> ^( ColorCR colorExpr regionSpecifications ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:315:4: colorExpr FOR regionSpecifications EOF
            {
            pushFollow(FOLLOW_colorExpr_in_colorConstrainedRegions1556);
            colorExpr105=colorExpr();

            state._fsp--;

            stream_colorExpr.add(colorExpr105.getTree());
            FOR106=(Token)match(input,FOR,FOLLOW_FOR_in_colorConstrainedRegions1558);  
            stream_FOR.add(FOR106);

            pushFollow(FOLLOW_regionSpecifications_in_colorConstrainedRegions1560);
            regionSpecifications107=regionSpecifications();

            state._fsp--;

            stream_regionSpecifications.add(regionSpecifications107.getTree());
            EOF108=(Token)match(input,EOF,FOLLOW_EOF_in_colorConstrainedRegions1562);  
            stream_EOF.add(EOF108);



            // AST REWRITE
            // elements: colorExpr, regionSpecifications
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 315:43: -> ^( ColorCR colorExpr regionSpecifications )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:315:46: ^( ColorCR colorExpr regionSpecifications )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorCR, "ColorCR"), root_1);

                adaptor.addChild(root_1, stream_colorExpr.nextTree());
                adaptor.addChild(root_1, stream_regionSpecifications.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorConstrainedRegions"

    public static class colorCard_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorCard"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:319:1: colorCard : colorCardSpec EOF -> colorCardSpec ;
    public final SLColorAnnotationsParser.colorCard_return colorCard() throws RecognitionException {
        SLColorAnnotationsParser.colorCard_return retval = new SLColorAnnotationsParser.colorCard_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF110=null;
        SLColorAnnotationsParser.colorCardSpec_return colorCardSpec109 = null;


        Tree EOF110_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_colorCardSpec=new RewriteRuleSubtreeStream(adaptor,"rule colorCardSpec");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:320:2: ( colorCardSpec EOF -> colorCardSpec )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:320:4: colorCardSpec EOF
            {
            pushFollow(FOLLOW_colorCardSpec_in_colorCard1586);
            colorCardSpec109=colorCardSpec();

            state._fsp--;

            stream_colorCardSpec.add(colorCardSpec109.getTree());
            EOF110=(Token)match(input,EOF,FOLLOW_EOF_in_colorCard1588);  
            stream_EOF.add(EOF110);



            // AST REWRITE
            // elements: colorCardSpec
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 320:22: -> colorCardSpec
            {
                adaptor.addChild(root_0, stream_colorCardSpec.nextTree());

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorCard"

    public static class colorCardSpec_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "colorCardSpec"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:324:1: colorCardSpec : '1' FOR colorSimpleNames -> ^( ColorCardSpec colorSimpleNames ) ;
    public final SLColorAnnotationsParser.colorCardSpec_return colorCardSpec() throws RecognitionException {
        SLColorAnnotationsParser.colorCardSpec_return retval = new SLColorAnnotationsParser.colorCardSpec_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal111=null;
        Token FOR112=null;
        SLColorAnnotationsParser.colorSimpleNames_return colorSimpleNames113 = null;


        Tree char_literal111_tree=null;
        Tree FOR112_tree=null;
        RewriteRuleTokenStream stream_FOR=new RewriteRuleTokenStream(adaptor,"token FOR");
        RewriteRuleTokenStream stream_83=new RewriteRuleTokenStream(adaptor,"token 83");
        RewriteRuleSubtreeStream stream_colorSimpleNames=new RewriteRuleSubtreeStream(adaptor,"rule colorSimpleNames");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:325:2: ( '1' FOR colorSimpleNames -> ^( ColorCardSpec colorSimpleNames ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:325:4: '1' FOR colorSimpleNames
            {
            char_literal111=(Token)match(input,83,FOLLOW_83_in_colorCardSpec1605);  
            stream_83.add(char_literal111);

            FOR112=(Token)match(input,FOR,FOLLOW_FOR_in_colorCardSpec1607);  
            stream_FOR.add(FOR112);

            pushFollow(FOLLOW_colorSimpleNames_in_colorCardSpec1609);
            colorSimpleNames113=colorSimpleNames();

            state._fsp--;

            stream_colorSimpleNames.add(colorSimpleNames113.getTree());


            // AST REWRITE
            // elements: colorSimpleNames
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 325:29: -> ^( ColorCardSpec colorSimpleNames )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:325:32: ^( ColorCardSpec colorSimpleNames )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ColorCardSpec, "ColorCardSpec"), root_1);

                adaptor.addChild(root_1, stream_colorSimpleNames.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "colorCardSpec"

    public static class moduleChoice_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "moduleChoice"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:328:1: moduleChoice : ( name -> ^( ModulePromise name ) | name CONTAINS names -> ^( ModuleWrapper name names ) );
    public final SLColorAnnotationsParser.moduleChoice_return moduleChoice() throws RecognitionException {
        SLColorAnnotationsParser.moduleChoice_return retval = new SLColorAnnotationsParser.moduleChoice_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token CONTAINS116=null;
        SLColorAnnotationsParser.name_return name114 = null;

        SLColorAnnotationsParser.name_return name115 = null;

        SLColorAnnotationsParser.names_return names117 = null;


        Tree CONTAINS116_tree=null;
        RewriteRuleTokenStream stream_CONTAINS=new RewriteRuleTokenStream(adaptor,"token CONTAINS");
        RewriteRuleSubtreeStream stream_names=new RewriteRuleSubtreeStream(adaptor,"rule names");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:333:2: ( name -> ^( ModulePromise name ) | name CONTAINS names -> ^( ModuleWrapper name names ) )
            int alt21=2;
            alt21 = dfa21.predict(input);
            switch (alt21) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:333:4: name
                    {
                    pushFollow(FOLLOW_name_in_moduleChoice1634);
                    name114=name();

                    state._fsp--;

                    stream_name.add(name114.getTree());


                    // AST REWRITE
                    // elements: name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 333:9: -> ^( ModulePromise name )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:333:12: ^( ModulePromise name )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ModulePromise, "ModulePromise"), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:334:4: name CONTAINS names
                    {
                    pushFollow(FOLLOW_name_in_moduleChoice1647);
                    name115=name();

                    state._fsp--;

                    stream_name.add(name115.getTree());
                    CONTAINS116=(Token)match(input,CONTAINS,FOLLOW_CONTAINS_in_moduleChoice1649);  
                    stream_CONTAINS.add(CONTAINS116);

                    pushFollow(FOLLOW_names_in_moduleChoice1651);
                    names117=names();

                    state._fsp--;

                    stream_names.add(names117.getTree());


                    // AST REWRITE
                    // elements: name, names
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 334:25: -> ^( ModuleWrapper name names )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:334:28: ^( ModuleWrapper name names )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ModuleWrapper, "ModuleWrapper"), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());
                        adaptor.addChild(root_1, stream_names.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "moduleChoice"

    public static class module_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "module"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:337:1: module : moduleChoice EOF -> ^( ModuleChoice moduleChoice ) ;
    public final SLColorAnnotationsParser.module_return module() throws RecognitionException {
        SLColorAnnotationsParser.module_return retval = new SLColorAnnotationsParser.module_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF119=null;
        SLColorAnnotationsParser.moduleChoice_return moduleChoice118 = null;


        Tree EOF119_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_moduleChoice=new RewriteRuleSubtreeStream(adaptor,"rule moduleChoice");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:338:2: ( moduleChoice EOF -> ^( ModuleChoice moduleChoice ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:338:4: moduleChoice EOF
            {
            pushFollow(FOLLOW_moduleChoice_in_module1674);
            moduleChoice118=moduleChoice();

            state._fsp--;

            stream_moduleChoice.add(moduleChoice118.getTree());
            EOF119=(Token)match(input,EOF,FOLLOW_EOF_in_module1676);  
            stream_EOF.add(EOF119);



            // AST REWRITE
            // elements: moduleChoice
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 338:21: -> ^( ModuleChoice moduleChoice )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:338:24: ^( ModuleChoice moduleChoice )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ModuleChoice, "ModuleChoice"), root_1);

                adaptor.addChild(root_1, stream_moduleChoice.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "module"

    public static class vis_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "vis"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:341:1: vis : ( name )? EOF -> ^( VisClause ( name )? ) ;
    public final SLColorAnnotationsParser.vis_return vis() throws RecognitionException {
        SLColorAnnotationsParser.vis_return retval = new SLColorAnnotationsParser.vis_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF121=null;
        SLColorAnnotationsParser.name_return name120 = null;


        Tree EOF121_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:342:2: ( ( name )? EOF -> ^( VisClause ( name )? ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:342:4: ( name )? EOF
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:342:4: ( name )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==IDENTIFIER) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:342:5: name
                    {
                    pushFollow(FOLLOW_name_in_vis1698);
                    name120=name();

                    state._fsp--;

                    stream_name.add(name120.getTree());

                    }
                    break;

            }

            EOF121=(Token)match(input,EOF,FOLLOW_EOF_in_vis1702);  
            stream_EOF.add(EOF121);



            // AST REWRITE
            // elements: name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 342:16: -> ^( VisClause ( name )? )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:342:19: ^( VisClause ( name )? )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(VisClause, "VisClause"), root_1);

                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:342:31: ( name )?
                if ( stream_name.hasNext() ) {
                    adaptor.addChild(root_1, stream_name.nextTree());

                }
                stream_name.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "vis"

    public static class noVis_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "noVis"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:345:1: noVis : nothing EOF -> ^( NoVisClause ) ;
    public final SLColorAnnotationsParser.noVis_return noVis() throws RecognitionException {
        SLColorAnnotationsParser.noVis_return retval = new SLColorAnnotationsParser.noVis_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF123=null;
        SLColorAnnotationsParser.nothing_return nothing122 = null;


        Tree EOF123_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_nothing=new RewriteRuleSubtreeStream(adaptor,"rule nothing");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:346:2: ( nothing EOF -> ^( NoVisClause ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:346:4: nothing EOF
            {
            pushFollow(FOLLOW_nothing_in_noVis1723);
            nothing122=nothing();

            state._fsp--;

            stream_nothing.add(nothing122.getTree());
            EOF123=(Token)match(input,EOF,FOLLOW_EOF_in_noVis1725);  
            stream_EOF.add(EOF123);



            // AST REWRITE
            // elements: 
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 346:16: -> ^( NoVisClause )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:346:19: ^( NoVisClause )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NoVisClause, "NoVisClause"), root_1);

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "noVis"

    public static class export_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "export"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:349:1: export : ( names FROM name EOF -> ^( Export names name ) | names TO names EOF -> ^( ExportTo names names ) );
    public final SLColorAnnotationsParser.export_return export() throws RecognitionException {
        SLColorAnnotationsParser.export_return retval = new SLColorAnnotationsParser.export_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token FROM125=null;
        Token EOF127=null;
        Token TO129=null;
        Token EOF131=null;
        SLColorAnnotationsParser.names_return names124 = null;

        SLColorAnnotationsParser.name_return name126 = null;

        SLColorAnnotationsParser.names_return names128 = null;

        SLColorAnnotationsParser.names_return names130 = null;


        Tree FROM125_tree=null;
        Tree EOF127_tree=null;
        Tree TO129_tree=null;
        Tree EOF131_tree=null;
        RewriteRuleTokenStream stream_TO=new RewriteRuleTokenStream(adaptor,"token TO");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleTokenStream stream_FROM=new RewriteRuleTokenStream(adaptor,"token FROM");
        RewriteRuleSubtreeStream stream_names=new RewriteRuleSubtreeStream(adaptor,"rule names");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:350:2: ( names FROM name EOF -> ^( Export names name ) | names TO names EOF -> ^( ExportTo names names ) )
            int alt23=2;
            alt23 = dfa23.predict(input);
            switch (alt23) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:350:4: names FROM name EOF
                    {
                    pushFollow(FOLLOW_names_in_export1743);
                    names124=names();

                    state._fsp--;

                    stream_names.add(names124.getTree());
                    FROM125=(Token)match(input,FROM,FOLLOW_FROM_in_export1745);  
                    stream_FROM.add(FROM125);

                    pushFollow(FOLLOW_name_in_export1747);
                    name126=name();

                    state._fsp--;

                    stream_name.add(name126.getTree());
                    EOF127=(Token)match(input,EOF,FOLLOW_EOF_in_export1749);  
                    stream_EOF.add(EOF127);



                    // AST REWRITE
                    // elements: names, name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 350:24: -> ^( Export names name )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:350:27: ^( Export names name )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Export, "Export"), root_1);

                        adaptor.addChild(root_1, stream_names.nextTree());
                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:351:4: names TO names EOF
                    {
                    pushFollow(FOLLOW_names_in_export1764);
                    names128=names();

                    state._fsp--;

                    stream_names.add(names128.getTree());
                    TO129=(Token)match(input,TO,FOLLOW_TO_in_export1766);  
                    stream_TO.add(TO129);

                    pushFollow(FOLLOW_names_in_export1768);
                    names130=names();

                    state._fsp--;

                    stream_names.add(names130.getTree());
                    EOF131=(Token)match(input,EOF,FOLLOW_EOF_in_export1770);  
                    stream_EOF.add(EOF131);



                    // AST REWRITE
                    // elements: names, names
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 351:23: -> ^( ExportTo names names )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:351:26: ^( ExportTo names names )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ExportTo, "ExportTo"), root_1);

                        adaptor.addChild(root_1, stream_names.nextTree());
                        adaptor.addChild(root_1, stream_names.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "export"

    public static class names_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "names"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:354:1: names : name ( ',' name )* -> ^( Names ( name )+ ) ;
    public final SLColorAnnotationsParser.names_return names() throws RecognitionException {
        SLColorAnnotationsParser.names_return retval = new SLColorAnnotationsParser.names_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal133=null;
        SLColorAnnotationsParser.name_return name132 = null;

        SLColorAnnotationsParser.name_return name134 = null;


        Tree char_literal133_tree=null;
        RewriteRuleTokenStream stream_80=new RewriteRuleTokenStream(adaptor,"token 80");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:355:3: ( name ( ',' name )* -> ^( Names ( name )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:355:5: name ( ',' name )*
            {
            pushFollow(FOLLOW_name_in_names1792);
            name132=name();

            state._fsp--;

            stream_name.add(name132.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:355:10: ( ',' name )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==80) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:355:11: ',' name
            	    {
            	    char_literal133=(Token)match(input,80,FOLLOW_80_in_names1795);  
            	    stream_80.add(char_literal133);

            	    pushFollow(FOLLOW_name_in_names1797);
            	    name134=name();

            	    state._fsp--;

            	    stream_name.add(name134.getTree());

            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);



            // AST REWRITE
            // elements: name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 355:22: -> ^( Names ( name )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:355:25: ^( Names ( name )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Names, "Names"), root_1);

                if ( !(stream_name.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_name.hasNext() ) {
                    adaptor.addChild(root_1, stream_name.nextTree());

                }
                stream_name.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "names"

    public static class blockImport_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "blockImport"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:358:2: blockImport : ( ofNamesClause )? FROM names EOF -> ^( BlockImport ( ofNamesClause )? names ) ;
    public final SLColorAnnotationsParser.blockImport_return blockImport() throws RecognitionException {
        SLColorAnnotationsParser.blockImport_return retval = new SLColorAnnotationsParser.blockImport_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token FROM136=null;
        Token EOF138=null;
        SLColorAnnotationsParser.ofNamesClause_return ofNamesClause135 = null;

        SLColorAnnotationsParser.names_return names137 = null;


        Tree FROM136_tree=null;
        Tree EOF138_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleTokenStream stream_FROM=new RewriteRuleTokenStream(adaptor,"token FROM");
        RewriteRuleSubtreeStream stream_names=new RewriteRuleSubtreeStream(adaptor,"rule names");
        RewriteRuleSubtreeStream stream_ofNamesClause=new RewriteRuleSubtreeStream(adaptor,"rule ofNamesClause");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:359:3: ( ( ofNamesClause )? FROM names EOF -> ^( BlockImport ( ofNamesClause )? names ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:359:5: ( ofNamesClause )? FROM names EOF
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:359:5: ( ofNamesClause )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==OF) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:359:5: ofNamesClause
                    {
                    pushFollow(FOLLOW_ofNamesClause_in_blockImport1825);
                    ofNamesClause135=ofNamesClause();

                    state._fsp--;

                    stream_ofNamesClause.add(ofNamesClause135.getTree());

                    }
                    break;

            }

            FROM136=(Token)match(input,FROM,FOLLOW_FROM_in_blockImport1828);  
            stream_FROM.add(FROM136);

            pushFollow(FOLLOW_names_in_blockImport1830);
            names137=names();

            state._fsp--;

            stream_names.add(names137.getTree());
            EOF138=(Token)match(input,EOF,FOLLOW_EOF_in_blockImport1832);  
            stream_EOF.add(EOF138);



            // AST REWRITE
            // elements: names, ofNamesClause
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 359:35: -> ^( BlockImport ( ofNamesClause )? names )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:359:38: ^( BlockImport ( ofNamesClause )? names )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(BlockImport, "BlockImport"), root_1);

                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:359:52: ( ofNamesClause )?
                if ( stream_ofNamesClause.hasNext() ) {
                    adaptor.addChild(root_1, stream_ofNamesClause.nextTree());

                }
                stream_ofNamesClause.reset();
                adaptor.addChild(root_1, stream_names.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "blockImport"

    public static class ofNamesClause_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ofNamesClause"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:362:2: ofNamesClause : OF names -> ^( OfNamesClause names ) ;
    public final SLColorAnnotationsParser.ofNamesClause_return ofNamesClause() throws RecognitionException {
        SLColorAnnotationsParser.ofNamesClause_return retval = new SLColorAnnotationsParser.ofNamesClause_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token OF139=null;
        SLColorAnnotationsParser.names_return names140 = null;


        Tree OF139_tree=null;
        RewriteRuleTokenStream stream_OF=new RewriteRuleTokenStream(adaptor,"token OF");
        RewriteRuleSubtreeStream stream_names=new RewriteRuleSubtreeStream(adaptor,"rule names");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:363:3: ( OF names -> ^( OfNamesClause names ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:363:5: OF names
            {
            OF139=(Token)match(input,OF,FOLLOW_OF_in_ofNamesClause1860);  
            stream_OF.add(OF139);

            pushFollow(FOLLOW_names_in_ofNamesClause1862);
            names140=names();

            state._fsp--;

            stream_names.add(names140.getTree());


            // AST REWRITE
            // elements: names
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 363:14: -> ^( OfNamesClause names )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:363:17: ^( OfNamesClause names )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OfNamesClause, "OfNamesClause"), root_1);

                adaptor.addChild(root_1, stream_names.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "ofNamesClause"

    // Delegated rules


    protected DFA15 dfa15 = new DFA15(this);
    protected DFA16 dfa16 = new DFA16(this);
    protected DFA19 dfa19 = new DFA19(this);
    protected DFA20 dfa20 = new DFA20(this);
    protected DFA21 dfa21 = new DFA21(this);
    protected DFA23 dfa23 = new DFA23(this);
    static final String DFA15_eotS =
        "\13\uffff";
    static final String DFA15_eofS =
        "\13\uffff";
    static final String DFA15_minS =
        "\1\76\1\uffff\1\76\1\102\1\76\1\uffff\1\76\2\102\1\76\1\102";
    static final String DFA15_maxS =
        "\1\121\1\uffff\1\121\1\117\1\76\1\uffff\1\76\2\117\1\76\1\117";
    static final String DFA15_acceptS =
        "\1\uffff\1\1\3\uffff\1\2\5\uffff";
    static final String DFA15_specialS =
        "\13\uffff}>";
    static final String[] DFA15_transitionS = {
            "\1\1\2\uffff\1\2\17\uffff\1\1",
            "",
            "\1\3\2\uffff\1\5\17\uffff\1\4",
            "\1\1\10\uffff\1\5\3\uffff\1\6",
            "\1\7",
            "",
            "\1\10",
            "\1\1\10\uffff\1\5\3\uffff\1\11",
            "\1\1\10\uffff\1\5\3\uffff\1\6",
            "\1\12",
            "\1\1\10\uffff\1\5\3\uffff\1\11"
    };

    static final short[] DFA15_eot = DFA.unpackEncodedString(DFA15_eotS);
    static final short[] DFA15_eof = DFA.unpackEncodedString(DFA15_eofS);
    static final char[] DFA15_min = DFA.unpackEncodedStringToUnsignedChars(DFA15_minS);
    static final char[] DFA15_max = DFA.unpackEncodedStringToUnsignedChars(DFA15_maxS);
    static final short[] DFA15_accept = DFA.unpackEncodedString(DFA15_acceptS);
    static final short[] DFA15_special = DFA.unpackEncodedString(DFA15_specialS);
    static final short[][] DFA15_transition;

    static {
        int numStates = DFA15_transitionS.length;
        DFA15_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA15_transition[i] = DFA.unpackEncodedString(DFA15_transitionS[i]);
        }
    }

    class DFA15 extends DFA {

        public DFA15(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 15;
            this.eot = DFA15_eot;
            this.eof = DFA15_eof;
            this.min = DFA15_min;
            this.max = DFA15_max;
            this.accept = DFA15_accept;
            this.special = DFA15_special;
            this.transition = DFA15_transition;
        }
        public String getDescription() {
            return "234:2: colorAnd : ( colorLit ( '&' colorLit )+ -> ^( ColorAnd ( colorLit )+ ) | LPAREN colorLit ( '&' colorLit )+ RPAREN -> ^( ColorAnd ( colorLit )+ ) );";
        }
    }
    static final String DFA16_eotS =
        "\24\uffff";
    static final String DFA16_eofS =
        "\3\uffff\2\11\7\uffff\1\11\1\uffff\3\11\3\uffff";
    static final String DFA16_minS =
        "\3\76\2\102\1\76\1\uffff\1\102\1\76\1\uffff\1\76\2\102\1\76\3\102"+
        "\1\76\2\102";
    static final String DFA16_maxS =
        "\1\121\1\76\1\121\2\122\1\76\1\uffff\1\117\1\76\1\uffff\1\76\1\117"+
        "\1\122\1\76\3\122\1\76\2\117";
    static final String DFA16_acceptS =
        "\6\uffff\1\2\2\uffff\1\1\12\uffff";
    static final String DFA16_specialS =
        "\24\uffff}>";
    static final String[] DFA16_transitionS = {
            "\1\3\2\uffff\1\2\17\uffff\1\1",
            "\1\4",
            "\1\7\2\uffff\1\6\17\uffff\1\5",
            "\2\11\7\uffff\1\6\3\uffff\1\10\2\uffff\1\11",
            "\2\11\7\uffff\1\6\3\uffff\1\12\2\uffff\1\11",
            "\1\13",
            "",
            "\1\14\10\uffff\1\6\3\uffff\1\15",
            "\1\16",
            "",
            "\1\17",
            "\1\20\10\uffff\1\6\3\uffff\1\21",
            "\2\11\7\uffff\1\6\6\uffff\1\11",
            "\1\22",
            "\2\11\7\uffff\1\6\3\uffff\1\10\2\uffff\1\11",
            "\2\11\7\uffff\1\6\3\uffff\1\12\2\uffff\1\11",
            "\2\11\7\uffff\1\6\6\uffff\1\11",
            "\1\23",
            "\1\14\10\uffff\1\6\3\uffff\1\15",
            "\1\20\10\uffff\1\6\3\uffff\1\21"
    };

    static final short[] DFA16_eot = DFA.unpackEncodedString(DFA16_eotS);
    static final short[] DFA16_eof = DFA.unpackEncodedString(DFA16_eofS);
    static final char[] DFA16_min = DFA.unpackEncodedStringToUnsignedChars(DFA16_minS);
    static final char[] DFA16_max = DFA.unpackEncodedStringToUnsignedChars(DFA16_maxS);
    static final short[] DFA16_accept = DFA.unpackEncodedString(DFA16_acceptS);
    static final short[] DFA16_special = DFA.unpackEncodedString(DFA16_specialS);
    static final short[][] DFA16_transition;

    static {
        int numStates = DFA16_transitionS.length;
        DFA16_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA16_transition[i] = DFA.unpackEncodedString(DFA16_transitionS[i]);
        }
    }

    class DFA16 extends DFA {

        public DFA16(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 16;
            this.eot = DFA16_eot;
            this.eof = DFA16_eof;
            this.min = DFA16_min;
            this.max = DFA16_max;
            this.accept = DFA16_accept;
            this.special = DFA16_special;
            this.transition = DFA16_transition;
        }
        public String getDescription() {
            return "239:2: colorOrElem : ( colorLit | colorAnd );";
        }
    }
    static final String DFA19_eotS =
        "\50\uffff";
    static final String DFA19_eofS =
        "\1\1\47\uffff";
    static final String DFA19_minS =
        "\1\76\2\uffff\3\76\2\102\1\76\1\102\1\uffff\3\76\1\102\1\113\1\76"+
        "\1\102\2\76\2\102\1\113\1\76\3\102\2\76\1\102\2\76\5\102\1\76\2"+
        "\102";
    static final String DFA19_maxS =
        "\1\121\2\uffff\1\121\1\76\1\121\2\122\1\76\1\117\1\uffff\1\76\1"+
        "\121\1\76\1\117\1\122\1\76\1\122\1\76\1\121\3\122\1\76\1\117\1\122"+
        "\1\117\2\76\1\117\2\76\1\122\1\117\2\122\1\117\1\76\1\122\1\117";
    static final String DFA19_acceptS =
        "\1\uffff\1\1\1\2\7\uffff\1\3\35\uffff";
    static final String DFA19_specialS =
        "\50\uffff}>";
    static final String[] DFA19_transitionS = {
            "\1\2\2\uffff\1\3\1\uffff\1\1\15\uffff\1\2",
            "",
            "",
            "\1\6\2\uffff\1\5\17\uffff\1\4",
            "\1\7",
            "\1\11\2\uffff\1\12\17\uffff\1\10",
            "\1\2\10\uffff\1\14\3\uffff\1\13\2\uffff\1\12",
            "\1\2\10\uffff\1\14\3\uffff\1\15\2\uffff\1\12",
            "\1\16",
            "\1\17\10\uffff\1\12\3\uffff\1\20",
            "",
            "\1\21",
            "\1\24\2\uffff\1\23\17\uffff\1\22",
            "\1\25",
            "\1\26\10\uffff\1\12\3\uffff\1\27",
            "\1\14\6\uffff\1\12",
            "\1\30",
            "\1\2\10\uffff\1\14\3\uffff\1\13\2\uffff\1\12",
            "\1\31",
            "\1\32\22\uffff\1\33",
            "\1\2\10\uffff\1\14\3\uffff\1\34\2\uffff\1\12",
            "\1\2\10\uffff\1\14\3\uffff\1\15\2\uffff\1\12",
            "\1\14\6\uffff\1\12",
            "\1\35",
            "\1\17\10\uffff\1\12\3\uffff\1\20",
            "\1\2\10\uffff\1\14\3\uffff\1\36\2\uffff\1\12",
            "\1\40\14\uffff\1\37",
            "\1\41",
            "\1\42",
            "\1\26\10\uffff\1\12\3\uffff\1\27",
            "\1\43",
            "\1\44",
            "\1\2\10\uffff\1\14\6\uffff\1\12",
            "\1\46\14\uffff\1\45",
            "\1\2\10\uffff\1\14\3\uffff\1\34\2\uffff\1\12",
            "\1\2\10\uffff\1\14\3\uffff\1\36\2\uffff\1\12",
            "\1\40\14\uffff\1\37",
            "\1\47",
            "\1\2\10\uffff\1\14\6\uffff\1\12",
            "\1\46\14\uffff\1\45"
    };

    static final short[] DFA19_eot = DFA.unpackEncodedString(DFA19_eotS);
    static final short[] DFA19_eof = DFA.unpackEncodedString(DFA19_eofS);
    static final char[] DFA19_min = DFA.unpackEncodedStringToUnsignedChars(DFA19_minS);
    static final char[] DFA19_max = DFA.unpackEncodedStringToUnsignedChars(DFA19_maxS);
    static final short[] DFA19_accept = DFA.unpackEncodedString(DFA19_acceptS);
    static final short[] DFA19_special = DFA.unpackEncodedString(DFA19_specialS);
    static final short[][] DFA19_transition;

    static {
        int numStates = DFA19_transitionS.length;
        DFA19_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA19_transition[i] = DFA.unpackEncodedString(DFA19_transitionS[i]);
        }
    }

    class DFA19 extends DFA {

        public DFA19(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 19;
            this.eot = DFA19_eot;
            this.eof = DFA19_eof;
            this.min = DFA19_min;
            this.max = DFA19_max;
            this.accept = DFA19_accept;
            this.special = DFA19_special;
            this.transition = DFA19_transition;
        }
        public String getDescription() {
            return "244:2: colorOr : ( | colorOrElem ( '|' colorOrElem )+ -> ^( ColorOr ( colorOrElem )+ ) | LPAREN colorOrElem ( '|' colorOrElem )+ RPAREN -> ^( ColorOr ( colorOrElem )+ ) );";
        }
    }
    static final String DFA20_eotS =
        "\104\uffff";
    static final String DFA20_eofS =
        "\1\4\2\uffff\1\12\1\uffff\1\12\10\uffff\1\12\4\uffff\1\12\2\uffff"+
        "\1\45\2\12\10\uffff\1\45\10\uffff\1\45\7\uffff\2\45\6\uffff\2\45"+
        "\10\uffff";
    static final String DFA20_minS =
        "\3\76\1\103\1\uffff\1\103\1\76\1\102\2\76\1\uffff\2\76\1\102\1\103"+
        "\2\76\1\102\1\76\1\103\2\76\3\103\1\76\1\102\2\76\1\102\1\76\1\113"+
        "\1\102\1\103\1\76\1\102\1\76\1\uffff\3\102\1\76\1\103\1\76\1\102"+
        "\1\76\1\113\1\76\1\102\1\76\2\103\2\76\4\102\2\103\1\76\4\102\1"+
        "\76\2\102";
    static final String DFA20_maxS =
        "\1\121\1\76\1\121\1\122\1\uffff\1\122\1\76\1\122\1\121\1\76\1\uffff"+
        "\1\121\1\76\2\122\1\76\1\121\1\117\1\76\1\122\1\76\1\121\3\122\1"+
        "\76\1\122\1\76\1\121\1\122\1\76\1\122\1\117\1\122\1\76\1\117\1\76"+
        "\1\uffff\2\122\1\117\1\76\1\122\1\76\1\117\1\76\1\122\1\76\1\117"+
        "\1\76\2\122\2\76\1\122\1\117\1\122\1\117\2\122\1\76\1\117\1\122"+
        "\1\117\1\122\1\76\2\117";
    static final String DFA20_acceptS =
        "\4\uffff\1\3\5\uffff\1\1\32\uffff\1\2\36\uffff";
    static final String DFA20_specialS =
        "\104\uffff}>";
    static final String[] DFA20_transitionS = {
            "\1\3\2\uffff\1\2\1\uffff\1\4\15\uffff\1\1",
            "\1\5",
            "\1\7\2\uffff\1\10\17\uffff\1\6",
            "\1\12\7\uffff\1\13\3\uffff\1\11\2\uffff\1\4",
            "",
            "\1\12\7\uffff\1\13\3\uffff\1\14\2\uffff\1\4",
            "\1\15",
            "\1\16\10\uffff\1\20\3\uffff\1\17\2\uffff\1\4",
            "\1\21\2\uffff\1\4\17\uffff\1\22",
            "\1\23",
            "",
            "\1\26\2\uffff\1\25\17\uffff\1\24",
            "\1\27",
            "\1\30\10\uffff\1\20\3\uffff\1\31\2\uffff\1\4",
            "\1\12\7\uffff\1\13\6\uffff\1\4",
            "\1\32",
            "\1\35\2\uffff\1\34\17\uffff\1\33",
            "\1\37\10\uffff\1\4\3\uffff\1\36",
            "\1\40",
            "\1\12\7\uffff\1\13\3\uffff\1\11\2\uffff\1\4",
            "\1\41",
            "\1\43\22\uffff\1\42",
            "\1\45\7\uffff\1\13\3\uffff\1\44\2\uffff\1\4",
            "\1\12\7\uffff\1\13\3\uffff\1\14\2\uffff\1\4",
            "\1\12\7\uffff\1\13\6\uffff\1\4",
            "\1\46",
            "\1\16\10\uffff\1\20\3\uffff\1\17\2\uffff\1\4",
            "\1\47",
            "\1\50\22\uffff\1\51",
            "\1\52\10\uffff\1\20\3\uffff\1\53\2\uffff\1\4",
            "\1\54",
            "\1\20\6\uffff\1\4",
            "\1\56\10\uffff\1\4\3\uffff\1\55",
            "\1\45\7\uffff\1\13\3\uffff\1\57\2\uffff\1\4",
            "\1\60",
            "\1\62\14\uffff\1\61",
            "\1\63",
            "",
            "\1\30\10\uffff\1\20\3\uffff\1\31\2\uffff\1\4",
            "\1\52\10\uffff\1\20\3\uffff\1\64\2\uffff\1\4",
            "\1\66\14\uffff\1\65",
            "\1\67",
            "\1\45\16\uffff\1\4",
            "\1\70",
            "\1\37\10\uffff\1\4\3\uffff\1\36",
            "\1\71",
            "\1\20\6\uffff\1\4",
            "\1\72",
            "\1\73\14\uffff\1\74",
            "\1\75",
            "\1\45\7\uffff\1\13\6\uffff\1\4",
            "\1\45\7\uffff\1\13\3\uffff\1\44\2\uffff\1\4",
            "\1\76",
            "\1\77",
            "\1\52\10\uffff\1\20\6\uffff\1\4",
            "\1\100\14\uffff\1\101",
            "\1\52\10\uffff\1\20\3\uffff\1\53\2\uffff\1\4",
            "\1\56\10\uffff\1\4\3\uffff\1\55",
            "\1\45\7\uffff\1\13\3\uffff\1\57\2\uffff\1\4",
            "\1\45\7\uffff\1\13\6\uffff\1\4",
            "\1\102",
            "\1\62\14\uffff\1\61",
            "\1\52\10\uffff\1\20\3\uffff\1\64\2\uffff\1\4",
            "\1\66\14\uffff\1\65",
            "\1\52\10\uffff\1\20\6\uffff\1\4",
            "\1\103",
            "\1\73\14\uffff\1\74",
            "\1\100\14\uffff\1\101"
    };

    static final short[] DFA20_eot = DFA.unpackEncodedString(DFA20_eotS);
    static final short[] DFA20_eof = DFA.unpackEncodedString(DFA20_eofS);
    static final char[] DFA20_min = DFA.unpackEncodedStringToUnsignedChars(DFA20_minS);
    static final char[] DFA20_max = DFA.unpackEncodedStringToUnsignedChars(DFA20_maxS);
    static final short[] DFA20_accept = DFA.unpackEncodedString(DFA20_acceptS);
    static final short[] DFA20_special = DFA.unpackEncodedString(DFA20_specialS);
    static final short[][] DFA20_transition;

    static {
        int numStates = DFA20_transitionS.length;
        DFA20_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA20_transition[i] = DFA.unpackEncodedString(DFA20_transitionS[i]);
        }
    }

    class DFA20 extends DFA {

        public DFA20(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 20;
            this.eot = DFA20_eot;
            this.eof = DFA20_eof;
            this.min = DFA20_min;
            this.max = DFA20_max;
            this.accept = DFA20_accept;
            this.special = DFA20_special;
            this.transition = DFA20_transition;
        }
        public String getDescription() {
            return "250:2: colorExpr : ( colorLit -> ^( ColorExpr colorLit ) | colorAnd -> ^( ColorExpr colorAnd ) | colorOr -> ^( ColorExpr colorOr ) );";
        }
    }
    static final String DFA21_eotS =
        "\6\uffff";
    static final String DFA21_eofS =
        "\1\uffff\1\4\3\uffff\1\4";
    static final String DFA21_minS =
        "\1\76\1\71\1\76\2\uffff\1\71";
    static final String DFA21_maxS =
        "\1\76\1\117\1\76\2\uffff\1\117";
    static final String DFA21_acceptS =
        "\3\uffff\1\2\1\1\1\uffff";
    static final String DFA21_specialS =
        "\6\uffff}>";
    static final String[] DFA21_transitionS = {
            "\1\1",
            "\1\3\25\uffff\1\2",
            "\1\5",
            "",
            "",
            "\1\3\25\uffff\1\2"
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "328:1: moduleChoice : ( name -> ^( ModulePromise name ) | name CONTAINS names -> ^( ModuleWrapper name names ) );";
        }
    }
    static final String DFA23_eotS =
        "\12\uffff";
    static final String DFA23_eofS =
        "\12\uffff";
    static final String DFA23_minS =
        "\1\76\1\72\2\76\2\uffff\2\72\1\76\1\72";
    static final String DFA23_maxS =
        "\1\76\1\120\2\76\2\uffff\2\120\1\76\1\120";
    static final String DFA23_acceptS =
        "\4\uffff\1\2\1\1\4\uffff";
    static final String DFA23_specialS =
        "\12\uffff}>";
    static final String[] DFA23_transitionS = {
            "\1\1",
            "\1\5\1\uffff\1\4\22\uffff\1\2\1\3",
            "\1\6",
            "\1\7",
            "",
            "",
            "\1\5\1\uffff\1\4\22\uffff\1\2\1\3",
            "\1\5\1\uffff\1\4\22\uffff\1\10\1\3",
            "\1\11",
            "\1\5\1\uffff\1\4\22\uffff\1\10\1\3"
    };

    static final short[] DFA23_eot = DFA.unpackEncodedString(DFA23_eotS);
    static final short[] DFA23_eof = DFA.unpackEncodedString(DFA23_eofS);
    static final char[] DFA23_min = DFA.unpackEncodedStringToUnsignedChars(DFA23_minS);
    static final char[] DFA23_max = DFA.unpackEncodedStringToUnsignedChars(DFA23_maxS);
    static final short[] DFA23_accept = DFA.unpackEncodedString(DFA23_acceptS);
    static final short[] DFA23_special = DFA.unpackEncodedString(DFA23_specialS);
    static final short[][] DFA23_transition;

    static {
        int numStates = DFA23_transitionS.length;
        DFA23_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA23_transition[i] = DFA.unpackEncodedString(DFA23_transitionS[i]);
        }
    }

    class DFA23 extends DFA {

        public DFA23(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 23;
            this.eot = DFA23_eot;
            this.eof = DFA23_eof;
            this.min = DFA23_min;
            this.max = DFA23_max;
            this.accept = DFA23_accept;
            this.special = DFA23_special;
            this.transition = DFA23_transition;
        }
        public String getDescription() {
            return "349:1: export : ( names FROM name EOF -> ^( Export names name ) | names TO names EOF -> ^( ExportTo names names ) );";
        }
    }
 

    public static final BitSet FOLLOW_74_in_testResult495 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult497 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_75_in_testResult499 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult501 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_76_in_testResult503 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_74_in_testResult523 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult525 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_76_in_testResult527 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_74_in_testResult543 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult545 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_75_in_testResult547 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult549 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_testResult551 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_74_in_testResult569 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult571 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_testResult573 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_77_in_testResultComment597 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_78_in_testResultComment601 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_testResult_in_testResultComment609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName629 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_79_in_qualifiedName643 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName645 = new BitSet(new long[]{0x0000000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleName666 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_name690 = new BitSet(new long[]{0x0000000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_79_in_name693 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_name695 = new BitSet(new long[]{0x0000000000000002L,0x0000000000008000L});
    public static final BitSet FOLLOW_qualifiedName_in_qualifiedNamedType711 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleNamedType732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedNamedType_in_qualifiedRegionName752 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_76_in_qualifiedRegionName754 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedRegionName756 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleNamedType_in_qualifiedRegionName771 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_76_in_qualifiedRegionName773 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedRegionName775 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionSpecification_in_regionSpecifications796 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_80_in_regionSpecifications799 = new BitSet(new long[]{0xC000000000000000L});
    public static final BitSet FOLLOW_regionSpecification_in_regionSpecifications801 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_qualifiedRegionName_in_regionSpecification823 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleRegionSpecification_in_regionSpecification829 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionName_in_simpleRegionSpecification842 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LBRACKET_in_simpleRegionSpecification848 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_RBRACKET_in_simpleRegionSpecification850 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_regionName872 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedName_in_colorName898 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleName_in_colorName912 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorName_in_colorNames936 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_80_in_colorNames939 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_colorName_in_colorNames941 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_simpleName_in_colorSimpleNames964 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_80_in_colorSimpleNames967 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_simpleName_in_colorSimpleNames969 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_colorNot_in_colorLit998 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_colorLit1008 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_colorNot_in_colorLit1010 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_RPAREN_in_colorLit1012 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorName_in_colorLit1022 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_colorLit1032 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_colorName_in_colorLit1034 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_RPAREN_in_colorLit1036 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_81_in_colorNot1055 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_colorName_in_colorNot1057 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorLit_in_colorAnd1079 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_75_in_colorAnd1082 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorLit_in_colorAnd1084 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000800L});
    public static final BitSet FOLLOW_LPAREN_in_colorAnd1101 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorLit_in_colorAnd1103 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_75_in_colorAnd1106 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorLit_in_colorAnd1108 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000804L});
    public static final BitSet FOLLOW_RPAREN_in_colorAnd1112 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorLit_in_colorOrElem1135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorAnd_in_colorOrElem1141 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorOrElem_in_colorOr1164 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_82_in_colorOr1167 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorOrElem_in_colorOr1169 = new BitSet(new long[]{0x0000000000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_LPAREN_in_colorOr1186 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorOrElem_in_colorOr1188 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_82_in_colorOr1191 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorOrElem_in_colorOr1193 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040004L});
    public static final BitSet FOLLOW_RPAREN_in_colorOr1197 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorLit_in_colorExpr1222 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorAnd_in_colorExpr1236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorOr_in_colorExpr1250 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EOF_in_nothing1278 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_nothing_in_colorTransparent1303 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorTransparent1305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorNames_in_colorDeclare1332 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorDeclare1334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorNames_in_colorGrant1359 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorGrant1361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorNames_in_colorRevoke1385 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorRevoke1387 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorNames_in_colorIncompatible1410 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorIncompatible1412 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorExpr_in_color1436 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_color1438 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorExpr_in_colorConstraint1458 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorConstraint1460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedName_in_colorImport1483 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorImport1485 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorName_in_colorRename1505 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_in_colorRename1507 = new BitSet(new long[]{0x4000000000000000L,0x0000000000020002L});
    public static final BitSet FOLLOW_colorExpr_in_colorRename1509 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionSpecifications_in_colorized1532 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorized1534 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorExpr_in_colorConstrainedRegions1556 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_in_colorConstrainedRegions1558 = new BitSet(new long[]{0xC000000000000000L});
    public static final BitSet FOLLOW_regionSpecifications_in_colorConstrainedRegions1560 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorConstrainedRegions1562 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_colorCardSpec_in_colorCard1586 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_colorCard1588 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_83_in_colorCardSpec1605 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_in_colorCardSpec1607 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_colorSimpleNames_in_colorCardSpec1609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_moduleChoice1634 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_moduleChoice1647 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_CONTAINS_in_moduleChoice1649 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_names_in_moduleChoice1651 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_moduleChoice_in_module1674 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_module1676 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_vis1698 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_vis1702 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_nothing_in_noVis1723 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_noVis1725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_names_in_export1743 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_FROM_in_export1745 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_name_in_export1747 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_export1749 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_names_in_export1764 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_TO_in_export1766 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_names_in_export1768 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_export1770 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_names1792 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_80_in_names1795 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_name_in_names1797 = new BitSet(new long[]{0x0000000000000002L,0x0000000000010000L});
    public static final BitSet FOLLOW_ofNamesClause_in_blockImport1825 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_FROM_in_blockImport1828 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_names_in_blockImport1830 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_blockImport1832 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OF_in_ofNamesClause1860 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_names_in_ofNamesClause1862 = new BitSet(new long[]{0x0000000000000002L});

}
