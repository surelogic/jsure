// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g 2008-09-25 15:48:52

package com.surelogic.annotation.parse;

import edu.cmu.cs.fluid.ir.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class ScopedPromisesParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "START_IMAGINARY", "QualifiedThisExpression", "BooleanType", "ByteType", "CharType", "ShortType", "IntType", "FloatType", "DoubleType", "LongType", "NamedType", "TypeRef", "ArrayType", "TypeQualifierPattern", "Annotations", "ThisExpression", "SuperExpression", "ReturnValueDeclaration", "FieldRef", "TypeExpression", "VariableUseExpression", "ClassExpression", "Nothing", "ScopedPromise", "AnyTarget", "AndTarget", "OrTarget", "NotTarget", "ConstructorDeclPattern", "MethodDeclPattern", "FieldDeclPattern", "TypeDeclPattern", "NamedTypePattern", "Parameters", "Throws", "InPattern", "InPackagePattern", "InAndPattern", "InOrPattern", "InNotPattern", "WildcardTypeQualifierPattern", "END_IMAGINARY", "INSTANCE", "MUTABLE", "FOR", "PromiseStringLiteral", "StringLiteral", "DOT", "IN", "IDENTIFIER", "STAR", "DSTAR", "VOID", "BOOLEAN", "BYTE", "CHAR", "SHORT", "INT", "FLOAT", "DOUBLE", "LONG", "WildcardIdentifier", "PUBLIC", "PROTECTED", "PRIVATE", "STATIC", "CLASS", "THIS", "ABSTRACT", "FINAL", "COLON", "SEMI", "LBRACKET", "RBRACKET", "AT", "LPAREN", "RPAREN", "QUOTE", "DQUOTE", "LBRACE", "RBRACE", "COMMA", "HexDigit", "IntegerTypeSuffix", "HexLiteral", "DecimalLiteral", "OctalLiteral", "Exponent", "FloatTypeSuffix", "FloatingPointLiteral", "EscapeSequence", "CharacterLiteral", "UnicodeEscape", "OctalEscape", "LETTER", "JavaIDDigit", "ID", "ID2", "WS", "NEWLINE", "'|'", "'&'", "'!'", "'new'"
    };
    public static final int COMMA=85;
    public static final int HexDigit=86;
    public static final int Throws=38;
    public static final int DOUBLE=63;
    public static final int START_IMAGINARY=4;
    public static final int FieldRef=22;
    public static final int ABSTRACT=72;
    public static final int IntType=10;
    public static final int NamedTypePattern=36;
    public static final int INSTANCE=46;
    public static final int DQUOTE=82;
    public static final int NEWLINE=103;
    public static final int DOT=51;
    public static final int PRIVATE=68;
    public static final int AndTarget=29;
    public static final int RBRACKET=77;
    public static final int FieldDeclPattern=34;
    public static final int RPAREN=80;
    public static final int WildcardIdentifier=65;
    public static final int ID2=101;
    public static final int VariableUseExpression=24;
    public static final int FloatTypeSuffix=92;
    public static final int AT=78;
    public static final int MethodDeclPattern=33;
    public static final int IntegerTypeSuffix=87;
    public static final int ClassExpression=25;
    public static final int InPattern=39;
    public static final int WS=102;
    public static final int ConstructorDeclPattern=32;
    public static final int SuperExpression=20;
    public static final int CHAR=59;
    public static final int WildcardTypeQualifierPattern=44;
    public static final int ReturnValueDeclaration=21;
    public static final int QualifiedThisExpression=5;
    public static final int NamedType=14;
    public static final int FINAL=73;
    public static final int InOrPattern=42;
    public static final int MUTABLE=47;
    public static final int TypeDeclPattern=35;
    public static final int STATIC=69;
    public static final int SEMI=75;
    public static final int FloatType=11;
    public static final int UnicodeEscape=96;
    public static final int HexLiteral=88;
    public static final int OrTarget=30;
    public static final int BOOLEAN=57;
    public static final int DecimalLiteral=89;
    public static final int DoubleType=12;
    public static final int ScopedPromise=27;
    public static final int COLON=74;
    public static final int Parameters=37;
    public static final int TypeQualifierPattern=17;
    public static final int IDENTIFIER=53;
    public static final int SHORT=60;
    public static final int ThisExpression=19;
    public static final int PUBLIC=66;
    public static final int LONG=64;
    public static final int TypeExpression=23;
    public static final int OctalLiteral=90;
    public static final int PromiseStringLiteral=49;
    public static final int FLOAT=62;
    public static final int LBRACKET=76;
    public static final int T__104=104;
    public static final int T__107=107;
    public static final int DSTAR=55;
    public static final int LBRACE=83;
    public static final int T__106=106;
    public static final int RBRACE=84;
    public static final int PROTECTED=67;
    public static final int NotTarget=31;
    public static final int BooleanType=6;
    public static final int EscapeSequence=94;
    public static final int INT=61;
    public static final int VOID=56;
    public static final int InPackagePattern=40;
    public static final int LPAREN=79;
    public static final int Nothing=26;
    public static final int InNotPattern=43;
    public static final int FloatingPointLiteral=93;
    public static final int ID=100;
    public static final int ByteType=7;
    public static final int LETTER=98;
    public static final int Exponent=91;
    public static final int Annotations=18;
    public static final int CharType=8;
    public static final int END_IMAGINARY=45;
    public static final int CharacterLiteral=95;
    public static final int AnyTarget=28;
    public static final int StringLiteral=50;
    public static final int QUOTE=81;
    public static final int THIS=71;
    public static final int InAndPattern=41;
    public static final int IN=52;
    public static final int ShortType=9;
    public static final int JavaIDDigit=99;
    public static final int TypeRef=15;
    public static final int CLASS=70;
    public static final int T__105=105;
    public static final int BYTE=58;
    public static final int EOF=-1;
    public static final int FOR=48;
    public static final int ArrayType=16;
    public static final int OctalEscape=97;
    public static final int STAR=54;
    public static final int LongType=13;

    // delegates
    // delegators


        public ScopedPromisesParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public ScopedPromisesParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return ScopedPromisesParser.tokenNames; }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g"; }


    @Override
    protected void mismatch(IntStream input, int ttype, BitSet follow)
    	throws RecognitionException{
    	throw new MismatchedTokenException(ttype, input);
    }
    @Override
    public Object recoverFromMismatchedSet(IntStream input, RecognitionException e, BitSet follow)
    	throws RecognitionException{
    	reportError(e);
    	throw e;
    }

      IRNode context;
      
      void setContext(IRNode n) {
        context = n;
      }
      
      boolean isType(String prefix, Token id) { 
        return ParseUtil.isType(context, prefix, id.getText());
      }


    public static class scopedPromise_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scopedPromise"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:111:1: scopedPromise : ( promiseString -> ^( ScopedPromise promiseString ^( AnyTarget ) ) | promiseString FOR promiseTarget -> ^( ScopedPromise promiseString promiseTarget ) );
    public final ScopedPromisesParser.scopedPromise_return scopedPromise() throws RecognitionException {
        ScopedPromisesParser.scopedPromise_return retval = new ScopedPromisesParser.scopedPromise_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token FOR3=null;
        ScopedPromisesParser.promiseString_return promiseString1 = null;

        ScopedPromisesParser.promiseString_return promiseString2 = null;

        ScopedPromisesParser.promiseTarget_return promiseTarget4 = null;


        Tree FOR3_tree=null;
        RewriteRuleTokenStream stream_FOR=new RewriteRuleTokenStream(adaptor,"token FOR");
        RewriteRuleSubtreeStream stream_promiseTarget=new RewriteRuleSubtreeStream(adaptor,"rule promiseTarget");
        RewriteRuleSubtreeStream stream_promiseString=new RewriteRuleSubtreeStream(adaptor,"rule promiseString");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:116:3: ( promiseString -> ^( ScopedPromise promiseString ^( AnyTarget ) ) | promiseString FOR promiseTarget -> ^( ScopedPromise promiseString promiseTarget ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( ((LA1_0>=PromiseStringLiteral && LA1_0<=StringLiteral)) ) {
                int LA1_1 = input.LA(2);

                if ( (LA1_1==EOF) ) {
                    alt1=1;
                }
                else if ( (LA1_1==FOR) ) {
                    alt1=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:116:5: promiseString
                    {
                    pushFollow(FOLLOW_promiseString_in_scopedPromise308);
                    promiseString1=promiseString();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_promiseString.add(promiseString1.getTree());


                    // AST REWRITE
                    // elements: promiseString
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 116:19: -> ^( ScopedPromise promiseString ^( AnyTarget ) )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:116:22: ^( ScopedPromise promiseString ^( AnyTarget ) )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ScopedPromise, "ScopedPromise"), root_1);

                        adaptor.addChild(root_1, stream_promiseString.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:116:52: ^( AnyTarget )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(AnyTarget, "AnyTarget"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:117:5: promiseString FOR promiseTarget
                    {
                    pushFollow(FOLLOW_promiseString_in_scopedPromise326);
                    promiseString2=promiseString();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_promiseString.add(promiseString2.getTree());
                    FOR3=(Token)match(input,FOR,FOLLOW_FOR_in_scopedPromise328); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOR.add(FOR3);

                    pushFollow(FOLLOW_promiseTarget_in_scopedPromise330);
                    promiseTarget4=promiseTarget();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_promiseTarget.add(promiseTarget4.getTree());


                    // AST REWRITE
                    // elements: promiseTarget, promiseString
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 117:37: -> ^( ScopedPromise promiseString promiseTarget )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:117:40: ^( ScopedPromise promiseString promiseTarget )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ScopedPromise, "ScopedPromise"), root_1);

                        adaptor.addChild(root_1, stream_promiseString.nextTree());
                        adaptor.addChild(root_1, stream_promiseTarget.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "scopedPromise"

    public static class promiseString_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "promiseString"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:120:1: promiseString : ( PromiseStringLiteral | StringLiteral );
    public final ScopedPromisesParser.promiseString_return promiseString() throws RecognitionException {
        ScopedPromisesParser.promiseString_return retval = new ScopedPromisesParser.promiseString_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token set5=null;

        Tree set5_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:121:3: ( PromiseStringLiteral | StringLiteral )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
            {
            root_0 = (Tree)adaptor.nil();

            set5=(Token)input.LT(1);
            if ( (input.LA(1)>=PromiseStringLiteral && input.LA(1)<=StringLiteral) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (Tree)adaptor.create(set5));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "promiseString"

    public static class promiseTarget_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "promiseTarget"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:125:1: promiseTarget : ( andTarget -> andTarget ) ( '|' a= andTarget -> ^( OrTarget $promiseTarget $a) )* ;
    public final ScopedPromisesParser.promiseTarget_return promiseTarget() throws RecognitionException {
        ScopedPromisesParser.promiseTarget_return retval = new ScopedPromisesParser.promiseTarget_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal7=null;
        ScopedPromisesParser.andTarget_return a = null;

        ScopedPromisesParser.andTarget_return andTarget6 = null;


        Tree char_literal7_tree=null;
        RewriteRuleTokenStream stream_104=new RewriteRuleTokenStream(adaptor,"token 104");
        RewriteRuleSubtreeStream stream_andTarget=new RewriteRuleSubtreeStream(adaptor,"rule andTarget");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:126:3: ( ( andTarget -> andTarget ) ( '|' a= andTarget -> ^( OrTarget $promiseTarget $a) )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:126:5: ( andTarget -> andTarget ) ( '|' a= andTarget -> ^( OrTarget $promiseTarget $a) )*
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:126:5: ( andTarget -> andTarget )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:126:6: andTarget
            {
            pushFollow(FOLLOW_andTarget_in_promiseTarget379);
            andTarget6=andTarget();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_andTarget.add(andTarget6.getTree());


            // AST REWRITE
            // elements: andTarget
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 126:16: -> andTarget
            {
                adaptor.addChild(root_0, stream_andTarget.nextTree());

            }

            retval.tree = root_0;}
            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:127:5: ( '|' a= andTarget -> ^( OrTarget $promiseTarget $a) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==104) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:127:6: '|' a= andTarget
            	    {
            	    char_literal7=(Token)match(input,104,FOLLOW_104_in_promiseTarget392); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_104.add(char_literal7);

            	    pushFollow(FOLLOW_andTarget_in_promiseTarget396);
            	    a=andTarget();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_andTarget.add(a.getTree());


            	    // AST REWRITE
            	    // elements: a, promiseTarget
            	    // token labels: 
            	    // rule labels: a, retval
            	    // token list labels: 
            	    // rule list labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_a=new RewriteRuleSubtreeStream(adaptor,"token a",a!=null?a.tree:null);
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            	    root_0 = (Tree)adaptor.nil();
            	    // 127:22: -> ^( OrTarget $promiseTarget $a)
            	    {
            	        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:127:25: ^( OrTarget $promiseTarget $a)
            	        {
            	        Tree root_1 = (Tree)adaptor.nil();
            	        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OrTarget, "OrTarget"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_a.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "promiseTarget"

    public static class andTarget_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "andTarget"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:130:1: andTarget : ( baseTarget -> baseTarget ) ( '&' b= baseTarget -> ^( AndTarget $andTarget $b) )* ;
    public final ScopedPromisesParser.andTarget_return andTarget() throws RecognitionException {
        ScopedPromisesParser.andTarget_return retval = new ScopedPromisesParser.andTarget_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal9=null;
        ScopedPromisesParser.baseTarget_return b = null;

        ScopedPromisesParser.baseTarget_return baseTarget8 = null;


        Tree char_literal9_tree=null;
        RewriteRuleTokenStream stream_105=new RewriteRuleTokenStream(adaptor,"token 105");
        RewriteRuleSubtreeStream stream_baseTarget=new RewriteRuleSubtreeStream(adaptor,"rule baseTarget");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:131:3: ( ( baseTarget -> baseTarget ) ( '&' b= baseTarget -> ^( AndTarget $andTarget $b) )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:131:5: ( baseTarget -> baseTarget ) ( '&' b= baseTarget -> ^( AndTarget $andTarget $b) )*
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:131:5: ( baseTarget -> baseTarget )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:131:6: baseTarget
            {
            pushFollow(FOLLOW_baseTarget_in_andTarget427);
            baseTarget8=baseTarget();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_baseTarget.add(baseTarget8.getTree());


            // AST REWRITE
            // elements: baseTarget
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 131:17: -> baseTarget
            {
                adaptor.addChild(root_0, stream_baseTarget.nextTree());

            }

            retval.tree = root_0;}
            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:132:5: ( '&' b= baseTarget -> ^( AndTarget $andTarget $b) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==105) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:132:6: '&' b= baseTarget
            	    {
            	    char_literal9=(Token)match(input,105,FOLLOW_105_in_andTarget440); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_105.add(char_literal9);

            	    pushFollow(FOLLOW_baseTarget_in_andTarget444);
            	    b=baseTarget();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_baseTarget.add(b.getTree());


            	    // AST REWRITE
            	    // elements: andTarget, b
            	    // token labels: 
            	    // rule labels: retval, b
            	    // token list labels: 
            	    // rule list labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_b=new RewriteRuleSubtreeStream(adaptor,"token b",b!=null?b.tree:null);

            	    root_0 = (Tree)adaptor.nil();
            	    // 132:23: -> ^( AndTarget $andTarget $b)
            	    {
            	        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:132:26: ^( AndTarget $andTarget $b)
            	        {
            	        Tree root_1 = (Tree)adaptor.nil();
            	        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(AndTarget, "AndTarget"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_b.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "andTarget"

    public static class baseTarget_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "baseTarget"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:135:1: baseTarget : ( ( constructorDeclPattern )=> constructorDeclPattern | ( noReturnMethodDeclPattern )=> noReturnMethodDeclPattern | ( fieldDeclPattern )=> fieldDeclPattern | typeDeclPattern | '!' '(' promiseTarget ')' -> ^( NotTarget promiseTarget ) | '(' promiseTarget ')' -> promiseTarget );
    public final ScopedPromisesParser.baseTarget_return baseTarget() throws RecognitionException {
        ScopedPromisesParser.baseTarget_return retval = new ScopedPromisesParser.baseTarget_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal14=null;
        Token char_literal15=null;
        Token char_literal17=null;
        Token char_literal18=null;
        Token char_literal20=null;
        ScopedPromisesParser.constructorDeclPattern_return constructorDeclPattern10 = null;

        ScopedPromisesParser.noReturnMethodDeclPattern_return noReturnMethodDeclPattern11 = null;

        ScopedPromisesParser.fieldDeclPattern_return fieldDeclPattern12 = null;

        ScopedPromisesParser.typeDeclPattern_return typeDeclPattern13 = null;

        ScopedPromisesParser.promiseTarget_return promiseTarget16 = null;

        ScopedPromisesParser.promiseTarget_return promiseTarget19 = null;


        Tree char_literal14_tree=null;
        Tree char_literal15_tree=null;
        Tree char_literal17_tree=null;
        Tree char_literal18_tree=null;
        Tree char_literal20_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_106=new RewriteRuleTokenStream(adaptor,"token 106");
        RewriteRuleSubtreeStream stream_promiseTarget=new RewriteRuleSubtreeStream(adaptor,"rule promiseTarget");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:136:3: ( ( constructorDeclPattern )=> constructorDeclPattern | ( noReturnMethodDeclPattern )=> noReturnMethodDeclPattern | ( fieldDeclPattern )=> fieldDeclPattern | typeDeclPattern | '!' '(' promiseTarget ')' -> ^( NotTarget promiseTarget ) | '(' promiseTarget ')' -> promiseTarget )
            int alt4=6;
            alt4 = dfa4.predict(input);
            switch (alt4) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:136:5: ( constructorDeclPattern )=> constructorDeclPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_constructorDeclPattern_in_baseTarget483);
                    constructorDeclPattern10=constructorDeclPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, constructorDeclPattern10.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:138:5: ( noReturnMethodDeclPattern )=> noReturnMethodDeclPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_noReturnMethodDeclPattern_in_baseTarget496);
                    noReturnMethodDeclPattern11=noReturnMethodDeclPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, noReturnMethodDeclPattern11.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:139:5: ( fieldDeclPattern )=> fieldDeclPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_fieldDeclPattern_in_baseTarget508);
                    fieldDeclPattern12=fieldDeclPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, fieldDeclPattern12.getTree());

                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:140:5: typeDeclPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_typeDeclPattern_in_baseTarget514);
                    typeDeclPattern13=typeDeclPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDeclPattern13.getTree());

                    }
                    break;
                case 5 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:141:5: '!' '(' promiseTarget ')'
                    {
                    char_literal14=(Token)match(input,106,FOLLOW_106_in_baseTarget520); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_106.add(char_literal14);

                    char_literal15=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_baseTarget522); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal15);

                    pushFollow(FOLLOW_promiseTarget_in_baseTarget524);
                    promiseTarget16=promiseTarget();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_promiseTarget.add(promiseTarget16.getTree());
                    char_literal17=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_baseTarget526); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal17);



                    // AST REWRITE
                    // elements: promiseTarget
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 141:31: -> ^( NotTarget promiseTarget )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:141:34: ^( NotTarget promiseTarget )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NotTarget, "NotTarget"), root_1);

                        adaptor.addChild(root_1, stream_promiseTarget.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:142:5: '(' promiseTarget ')'
                    {
                    char_literal18=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_baseTarget540); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal18);

                    pushFollow(FOLLOW_promiseTarget_in_baseTarget542);
                    promiseTarget19=promiseTarget();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_promiseTarget.add(promiseTarget19.getTree());
                    char_literal20=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_baseTarget544); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal20);



                    // AST REWRITE
                    // elements: promiseTarget
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 142:27: -> promiseTarget
                    {
                        adaptor.addChild(root_0, stream_promiseTarget.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "baseTarget"

    public static class constructorDeclPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constructorDeclPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:145:1: constructorDeclPattern : ( accessModPattern typeQualifierPattern 'new' methodSigPattern -> ^( ConstructorDeclPattern accessModPattern typeQualifierPattern ^( InPattern ) methodSigPattern ) | accessModPattern 'new' methodSigPattern inPattern -> ^( ConstructorDeclPattern accessModPattern ^( TypeQualifierPattern ) inPattern methodSigPattern ^( Throws ) ) );
    public final ScopedPromisesParser.constructorDeclPattern_return constructorDeclPattern() throws RecognitionException {
        ScopedPromisesParser.constructorDeclPattern_return retval = new ScopedPromisesParser.constructorDeclPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal23=null;
        Token string_literal26=null;
        ScopedPromisesParser.accessModPattern_return accessModPattern21 = null;

        ScopedPromisesParser.typeQualifierPattern_return typeQualifierPattern22 = null;

        ScopedPromisesParser.methodSigPattern_return methodSigPattern24 = null;

        ScopedPromisesParser.accessModPattern_return accessModPattern25 = null;

        ScopedPromisesParser.methodSigPattern_return methodSigPattern27 = null;

        ScopedPromisesParser.inPattern_return inPattern28 = null;


        Tree string_literal23_tree=null;
        Tree string_literal26_tree=null;
        RewriteRuleTokenStream stream_107=new RewriteRuleTokenStream(adaptor,"token 107");
        RewriteRuleSubtreeStream stream_methodSigPattern=new RewriteRuleSubtreeStream(adaptor,"rule methodSigPattern");
        RewriteRuleSubtreeStream stream_accessModPattern=new RewriteRuleSubtreeStream(adaptor,"rule accessModPattern");
        RewriteRuleSubtreeStream stream_inPattern=new RewriteRuleSubtreeStream(adaptor,"rule inPattern");
        RewriteRuleSubtreeStream stream_typeQualifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule typeQualifierPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:150:3: ( accessModPattern typeQualifierPattern 'new' methodSigPattern -> ^( ConstructorDeclPattern accessModPattern typeQualifierPattern ^( InPattern ) methodSigPattern ) | accessModPattern 'new' methodSigPattern inPattern -> ^( ConstructorDeclPattern accessModPattern ^( TypeQualifierPattern ) inPattern methodSigPattern ^( Throws ) ) )
            int alt5=2;
            alt5 = dfa5.predict(input);
            switch (alt5) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:150:5: accessModPattern typeQualifierPattern 'new' methodSigPattern
                    {
                    pushFollow(FOLLOW_accessModPattern_in_constructorDeclPattern564);
                    accessModPattern21=accessModPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_accessModPattern.add(accessModPattern21.getTree());
                    pushFollow(FOLLOW_typeQualifierPattern_in_constructorDeclPattern566);
                    typeQualifierPattern22=typeQualifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeQualifierPattern.add(typeQualifierPattern22.getTree());
                    string_literal23=(Token)match(input,107,FOLLOW_107_in_constructorDeclPattern568); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_107.add(string_literal23);

                    pushFollow(FOLLOW_methodSigPattern_in_constructorDeclPattern570);
                    methodSigPattern24=methodSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_methodSigPattern.add(methodSigPattern24.getTree());


                    // AST REWRITE
                    // elements: methodSigPattern, accessModPattern, typeQualifierPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 150:66: -> ^( ConstructorDeclPattern accessModPattern typeQualifierPattern ^( InPattern ) methodSigPattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:151:5: ^( ConstructorDeclPattern accessModPattern typeQualifierPattern ^( InPattern ) methodSigPattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ConstructorDeclPattern, "ConstructorDeclPattern"), root_1);

                        adaptor.addChild(root_1, stream_accessModPattern.nextTree());
                        adaptor.addChild(root_1, stream_typeQualifierPattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:151:68: ^( InPattern )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPattern, "InPattern"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_methodSigPattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:152:5: accessModPattern 'new' methodSigPattern inPattern
                    {
                    pushFollow(FOLLOW_accessModPattern_in_constructorDeclPattern596);
                    accessModPattern25=accessModPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_accessModPattern.add(accessModPattern25.getTree());
                    string_literal26=(Token)match(input,107,FOLLOW_107_in_constructorDeclPattern598); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_107.add(string_literal26);

                    pushFollow(FOLLOW_methodSigPattern_in_constructorDeclPattern600);
                    methodSigPattern27=methodSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_methodSigPattern.add(methodSigPattern27.getTree());
                    pushFollow(FOLLOW_inPattern_in_constructorDeclPattern602);
                    inPattern28=inPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inPattern.add(inPattern28.getTree());


                    // AST REWRITE
                    // elements: methodSigPattern, inPattern, accessModPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 152:55: -> ^( ConstructorDeclPattern accessModPattern ^( TypeQualifierPattern ) inPattern methodSigPattern ^( Throws ) )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:153:5: ^( ConstructorDeclPattern accessModPattern ^( TypeQualifierPattern ) inPattern methodSigPattern ^( Throws ) )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ConstructorDeclPattern, "ConstructorDeclPattern"), root_1);

                        adaptor.addChild(root_1, stream_accessModPattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:153:47: ^( TypeQualifierPattern )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeQualifierPattern, "TypeQualifierPattern"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_inPattern.nextTree());
                        adaptor.addChild(root_1, stream_methodSigPattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:153:98: ^( Throws )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Throws, "Throws"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "constructorDeclPattern"

    public static class methodMatchPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "methodMatchPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:158:1: methodMatchPattern : ( typeQualifierPattern methodNamePattern methodSigPattern -> typeQualifierPattern ^( InPattern ) methodNamePattern methodSigPattern | methodNamePattern methodSigPattern inPattern -> ^( TypeQualifierPattern ) inPattern methodNamePattern methodSigPattern );
    public final ScopedPromisesParser.methodMatchPattern_return methodMatchPattern() throws RecognitionException {
        ScopedPromisesParser.methodMatchPattern_return retval = new ScopedPromisesParser.methodMatchPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.typeQualifierPattern_return typeQualifierPattern29 = null;

        ScopedPromisesParser.methodNamePattern_return methodNamePattern30 = null;

        ScopedPromisesParser.methodSigPattern_return methodSigPattern31 = null;

        ScopedPromisesParser.methodNamePattern_return methodNamePattern32 = null;

        ScopedPromisesParser.methodSigPattern_return methodSigPattern33 = null;

        ScopedPromisesParser.inPattern_return inPattern34 = null;


        RewriteRuleSubtreeStream stream_methodNamePattern=new RewriteRuleSubtreeStream(adaptor,"rule methodNamePattern");
        RewriteRuleSubtreeStream stream_methodSigPattern=new RewriteRuleSubtreeStream(adaptor,"rule methodSigPattern");
        RewriteRuleSubtreeStream stream_inPattern=new RewriteRuleSubtreeStream(adaptor,"rule inPattern");
        RewriteRuleSubtreeStream stream_typeQualifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule typeQualifierPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:159:3: ( typeQualifierPattern methodNamePattern methodSigPattern -> typeQualifierPattern ^( InPattern ) methodNamePattern methodSigPattern | methodNamePattern methodSigPattern inPattern -> ^( TypeQualifierPattern ) inPattern methodNamePattern methodSigPattern )
            int alt6=2;
            alt6 = dfa6.predict(input);
            switch (alt6) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:159:5: typeQualifierPattern methodNamePattern methodSigPattern
                    {
                    pushFollow(FOLLOW_typeQualifierPattern_in_methodMatchPattern641);
                    typeQualifierPattern29=typeQualifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeQualifierPattern.add(typeQualifierPattern29.getTree());
                    pushFollow(FOLLOW_methodNamePattern_in_methodMatchPattern643);
                    methodNamePattern30=methodNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_methodNamePattern.add(methodNamePattern30.getTree());
                    pushFollow(FOLLOW_methodSigPattern_in_methodMatchPattern645);
                    methodSigPattern31=methodSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_methodSigPattern.add(methodSigPattern31.getTree());


                    // AST REWRITE
                    // elements: typeQualifierPattern, methodNamePattern, methodSigPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 159:62: -> typeQualifierPattern ^( InPattern ) methodNamePattern methodSigPattern
                    {
                        adaptor.addChild(root_0, stream_typeQualifierPattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:159:86: ^( InPattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPattern, "InPattern"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }
                        adaptor.addChild(root_0, stream_methodNamePattern.nextTree());
                        adaptor.addChild(root_0, stream_methodSigPattern.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:160:5: methodNamePattern methodSigPattern inPattern
                    {
                    pushFollow(FOLLOW_methodNamePattern_in_methodMatchPattern664);
                    methodNamePattern32=methodNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_methodNamePattern.add(methodNamePattern32.getTree());
                    pushFollow(FOLLOW_methodSigPattern_in_methodMatchPattern666);
                    methodSigPattern33=methodSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_methodSigPattern.add(methodSigPattern33.getTree());
                    pushFollow(FOLLOW_inPattern_in_methodMatchPattern668);
                    inPattern34=inPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inPattern.add(inPattern34.getTree());


                    // AST REWRITE
                    // elements: methodNamePattern, methodSigPattern, inPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 160:50: -> ^( TypeQualifierPattern ) inPattern methodNamePattern methodSigPattern
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:160:53: ^( TypeQualifierPattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeQualifierPattern, "TypeQualifierPattern"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }
                        adaptor.addChild(root_0, stream_inPattern.nextTree());
                        adaptor.addChild(root_0, stream_methodNamePattern.nextTree());
                        adaptor.addChild(root_0, stream_methodSigPattern.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "methodMatchPattern"

    public static class methodDeclPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "methodDeclPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:163:1: methodDeclPattern : modifierPattern returnTypeSigPattern methodMatchPattern -> ^( MethodDeclPattern modifierPattern returnTypeSigPattern methodMatchPattern ) ;
    public final ScopedPromisesParser.methodDeclPattern_return methodDeclPattern() throws RecognitionException {
        ScopedPromisesParser.methodDeclPattern_return retval = new ScopedPromisesParser.methodDeclPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.modifierPattern_return modifierPattern35 = null;

        ScopedPromisesParser.returnTypeSigPattern_return returnTypeSigPattern36 = null;

        ScopedPromisesParser.methodMatchPattern_return methodMatchPattern37 = null;


        RewriteRuleSubtreeStream stream_methodMatchPattern=new RewriteRuleSubtreeStream(adaptor,"rule methodMatchPattern");
        RewriteRuleSubtreeStream stream_returnTypeSigPattern=new RewriteRuleSubtreeStream(adaptor,"rule returnTypeSigPattern");
        RewriteRuleSubtreeStream stream_modifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule modifierPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:164:3: ( modifierPattern returnTypeSigPattern methodMatchPattern -> ^( MethodDeclPattern modifierPattern returnTypeSigPattern methodMatchPattern ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:164:5: modifierPattern returnTypeSigPattern methodMatchPattern
            {
            pushFollow(FOLLOW_modifierPattern_in_methodDeclPattern693);
            modifierPattern35=modifierPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_modifierPattern.add(modifierPattern35.getTree());
            pushFollow(FOLLOW_returnTypeSigPattern_in_methodDeclPattern695);
            returnTypeSigPattern36=returnTypeSigPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_returnTypeSigPattern.add(returnTypeSigPattern36.getTree());
            pushFollow(FOLLOW_methodMatchPattern_in_methodDeclPattern697);
            methodMatchPattern37=methodMatchPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_methodMatchPattern.add(methodMatchPattern37.getTree());


            // AST REWRITE
            // elements: methodMatchPattern, returnTypeSigPattern, modifierPattern
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 164:61: -> ^( MethodDeclPattern modifierPattern returnTypeSigPattern methodMatchPattern )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:165:5: ^( MethodDeclPattern modifierPattern returnTypeSigPattern methodMatchPattern )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(MethodDeclPattern, "MethodDeclPattern"), root_1);

                adaptor.addChild(root_1, stream_modifierPattern.nextTree());
                adaptor.addChild(root_1, stream_returnTypeSigPattern.nextTree());
                adaptor.addChild(root_1, stream_methodMatchPattern.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "methodDeclPattern"

    public static class noReturnMethodDeclPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "noReturnMethodDeclPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:168:1: noReturnMethodDeclPattern : modifierPattern methodMatchPattern -> ^( MethodDeclPattern modifierPattern ^( NamedTypePattern STAR ) methodMatchPattern ) ;
    public final ScopedPromisesParser.noReturnMethodDeclPattern_return noReturnMethodDeclPattern() throws RecognitionException {
        ScopedPromisesParser.noReturnMethodDeclPattern_return retval = new ScopedPromisesParser.noReturnMethodDeclPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.modifierPattern_return modifierPattern38 = null;

        ScopedPromisesParser.methodMatchPattern_return methodMatchPattern39 = null;


        RewriteRuleSubtreeStream stream_methodMatchPattern=new RewriteRuleSubtreeStream(adaptor,"rule methodMatchPattern");
        RewriteRuleSubtreeStream stream_modifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule modifierPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:169:3: ( modifierPattern methodMatchPattern -> ^( MethodDeclPattern modifierPattern ^( NamedTypePattern STAR ) methodMatchPattern ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:169:5: modifierPattern methodMatchPattern
            {
            pushFollow(FOLLOW_modifierPattern_in_noReturnMethodDeclPattern726);
            modifierPattern38=modifierPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_modifierPattern.add(modifierPattern38.getTree());
            pushFollow(FOLLOW_methodMatchPattern_in_noReturnMethodDeclPattern728);
            methodMatchPattern39=methodMatchPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_methodMatchPattern.add(methodMatchPattern39.getTree());


            // AST REWRITE
            // elements: modifierPattern, methodMatchPattern
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 169:40: -> ^( MethodDeclPattern modifierPattern ^( NamedTypePattern STAR ) methodMatchPattern )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:170:5: ^( MethodDeclPattern modifierPattern ^( NamedTypePattern STAR ) methodMatchPattern )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(MethodDeclPattern, "MethodDeclPattern"), root_1);

                adaptor.addChild(root_1, stream_modifierPattern.nextTree());
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:170:41: ^( NamedTypePattern STAR )
                {
                Tree root_2 = (Tree)adaptor.nil();
                root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedTypePattern, "NamedTypePattern"), root_2);

                adaptor.addChild(root_2, (Tree)adaptor.create(STAR, "STAR"));

                adaptor.addChild(root_1, root_2);
                }
                adaptor.addChild(root_1, stream_methodMatchPattern.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "noReturnMethodDeclPattern"

    public static class fieldDeclPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldDeclPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:173:1: fieldDeclPattern : ( modifierPattern typeSigPattern typeQualifierPattern fieldNamePattern -> ^( FieldDeclPattern modifierPattern typeSigPattern typeQualifierPattern ^( InPattern ) fieldNamePattern ) | modifierPattern typeSigPattern fieldNamePattern inPattern -> ^( FieldDeclPattern modifierPattern typeSigPattern ^( TypeQualifierPattern ) inPattern fieldNamePattern ) );
    public final ScopedPromisesParser.fieldDeclPattern_return fieldDeclPattern() throws RecognitionException {
        ScopedPromisesParser.fieldDeclPattern_return retval = new ScopedPromisesParser.fieldDeclPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.modifierPattern_return modifierPattern40 = null;

        ScopedPromisesParser.typeSigPattern_return typeSigPattern41 = null;

        ScopedPromisesParser.typeQualifierPattern_return typeQualifierPattern42 = null;

        ScopedPromisesParser.fieldNamePattern_return fieldNamePattern43 = null;

        ScopedPromisesParser.modifierPattern_return modifierPattern44 = null;

        ScopedPromisesParser.typeSigPattern_return typeSigPattern45 = null;

        ScopedPromisesParser.fieldNamePattern_return fieldNamePattern46 = null;

        ScopedPromisesParser.inPattern_return inPattern47 = null;


        RewriteRuleSubtreeStream stream_typeSigPattern=new RewriteRuleSubtreeStream(adaptor,"rule typeSigPattern");
        RewriteRuleSubtreeStream stream_inPattern=new RewriteRuleSubtreeStream(adaptor,"rule inPattern");
        RewriteRuleSubtreeStream stream_typeQualifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule typeQualifierPattern");
        RewriteRuleSubtreeStream stream_fieldNamePattern=new RewriteRuleSubtreeStream(adaptor,"rule fieldNamePattern");
        RewriteRuleSubtreeStream stream_modifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule modifierPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:174:3: ( modifierPattern typeSigPattern typeQualifierPattern fieldNamePattern -> ^( FieldDeclPattern modifierPattern typeSigPattern typeQualifierPattern ^( InPattern ) fieldNamePattern ) | modifierPattern typeSigPattern fieldNamePattern inPattern -> ^( FieldDeclPattern modifierPattern typeSigPattern ^( TypeQualifierPattern ) inPattern fieldNamePattern ) )
            int alt7=2;
            alt7 = dfa7.predict(input);
            switch (alt7) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:174:5: modifierPattern typeSigPattern typeQualifierPattern fieldNamePattern
                    {
                    pushFollow(FOLLOW_modifierPattern_in_fieldDeclPattern761);
                    modifierPattern40=modifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_modifierPattern.add(modifierPattern40.getTree());
                    pushFollow(FOLLOW_typeSigPattern_in_fieldDeclPattern763);
                    typeSigPattern41=typeSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeSigPattern.add(typeSigPattern41.getTree());
                    pushFollow(FOLLOW_typeQualifierPattern_in_fieldDeclPattern765);
                    typeQualifierPattern42=typeQualifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeQualifierPattern.add(typeQualifierPattern42.getTree());
                    pushFollow(FOLLOW_fieldNamePattern_in_fieldDeclPattern767);
                    fieldNamePattern43=fieldNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_fieldNamePattern.add(fieldNamePattern43.getTree());


                    // AST REWRITE
                    // elements: typeSigPattern, modifierPattern, fieldNamePattern, typeQualifierPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 174:74: -> ^( FieldDeclPattern modifierPattern typeSigPattern typeQualifierPattern ^( InPattern ) fieldNamePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:175:5: ^( FieldDeclPattern modifierPattern typeSigPattern typeQualifierPattern ^( InPattern ) fieldNamePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldDeclPattern, "FieldDeclPattern"), root_1);

                        adaptor.addChild(root_1, stream_modifierPattern.nextTree());
                        adaptor.addChild(root_1, stream_typeSigPattern.nextTree());
                        adaptor.addChild(root_1, stream_typeQualifierPattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:175:76: ^( InPattern )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPattern, "InPattern"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_fieldNamePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:176:5: modifierPattern typeSigPattern fieldNamePattern inPattern
                    {
                    pushFollow(FOLLOW_modifierPattern_in_fieldDeclPattern795);
                    modifierPattern44=modifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_modifierPattern.add(modifierPattern44.getTree());
                    pushFollow(FOLLOW_typeSigPattern_in_fieldDeclPattern797);
                    typeSigPattern45=typeSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeSigPattern.add(typeSigPattern45.getTree());
                    pushFollow(FOLLOW_fieldNamePattern_in_fieldDeclPattern800);
                    fieldNamePattern46=fieldNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_fieldNamePattern.add(fieldNamePattern46.getTree());
                    pushFollow(FOLLOW_inPattern_in_fieldDeclPattern802);
                    inPattern47=inPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inPattern.add(inPattern47.getTree());


                    // AST REWRITE
                    // elements: typeSigPattern, modifierPattern, fieldNamePattern, inPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 176:64: -> ^( FieldDeclPattern modifierPattern typeSigPattern ^( TypeQualifierPattern ) inPattern fieldNamePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:177:5: ^( FieldDeclPattern modifierPattern typeSigPattern ^( TypeQualifierPattern ) inPattern fieldNamePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldDeclPattern, "FieldDeclPattern"), root_1);

                        adaptor.addChild(root_1, stream_modifierPattern.nextTree());
                        adaptor.addChild(root_1, stream_typeSigPattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:177:55: ^( TypeQualifierPattern )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeQualifierPattern, "TypeQualifierPattern"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_inPattern.nextTree());
                        adaptor.addChild(root_1, stream_fieldNamePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldDeclPattern"

    public static class typeDeclPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeDeclPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:184:1: typeDeclPattern : ( modifierPattern optQualifiedTypeNamePattern -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern ^( InPattern ) ) | modifierPattern optQualifiedTypeNamePattern inPattern -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern inPattern ) );
    public final ScopedPromisesParser.typeDeclPattern_return typeDeclPattern() throws RecognitionException {
        ScopedPromisesParser.typeDeclPattern_return retval = new ScopedPromisesParser.typeDeclPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.modifierPattern_return modifierPattern48 = null;

        ScopedPromisesParser.optQualifiedTypeNamePattern_return optQualifiedTypeNamePattern49 = null;

        ScopedPromisesParser.modifierPattern_return modifierPattern50 = null;

        ScopedPromisesParser.optQualifiedTypeNamePattern_return optQualifiedTypeNamePattern51 = null;

        ScopedPromisesParser.inPattern_return inPattern52 = null;


        RewriteRuleSubtreeStream stream_inPattern=new RewriteRuleSubtreeStream(adaptor,"rule inPattern");
        RewriteRuleSubtreeStream stream_modifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule modifierPattern");
        RewriteRuleSubtreeStream stream_optQualifiedTypeNamePattern=new RewriteRuleSubtreeStream(adaptor,"rule optQualifiedTypeNamePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:185:3: ( modifierPattern optQualifiedTypeNamePattern -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern ^( InPattern ) ) | modifierPattern optQualifiedTypeNamePattern inPattern -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern inPattern ) )
            int alt8=2;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:185:5: modifierPattern optQualifiedTypeNamePattern
                    {
                    pushFollow(FOLLOW_modifierPattern_in_typeDeclPattern843);
                    modifierPattern48=modifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_modifierPattern.add(modifierPattern48.getTree());
                    pushFollow(FOLLOW_optQualifiedTypeNamePattern_in_typeDeclPattern845);
                    optQualifiedTypeNamePattern49=optQualifiedTypeNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_optQualifiedTypeNamePattern.add(optQualifiedTypeNamePattern49.getTree());


                    // AST REWRITE
                    // elements: optQualifiedTypeNamePattern, modifierPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 185:49: -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern ^( InPattern ) )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:186:5: ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern ^( InPattern ) )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeDeclPattern, "TypeDeclPattern"), root_1);

                        adaptor.addChild(root_1, stream_modifierPattern.nextTree());
                        adaptor.addChild(root_1, stream_optQualifiedTypeNamePattern.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:186:67: ^( InPattern )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPattern, "InPattern"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:187:5: modifierPattern optQualifiedTypeNamePattern inPattern
                    {
                    pushFollow(FOLLOW_modifierPattern_in_typeDeclPattern869);
                    modifierPattern50=modifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_modifierPattern.add(modifierPattern50.getTree());
                    pushFollow(FOLLOW_optQualifiedTypeNamePattern_in_typeDeclPattern871);
                    optQualifiedTypeNamePattern51=optQualifiedTypeNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_optQualifiedTypeNamePattern.add(optQualifiedTypeNamePattern51.getTree());
                    pushFollow(FOLLOW_inPattern_in_typeDeclPattern873);
                    inPattern52=inPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inPattern.add(inPattern52.getTree());


                    // AST REWRITE
                    // elements: optQualifiedTypeNamePattern, inPattern, modifierPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 187:58: -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern inPattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:188:6: ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern inPattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeDeclPattern, "TypeDeclPattern"), root_1);

                        adaptor.addChild(root_1, stream_modifierPattern.nextTree());
                        adaptor.addChild(root_1, stream_optQualifiedTypeNamePattern.nextTree());
                        adaptor.addChild(root_1, stream_inPattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeDeclPattern"

    public static class typeQualifierPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeQualifierPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:191:1: typeQualifierPattern : ( typeNamePattern '.' -> ^( TypeQualifierPattern typeNamePattern ) | -> ^( TypeQualifierPattern ) );
    public final ScopedPromisesParser.typeQualifierPattern_return typeQualifierPattern() throws RecognitionException {
        ScopedPromisesParser.typeQualifierPattern_return retval = new ScopedPromisesParser.typeQualifierPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal54=null;
        ScopedPromisesParser.typeNamePattern_return typeNamePattern53 = null;


        Tree char_literal54_tree=null;
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_typeNamePattern=new RewriteRuleSubtreeStream(adaptor,"rule typeNamePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:192:3: ( typeNamePattern '.' -> ^( TypeQualifierPattern typeNamePattern ) | -> ^( TypeQualifierPattern ) )
            int alt9=2;
            switch ( input.LA(1) ) {
            case WildcardIdentifier:
                {
                int LA9_1 = input.LA(2);

                if ( (LA9_1==EOF||(LA9_1>=LPAREN && LA9_1<=RPAREN)||(LA9_1>=104 && LA9_1<=105)) ) {
                    alt9=2;
                }
                else if ( (LA9_1==DOT) ) {
                    alt9=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 1, input);

                    throw nvae;
                }
                }
                break;
            case IDENTIFIER:
                {
                int LA9_2 = input.LA(2);

                if ( (LA9_2==EOF||(LA9_2>=LPAREN && LA9_2<=RPAREN)||(LA9_2>=104 && LA9_2<=105)) ) {
                    alt9=2;
                }
                else if ( (LA9_2==DOT) ) {
                    alt9=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 2, input);

                    throw nvae;
                }
                }
                break;
            case STAR:
            case DSTAR:
            case 107:
                {
                alt9=2;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:192:5: typeNamePattern '.'
                    {
                    pushFollow(FOLLOW_typeNamePattern_in_typeQualifierPattern902);
                    typeNamePattern53=typeNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeNamePattern.add(typeNamePattern53.getTree());
                    char_literal54=(Token)match(input,DOT,FOLLOW_DOT_in_typeQualifierPattern904); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(char_literal54);



                    // AST REWRITE
                    // elements: typeNamePattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 192:25: -> ^( TypeQualifierPattern typeNamePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:192:28: ^( TypeQualifierPattern typeNamePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeQualifierPattern, "TypeQualifierPattern"), root_1);

                        adaptor.addChild(root_1, stream_typeNamePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:193:5: 
                    {

                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 193:5: -> ^( TypeQualifierPattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:193:8: ^( TypeQualifierPattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeQualifierPattern, "TypeQualifierPattern"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeQualifierPattern"

    public static class wildcardTypeQualifierPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "wildcardTypeQualifierPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:197:1: wildcardTypeQualifierPattern : methodNamePattern ( DOT methodNamePattern )* (c= DOT )? -> ^( WildcardTypeQualifierPattern methodNamePattern ( DOT methodNamePattern )* ( DOT )? ) ;
    public final ScopedPromisesParser.wildcardTypeQualifierPattern_return wildcardTypeQualifierPattern() throws RecognitionException {
        ScopedPromisesParser.wildcardTypeQualifierPattern_return retval = new ScopedPromisesParser.wildcardTypeQualifierPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token c=null;
        Token DOT56=null;
        ScopedPromisesParser.methodNamePattern_return methodNamePattern55 = null;

        ScopedPromisesParser.methodNamePattern_return methodNamePattern57 = null;


        Tree c_tree=null;
        Tree DOT56_tree=null;
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_methodNamePattern=new RewriteRuleSubtreeStream(adaptor,"rule methodNamePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:3: ( methodNamePattern ( DOT methodNamePattern )* (c= DOT )? -> ^( WildcardTypeQualifierPattern methodNamePattern ( DOT methodNamePattern )* ( DOT )? ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:5: methodNamePattern ( DOT methodNamePattern )* (c= DOT )?
            {
            pushFollow(FOLLOW_methodNamePattern_in_wildcardTypeQualifierPattern936);
            methodNamePattern55=methodNamePattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_methodNamePattern.add(methodNamePattern55.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:23: ( DOT methodNamePattern )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==DOT) ) {
                    int LA10_1 = input.LA(2);

                    if ( ((LA10_1>=IDENTIFIER && LA10_1<=DSTAR)||LA10_1==WildcardIdentifier) ) {
                        alt10=1;
                    }


                }


                switch (alt10) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:24: DOT methodNamePattern
            	    {
            	    DOT56=(Token)match(input,DOT,FOLLOW_DOT_in_wildcardTypeQualifierPattern939); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_DOT.add(DOT56);

            	    pushFollow(FOLLOW_methodNamePattern_in_wildcardTypeQualifierPattern941);
            	    methodNamePattern57=methodNamePattern();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_methodNamePattern.add(methodNamePattern57.getTree());

            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:49: (c= DOT )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==DOT) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:49: c= DOT
                    {
                    c=(Token)match(input,DOT,FOLLOW_DOT_in_wildcardTypeQualifierPattern947); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(c);


                    }
                    break;

            }



            // AST REWRITE
            // elements: DOT, methodNamePattern, methodNamePattern, DOT
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 198:55: -> ^( WildcardTypeQualifierPattern methodNamePattern ( DOT methodNamePattern )* ( DOT )? )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:58: ^( WildcardTypeQualifierPattern methodNamePattern ( DOT methodNamePattern )* ( DOT )? )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(WildcardTypeQualifierPattern, "WildcardTypeQualifierPattern"), root_1);

                adaptor.addChild(root_1, stream_methodNamePattern.nextTree());
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:107: ( DOT methodNamePattern )*
                while ( stream_DOT.hasNext()||stream_methodNamePattern.hasNext() ) {
                    adaptor.addChild(root_1, stream_DOT.nextNode());
                    adaptor.addChild(root_1, stream_methodNamePattern.nextTree());

                }
                stream_DOT.reset();
                stream_methodNamePattern.reset();
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:198:132: ( DOT )?
                if ( stream_DOT.hasNext() ) {
                    adaptor.addChild(root_1, stream_DOT.nextNode());

                }
                stream_DOT.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "wildcardTypeQualifierPattern"

    public static class inPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:201:1: inPattern : ( IN wildcardTypeQualifierPattern inPackagePattern -> ^( InPattern wildcardTypeQualifierPattern inPackagePattern ) | IN '(' inTypePattern ')' inPackagePattern -> ^( InPattern inTypePattern inPackagePattern ) );
    public final ScopedPromisesParser.inPattern_return inPattern() throws RecognitionException {
        ScopedPromisesParser.inPattern_return retval = new ScopedPromisesParser.inPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IN58=null;
        Token IN61=null;
        Token char_literal62=null;
        Token char_literal64=null;
        ScopedPromisesParser.wildcardTypeQualifierPattern_return wildcardTypeQualifierPattern59 = null;

        ScopedPromisesParser.inPackagePattern_return inPackagePattern60 = null;

        ScopedPromisesParser.inTypePattern_return inTypePattern63 = null;

        ScopedPromisesParser.inPackagePattern_return inPackagePattern65 = null;


        Tree IN58_tree=null;
        Tree IN61_tree=null;
        Tree char_literal62_tree=null;
        Tree char_literal64_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_IN=new RewriteRuleTokenStream(adaptor,"token IN");
        RewriteRuleSubtreeStream stream_wildcardTypeQualifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule wildcardTypeQualifierPattern");
        RewriteRuleSubtreeStream stream_inPackagePattern=new RewriteRuleSubtreeStream(adaptor,"rule inPackagePattern");
        RewriteRuleSubtreeStream stream_inTypePattern=new RewriteRuleSubtreeStream(adaptor,"rule inTypePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:202:3: ( IN wildcardTypeQualifierPattern inPackagePattern -> ^( InPattern wildcardTypeQualifierPattern inPackagePattern ) | IN '(' inTypePattern ')' inPackagePattern -> ^( InPattern inTypePattern inPackagePattern ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==IN) ) {
                int LA12_1 = input.LA(2);

                if ( (LA12_1==LPAREN) ) {
                    alt12=2;
                }
                else if ( ((LA12_1>=IDENTIFIER && LA12_1<=DSTAR)||LA12_1==WildcardIdentifier) ) {
                    alt12=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 12, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:202:5: IN wildcardTypeQualifierPattern inPackagePattern
                    {
                    IN58=(Token)match(input,IN,FOLLOW_IN_in_inPattern981); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IN.add(IN58);

                    pushFollow(FOLLOW_wildcardTypeQualifierPattern_in_inPattern983);
                    wildcardTypeQualifierPattern59=wildcardTypeQualifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_wildcardTypeQualifierPattern.add(wildcardTypeQualifierPattern59.getTree());
                    pushFollow(FOLLOW_inPackagePattern_in_inPattern985);
                    inPackagePattern60=inPackagePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inPackagePattern.add(inPackagePattern60.getTree());


                    // AST REWRITE
                    // elements: inPackagePattern, wildcardTypeQualifierPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 202:54: -> ^( InPattern wildcardTypeQualifierPattern inPackagePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:202:57: ^( InPattern wildcardTypeQualifierPattern inPackagePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPattern, "InPattern"), root_1);

                        adaptor.addChild(root_1, stream_wildcardTypeQualifierPattern.nextTree());
                        adaptor.addChild(root_1, stream_inPackagePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:203:5: IN '(' inTypePattern ')' inPackagePattern
                    {
                    IN61=(Token)match(input,IN,FOLLOW_IN_in_inPattern1001); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IN.add(IN61);

                    char_literal62=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_inPattern1003); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal62);

                    pushFollow(FOLLOW_inTypePattern_in_inPattern1005);
                    inTypePattern63=inTypePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inTypePattern.add(inTypePattern63.getTree());
                    char_literal64=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_inPattern1007); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal64);

                    pushFollow(FOLLOW_inPackagePattern_in_inPattern1009);
                    inPackagePattern65=inPackagePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inPackagePattern.add(inPackagePattern65.getTree());


                    // AST REWRITE
                    // elements: inPackagePattern, inTypePattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 203:47: -> ^( InPattern inTypePattern inPackagePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:203:50: ^( InPattern inTypePattern inPackagePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPattern, "InPattern"), root_1);

                        adaptor.addChild(root_1, stream_inTypePattern.nextTree());
                        adaptor.addChild(root_1, stream_inPackagePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "inPattern"

    public static class inTypePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inTypePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:207:1: inTypePattern : ( inAndPattern -> inAndPattern ) ( '|' b= inAndPattern -> ^( InOrPattern $inTypePattern $b) )* ;
    public final ScopedPromisesParser.inTypePattern_return inTypePattern() throws RecognitionException {
        ScopedPromisesParser.inTypePattern_return retval = new ScopedPromisesParser.inTypePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal67=null;
        ScopedPromisesParser.inAndPattern_return b = null;

        ScopedPromisesParser.inAndPattern_return inAndPattern66 = null;


        Tree char_literal67_tree=null;
        RewriteRuleTokenStream stream_104=new RewriteRuleTokenStream(adaptor,"token 104");
        RewriteRuleSubtreeStream stream_inAndPattern=new RewriteRuleSubtreeStream(adaptor,"rule inAndPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:3: ( ( inAndPattern -> inAndPattern ) ( '|' b= inAndPattern -> ^( InOrPattern $inTypePattern $b) )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:5: ( inAndPattern -> inAndPattern ) ( '|' b= inAndPattern -> ^( InOrPattern $inTypePattern $b) )*
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:5: ( inAndPattern -> inAndPattern )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:6: inAndPattern
            {
            pushFollow(FOLLOW_inAndPattern_in_inTypePattern1036);
            inAndPattern66=inAndPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_inAndPattern.add(inAndPattern66.getTree());


            // AST REWRITE
            // elements: inAndPattern
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 208:19: -> inAndPattern
            {
                adaptor.addChild(root_0, stream_inAndPattern.nextTree());

            }

            retval.tree = root_0;}
            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:36: ( '|' b= inAndPattern -> ^( InOrPattern $inTypePattern $b) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==104) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:38: '|' b= inAndPattern
            	    {
            	    char_literal67=(Token)match(input,104,FOLLOW_104_in_inTypePattern1045); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_104.add(char_literal67);

            	    pushFollow(FOLLOW_inAndPattern_in_inTypePattern1049);
            	    b=inAndPattern();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_inAndPattern.add(b.getTree());


            	    // AST REWRITE
            	    // elements: inTypePattern, b
            	    // token labels: 
            	    // rule labels: retval, b
            	    // token list labels: 
            	    // rule list labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_b=new RewriteRuleSubtreeStream(adaptor,"token b",b!=null?b.tree:null);

            	    root_0 = (Tree)adaptor.nil();
            	    // 208:57: -> ^( InOrPattern $inTypePattern $b)
            	    {
            	        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:208:60: ^( InOrPattern $inTypePattern $b)
            	        {
            	        Tree root_1 = (Tree)adaptor.nil();
            	        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InOrPattern, "InOrPattern"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_b.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "inTypePattern"

    public static class inAndPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inAndPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:211:1: inAndPattern : ( inBasePattern -> inBasePattern ) ( '&' b= inBasePattern -> ^( InAndPattern $inAndPattern $b) )* ;
    public final ScopedPromisesParser.inAndPattern_return inAndPattern() throws RecognitionException {
        ScopedPromisesParser.inAndPattern_return retval = new ScopedPromisesParser.inAndPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal69=null;
        ScopedPromisesParser.inBasePattern_return b = null;

        ScopedPromisesParser.inBasePattern_return inBasePattern68 = null;


        Tree char_literal69_tree=null;
        RewriteRuleTokenStream stream_105=new RewriteRuleTokenStream(adaptor,"token 105");
        RewriteRuleSubtreeStream stream_inBasePattern=new RewriteRuleSubtreeStream(adaptor,"rule inBasePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:3: ( ( inBasePattern -> inBasePattern ) ( '&' b= inBasePattern -> ^( InAndPattern $inAndPattern $b) )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:6: ( inBasePattern -> inBasePattern ) ( '&' b= inBasePattern -> ^( InAndPattern $inAndPattern $b) )*
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:6: ( inBasePattern -> inBasePattern )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:7: inBasePattern
            {
            pushFollow(FOLLOW_inBasePattern_in_inAndPattern1078);
            inBasePattern68=inBasePattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_inBasePattern.add(inBasePattern68.getTree());


            // AST REWRITE
            // elements: inBasePattern
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 212:21: -> inBasePattern
            {
                adaptor.addChild(root_0, stream_inBasePattern.nextTree());

            }

            retval.tree = root_0;}
            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:39: ( '&' b= inBasePattern -> ^( InAndPattern $inAndPattern $b) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==105) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:40: '&' b= inBasePattern
            	    {
            	    char_literal69=(Token)match(input,105,FOLLOW_105_in_inAndPattern1086); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_105.add(char_literal69);

            	    pushFollow(FOLLOW_inBasePattern_in_inAndPattern1090);
            	    b=inBasePattern();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_inBasePattern.add(b.getTree());


            	    // AST REWRITE
            	    // elements: inAndPattern, b
            	    // token labels: 
            	    // rule labels: retval, b
            	    // token list labels: 
            	    // rule list labels: 
            	    if ( state.backtracking==0 ) {
            	    retval.tree = root_0;
            	    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);
            	    RewriteRuleSubtreeStream stream_b=new RewriteRuleSubtreeStream(adaptor,"token b",b!=null?b.tree:null);

            	    root_0 = (Tree)adaptor.nil();
            	    // 212:60: -> ^( InAndPattern $inAndPattern $b)
            	    {
            	        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:212:63: ^( InAndPattern $inAndPattern $b)
            	        {
            	        Tree root_1 = (Tree)adaptor.nil();
            	        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InAndPattern, "InAndPattern"), root_1);

            	        adaptor.addChild(root_1, stream_retval.nextTree());
            	        adaptor.addChild(root_1, stream_b.nextTree());

            	        adaptor.addChild(root_0, root_1);
            	        }

            	    }

            	    retval.tree = root_0;}
            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "inAndPattern"

    public static class inBasePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inBasePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:215:1: inBasePattern : ( wildcardTypeQualifierPattern | '!' '(' inTypePattern ')' -> ^( InNotPattern inTypePattern ) | '(' inTypePattern ')' -> inTypePattern );
    public final ScopedPromisesParser.inBasePattern_return inBasePattern() throws RecognitionException {
        ScopedPromisesParser.inBasePattern_return retval = new ScopedPromisesParser.inBasePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal71=null;
        Token char_literal72=null;
        Token char_literal74=null;
        Token char_literal75=null;
        Token char_literal77=null;
        ScopedPromisesParser.wildcardTypeQualifierPattern_return wildcardTypeQualifierPattern70 = null;

        ScopedPromisesParser.inTypePattern_return inTypePattern73 = null;

        ScopedPromisesParser.inTypePattern_return inTypePattern76 = null;


        Tree char_literal71_tree=null;
        Tree char_literal72_tree=null;
        Tree char_literal74_tree=null;
        Tree char_literal75_tree=null;
        Tree char_literal77_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_106=new RewriteRuleTokenStream(adaptor,"token 106");
        RewriteRuleSubtreeStream stream_inTypePattern=new RewriteRuleSubtreeStream(adaptor,"rule inTypePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:216:3: ( wildcardTypeQualifierPattern | '!' '(' inTypePattern ')' -> ^( InNotPattern inTypePattern ) | '(' inTypePattern ')' -> inTypePattern )
            int alt15=3;
            switch ( input.LA(1) ) {
            case IDENTIFIER:
            case STAR:
            case DSTAR:
            case WildcardIdentifier:
                {
                alt15=1;
                }
                break;
            case 106:
                {
                alt15=2;
                }
                break;
            case LPAREN:
                {
                alt15=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:216:5: wildcardTypeQualifierPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_wildcardTypeQualifierPattern_in_inBasePattern1119);
                    wildcardTypeQualifierPattern70=wildcardTypeQualifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, wildcardTypeQualifierPattern70.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:217:5: '!' '(' inTypePattern ')'
                    {
                    char_literal71=(Token)match(input,106,FOLLOW_106_in_inBasePattern1125); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_106.add(char_literal71);

                    char_literal72=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_inBasePattern1127); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal72);

                    pushFollow(FOLLOW_inTypePattern_in_inBasePattern1129);
                    inTypePattern73=inTypePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inTypePattern.add(inTypePattern73.getTree());
                    char_literal74=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_inBasePattern1131); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal74);



                    // AST REWRITE
                    // elements: inTypePattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 217:31: -> ^( InNotPattern inTypePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:217:34: ^( InNotPattern inTypePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InNotPattern, "InNotPattern"), root_1);

                        adaptor.addChild(root_1, stream_inTypePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:218:5: '(' inTypePattern ')'
                    {
                    char_literal75=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_inBasePattern1145); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal75);

                    pushFollow(FOLLOW_inTypePattern_in_inBasePattern1147);
                    inTypePattern76=inTypePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inTypePattern.add(inTypePattern76.getTree());
                    char_literal77=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_inBasePattern1149); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal77);



                    // AST REWRITE
                    // elements: inTypePattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 218:27: -> inTypePattern
                    {
                        adaptor.addChild(root_0, stream_inTypePattern.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "inBasePattern"

    public static class inPackagePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inPackagePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:221:1: inPackagePattern : ( IN wildcardTypeQualifierPattern -> ^( InPackagePattern wildcardTypeQualifierPattern ) | IN '(' inTypePattern ')' -> ^( InPackagePattern inTypePattern ) | -> ^( InPackagePattern ) );
    public final ScopedPromisesParser.inPackagePattern_return inPackagePattern() throws RecognitionException {
        ScopedPromisesParser.inPackagePattern_return retval = new ScopedPromisesParser.inPackagePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IN78=null;
        Token IN80=null;
        Token char_literal81=null;
        Token char_literal83=null;
        ScopedPromisesParser.wildcardTypeQualifierPattern_return wildcardTypeQualifierPattern79 = null;

        ScopedPromisesParser.inTypePattern_return inTypePattern82 = null;


        Tree IN78_tree=null;
        Tree IN80_tree=null;
        Tree char_literal81_tree=null;
        Tree char_literal83_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_IN=new RewriteRuleTokenStream(adaptor,"token IN");
        RewriteRuleSubtreeStream stream_wildcardTypeQualifierPattern=new RewriteRuleSubtreeStream(adaptor,"rule wildcardTypeQualifierPattern");
        RewriteRuleSubtreeStream stream_inTypePattern=new RewriteRuleSubtreeStream(adaptor,"rule inTypePattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:222:3: ( IN wildcardTypeQualifierPattern -> ^( InPackagePattern wildcardTypeQualifierPattern ) | IN '(' inTypePattern ')' -> ^( InPackagePattern inTypePattern ) | -> ^( InPackagePattern ) )
            int alt16=3;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==IN) ) {
                int LA16_1 = input.LA(2);

                if ( (LA16_1==LPAREN) ) {
                    alt16=2;
                }
                else if ( ((LA16_1>=IDENTIFIER && LA16_1<=DSTAR)||LA16_1==WildcardIdentifier) ) {
                    alt16=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 16, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA16_0==EOF||LA16_0==RPAREN||(LA16_0>=104 && LA16_0<=105)) ) {
                alt16=3;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:222:5: IN wildcardTypeQualifierPattern
                    {
                    IN78=(Token)match(input,IN,FOLLOW_IN_in_inPackagePattern1168); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IN.add(IN78);

                    pushFollow(FOLLOW_wildcardTypeQualifierPattern_in_inPackagePattern1170);
                    wildcardTypeQualifierPattern79=wildcardTypeQualifierPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_wildcardTypeQualifierPattern.add(wildcardTypeQualifierPattern79.getTree());


                    // AST REWRITE
                    // elements: wildcardTypeQualifierPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 222:37: -> ^( InPackagePattern wildcardTypeQualifierPattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:222:39: ^( InPackagePattern wildcardTypeQualifierPattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPackagePattern, "InPackagePattern"), root_1);

                        adaptor.addChild(root_1, stream_wildcardTypeQualifierPattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:223:5: IN '(' inTypePattern ')'
                    {
                    IN80=(Token)match(input,IN,FOLLOW_IN_in_inPackagePattern1183); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IN.add(IN80);

                    char_literal81=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_inPackagePattern1185); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal81);

                    pushFollow(FOLLOW_inTypePattern_in_inPackagePattern1187);
                    inTypePattern82=inTypePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_inTypePattern.add(inTypePattern82.getTree());
                    char_literal83=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_inPackagePattern1189); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal83);



                    // AST REWRITE
                    // elements: inTypePattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 223:30: -> ^( InPackagePattern inTypePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:223:33: ^( InPackagePattern inTypePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPackagePattern, "InPackagePattern"), root_1);

                        adaptor.addChild(root_1, stream_inTypePattern.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:224:5: 
                    {

                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 224:5: -> ^( InPackagePattern )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:224:8: ^( InPackagePattern )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InPackagePattern, "InPackagePattern"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "inPackagePattern"

    public static class methodNamePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "methodNamePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:229:1: methodNamePattern : ( wildcardIdentifier | IDENTIFIER | STAR | DSTAR );
    public final ScopedPromisesParser.methodNamePattern_return methodNamePattern() throws RecognitionException {
        ScopedPromisesParser.methodNamePattern_return retval = new ScopedPromisesParser.methodNamePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER85=null;
        Token STAR86=null;
        Token DSTAR87=null;
        ScopedPromisesParser.wildcardIdentifier_return wildcardIdentifier84 = null;


        Tree IDENTIFIER85_tree=null;
        Tree STAR86_tree=null;
        Tree DSTAR87_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:230:3: ( wildcardIdentifier | IDENTIFIER | STAR | DSTAR )
            int alt17=4;
            switch ( input.LA(1) ) {
            case WildcardIdentifier:
                {
                alt17=1;
                }
                break;
            case IDENTIFIER:
                {
                alt17=2;
                }
                break;
            case STAR:
                {
                alt17=3;
                }
                break;
            case DSTAR:
                {
                alt17=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:230:5: wildcardIdentifier
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_wildcardIdentifier_in_methodNamePattern1224);
                    wildcardIdentifier84=wildcardIdentifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, wildcardIdentifier84.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:231:5: IDENTIFIER
                    {
                    root_0 = (Tree)adaptor.nil();

                    IDENTIFIER85=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_methodNamePattern1230); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER85_tree = (Tree)adaptor.create(IDENTIFIER85);
                    adaptor.addChild(root_0, IDENTIFIER85_tree);
                    }

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:232:5: STAR
                    {
                    root_0 = (Tree)adaptor.nil();

                    STAR86=(Token)match(input,STAR,FOLLOW_STAR_in_methodNamePattern1236); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STAR86_tree = (Tree)adaptor.create(STAR86);
                    adaptor.addChild(root_0, STAR86_tree);
                    }

                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:233:5: DSTAR
                    {
                    root_0 = (Tree)adaptor.nil();

                    DSTAR87=(Token)match(input,DSTAR,FOLLOW_DSTAR_in_methodNamePattern1242); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DSTAR87_tree = (Tree)adaptor.create(DSTAR87);
                    adaptor.addChild(root_0, DSTAR87_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "methodNamePattern"

    public static class methodSigPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "methodSigPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:236:1: methodSigPattern : ( '(' ')' -> ^( Parameters ) | '(' paramTypeSigPattern ( ',' paramTypeSigPattern )* ')' -> ^( Parameters ( paramTypeSigPattern )+ ) | '(' DSTAR ')' -> ^( Parameters ^( NamedTypePattern DSTAR ) ) );
    public final ScopedPromisesParser.methodSigPattern_return methodSigPattern() throws RecognitionException {
        ScopedPromisesParser.methodSigPattern_return retval = new ScopedPromisesParser.methodSigPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal88=null;
        Token char_literal89=null;
        Token char_literal90=null;
        Token char_literal92=null;
        Token char_literal94=null;
        Token char_literal95=null;
        Token DSTAR96=null;
        Token char_literal97=null;
        ScopedPromisesParser.paramTypeSigPattern_return paramTypeSigPattern91 = null;

        ScopedPromisesParser.paramTypeSigPattern_return paramTypeSigPattern93 = null;


        Tree char_literal88_tree=null;
        Tree char_literal89_tree=null;
        Tree char_literal90_tree=null;
        Tree char_literal92_tree=null;
        Tree char_literal94_tree=null;
        Tree char_literal95_tree=null;
        Tree DSTAR96_tree=null;
        Tree char_literal97_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_DSTAR=new RewriteRuleTokenStream(adaptor,"token DSTAR");
        RewriteRuleSubtreeStream stream_paramTypeSigPattern=new RewriteRuleSubtreeStream(adaptor,"rule paramTypeSigPattern");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:237:3: ( '(' ')' -> ^( Parameters ) | '(' paramTypeSigPattern ( ',' paramTypeSigPattern )* ')' -> ^( Parameters ( paramTypeSigPattern )+ ) | '(' DSTAR ')' -> ^( Parameters ^( NamedTypePattern DSTAR ) ) )
            int alt19=3;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==LPAREN) ) {
                switch ( input.LA(2) ) {
                case RPAREN:
                    {
                    alt19=1;
                    }
                    break;
                case DSTAR:
                    {
                    alt19=3;
                    }
                    break;
                case IDENTIFIER:
                case STAR:
                case BOOLEAN:
                case BYTE:
                case CHAR:
                case SHORT:
                case INT:
                case FLOAT:
                case DOUBLE:
                case LONG:
                case WildcardIdentifier:
                    {
                    alt19=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:237:5: '(' ')'
                    {
                    char_literal88=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_methodSigPattern1257); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal88);

                    char_literal89=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_methodSigPattern1259); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal89);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 237:13: -> ^( Parameters )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:237:16: ^( Parameters )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Parameters, "Parameters"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:238:5: '(' paramTypeSigPattern ( ',' paramTypeSigPattern )* ')'
                    {
                    char_literal90=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_methodSigPattern1271); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal90);

                    pushFollow(FOLLOW_paramTypeSigPattern_in_methodSigPattern1273);
                    paramTypeSigPattern91=paramTypeSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_paramTypeSigPattern.add(paramTypeSigPattern91.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:238:29: ( ',' paramTypeSigPattern )*
                    loop18:
                    do {
                        int alt18=2;
                        int LA18_0 = input.LA(1);

                        if ( (LA18_0==COMMA) ) {
                            alt18=1;
                        }


                        switch (alt18) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:238:30: ',' paramTypeSigPattern
                    	    {
                    	    char_literal92=(Token)match(input,COMMA,FOLLOW_COMMA_in_methodSigPattern1276); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal92);

                    	    pushFollow(FOLLOW_paramTypeSigPattern_in_methodSigPattern1278);
                    	    paramTypeSigPattern93=paramTypeSigPattern();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_paramTypeSigPattern.add(paramTypeSigPattern93.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop18;
                        }
                    } while (true);

                    char_literal94=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_methodSigPattern1282); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal94);



                    // AST REWRITE
                    // elements: paramTypeSigPattern
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 238:60: -> ^( Parameters ( paramTypeSigPattern )+ )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:238:63: ^( Parameters ( paramTypeSigPattern )+ )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Parameters, "Parameters"), root_1);

                        if ( !(stream_paramTypeSigPattern.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_paramTypeSigPattern.hasNext() ) {
                            adaptor.addChild(root_1, stream_paramTypeSigPattern.nextTree());

                        }
                        stream_paramTypeSigPattern.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:239:5: '(' DSTAR ')'
                    {
                    char_literal95=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_methodSigPattern1297); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal95);

                    DSTAR96=(Token)match(input,DSTAR,FOLLOW_DSTAR_in_methodSigPattern1299); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DSTAR.add(DSTAR96);

                    char_literal97=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_methodSigPattern1301); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal97);



                    // AST REWRITE
                    // elements: DSTAR
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 239:19: -> ^( Parameters ^( NamedTypePattern DSTAR ) )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:239:22: ^( Parameters ^( NamedTypePattern DSTAR ) )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Parameters, "Parameters"), root_1);

                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:239:35: ^( NamedTypePattern DSTAR )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedTypePattern, "NamedTypePattern"), root_2);

                        adaptor.addChild(root_2, stream_DSTAR.nextNode());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "methodSigPattern"

    public static class paramTypeSigPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "paramTypeSigPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:242:1: paramTypeSigPattern : ( typeSigPattern | qualifiedName -> ^( NamedTypePattern qualifiedName ) );
    public final ScopedPromisesParser.paramTypeSigPattern_return paramTypeSigPattern() throws RecognitionException {
        ScopedPromisesParser.paramTypeSigPattern_return retval = new ScopedPromisesParser.paramTypeSigPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.typeSigPattern_return typeSigPattern98 = null;

        ScopedPromisesParser.qualifiedName_return qualifiedName99 = null;


        RewriteRuleSubtreeStream stream_qualifiedName=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:243:3: ( typeSigPattern | qualifiedName -> ^( NamedTypePattern qualifiedName ) )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==STAR||(LA20_0>=BOOLEAN && LA20_0<=WildcardIdentifier)) ) {
                alt20=1;
            }
            else if ( (LA20_0==IDENTIFIER) ) {
                int LA20_2 = input.LA(2);

                if ( (LA20_2==RPAREN||LA20_2==COMMA) ) {
                    alt20=1;
                }
                else if ( (LA20_2==DOT) ) {
                    alt20=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 20, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:243:5: typeSigPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_typeSigPattern_in_paramTypeSigPattern1328);
                    typeSigPattern98=typeSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, typeSigPattern98.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:244:5: qualifiedName
                    {
                    pushFollow(FOLLOW_qualifiedName_in_paramTypeSigPattern1334);
                    qualifiedName99=qualifiedName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_qualifiedName.add(qualifiedName99.getTree());


                    // AST REWRITE
                    // elements: qualifiedName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 244:19: -> ^( NamedTypePattern qualifiedName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:244:22: ^( NamedTypePattern qualifiedName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedTypePattern, "NamedTypePattern"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "paramTypeSigPattern"

    public static class returnTypeSigPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "returnTypeSigPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:247:1: returnTypeSigPattern : ( VOID | typeSigPattern );
    public final ScopedPromisesParser.returnTypeSigPattern_return returnTypeSigPattern() throws RecognitionException {
        ScopedPromisesParser.returnTypeSigPattern_return retval = new ScopedPromisesParser.returnTypeSigPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token VOID100=null;
        ScopedPromisesParser.typeSigPattern_return typeSigPattern101 = null;


        Tree VOID100_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:248:3: ( VOID | typeSigPattern )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==VOID) ) {
                alt21=1;
            }
            else if ( ((LA21_0>=IDENTIFIER && LA21_0<=STAR)||(LA21_0>=BOOLEAN && LA21_0<=WildcardIdentifier)) ) {
                alt21=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:248:5: VOID
                    {
                    root_0 = (Tree)adaptor.nil();

                    VOID100=(Token)match(input,VOID,FOLLOW_VOID_in_returnTypeSigPattern1357); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    VOID100_tree = (Tree)adaptor.create(VOID100);
                    adaptor.addChild(root_0, VOID100_tree);
                    }

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:248:12: typeSigPattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_typeSigPattern_in_returnTypeSigPattern1361);
                    typeSigPattern101=typeSigPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, typeSigPattern101.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "returnTypeSigPattern"

    public static class typeSigPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeSigPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:251:1: typeSigPattern : ( BOOLEAN -> ^( BooleanType ) | BYTE -> ^( ByteType ) | CHAR -> ^( CharType ) | SHORT -> ^( ShortType ) | INT -> ^( IntType ) | FLOAT -> ^( FloatType ) | DOUBLE -> ^( DoubleType ) | LONG -> ^( LongType ) | STAR -> ^( NamedTypePattern STAR ) | namedTypePattern );
    public final ScopedPromisesParser.typeSigPattern_return typeSigPattern() throws RecognitionException {
        ScopedPromisesParser.typeSigPattern_return retval = new ScopedPromisesParser.typeSigPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token BOOLEAN102=null;
        Token BYTE103=null;
        Token CHAR104=null;
        Token SHORT105=null;
        Token INT106=null;
        Token FLOAT107=null;
        Token DOUBLE108=null;
        Token LONG109=null;
        Token STAR110=null;
        ScopedPromisesParser.namedTypePattern_return namedTypePattern111 = null;


        Tree BOOLEAN102_tree=null;
        Tree BYTE103_tree=null;
        Tree CHAR104_tree=null;
        Tree SHORT105_tree=null;
        Tree INT106_tree=null;
        Tree FLOAT107_tree=null;
        Tree DOUBLE108_tree=null;
        Tree LONG109_tree=null;
        Tree STAR110_tree=null;
        RewriteRuleTokenStream stream_LONG=new RewriteRuleTokenStream(adaptor,"token LONG");
        RewriteRuleTokenStream stream_BOOLEAN=new RewriteRuleTokenStream(adaptor,"token BOOLEAN");
        RewriteRuleTokenStream stream_STAR=new RewriteRuleTokenStream(adaptor,"token STAR");
        RewriteRuleTokenStream stream_BYTE=new RewriteRuleTokenStream(adaptor,"token BYTE");
        RewriteRuleTokenStream stream_DOUBLE=new RewriteRuleTokenStream(adaptor,"token DOUBLE");
        RewriteRuleTokenStream stream_INT=new RewriteRuleTokenStream(adaptor,"token INT");
        RewriteRuleTokenStream stream_CHAR=new RewriteRuleTokenStream(adaptor,"token CHAR");
        RewriteRuleTokenStream stream_SHORT=new RewriteRuleTokenStream(adaptor,"token SHORT");
        RewriteRuleTokenStream stream_FLOAT=new RewriteRuleTokenStream(adaptor,"token FLOAT");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:252:3: ( BOOLEAN -> ^( BooleanType ) | BYTE -> ^( ByteType ) | CHAR -> ^( CharType ) | SHORT -> ^( ShortType ) | INT -> ^( IntType ) | FLOAT -> ^( FloatType ) | DOUBLE -> ^( DoubleType ) | LONG -> ^( LongType ) | STAR -> ^( NamedTypePattern STAR ) | namedTypePattern )
            int alt22=10;
            switch ( input.LA(1) ) {
            case BOOLEAN:
                {
                alt22=1;
                }
                break;
            case BYTE:
                {
                alt22=2;
                }
                break;
            case CHAR:
                {
                alt22=3;
                }
                break;
            case SHORT:
                {
                alt22=4;
                }
                break;
            case INT:
                {
                alt22=5;
                }
                break;
            case FLOAT:
                {
                alt22=6;
                }
                break;
            case DOUBLE:
                {
                alt22=7;
                }
                break;
            case LONG:
                {
                alt22=8;
                }
                break;
            case STAR:
                {
                alt22=9;
                }
                break;
            case IDENTIFIER:
            case WildcardIdentifier:
                {
                alt22=10;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }

            switch (alt22) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:252:5: BOOLEAN
                    {
                    BOOLEAN102=(Token)match(input,BOOLEAN,FOLLOW_BOOLEAN_in_typeSigPattern1376); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BOOLEAN.add(BOOLEAN102);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 252:13: -> ^( BooleanType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:252:16: ^( BooleanType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(BooleanType, "BooleanType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:253:5: BYTE
                    {
                    BYTE103=(Token)match(input,BYTE,FOLLOW_BYTE_in_typeSigPattern1388); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_BYTE.add(BYTE103);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 253:10: -> ^( ByteType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:253:13: ^( ByteType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ByteType, "ByteType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:254:5: CHAR
                    {
                    CHAR104=(Token)match(input,CHAR,FOLLOW_CHAR_in_typeSigPattern1400); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CHAR.add(CHAR104);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 254:10: -> ^( CharType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:254:13: ^( CharType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(CharType, "CharType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:255:5: SHORT
                    {
                    SHORT105=(Token)match(input,SHORT,FOLLOW_SHORT_in_typeSigPattern1412); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SHORT.add(SHORT105);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 255:11: -> ^( ShortType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:255:14: ^( ShortType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ShortType, "ShortType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:256:5: INT
                    {
                    INT106=(Token)match(input,INT,FOLLOW_INT_in_typeSigPattern1424); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INT.add(INT106);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 256:9: -> ^( IntType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:256:12: ^( IntType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(IntType, "IntType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:257:5: FLOAT
                    {
                    FLOAT107=(Token)match(input,FLOAT,FOLLOW_FLOAT_in_typeSigPattern1436); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FLOAT.add(FLOAT107);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 257:11: -> ^( FloatType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:257:14: ^( FloatType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FloatType, "FloatType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:258:5: DOUBLE
                    {
                    DOUBLE108=(Token)match(input,DOUBLE,FOLLOW_DOUBLE_in_typeSigPattern1448); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOUBLE.add(DOUBLE108);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 258:12: -> ^( DoubleType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:258:15: ^( DoubleType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(DoubleType, "DoubleType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:259:5: LONG
                    {
                    LONG109=(Token)match(input,LONG,FOLLOW_LONG_in_typeSigPattern1460); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LONG.add(LONG109);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 259:10: -> ^( LongType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:259:13: ^( LongType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(LongType, "LongType"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:260:5: STAR
                    {
                    STAR110=(Token)match(input,STAR,FOLLOW_STAR_in_typeSigPattern1472); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_STAR.add(STAR110);



                    // AST REWRITE
                    // elements: STAR
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 260:10: -> ^( NamedTypePattern STAR )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:260:13: ^( NamedTypePattern STAR )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedTypePattern, "NamedTypePattern"), root_1);

                        adaptor.addChild(root_1, stream_STAR.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:261:5: namedTypePattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_namedTypePattern_in_typeSigPattern1486);
                    namedTypePattern111=namedTypePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, namedTypePattern111.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeSigPattern"

    public static class fieldNamePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldNamePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:264:1: fieldNamePattern : ( wildcardIdentifier | IDENTIFIER | STAR );
    public final ScopedPromisesParser.fieldNamePattern_return fieldNamePattern() throws RecognitionException {
        ScopedPromisesParser.fieldNamePattern_return retval = new ScopedPromisesParser.fieldNamePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER113=null;
        Token STAR114=null;
        ScopedPromisesParser.wildcardIdentifier_return wildcardIdentifier112 = null;


        Tree IDENTIFIER113_tree=null;
        Tree STAR114_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:265:3: ( wildcardIdentifier | IDENTIFIER | STAR )
            int alt23=3;
            switch ( input.LA(1) ) {
            case WildcardIdentifier:
                {
                alt23=1;
                }
                break;
            case IDENTIFIER:
                {
                alt23=2;
                }
                break;
            case STAR:
                {
                alt23=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:265:5: wildcardIdentifier
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_wildcardIdentifier_in_fieldNamePattern1500);
                    wildcardIdentifier112=wildcardIdentifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, wildcardIdentifier112.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:266:5: IDENTIFIER
                    {
                    root_0 = (Tree)adaptor.nil();

                    IDENTIFIER113=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fieldNamePattern1506); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER113_tree = (Tree)adaptor.create(IDENTIFIER113);
                    adaptor.addChild(root_0, IDENTIFIER113_tree);
                    }

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:267:5: STAR
                    {
                    root_0 = (Tree)adaptor.nil();

                    STAR114=(Token)match(input,STAR,FOLLOW_STAR_in_fieldNamePattern1512); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STAR114_tree = (Tree)adaptor.create(STAR114);
                    adaptor.addChild(root_0, STAR114_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldNamePattern"

    public static class optQualifiedTypeNamePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "optQualifiedTypeNamePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:270:1: optQualifiedTypeNamePattern : ( typeNamePattern | STAR );
    public final ScopedPromisesParser.optQualifiedTypeNamePattern_return optQualifiedTypeNamePattern() throws RecognitionException {
        ScopedPromisesParser.optQualifiedTypeNamePattern_return retval = new ScopedPromisesParser.optQualifiedTypeNamePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token STAR116=null;
        ScopedPromisesParser.typeNamePattern_return typeNamePattern115 = null;


        Tree STAR116_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:271:3: ( typeNamePattern | STAR )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==IDENTIFIER||LA24_0==WildcardIdentifier) ) {
                alt24=1;
            }
            else if ( (LA24_0==STAR) ) {
                alt24=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:271:5: typeNamePattern
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_typeNamePattern_in_optQualifiedTypeNamePattern1529);
                    typeNamePattern115=typeNamePattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, typeNamePattern115.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:272:5: STAR
                    {
                    root_0 = (Tree)adaptor.nil();

                    STAR116=(Token)match(input,STAR,FOLLOW_STAR_in_optQualifiedTypeNamePattern1535); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STAR116_tree = (Tree)adaptor.create(STAR116);
                    adaptor.addChild(root_0, STAR116_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "optQualifiedTypeNamePattern"

    public static class namedTypePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "namedTypePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:275:1: namedTypePattern : ( wildcardIdentifier -> ^( NamedTypePattern wildcardIdentifier ) | IDENTIFIER -> ^( NamedTypePattern IDENTIFIER ) );
    public final ScopedPromisesParser.namedTypePattern_return namedTypePattern() throws RecognitionException {
        ScopedPromisesParser.namedTypePattern_return retval = new ScopedPromisesParser.namedTypePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER118=null;
        ScopedPromisesParser.wildcardIdentifier_return wildcardIdentifier117 = null;


        Tree IDENTIFIER118_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_wildcardIdentifier=new RewriteRuleSubtreeStream(adaptor,"rule wildcardIdentifier");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:276:3: ( wildcardIdentifier -> ^( NamedTypePattern wildcardIdentifier ) | IDENTIFIER -> ^( NamedTypePattern IDENTIFIER ) )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==WildcardIdentifier) ) {
                alt25=1;
            }
            else if ( (LA25_0==IDENTIFIER) ) {
                alt25=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:276:5: wildcardIdentifier
                    {
                    pushFollow(FOLLOW_wildcardIdentifier_in_namedTypePattern1548);
                    wildcardIdentifier117=wildcardIdentifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_wildcardIdentifier.add(wildcardIdentifier117.getTree());


                    // AST REWRITE
                    // elements: wildcardIdentifier
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 276:24: -> ^( NamedTypePattern wildcardIdentifier )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:276:27: ^( NamedTypePattern wildcardIdentifier )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedTypePattern, "NamedTypePattern"), root_1);

                        adaptor.addChild(root_1, stream_wildcardIdentifier.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:277:5: IDENTIFIER
                    {
                    IDENTIFIER118=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_namedTypePattern1562); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER118);



                    // AST REWRITE
                    // elements: IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 277:16: -> ^( NamedTypePattern IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:277:19: ^( NamedTypePattern IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedTypePattern, "NamedTypePattern"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "namedTypePattern"

    public static class typeNamePattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeNamePattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:280:1: typeNamePattern : ( wildcardIdentifier | IDENTIFIER );
    public final ScopedPromisesParser.typeNamePattern_return typeNamePattern() throws RecognitionException {
        ScopedPromisesParser.typeNamePattern_return retval = new ScopedPromisesParser.typeNamePattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER120=null;
        ScopedPromisesParser.wildcardIdentifier_return wildcardIdentifier119 = null;


        Tree IDENTIFIER120_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:281:3: ( wildcardIdentifier | IDENTIFIER )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==WildcardIdentifier) ) {
                alt26=1;
            }
            else if ( (LA26_0==IDENTIFIER) ) {
                alt26=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:281:5: wildcardIdentifier
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_wildcardIdentifier_in_typeNamePattern1584);
                    wildcardIdentifier119=wildcardIdentifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, wildcardIdentifier119.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:282:5: IDENTIFIER
                    {
                    root_0 = (Tree)adaptor.nil();

                    IDENTIFIER120=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_typeNamePattern1590); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER120_tree = (Tree)adaptor.create(IDENTIFIER120);
                    adaptor.addChild(root_0, IDENTIFIER120_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeNamePattern"

    public static class qualifiedName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:285:1: qualifiedName : IDENTIFIER ( DOT IDENTIFIER )+ ;
    public final ScopedPromisesParser.qualifiedName_return qualifiedName() throws RecognitionException {
        ScopedPromisesParser.qualifiedName_return retval = new ScopedPromisesParser.qualifiedName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER121=null;
        Token DOT122=null;
        Token IDENTIFIER123=null;

        Tree IDENTIFIER121_tree=null;
        Tree DOT122_tree=null;
        Tree IDENTIFIER123_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:286:3: ( IDENTIFIER ( DOT IDENTIFIER )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:286:5: IDENTIFIER ( DOT IDENTIFIER )+
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER121=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName1605); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER121_tree = (Tree)adaptor.create(IDENTIFIER121);
            adaptor.addChild(root_0, IDENTIFIER121_tree);
            }
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:286:16: ( DOT IDENTIFIER )+
            int cnt27=0;
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==DOT) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:286:17: DOT IDENTIFIER
            	    {
            	    DOT122=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedName1608); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    DOT122_tree = (Tree)adaptor.create(DOT122);
            	    adaptor.addChild(root_0, DOT122_tree);
            	    }
            	    IDENTIFIER123=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName1610); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    IDENTIFIER123_tree = (Tree)adaptor.create(IDENTIFIER123);
            	    adaptor.addChild(root_0, IDENTIFIER123_tree);
            	    }

            	    }
            	    break;

            	default :
            	    if ( cnt27 >= 1 ) break loop27;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(27, input);
                        throw eee;
                }
                cnt27++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedName"

    public static class namedTypes_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "namedTypes"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:289:1: namedTypes : namedType ( ',' namedType )* -> ( namedType )+ ;
    public final ScopedPromisesParser.namedTypes_return namedTypes() throws RecognitionException {
        ScopedPromisesParser.namedTypes_return retval = new ScopedPromisesParser.namedTypes_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal125=null;
        ScopedPromisesParser.namedType_return namedType124 = null;

        ScopedPromisesParser.namedType_return namedType126 = null;


        Tree char_literal125_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:290:3: ( namedType ( ',' namedType )* -> ( namedType )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:290:5: namedType ( ',' namedType )*
            {
            pushFollow(FOLLOW_namedType_in_namedTypes1625);
            namedType124=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType124.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:290:15: ( ',' namedType )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==COMMA) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:290:16: ',' namedType
            	    {
            	    char_literal125=(Token)match(input,COMMA,FOLLOW_COMMA_in_namedTypes1628); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal125);

            	    pushFollow(FOLLOW_namedType_in_namedTypes1630);
            	    namedType126=namedType();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_namedType.add(namedType126.getTree());

            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 290:32: -> ( namedType )+
            {
                if ( !(stream_namedType.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_namedType.hasNext() ) {
                    adaptor.addChild(root_0, stream_namedType.nextTree());

                }
                stream_namedType.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "namedTypes"

    public static class wildcardIdentifier_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "wildcardIdentifier"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:293:1: wildcardIdentifier : WildcardIdentifier ;
    public final ScopedPromisesParser.wildcardIdentifier_return wildcardIdentifier() throws RecognitionException {
        ScopedPromisesParser.wildcardIdentifier_return retval = new ScopedPromisesParser.wildcardIdentifier_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token WildcardIdentifier127=null;

        Tree WildcardIdentifier127_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:298:3: ( WildcardIdentifier )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:298:5: WildcardIdentifier
            {
            root_0 = (Tree)adaptor.nil();

            WildcardIdentifier127=(Token)match(input,WildcardIdentifier,FOLLOW_WildcardIdentifier_in_wildcardIdentifier1652); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            WildcardIdentifier127_tree = (Tree)adaptor.create(WildcardIdentifier127);
            adaptor.addChild(root_0, WildcardIdentifier127_tree);
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "wildcardIdentifier"

    public static class modifierPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifierPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:301:1: modifierPattern : accessModPattern ( staticPattern )? ;
    public final ScopedPromisesParser.modifierPattern_return modifierPattern() throws RecognitionException {
        ScopedPromisesParser.modifierPattern_return retval = new ScopedPromisesParser.modifierPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.accessModPattern_return accessModPattern128 = null;

        ScopedPromisesParser.staticPattern_return staticPattern129 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:316:3: ( accessModPattern ( staticPattern )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:316:5: accessModPattern ( staticPattern )?
            {
            root_0 = (Tree)adaptor.nil();

            pushFollow(FOLLOW_accessModPattern_in_modifierPattern1672);
            accessModPattern128=accessModPattern();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, accessModPattern128.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:316:22: ( staticPattern )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==STATIC||LA29_0==106) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:316:22: staticPattern
                    {
                    pushFollow(FOLLOW_staticPattern_in_modifierPattern1674);
                    staticPattern129=staticPattern();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, staticPattern129.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifierPattern"

    public static class accessModPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "accessModPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:320:1: accessModPattern : ( PUBLIC | PROTECTED | PRIVATE )? ;
    public final ScopedPromisesParser.accessModPattern_return accessModPattern() throws RecognitionException {
        ScopedPromisesParser.accessModPattern_return retval = new ScopedPromisesParser.accessModPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token set130=null;

        Tree set130_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:321:3: ( ( PUBLIC | PROTECTED | PRIVATE )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:321:5: ( PUBLIC | PROTECTED | PRIVATE )?
            {
            root_0 = (Tree)adaptor.nil();

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:321:5: ( PUBLIC | PROTECTED | PRIVATE )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( ((LA30_0>=PUBLIC && LA30_0<=PRIVATE)) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
                    {
                    set130=(Token)input.LT(1);
                    if ( (input.LA(1)>=PUBLIC && input.LA(1)<=PRIVATE) ) {
                        input.consume();
                        if ( state.backtracking==0 ) adaptor.addChild(root_0, (Tree)adaptor.create(set130));
                        state.errorRecovery=false;state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "accessModPattern"

    public static class staticPattern_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "staticPattern"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:324:1: staticPattern : ( STATIC | '!' STATIC -> INSTANCE );
    public final ScopedPromisesParser.staticPattern_return staticPattern() throws RecognitionException {
        ScopedPromisesParser.staticPattern_return retval = new ScopedPromisesParser.staticPattern_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token STATIC131=null;
        Token char_literal132=null;
        Token STATIC133=null;

        Tree STATIC131_tree=null;
        Tree char_literal132_tree=null;
        Tree STATIC133_tree=null;
        RewriteRuleTokenStream stream_STATIC=new RewriteRuleTokenStream(adaptor,"token STATIC");
        RewriteRuleTokenStream stream_106=new RewriteRuleTokenStream(adaptor,"token 106");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:325:3: ( STATIC | '!' STATIC -> INSTANCE )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==STATIC) ) {
                alt31=1;
            }
            else if ( (LA31_0==106) ) {
                alt31=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:325:5: STATIC
                    {
                    root_0 = (Tree)adaptor.nil();

                    STATIC131=(Token)match(input,STATIC,FOLLOW_STATIC_in_staticPattern1716); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STATIC131_tree = (Tree)adaptor.create(STATIC131);
                    adaptor.addChild(root_0, STATIC131_tree);
                    }

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:326:5: '!' STATIC
                    {
                    char_literal132=(Token)match(input,106,FOLLOW_106_in_staticPattern1723); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_106.add(char_literal132);

                    STATIC133=(Token)match(input,STATIC,FOLLOW_STATIC_in_staticPattern1725); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_STATIC.add(STATIC133);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 326:16: -> INSTANCE
                    {
                        adaptor.addChild(root_0, (Tree)adaptor.create(INSTANCE, "INSTANCE"));

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "staticPattern"

    public static class qualifiedClassExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedClassExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:336:1: qualifiedClassExpression : namedType '.' CLASS -> ^( ClassExpression namedType ) ;
    public final ScopedPromisesParser.qualifiedClassExpression_return qualifiedClassExpression() throws RecognitionException {
        ScopedPromisesParser.qualifiedClassExpression_return retval = new ScopedPromisesParser.qualifiedClassExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal135=null;
        Token CLASS136=null;
        ScopedPromisesParser.namedType_return namedType134 = null;


        Tree char_literal135_tree=null;
        Tree CLASS136_tree=null;
        RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:341:2: ( namedType '.' CLASS -> ^( ClassExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:341:4: namedType '.' CLASS
            {
            pushFollow(FOLLOW_namedType_in_qualifiedClassExpression1750);
            namedType134=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType134.getTree());
            char_literal135=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedClassExpression1752); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOT.add(char_literal135);

            CLASS136=(Token)match(input,CLASS,FOLLOW_CLASS_in_qualifiedClassExpression1754); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLASS.add(CLASS136);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 341:24: -> ^( ClassExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:341:27: ^( ClassExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ClassExpression, "ClassExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedClassExpression"

    public static class qualifiedThisExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedThisExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:344:1: qualifiedThisExpression : namedType '.' THIS -> ^( QualifiedThisExpression namedType ) ;
    public final ScopedPromisesParser.qualifiedThisExpression_return qualifiedThisExpression() throws RecognitionException {
        ScopedPromisesParser.qualifiedThisExpression_return retval = new ScopedPromisesParser.qualifiedThisExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal138=null;
        Token THIS139=null;
        ScopedPromisesParser.namedType_return namedType137 = null;


        Tree char_literal138_tree=null;
        Tree THIS139_tree=null;
        RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:345:2: ( namedType '.' THIS -> ^( QualifiedThisExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:345:4: namedType '.' THIS
            {
            pushFollow(FOLLOW_namedType_in_qualifiedThisExpression1775);
            namedType137=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType137.getTree());
            char_literal138=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedThisExpression1777); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOT.add(char_literal138);

            THIS139=(Token)match(input,THIS,FOLLOW_THIS_in_qualifiedThisExpression1779); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_THIS.add(THIS139);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 345:23: -> ^( QualifiedThisExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:345:26: ^( QualifiedThisExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedThisExpression, "QualifiedThisExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedThisExpression"

    public static class typeExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:348:1: typeExpression : namedType -> ^( TypeExpression namedType ) ;
    public final ScopedPromisesParser.typeExpression_return typeExpression() throws RecognitionException {
        ScopedPromisesParser.typeExpression_return retval = new ScopedPromisesParser.typeExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.namedType_return namedType140 = null;


        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:349:2: ( namedType -> ^( TypeExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:349:4: namedType
            {
            pushFollow(FOLLOW_namedType_in_typeExpression1800);
            namedType140=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType140.getTree());


            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 349:14: -> ^( TypeExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:349:17: ^( TypeExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeExpression, "TypeExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeExpression"

    public static class fieldRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:352:1: fieldRef : ( qualifiedFieldRef | simpleFieldRef );
    public final ScopedPromisesParser.fieldRef_return fieldRef() throws RecognitionException {
        ScopedPromisesParser.fieldRef_return retval = new ScopedPromisesParser.fieldRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.qualifiedFieldRef_return qualifiedFieldRef141 = null;

        ScopedPromisesParser.simpleFieldRef_return simpleFieldRef142 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:353:3: ( qualifiedFieldRef | simpleFieldRef )
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==IDENTIFIER) ) {
                int LA32_1 = input.LA(2);

                if ( (LA32_1==DOT) ) {
                    alt32=1;
                }
                else if ( (LA32_1==EOF) ) {
                    alt32=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 32, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA32_0==THIS) ) {
                alt32=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }
            switch (alt32) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:353:5: qualifiedFieldRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedFieldRef_in_fieldRef1820);
                    qualifiedFieldRef141=qualifiedFieldRef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedFieldRef141.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:354:5: simpleFieldRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleFieldRef_in_fieldRef1826);
                    simpleFieldRef142=simpleFieldRef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleFieldRef142.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldRef"

    public static class qualifiedFieldRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedFieldRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:357:1: qualifiedFieldRef : typeExpression '.' IDENTIFIER -> ^( FieldRef typeExpression IDENTIFIER ) ;
    public final ScopedPromisesParser.qualifiedFieldRef_return qualifiedFieldRef() throws RecognitionException {
        ScopedPromisesParser.qualifiedFieldRef_return retval = new ScopedPromisesParser.qualifiedFieldRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal144=null;
        Token IDENTIFIER145=null;
        ScopedPromisesParser.typeExpression_return typeExpression143 = null;


        Tree char_literal144_tree=null;
        Tree IDENTIFIER145_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_typeExpression=new RewriteRuleSubtreeStream(adaptor,"rule typeExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:358:2: ( typeExpression '.' IDENTIFIER -> ^( FieldRef typeExpression IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:358:4: typeExpression '.' IDENTIFIER
            {
            pushFollow(FOLLOW_typeExpression_in_qualifiedFieldRef1838);
            typeExpression143=typeExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_typeExpression.add(typeExpression143.getTree());
            char_literal144=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedFieldRef1840); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOT.add(char_literal144);

            IDENTIFIER145=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedFieldRef1842); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER145);



            // AST REWRITE
            // elements: typeExpression, IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 358:34: -> ^( FieldRef typeExpression IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:358:37: ^( FieldRef typeExpression IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                adaptor.addChild(root_1, stream_typeExpression.nextTree());
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedFieldRef"

    public static class namedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "namedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:361:1: namedType : name -> ^( NamedType name ) ;
    public final ScopedPromisesParser.namedType_return namedType() throws RecognitionException {
        ScopedPromisesParser.namedType_return retval = new ScopedPromisesParser.namedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.name_return name146 = null;


        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:362:4: ( name -> ^( NamedType name ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:362:6: name
            {
            pushFollow(FOLLOW_name_in_namedType1865);
            name146=name();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_name.add(name146.getTree());


            // AST REWRITE
            // elements: name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 362:11: -> ^( NamedType name )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:362:14: ^( NamedType name )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedType, "NamedType"), root_1);

                adaptor.addChild(root_1, stream_name.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "namedType"

    public static class typeName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:365:1: typeName : ({...}? IDENTIFIER | qualifiedTypeName );
    public final ScopedPromisesParser.typeName_return typeName() throws RecognitionException {
        ScopedPromisesParser.typeName_return retval = new ScopedPromisesParser.typeName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER147=null;
        ScopedPromisesParser.qualifiedTypeName_return qualifiedTypeName148 = null;


        Tree IDENTIFIER147_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:366:4: ({...}? IDENTIFIER | qualifiedTypeName )
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==IDENTIFIER) ) {
                int LA33_1 = input.LA(2);

                if ( ((isType("", ScopedPromisesParser.this.input.LT(1)))) ) {
                    alt33=1;
                }
                else if ( (true) ) {
                    alt33=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 33, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }
            switch (alt33) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:366:6: {...}? IDENTIFIER
                    {
                    root_0 = (Tree)adaptor.nil();

                    if ( !((isType("", ScopedPromisesParser.this.input.LT(1)))) ) {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        throw new FailedPredicateException(input, "typeName", "isType(\"\", ScopedPromisesParser.this.input.LT(1))");
                    }
                    IDENTIFIER147=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_typeName1893); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER147_tree = (Tree)adaptor.create(IDENTIFIER147);
                    adaptor.addChild(root_0, IDENTIFIER147_tree);
                    }

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:367:6: qualifiedTypeName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedTypeName_in_typeName1900);
                    qualifiedTypeName148=qualifiedTypeName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedTypeName148.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeName"

    public static class qualifiedTypeName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedTypeName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:370:1: qualifiedTypeName : IDENTIFIER ({...}? '.' IDENTIFIER )* ;
    public final ScopedPromisesParser.qualifiedTypeName_return qualifiedTypeName() throws RecognitionException {
        ScopedPromisesParser.qualifiedTypeName_return retval = new ScopedPromisesParser.qualifiedTypeName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER149=null;
        Token char_literal150=null;
        Token IDENTIFIER151=null;

        Tree IDENTIFIER149_tree=null;
        Tree char_literal150_tree=null;
        Tree IDENTIFIER151_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:371:2: ( IDENTIFIER ({...}? '.' IDENTIFIER )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:371:4: IDENTIFIER ({...}? '.' IDENTIFIER )*
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER149=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedTypeName1918); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER149_tree = (Tree)adaptor.create(IDENTIFIER149);
            adaptor.addChild(root_0, IDENTIFIER149_tree);
            }
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:371:15: ({...}? '.' IDENTIFIER )*
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( (LA34_0==DOT) ) {
                    alt34=1;
                }


                switch (alt34) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:371:16: {...}? '.' IDENTIFIER
            	    {
            	    if ( !((isType(input.toString(retval.start,input.LT(-1)), ScopedPromisesParser.this.input.LT(2)))) ) {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        throw new FailedPredicateException(input, "qualifiedTypeName", "isType($qualifiedTypeName.text, ScopedPromisesParser.this.input.LT(2))");
            	    }
            	    char_literal150=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedTypeName1939); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal150_tree = (Tree)adaptor.create(char_literal150);
            	    adaptor.addChild(root_0, char_literal150_tree);
            	    }
            	    IDENTIFIER151=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedTypeName1941); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    IDENTIFIER151_tree = (Tree)adaptor.create(IDENTIFIER151);
            	    adaptor.addChild(root_0, IDENTIFIER151_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedTypeName"

    public static class simpleFieldRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleFieldRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:375:1: simpleFieldRef : ( thisExpr DOT IDENTIFIER -> ^( FieldRef thisExpr IDENTIFIER ) | IDENTIFIER -> ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER ) );
    public final ScopedPromisesParser.simpleFieldRef_return simpleFieldRef() throws RecognitionException {
        ScopedPromisesParser.simpleFieldRef_return retval = new ScopedPromisesParser.simpleFieldRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token DOT153=null;
        Token IDENTIFIER154=null;
        Token IDENTIFIER155=null;
        ScopedPromisesParser.thisExpr_return thisExpr152 = null;


        Tree DOT153_tree=null;
        Tree IDENTIFIER154_tree=null;
        Tree IDENTIFIER155_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_thisExpr=new RewriteRuleSubtreeStream(adaptor,"rule thisExpr");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:376:3: ( thisExpr DOT IDENTIFIER -> ^( FieldRef thisExpr IDENTIFIER ) | IDENTIFIER -> ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER ) )
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==THIS) ) {
                alt35=1;
            }
            else if ( (LA35_0==IDENTIFIER) ) {
                alt35=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }
            switch (alt35) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:376:5: thisExpr DOT IDENTIFIER
                    {
                    pushFollow(FOLLOW_thisExpr_in_simpleFieldRef1971);
                    thisExpr152=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_thisExpr.add(thisExpr152.getTree());
                    DOT153=(Token)match(input,DOT,FOLLOW_DOT_in_simpleFieldRef1973); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(DOT153);

                    IDENTIFIER154=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleFieldRef1975); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER154);



                    // AST REWRITE
                    // elements: thisExpr, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 376:29: -> ^( FieldRef thisExpr IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:376:32: ^( FieldRef thisExpr IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                        adaptor.addChild(root_1, stream_thisExpr.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:377:4: IDENTIFIER
                    {
                    IDENTIFIER155=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleFieldRef1991); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER155);



                    // AST REWRITE
                    // elements: IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 377:15: -> ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:377:18: ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:377:29: ^( ThisExpression THIS )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ThisExpression, "ThisExpression"), root_2);

                        adaptor.addChild(root_2, (Tree)adaptor.create(THIS, "THIS"));

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleFieldRef"

    public static class simpleExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:380:1: simpleExpression : ( thisExpr | varUse );
    public final ScopedPromisesParser.simpleExpression_return simpleExpression() throws RecognitionException {
        ScopedPromisesParser.simpleExpression_return retval = new ScopedPromisesParser.simpleExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        ScopedPromisesParser.thisExpr_return thisExpr156 = null;

        ScopedPromisesParser.varUse_return varUse157 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:385:2: ( thisExpr | varUse )
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==THIS) ) {
                alt36=1;
            }
            else if ( (LA36_0==IDENTIFIER) ) {
                alt36=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }
            switch (alt36) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:385:4: thisExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_thisExpr_in_simpleExpression2022);
                    thisExpr156=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, thisExpr156.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:386:4: varUse
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_varUse_in_simpleExpression2028);
                    varUse157=varUse();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, varUse157.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleExpression"

    public static class varUse_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "varUse"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:389:1: varUse : IDENTIFIER -> ^( VariableUseExpression IDENTIFIER ) ;
    public final ScopedPromisesParser.varUse_return varUse() throws RecognitionException {
        ScopedPromisesParser.varUse_return retval = new ScopedPromisesParser.varUse_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER158=null;

        Tree IDENTIFIER158_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:390:6: ( IDENTIFIER -> ^( VariableUseExpression IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:390:8: IDENTIFIER
            {
            IDENTIFIER158=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_varUse2043); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER158);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 390:19: -> ^( VariableUseExpression IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:390:22: ^( VariableUseExpression IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(VariableUseExpression, "VariableUseExpression"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "varUse"

    public static class thisExpr_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "thisExpr"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:393:1: thisExpr : THIS -> ^( ThisExpression THIS ) ;
    public final ScopedPromisesParser.thisExpr_return thisExpr() throws RecognitionException {
        ScopedPromisesParser.thisExpr_return retval = new ScopedPromisesParser.thisExpr_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token THIS159=null;

        Tree THIS159_tree=null;
        RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:394:5: ( THIS -> ^( ThisExpression THIS ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:394:7: THIS
            {
            THIS159=(Token)match(input,THIS,FOLLOW_THIS_in_thisExpr2071); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_THIS.add(THIS159);



            // AST REWRITE
            // elements: THIS
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 394:12: -> ^( ThisExpression THIS )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:394:15: ^( ThisExpression THIS )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ThisExpression, "ThisExpression"), root_1);

                adaptor.addChild(root_1, stream_THIS.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "thisExpr"

    public static class nothing_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nothing"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:397:1: nothing : EOF -> ^( Nothing ) ;
    public final ScopedPromisesParser.nothing_return nothing() throws RecognitionException {
        ScopedPromisesParser.nothing_return retval = new ScopedPromisesParser.nothing_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF160=null;

        Tree EOF160_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:398:5: ( EOF -> ^( Nothing ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:398:7: EOF
            {
            EOF160=(Token)match(input,EOF,FOLLOW_EOF_in_nothing2100); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF160);



            // AST REWRITE
            // elements: 
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 398:11: -> ^( Nothing )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:398:14: ^( Nothing )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Nothing, "Nothing"), root_1);

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "nothing"

    public static class accessModifiers_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "accessModifiers"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:401:1: accessModifiers : ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? ;
    public final ScopedPromisesParser.accessModifiers_return accessModifiers() throws RecognitionException {
        ScopedPromisesParser.accessModifiers_return retval = new ScopedPromisesParser.accessModifiers_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token set161=null;
        Token STATIC162=null;

        Tree set161_tree=null;
        Tree STATIC162_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:402:2: ( ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:402:4: ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )?
            {
            root_0 = (Tree)adaptor.nil();

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:402:4: ( PUBLIC | PROTECTED | PRIVATE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( ((LA37_0>=PUBLIC && LA37_0<=PRIVATE)) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
                    {
                    set161=(Token)input.LT(1);
                    if ( (input.LA(1)>=PUBLIC && input.LA(1)<=PRIVATE) ) {
                        input.consume();
                        if ( state.backtracking==0 ) adaptor.addChild(root_0, (Tree)adaptor.create(set161));
                        state.errorRecovery=false;state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:402:36: ( STATIC )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==STATIC) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:402:36: STATIC
                    {
                    STATIC162=(Token)match(input,STATIC,FOLLOW_STATIC_in_accessModifiers2135); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STATIC162_tree = (Tree)adaptor.create(STATIC162);
                    adaptor.addChild(root_0, STATIC162_tree);
                    }

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "accessModifiers"

    public static class name_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "name"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:405:1: name : IDENTIFIER ( DOT name ) ;
    public final ScopedPromisesParser.name_return name() throws RecognitionException {
        ScopedPromisesParser.name_return retval = new ScopedPromisesParser.name_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER163=null;
        Token DOT164=null;
        ScopedPromisesParser.name_return name165 = null;


        Tree IDENTIFIER163_tree=null;
        Tree DOT164_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:410:2: ( IDENTIFIER ( DOT name ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:411:4: IDENTIFIER ( DOT name )
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER163=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_name2155); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER163_tree = (Tree)adaptor.create(IDENTIFIER163);
            adaptor.addChild(root_0, IDENTIFIER163_tree);
            }
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:411:15: ( DOT name )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:411:16: DOT name
            {
            DOT164=(Token)match(input,DOT,FOLLOW_DOT_in_name2158); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            DOT164_tree = (Tree)adaptor.create(DOT164);
            adaptor.addChild(root_0, DOT164_tree);
            }
            pushFollow(FOLLOW_name_in_name2160);
            name165=name();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, name165.getTree());

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "name"

    // $ANTLR start synpred1_ScopedPromises
    public final void synpred1_ScopedPromises_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:136:5: ( constructorDeclPattern )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:136:6: constructorDeclPattern
        {
        pushFollow(FOLLOW_constructorDeclPattern_in_synpred1_ScopedPromises478);
        constructorDeclPattern();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_ScopedPromises

    // $ANTLR start synpred2_ScopedPromises
    public final void synpred2_ScopedPromises_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:138:5: ( noReturnMethodDeclPattern )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:138:6: noReturnMethodDeclPattern
        {
        pushFollow(FOLLOW_noReturnMethodDeclPattern_in_synpred2_ScopedPromises491);
        noReturnMethodDeclPattern();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_ScopedPromises

    // $ANTLR start synpred3_ScopedPromises
    public final void synpred3_ScopedPromises_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:139:5: ( fieldDeclPattern )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:139:6: fieldDeclPattern
        {
        pushFollow(FOLLOW_fieldDeclPattern_in_synpred3_ScopedPromises503);
        fieldDeclPattern();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred3_ScopedPromises

    // Delegated rules

    public final boolean synpred1_ScopedPromises() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_ScopedPromises_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_ScopedPromises() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_ScopedPromises_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred3_ScopedPromises() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred3_ScopedPromises_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA4 dfa4 = new DFA4(this);
    protected DFA5 dfa5 = new DFA5(this);
    protected DFA6 dfa6 = new DFA6(this);
    protected DFA7 dfa7 = new DFA7(this);
    protected DFA8 dfa8 = new DFA8(this);
    static final String DFA4_eotS =
        "\43\uffff";
    static final String DFA4_eofS =
        "\2\uffff\2\23\3\uffff\1\23\21\uffff\2\23\10\uffff";
    static final String DFA4_minS =
        "\2\65\2\63\1\uffff\1\65\1\105\1\64\12\uffff\1\105\1\uffff\1\65\4"+
        "\uffff\2\63\1\65\7\uffff";
    static final String DFA4_maxS =
        "\2\153\2\151\1\uffff\1\101\1\117\1\151\12\uffff\1\105\1\uffff\1"+
        "\153\4\uffff\2\151\1\101\7\uffff";
    static final String DFA4_acceptS =
        "\4\uffff\1\1\3\uffff\1\2\10\3\1\6\1\uffff\1\4\1\uffff\3\3\1\2\3"+
        "\uffff\1\5\4\2\1\1\1\2";
    static final String DFA4_specialS =
        "\1\5\1\7\1\0\1\1\1\uffff\1\10\1\uffff\1\3\14\uffff\1\2\4\uffff\1"+
        "\4\1\6\1\11\7\uffff}>";
    static final String[] DFA4_transitionS = {
            "\1\3\1\7\1\10\1\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20"+
            "\1\2\3\1\1\5\11\uffff\1\21\32\uffff\1\6\1\4",
            "\1\3\1\7\1\10\1\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1"+
            "\20\1\2\3\uffff\1\5\44\uffff\1\22\1\4",
            "\1\24\1\23\1\26\1\27\12\uffff\1\25\15\uffff\1\30\1\23\27\uffff"+
            "\2\23",
            "\1\24\1\23\1\26\1\27\12\uffff\1\25\15\uffff\1\30\1\23\27\uffff"+
            "\2\23",
            "",
            "\1\32\1\7\1\10\1\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1"+
            "\20\1\31",
            "\1\33\11\uffff\1\34",
            "\1\23\1\26\1\27\12\uffff\1\25\15\uffff\1\30\1\23\27\uffff\2"+
            "\23",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\33",
            "",
            "\1\36\1\37\1\40\11\uffff\1\35\51\uffff\1\41",
            "",
            "",
            "",
            "",
            "\1\42\1\23\1\26\1\27\12\uffff\1\25\15\uffff\1\30\1\23\27\uffff"+
            "\2\23",
            "\1\42\1\23\1\26\1\27\12\uffff\1\25\15\uffff\1\30\1\23\27\uffff"+
            "\2\23",
            "\1\32\1\7\1\10\1\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1"+
            "\20\1\31",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA4_eot = DFA.unpackEncodedString(DFA4_eotS);
    static final short[] DFA4_eof = DFA.unpackEncodedString(DFA4_eofS);
    static final char[] DFA4_min = DFA.unpackEncodedStringToUnsignedChars(DFA4_minS);
    static final char[] DFA4_max = DFA.unpackEncodedStringToUnsignedChars(DFA4_maxS);
    static final short[] DFA4_accept = DFA.unpackEncodedString(DFA4_acceptS);
    static final short[] DFA4_special = DFA.unpackEncodedString(DFA4_specialS);
    static final short[][] DFA4_transition;

    static {
        int numStates = DFA4_transitionS.length;
        DFA4_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA4_transition[i] = DFA.unpackEncodedString(DFA4_transitionS[i]);
        }
    }

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = DFA4_eot;
            this.eof = DFA4_eof;
            this.min = DFA4_min;
            this.max = DFA4_max;
            this.accept = DFA4_accept;
            this.special = DFA4_special;
            this.transition = DFA4_transition;
        }
        public String getDescription() {
            return "135:1: baseTarget : ( ( constructorDeclPattern )=> constructorDeclPattern | ( noReturnMethodDeclPattern )=> noReturnMethodDeclPattern | ( fieldDeclPattern )=> fieldDeclPattern | typeDeclPattern | '!' '(' promiseTarget ')' -> ^( NotTarget promiseTarget ) | '(' promiseTarget ')' -> promiseTarget );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA4_2 = input.LA(1);

                         
                        int index4_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_2==EOF||LA4_2==IN||LA4_2==RPAREN||(LA4_2>=104 && LA4_2<=105)) ) {s = 19;}

                        else if ( (LA4_2==DOT) ) {s = 20;}

                        else if ( (LA4_2==WildcardIdentifier) && (synpred3_ScopedPromises())) {s = 21;}

                        else if ( (LA4_2==IDENTIFIER) && (synpred3_ScopedPromises())) {s = 22;}

                        else if ( (LA4_2==STAR) && (synpred3_ScopedPromises())) {s = 23;}

                        else if ( (LA4_2==LPAREN) && (synpred2_ScopedPromises())) {s = 24;}

                         
                        input.seek(index4_2);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA4_3 = input.LA(1);

                         
                        int index4_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_3==EOF||LA4_3==IN||LA4_3==RPAREN||(LA4_3>=104 && LA4_3<=105)) ) {s = 19;}

                        else if ( (LA4_3==LPAREN) && (synpred2_ScopedPromises())) {s = 24;}

                        else if ( (LA4_3==DOT) ) {s = 20;}

                        else if ( (LA4_3==WildcardIdentifier) && (synpred3_ScopedPromises())) {s = 21;}

                        else if ( (LA4_3==IDENTIFIER) && (synpred3_ScopedPromises())) {s = 22;}

                        else if ( (LA4_3==STAR) && (synpred3_ScopedPromises())) {s = 23;}

                         
                        input.seek(index4_3);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA4_20 = input.LA(1);

                         
                        int index4_20 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_20==WildcardIdentifier) && (synpred2_ScopedPromises())) {s = 29;}

                        else if ( (LA4_20==IDENTIFIER) && (synpred2_ScopedPromises())) {s = 30;}

                        else if ( (LA4_20==STAR) && (synpred2_ScopedPromises())) {s = 31;}

                        else if ( (LA4_20==DSTAR) && (synpred2_ScopedPromises())) {s = 32;}

                        else if ( (LA4_20==107) && (synpred1_ScopedPromises())) {s = 33;}

                         
                        input.seek(index4_20);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA4_7 = input.LA(1);

                         
                        int index4_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_7==WildcardIdentifier) && (synpred3_ScopedPromises())) {s = 21;}

                        else if ( (LA4_7==IDENTIFIER) && (synpred3_ScopedPromises())) {s = 22;}

                        else if ( (LA4_7==STAR) && (synpred3_ScopedPromises())) {s = 23;}

                        else if ( (LA4_7==EOF||LA4_7==IN||LA4_7==RPAREN||(LA4_7>=104 && LA4_7<=105)) ) {s = 19;}

                        else if ( (LA4_7==LPAREN) && (synpred2_ScopedPromises())) {s = 24;}

                         
                        input.seek(index4_7);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA4_25 = input.LA(1);

                         
                        int index4_25 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_25==EOF||LA4_25==IN||LA4_25==RPAREN||(LA4_25>=104 && LA4_25<=105)) ) {s = 19;}

                        else if ( (LA4_25==DOT) && (synpred2_ScopedPromises())) {s = 34;}

                        else if ( (LA4_25==LPAREN) && (synpred2_ScopedPromises())) {s = 24;}

                        else if ( (LA4_25==WildcardIdentifier) && (synpred3_ScopedPromises())) {s = 21;}

                        else if ( (LA4_25==IDENTIFIER) && (synpred3_ScopedPromises())) {s = 22;}

                        else if ( (LA4_25==STAR) && (synpred3_ScopedPromises())) {s = 23;}

                         
                        input.seek(index4_25);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA4_0 = input.LA(1);

                         
                        int index4_0 = input.index();
                        input.rewind();
                        s = -1;
                        if ( ((LA4_0>=PUBLIC && LA4_0<=PRIVATE)) ) {s = 1;}

                        else if ( (LA4_0==WildcardIdentifier) ) {s = 2;}

                        else if ( (LA4_0==IDENTIFIER) ) {s = 3;}

                        else if ( (LA4_0==107) && (synpred1_ScopedPromises())) {s = 4;}

                        else if ( (LA4_0==STATIC) ) {s = 5;}

                        else if ( (LA4_0==106) ) {s = 6;}

                        else if ( (LA4_0==STAR) ) {s = 7;}

                        else if ( (LA4_0==DSTAR) && (synpred2_ScopedPromises())) {s = 8;}

                        else if ( (LA4_0==BOOLEAN) && (synpred3_ScopedPromises())) {s = 9;}

                        else if ( (LA4_0==BYTE) && (synpred3_ScopedPromises())) {s = 10;}

                        else if ( (LA4_0==CHAR) && (synpred3_ScopedPromises())) {s = 11;}

                        else if ( (LA4_0==SHORT) && (synpred3_ScopedPromises())) {s = 12;}

                        else if ( (LA4_0==INT) && (synpred3_ScopedPromises())) {s = 13;}

                        else if ( (LA4_0==FLOAT) && (synpred3_ScopedPromises())) {s = 14;}

                        else if ( (LA4_0==DOUBLE) && (synpred3_ScopedPromises())) {s = 15;}

                        else if ( (LA4_0==LONG) && (synpred3_ScopedPromises())) {s = 16;}

                        else if ( (LA4_0==LPAREN) ) {s = 17;}

                         
                        input.seek(index4_0);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA4_26 = input.LA(1);

                         
                        int index4_26 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_26==EOF||LA4_26==IN||LA4_26==RPAREN||(LA4_26>=104 && LA4_26<=105)) ) {s = 19;}

                        else if ( (LA4_26==LPAREN) && (synpred2_ScopedPromises())) {s = 24;}

                        else if ( (LA4_26==WildcardIdentifier) && (synpred3_ScopedPromises())) {s = 21;}

                        else if ( (LA4_26==IDENTIFIER) && (synpred3_ScopedPromises())) {s = 22;}

                        else if ( (LA4_26==STAR) && (synpred3_ScopedPromises())) {s = 23;}

                        else if ( (LA4_26==DOT) && (synpred2_ScopedPromises())) {s = 34;}

                         
                        input.seek(index4_26);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA4_1 = input.LA(1);

                         
                        int index4_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_1==STATIC) ) {s = 5;}

                        else if ( (LA4_1==106) ) {s = 18;}

                        else if ( (LA4_1==WildcardIdentifier) ) {s = 2;}

                        else if ( (LA4_1==IDENTIFIER) ) {s = 3;}

                        else if ( (LA4_1==STAR) ) {s = 7;}

                        else if ( (LA4_1==107) && (synpred1_ScopedPromises())) {s = 4;}

                        else if ( (LA4_1==BOOLEAN) && (synpred3_ScopedPromises())) {s = 9;}

                        else if ( (LA4_1==BYTE) && (synpred3_ScopedPromises())) {s = 10;}

                        else if ( (LA4_1==CHAR) && (synpred3_ScopedPromises())) {s = 11;}

                        else if ( (LA4_1==SHORT) && (synpred3_ScopedPromises())) {s = 12;}

                        else if ( (LA4_1==INT) && (synpred3_ScopedPromises())) {s = 13;}

                        else if ( (LA4_1==FLOAT) && (synpred3_ScopedPromises())) {s = 14;}

                        else if ( (LA4_1==DOUBLE) && (synpred3_ScopedPromises())) {s = 15;}

                        else if ( (LA4_1==LONG) && (synpred3_ScopedPromises())) {s = 16;}

                        else if ( (LA4_1==DSTAR) && (synpred2_ScopedPromises())) {s = 8;}

                         
                        input.seek(index4_1);
                        if ( s>=0 ) return s;
                        break;
                    case 8 : 
                        int LA4_5 = input.LA(1);

                         
                        int index4_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_5==WildcardIdentifier) ) {s = 25;}

                        else if ( (LA4_5==IDENTIFIER) ) {s = 26;}

                        else if ( (LA4_5==STAR) ) {s = 7;}

                        else if ( (LA4_5==BOOLEAN) && (synpred3_ScopedPromises())) {s = 9;}

                        else if ( (LA4_5==BYTE) && (synpred3_ScopedPromises())) {s = 10;}

                        else if ( (LA4_5==CHAR) && (synpred3_ScopedPromises())) {s = 11;}

                        else if ( (LA4_5==SHORT) && (synpred3_ScopedPromises())) {s = 12;}

                        else if ( (LA4_5==INT) && (synpred3_ScopedPromises())) {s = 13;}

                        else if ( (LA4_5==FLOAT) && (synpred3_ScopedPromises())) {s = 14;}

                        else if ( (LA4_5==DOUBLE) && (synpred3_ScopedPromises())) {s = 15;}

                        else if ( (LA4_5==LONG) && (synpred3_ScopedPromises())) {s = 16;}

                        else if ( (LA4_5==DSTAR) && (synpred2_ScopedPromises())) {s = 8;}

                         
                        input.seek(index4_5);
                        if ( s>=0 ) return s;
                        break;
                    case 9 : 
                        int LA4_27 = input.LA(1);

                         
                        int index4_27 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA4_27==WildcardIdentifier) ) {s = 25;}

                        else if ( (LA4_27==IDENTIFIER) ) {s = 26;}

                        else if ( (LA4_27==STAR) ) {s = 7;}

                        else if ( (LA4_27==DSTAR) && (synpred2_ScopedPromises())) {s = 8;}

                        else if ( (LA4_27==BOOLEAN) && (synpred3_ScopedPromises())) {s = 9;}

                        else if ( (LA4_27==BYTE) && (synpred3_ScopedPromises())) {s = 10;}

                        else if ( (LA4_27==CHAR) && (synpred3_ScopedPromises())) {s = 11;}

                        else if ( (LA4_27==SHORT) && (synpred3_ScopedPromises())) {s = 12;}

                        else if ( (LA4_27==INT) && (synpred3_ScopedPromises())) {s = 13;}

                        else if ( (LA4_27==FLOAT) && (synpred3_ScopedPromises())) {s = 14;}

                        else if ( (LA4_27==DOUBLE) && (synpred3_ScopedPromises())) {s = 15;}

                        else if ( (LA4_27==LONG) && (synpred3_ScopedPromises())) {s = 16;}

                         
                        input.seek(index4_27);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 4, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA5_eotS =
        "\45\uffff";
    static final String DFA5_eofS =
        "\5\uffff\1\2\15\uffff\1\2\1\uffff\1\2\17\uffff";
    static final String DFA5_minS =
        "\2\65\1\uffff\1\117\1\65\1\64\13\120\1\63\1\uffff\1\64\1\65\1\64"+
        "\1\65\12\120\2\63\1\65\1\63";
    static final String DFA5_maxS =
        "\2\153\1\uffff\1\117\1\120\1\151\1\120\13\125\1\uffff\1\151\1\101"+
        "\1\151\1\65\14\125\1\65\1\125";
    static final String DFA5_acceptS =
        "\2\uffff\1\1\17\uffff\1\2\22\uffff";
    static final String DFA5_specialS =
        "\45\uffff}>";
    static final String[] DFA5_transitionS = {
            "\1\2\13\uffff\1\2\3\1\46\uffff\1\3",
            "\1\2\13\uffff\1\2\51\uffff\1\3",
            "",
            "\1\4",
            "\1\21\1\17\1\6\1\uffff\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1"+
            "\16\1\20\16\uffff\1\5",
            "\1\22\33\uffff\1\2\27\uffff\2\2",
            "\1\23",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\26\34\uffff\1\25\4\uffff\1\24",
            "",
            "\1\22\33\uffff\1\2\27\uffff\2\2",
            "\1\41\1\37\2\uffff\1\27\1\30\1\31\1\32\1\33\1\34\1\35\1\36"+
            "\1\40",
            "\1\22\33\uffff\1\2\27\uffff\2\2",
            "\1\42",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\25\4\uffff\1\24",
            "\1\43\34\uffff\1\25\4\uffff\1\24",
            "\1\26\34\uffff\1\25\4\uffff\1\24",
            "\1\44",
            "\1\43\34\uffff\1\25\4\uffff\1\24"
    };

    static final short[] DFA5_eot = DFA.unpackEncodedString(DFA5_eotS);
    static final short[] DFA5_eof = DFA.unpackEncodedString(DFA5_eofS);
    static final char[] DFA5_min = DFA.unpackEncodedStringToUnsignedChars(DFA5_minS);
    static final char[] DFA5_max = DFA.unpackEncodedStringToUnsignedChars(DFA5_maxS);
    static final short[] DFA5_accept = DFA.unpackEncodedString(DFA5_acceptS);
    static final short[] DFA5_special = DFA.unpackEncodedString(DFA5_specialS);
    static final short[][] DFA5_transition;

    static {
        int numStates = DFA5_transitionS.length;
        DFA5_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA5_transition[i] = DFA.unpackEncodedString(DFA5_transitionS[i]);
        }
    }

    class DFA5 extends DFA {

        public DFA5(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 5;
            this.eot = DFA5_eot;
            this.eof = DFA5_eof;
            this.min = DFA5_min;
            this.max = DFA5_max;
            this.accept = DFA5_accept;
            this.special = DFA5_special;
            this.transition = DFA5_transition;
        }
        public String getDescription() {
            return "145:1: constructorDeclPattern : ( accessModPattern typeQualifierPattern 'new' methodSigPattern -> ^( ConstructorDeclPattern accessModPattern typeQualifierPattern ^( InPattern ) methodSigPattern ) | accessModPattern 'new' methodSigPattern inPattern -> ^( ConstructorDeclPattern accessModPattern ^( TypeQualifierPattern ) inPattern methodSigPattern ^( Throws ) ) );";
        }
    }
    static final String DFA6_eotS =
        "\47\uffff";
    static final String DFA6_eofS =
        "\7\uffff\1\6\15\uffff\1\6\1\uffff\1\6\17\uffff";
    static final String DFA6_minS =
        "\1\65\2\63\2\117\1\65\1\uffff\1\64\13\120\1\63\1\uffff\1\64\1\65"+
        "\1\64\1\65\12\120\2\63\1\65\1\63";
    static final String DFA6_maxS =
        "\1\101\4\117\1\120\1\uffff\1\151\1\120\13\125\1\uffff\1\151\1\101"+
        "\1\151\1\65\14\125\1\65\1\125";
    static final String DFA6_acceptS =
        "\6\uffff\1\1\15\uffff\1\2\22\uffff";
    static final String DFA6_specialS =
        "\47\uffff}>";
    static final String[] DFA6_transitionS = {
            "\1\2\1\3\1\4\11\uffff\1\1",
            "\1\6\33\uffff\1\5",
            "\1\6\33\uffff\1\5",
            "\1\5",
            "\1\5",
            "\1\23\1\21\1\10\1\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17"+
            "\1\20\1\22\16\uffff\1\7",
            "",
            "\1\24\33\uffff\1\6\27\uffff\2\6",
            "\1\25",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\30\34\uffff\1\27\4\uffff\1\26",
            "",
            "\1\24\33\uffff\1\6\27\uffff\2\6",
            "\1\43\1\41\2\uffff\1\31\1\32\1\33\1\34\1\35\1\36\1\37\1\40"+
            "\1\42",
            "\1\24\33\uffff\1\6\27\uffff\2\6",
            "\1\44",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\27\4\uffff\1\26",
            "\1\45\34\uffff\1\27\4\uffff\1\26",
            "\1\30\34\uffff\1\27\4\uffff\1\26",
            "\1\46",
            "\1\45\34\uffff\1\27\4\uffff\1\26"
    };

    static final short[] DFA6_eot = DFA.unpackEncodedString(DFA6_eotS);
    static final short[] DFA6_eof = DFA.unpackEncodedString(DFA6_eofS);
    static final char[] DFA6_min = DFA.unpackEncodedStringToUnsignedChars(DFA6_minS);
    static final char[] DFA6_max = DFA.unpackEncodedStringToUnsignedChars(DFA6_maxS);
    static final short[] DFA6_accept = DFA.unpackEncodedString(DFA6_acceptS);
    static final short[] DFA6_special = DFA.unpackEncodedString(DFA6_specialS);
    static final short[][] DFA6_transition;

    static {
        int numStates = DFA6_transitionS.length;
        DFA6_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA6_transition[i] = DFA.unpackEncodedString(DFA6_transitionS[i]);
        }
    }

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = DFA6_eot;
            this.eof = DFA6_eof;
            this.min = DFA6_min;
            this.max = DFA6_max;
            this.accept = DFA6_accept;
            this.special = DFA6_special;
            this.transition = DFA6_transition;
        }
        public String getDescription() {
            return "158:1: methodMatchPattern : ( typeQualifierPattern methodNamePattern methodSigPattern -> typeQualifierPattern ^( InPattern ) methodNamePattern methodSigPattern | methodNamePattern methodSigPattern inPattern -> ^( TypeQualifierPattern ) inPattern methodNamePattern methodSigPattern );";
        }
    }
    static final String DFA7_eotS =
        "\25\uffff";
    static final String DFA7_eofS =
        "\20\uffff\3\24\2\uffff";
    static final String DFA7_minS =
        "\3\65\1\105\14\65\2\63\1\64\2\uffff";
    static final String DFA7_maxS =
        "\2\152\1\101\1\105\14\101\3\151\2\uffff";
    static final String DFA7_acceptS =
        "\23\uffff\1\2\1\1";
    static final String DFA7_specialS =
        "\25\uffff}>";
    static final String[] DFA7_transitionS = {
            "\1\16\1\14\2\uffff\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\15"+
            "\3\1\1\2\44\uffff\1\3",
            "\1\16\1\14\2\uffff\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\15"+
            "\3\uffff\1\2\44\uffff\1\3",
            "\1\16\1\14\2\uffff\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\15",
            "\1\17",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\21\1\22\12\uffff\1\20",
            "\1\16\1\14\2\uffff\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\15",
            "\1\24\1\23\33\uffff\1\24\27\uffff\2\24",
            "\1\24\1\23\33\uffff\1\24\27\uffff\2\24",
            "\1\23\33\uffff\1\24\27\uffff\2\24",
            "",
            ""
    };

    static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
    static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
    static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
    static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
    static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
    static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
    static final short[][] DFA7_transition;

    static {
        int numStates = DFA7_transitionS.length;
        DFA7_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
        }
    }

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA7_eot;
            this.eof = DFA7_eof;
            this.min = DFA7_min;
            this.max = DFA7_max;
            this.accept = DFA7_accept;
            this.special = DFA7_special;
            this.transition = DFA7_transition;
        }
        public String getDescription() {
            return "173:1: fieldDeclPattern : ( modifierPattern typeSigPattern typeQualifierPattern fieldNamePattern -> ^( FieldDeclPattern modifierPattern typeSigPattern typeQualifierPattern ^( InPattern ) fieldNamePattern ) | modifierPattern typeSigPattern fieldNamePattern inPattern -> ^( FieldDeclPattern modifierPattern typeSigPattern ^( TypeQualifierPattern ) inPattern fieldNamePattern ) );";
        }
    }
    static final String DFA8_eotS =
        "\12\uffff";
    static final String DFA8_eofS =
        "\4\uffff\3\11\3\uffff";
    static final String DFA8_minS =
        "\3\65\1\105\3\64\1\65\2\uffff";
    static final String DFA8_maxS =
        "\2\152\1\101\1\105\3\151\1\101\2\uffff";
    static final String DFA8_acceptS =
        "\10\uffff\1\2\1\1";
    static final String DFA8_specialS =
        "\12\uffff}>";
    static final String[] DFA8_transitionS = {
            "\1\5\1\6\12\uffff\1\4\3\1\1\2\44\uffff\1\3",
            "\1\5\1\6\12\uffff\1\4\3\uffff\1\2\44\uffff\1\3",
            "\1\5\1\6\12\uffff\1\4",
            "\1\7",
            "\1\10\33\uffff\1\11\27\uffff\2\11",
            "\1\10\33\uffff\1\11\27\uffff\2\11",
            "\1\10\33\uffff\1\11\27\uffff\2\11",
            "\1\5\1\6\12\uffff\1\4",
            "",
            ""
    };

    static final short[] DFA8_eot = DFA.unpackEncodedString(DFA8_eotS);
    static final short[] DFA8_eof = DFA.unpackEncodedString(DFA8_eofS);
    static final char[] DFA8_min = DFA.unpackEncodedStringToUnsignedChars(DFA8_minS);
    static final char[] DFA8_max = DFA.unpackEncodedStringToUnsignedChars(DFA8_maxS);
    static final short[] DFA8_accept = DFA.unpackEncodedString(DFA8_acceptS);
    static final short[] DFA8_special = DFA.unpackEncodedString(DFA8_specialS);
    static final short[][] DFA8_transition;

    static {
        int numStates = DFA8_transitionS.length;
        DFA8_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA8_transition[i] = DFA.unpackEncodedString(DFA8_transitionS[i]);
        }
    }

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = DFA8_eot;
            this.eof = DFA8_eof;
            this.min = DFA8_min;
            this.max = DFA8_max;
            this.accept = DFA8_accept;
            this.special = DFA8_special;
            this.transition = DFA8_transition;
        }
        public String getDescription() {
            return "184:1: typeDeclPattern : ( modifierPattern optQualifiedTypeNamePattern -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern ^( InPattern ) ) | modifierPattern optQualifiedTypeNamePattern inPattern -> ^( TypeDeclPattern modifierPattern optQualifiedTypeNamePattern inPattern ) );";
        }
    }
 

    public static final BitSet FOLLOW_promiseString_in_scopedPromise308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_promiseString_in_scopedPromise326 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_FOR_in_scopedPromise328 = new BitSet(new long[]{0x0020000000000000L,0x00000C000000803EL});
    public static final BitSet FOLLOW_promiseTarget_in_scopedPromise330 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_promiseString0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_andTarget_in_promiseTarget379 = new BitSet(new long[]{0x0000000000000002L,0x0000010000000000L});
    public static final BitSet FOLLOW_104_in_promiseTarget392 = new BitSet(new long[]{0x0020000000000000L,0x00000C000000803EL});
    public static final BitSet FOLLOW_andTarget_in_promiseTarget396 = new BitSet(new long[]{0x0000000000000002L,0x0000010000000000L});
    public static final BitSet FOLLOW_baseTarget_in_andTarget427 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
    public static final BitSet FOLLOW_105_in_andTarget440 = new BitSet(new long[]{0x0020000000000000L,0x00000C000000803EL});
    public static final BitSet FOLLOW_baseTarget_in_andTarget444 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
    public static final BitSet FOLLOW_constructorDeclPattern_in_baseTarget483 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_noReturnMethodDeclPattern_in_baseTarget496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldDeclPattern_in_baseTarget508 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeDeclPattern_in_baseTarget514 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_106_in_baseTarget520 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LPAREN_in_baseTarget522 = new BitSet(new long[]{0x0020000000000000L,0x00000C000000803EL});
    public static final BitSet FOLLOW_promiseTarget_in_baseTarget524 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_baseTarget526 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_baseTarget540 = new BitSet(new long[]{0x0020000000000000L,0x00000C000000803EL});
    public static final BitSet FOLLOW_promiseTarget_in_baseTarget542 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_baseTarget544 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_accessModPattern_in_constructorDeclPattern564 = new BitSet(new long[]{0x0020000000000000L,0x0000080000000002L});
    public static final BitSet FOLLOW_typeQualifierPattern_in_constructorDeclPattern566 = new BitSet(new long[]{0x0000000000000000L,0x0000080000000000L});
    public static final BitSet FOLLOW_107_in_constructorDeclPattern568 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_methodSigPattern_in_constructorDeclPattern570 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_accessModPattern_in_constructorDeclPattern596 = new BitSet(new long[]{0x0000000000000000L,0x0000080000000000L});
    public static final BitSet FOLLOW_107_in_constructorDeclPattern598 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_methodSigPattern_in_constructorDeclPattern600 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_inPattern_in_constructorDeclPattern602 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeQualifierPattern_in_methodMatchPattern641 = new BitSet(new long[]{0x00E0000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_methodNamePattern_in_methodMatchPattern643 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_methodSigPattern_in_methodMatchPattern645 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_methodNamePattern_in_methodMatchPattern664 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_methodSigPattern_in_methodMatchPattern666 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_inPattern_in_methodMatchPattern668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifierPattern_in_methodDeclPattern693 = new BitSet(new long[]{0xFF60000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_returnTypeSigPattern_in_methodDeclPattern695 = new BitSet(new long[]{0x00E0000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_methodMatchPattern_in_methodDeclPattern697 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifierPattern_in_noReturnMethodDeclPattern726 = new BitSet(new long[]{0x00E0000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_methodMatchPattern_in_noReturnMethodDeclPattern728 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifierPattern_in_fieldDeclPattern761 = new BitSet(new long[]{0xFF60000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_typeSigPattern_in_fieldDeclPattern763 = new BitSet(new long[]{0x0060000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_typeQualifierPattern_in_fieldDeclPattern765 = new BitSet(new long[]{0x0060000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_fieldNamePattern_in_fieldDeclPattern767 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifierPattern_in_fieldDeclPattern795 = new BitSet(new long[]{0xFF60000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_typeSigPattern_in_fieldDeclPattern797 = new BitSet(new long[]{0x0060000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_fieldNamePattern_in_fieldDeclPattern800 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_inPattern_in_fieldDeclPattern802 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifierPattern_in_typeDeclPattern843 = new BitSet(new long[]{0x0060000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_optQualifiedTypeNamePattern_in_typeDeclPattern845 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_modifierPattern_in_typeDeclPattern869 = new BitSet(new long[]{0x0060000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_optQualifiedTypeNamePattern_in_typeDeclPattern871 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_inPattern_in_typeDeclPattern873 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeNamePattern_in_typeQualifierPattern902 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_typeQualifierPattern904 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_methodNamePattern_in_wildcardTypeQualifierPattern936 = new BitSet(new long[]{0x0008000000000002L});
    public static final BitSet FOLLOW_DOT_in_wildcardTypeQualifierPattern939 = new BitSet(new long[]{0x00E0000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_methodNamePattern_in_wildcardTypeQualifierPattern941 = new BitSet(new long[]{0x0008000000000002L});
    public static final BitSet FOLLOW_DOT_in_wildcardTypeQualifierPattern947 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IN_in_inPattern981 = new BitSet(new long[]{0x00E0000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_wildcardTypeQualifierPattern_in_inPattern983 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_inPackagePattern_in_inPattern985 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IN_in_inPattern1001 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LPAREN_in_inPattern1003 = new BitSet(new long[]{0x00E0000000000000L,0x0000040000008002L});
    public static final BitSet FOLLOW_inTypePattern_in_inPattern1005 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_inPattern1007 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_inPackagePattern_in_inPattern1009 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_inAndPattern_in_inTypePattern1036 = new BitSet(new long[]{0x0000000000000002L,0x0000010000000000L});
    public static final BitSet FOLLOW_104_in_inTypePattern1045 = new BitSet(new long[]{0x00E0000000000000L,0x0000040000008002L});
    public static final BitSet FOLLOW_inAndPattern_in_inTypePattern1049 = new BitSet(new long[]{0x0000000000000002L,0x0000010000000000L});
    public static final BitSet FOLLOW_inBasePattern_in_inAndPattern1078 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
    public static final BitSet FOLLOW_105_in_inAndPattern1086 = new BitSet(new long[]{0x00E0000000000000L,0x0000040000008002L});
    public static final BitSet FOLLOW_inBasePattern_in_inAndPattern1090 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
    public static final BitSet FOLLOW_wildcardTypeQualifierPattern_in_inBasePattern1119 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_106_in_inBasePattern1125 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LPAREN_in_inBasePattern1127 = new BitSet(new long[]{0x00E0000000000000L,0x0000040000008002L});
    public static final BitSet FOLLOW_inTypePattern_in_inBasePattern1129 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_inBasePattern1131 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_inBasePattern1145 = new BitSet(new long[]{0x00E0000000000000L,0x0000040000008002L});
    public static final BitSet FOLLOW_inTypePattern_in_inBasePattern1147 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_inBasePattern1149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IN_in_inPackagePattern1168 = new BitSet(new long[]{0x00E0000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_wildcardTypeQualifierPattern_in_inPackagePattern1170 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IN_in_inPackagePattern1183 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LPAREN_in_inPackagePattern1185 = new BitSet(new long[]{0x00E0000000000000L,0x0000040000008002L});
    public static final BitSet FOLLOW_inTypePattern_in_inPackagePattern1187 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_inPackagePattern1189 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_wildcardIdentifier_in_methodNamePattern1224 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_methodNamePattern1230 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STAR_in_methodNamePattern1236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DSTAR_in_methodNamePattern1242 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_methodSigPattern1257 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_methodSigPattern1259 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_methodSigPattern1271 = new BitSet(new long[]{0xFF60000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_paramTypeSigPattern_in_methodSigPattern1273 = new BitSet(new long[]{0x0000000000000000L,0x0000000000210000L});
    public static final BitSet FOLLOW_COMMA_in_methodSigPattern1276 = new BitSet(new long[]{0xFF60000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_paramTypeSigPattern_in_methodSigPattern1278 = new BitSet(new long[]{0x0000000000000000L,0x0000000000210000L});
    public static final BitSet FOLLOW_RPAREN_in_methodSigPattern1282 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_methodSigPattern1297 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_DSTAR_in_methodSigPattern1299 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_RPAREN_in_methodSigPattern1301 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeSigPattern_in_paramTypeSigPattern1328 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedName_in_paramTypeSigPattern1334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VOID_in_returnTypeSigPattern1357 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeSigPattern_in_returnTypeSigPattern1361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BOOLEAN_in_typeSigPattern1376 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BYTE_in_typeSigPattern1388 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CHAR_in_typeSigPattern1400 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SHORT_in_typeSigPattern1412 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INT_in_typeSigPattern1424 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOAT_in_typeSigPattern1436 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOUBLE_in_typeSigPattern1448 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LONG_in_typeSigPattern1460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STAR_in_typeSigPattern1472 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedTypePattern_in_typeSigPattern1486 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_wildcardIdentifier_in_fieldNamePattern1500 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fieldNamePattern1506 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STAR_in_fieldNamePattern1512 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeNamePattern_in_optQualifiedTypeNamePattern1529 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STAR_in_optQualifiedTypeNamePattern1535 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_wildcardIdentifier_in_namedTypePattern1548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_namedTypePattern1562 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_wildcardIdentifier_in_typeNamePattern1584 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_typeNamePattern1590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName1605 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedName1608 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName1610 = new BitSet(new long[]{0x0008000000000002L});
    public static final BitSet FOLLOW_namedType_in_namedTypes1625 = new BitSet(new long[]{0x0000000000000002L,0x0000000000200000L});
    public static final BitSet FOLLOW_COMMA_in_namedTypes1628 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_namedType_in_namedTypes1630 = new BitSet(new long[]{0x0000000000000002L,0x0000000000200000L});
    public static final BitSet FOLLOW_WildcardIdentifier_in_wildcardIdentifier1652 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_accessModPattern_in_modifierPattern1672 = new BitSet(new long[]{0x0000000000000002L,0x0000040000000020L});
    public static final BitSet FOLLOW_staticPattern_in_modifierPattern1674 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_accessModPattern1690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STATIC_in_staticPattern1716 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_106_in_staticPattern1723 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_STATIC_in_staticPattern1725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_qualifiedClassExpression1750 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedClassExpression1752 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_CLASS_in_qualifiedClassExpression1754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_qualifiedThisExpression1775 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedThisExpression1777 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_THIS_in_qualifiedThisExpression1779 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_typeExpression1800 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedFieldRef_in_fieldRef1820 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleFieldRef_in_fieldRef1826 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeExpression_in_qualifiedFieldRef1838 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedFieldRef1840 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedFieldRef1842 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_namedType1865 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_typeName1893 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedTypeName_in_typeName1900 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedTypeName1918 = new BitSet(new long[]{0x0008000000000002L});
    public static final BitSet FOLLOW_DOT_in_qualifiedTypeName1939 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedTypeName1941 = new BitSet(new long[]{0x0008000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_simpleFieldRef1971 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_simpleFieldRef1973 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleFieldRef1975 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleFieldRef1991 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_simpleExpression2022 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_varUse_in_simpleExpression2028 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_varUse2043 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_THIS_in_thisExpr2071 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EOF_in_nothing2100 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_accessModifiers2122 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000020L});
    public static final BitSet FOLLOW_STATIC_in_accessModifiers2135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_name2155 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_DOT_in_name2158 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_name_in_name2160 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constructorDeclPattern_in_synpred1_ScopedPromises478 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_noReturnMethodDeclPattern_in_synpred2_ScopedPromises491 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldDeclPattern_in_synpred3_ScopedPromises503 = new BitSet(new long[]{0x0000000000000002L});

}
