package com.surelogic.annotation.parse;

import com.surelogic.aast.java.*;
import com.surelogic.aast.promise.*;
import com.surelogic.parse.*;

public class MoreFactoryRefs {
  public static void register(IASTFactory f) {
    QualifiedThisExpressionNode.factory.register(f);
    BooleanTypeNode.factory.register(f);
    ByteTypeNode.factory.register(f);
    CharTypeNode.factory.register(f);
    ShortTypeNode.factory.register(f);
    IntTypeNode.factory.register(f);
    FloatTypeNode.factory.register(f);
    DoubleTypeNode.factory.register(f);
    LongTypeNode.factory.register(f);
    NamedTypeNode.factory.register(f);
    TypeRefNode.factory.register(f);
    ArrayTypeNode.factory.register(f);
    TypeQualifierPatternNode.factory.register(f);
    ThisExpressionNode.factory.register(f);
    SuperExpressionNode.factory.register(f);
    ReturnValueDeclarationNode.factory.register(f);
    FieldRefNode.factory.register(f);
    TypeExpressionNode.factory.register(f);
    VariableUseExpressionNode.factory.register(f);
    ClassExpressionNode.factory.register(f);
    ScopedPromiseNode.factory.register(f);
    AnyTargetNode.factory.register(f);
    AndTargetNode.factory.register(f);
    OrTargetNode.factory.register(f);
    NotTargetNode.factory.register(f);
    ConstructorDeclPatternNode.factory.register(f);
    MethodDeclPatternNode.factory.register(f);
    FieldDeclPatternNode.factory.register(f);
    TypeDeclPatternNode.factory.register(f);
    NamedTypePatternNode.factory.register(f);
    InPatternNode.factory.register(f);
    InPackagePatternNode.factory.register(f);
    InAndPatternNode.factory.register(f);
    InOrPatternNode.factory.register(f);
    InNotPatternNode.factory.register(f);
    WildcardTypeQualifierPatternNode.factory.register(f);
  }
}
