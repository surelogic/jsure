// Generated code.  Do *NOT* edit!
/**
 * Interface for resolving Java bindings and the like
 * <p>
 * Contains one resolve() method for each kind of name/call
 */
package com.surelogic.ast.java.operator;

import java.util.*;
import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

public interface IJavaBinder {
  /**
   * Gets the 'super-implementation' (a la Eclipse) for the method
   * @return The method declaration (possibly abstract) overridden in a superclass of 
   * this method's enclosing class, and otherwise null
   */
  public IMethodDeclarationNode getOverriddenMethod(IMethodDeclarationNode md);

  /**
   * Gets all of immediately overridden methods from super-classes and -interfaces
   * @return A list of all the methods overridden by this one
   */
  public List<IMethodDeclarationNode> getAllOverriddenMethods(IMethodDeclarationNode md);

  /**
   * Gets the 'super-implementation' (a la Eclipse) for the constructor
   * @return The concrete declaration of the superclass' constructor called by this one
   */
  public IConstructorDeclarationNode getSuperConstructor(IConstructorDeclarationNode cd);

  public boolean isSubtypeOf(ITypeDeclarationNode td, IType t);

  public boolean isCastCompatibleTo(ITypeDeclarationNode td, IType t);

  public boolean isAssignmentCompatibleTo(ITypeDeclarationNode td, IType t);

}
