// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "continue"
 *    id : Info (String)
 *    <semi>
 *    ";"
 * 
 */
public interface ILabeledContinueStatementNode extends ISomeContinueStatementNode { 
  public BaseNodeType getNodeType();
}

