// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

/**
 * Has each visit() method in INodeVisitor call the
 * corresponding method for its superinterface
 */
@SuppressWarnings("deprecation")
public class AbstractingPromiseVisitor<T> extends AbstractingBaseVisitor<T> implements IPromiseNodeVisitor<T> {
  public AbstractingPromiseVisitor(T defaultVal) {
    super(defaultVal);
  }

  public AbstractingPromiseVisitor() {
    super(null);
  }

  public T visit(IColorRenameNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IColorRequireNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IColorCardNNode n) {
    return visit((IColorCardChoiceNode) n);
  }
  public T visit(IColorAndParenNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IQualifiedRegionNameNode n) {
    return visit((IRegionSpecificationNode) n);
  }
  public T visit(IInitDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IEnclosingModuleNode n) {
    return visit((IModuleNode) n);
  }
  public T visit(ITaintedNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IStartsSpecificationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IAndTargetNode n) {
    return visit((IComplexTargetNode) n);
  }
  public T visit(IColorNameNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorDeclarationNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IConstructorDeclPatternNode n) {
    return visit((IPromiseTargetNode) n);
  }
  public T visit(IReturnValueDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorCard1Node n) {
    return visit((IColorCardChoiceNode) n);
  }
  public T visit(IColorAndNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IInvariantDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IScopedModuleNode n) {
    return visit((IModuleNode) n);
  }
  public T visit(IColorExprNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IModuleNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IComplexTargetNode n) {
    return visit((IPromiseTargetNode) n);
  }
  public T visit(ITransparentNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IFieldRegionSpecificationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IRegionDeclarationNode n) {
    return visit((IPromiseDeclarationNode) n);
  }
  public T visit(IAPINode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IRegionSpecificationNode n) {
    return visit((IFieldRegionSpecificationNode) n);
  }
  public T visit(IColorIncompatibleNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IColorOrElemNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColoringAnnotationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorSpecNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IRegionMappingNode n) {
    return visit((IRegionDeclarationNode) n);
  }
  public T visit(IColorRevokeNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(ISubtypedBySpecificationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ITargetedAnnotationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(INotTaintedNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IEffectSpecificationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorOrParenNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IIntOrNNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IPromiseTargetNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IFieldDeclPatternNode n) {
    return visit((IPromiseTargetNode) n);
  }
  public T visit(IColorConstrainedRegionsNode n) {
    return visit((IDataColoringAnnotationNode) n);
  }
  public T visit(IEffectsSpecificationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IMethodDeclPatternNode n) {
    return visit((IPromiseTargetNode) n);
  }
  public T visit(IColorOrNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ITypeDeclPatternNode n) {
    return visit((IPromiseTargetNode) n);
  }
  public T visit(IColorImportNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorCardChoiceNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IUsedBySpecificationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IOrTargetNode n) {
    return visit((IComplexTargetNode) n);
  }
  public T visit(IAnyInstanceExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(INewRegionDeclarationNode n) {
    return visit((IRegionDeclarationNode) n);
  }
  public T visit(IScopedPromiseNode n) {
    return visit((ITargetedAnnotationNode) n);
  }
  public T visit(ITypeQualifierPatternNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorGrantNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IColorContextNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IColorCardinalityNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IClassInitDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(INotTargetNode n) {
    return visit((IComplexTargetNode) n);
  }
  public T visit(IColorNoteNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IRegionNameNode n) {
    return visit((IRegionSpecificationNode) n);
  }
  public T visit(IFieldMappingsNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IConditionNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IPromiseDeclarationNode n) {
    return visit((IDeclarationNode) n);
  }
  public T visit(IColorNotNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IColorizedRegionNode n) {
    return visit((IDataColoringAnnotationNode) n);
  }
  public T visit(IReceiverDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IMappedRegionSpecificationNode n) {
    return visit((IFieldRegionSpecificationNode) n);
  }
  public T visit(IDataColoringAnnotationNode n) {
    return visit((IColoringAnnotationNode) n);
  }
  public T visit(IColorAndElemNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IQualifiedReceiverDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
}
