// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "="
 *    value : IInitializerNode
 * 
 */
public interface IInitializationNode extends IOptInitializationNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IInitializerNode getValue();
}

