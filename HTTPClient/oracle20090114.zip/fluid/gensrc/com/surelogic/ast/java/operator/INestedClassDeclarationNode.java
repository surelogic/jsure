// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    "class"
 *    id : Info (String)
 *    typesList : List<ITypeFormalNode>
 *    <?>
 *    "extends"
 *    extension : IClassTypeNode
 *    </?>
 *    implsList : List<IClassTypeNode>
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * 
 */
public interface INestedClassDeclarationNode extends IClassDeclarationNode, IClassBodyDeclarationNode, INestedTypeDeclarationNode, IDeclaredType { 
  public BaseNodeType getNodeType();
  public boolean isStatic();
  public boolean isAbstract();
  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isFinal();
  public boolean isStrictfp();
}

