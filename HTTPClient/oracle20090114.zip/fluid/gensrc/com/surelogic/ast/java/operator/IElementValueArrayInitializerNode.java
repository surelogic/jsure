// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "{"
 *    Zero or more of:
 *      valueList : List<IElementValueNode>
 *    Separated by:
 *      ","
 *    "}"
 * 
 */
public interface IElementValueArrayInitializerNode extends IElementValueNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IElementValueNode> getValueList();
}

