// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "@"
 *    id : Info (String)
 *    "("
 *    <paren>
 *    pairsList : List<IElementValuePairNode>
 *    </paren>
 *    ")"
 * 
 */
public interface INormalAnnotationNode extends IAnnotationNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IElementValuePairNode> getPairsList();
}

