// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

public interface IJavaOperatorNode {
  public int getOffset();
  public INodeType getNodeType();
  public String unparse(boolean debug);
  public String unparse(boolean debug, int indent);
  public <T> T accept(INodeVisitor<T> visitor);
  public IJavaOperatorNode getParent();
}
