// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * A very special form of call: legal only as the first statement expression
 * of a constructor.  The object must be "this" or "super".
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    typeArgsList : List<IReferenceTypeNode> or null
 *    object : IConstructionObjectNode
 *    argsList : List<IExpressionNode>
 * 
 * Binds this name to IConstructorBinding
 */
public interface IConstructorCallNode extends ISomeFunctionCallNode, IHasBinding { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IConstructorBinding resolveBinding();

  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IReferenceTypeNode> getTypeArgsList();
  /**
   * @return A non-null node
   */
  public IConstructionObjectNode getObject();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

