// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "continue"
 *    <>
 *    ";"
 * 
 */
public interface IContinueStatementNode extends ISomeContinueStatementNode { 
  public BaseNodeType getNodeType();
}

