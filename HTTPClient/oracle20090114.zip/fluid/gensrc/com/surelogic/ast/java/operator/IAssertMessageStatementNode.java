// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "assert"
 *    assertion : IExpressionNode
 *    ":"
 *    message : IExpressionNode
 *    <>
 *    ";"
 * 
 */
public interface IAssertMessageStatementNode extends ISomeAssertStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getAssertion();
  /**
   * @return A non-null node
   */
  public IExpressionNode getMessage();
}

