// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    op1 : IExpressionNode
 *    op : Op (com.surelogic.ast.AssignOperator)
 *    <>
 *    "="
 *    op2 : IExpressionNode
 * 
 */
public interface IOpAssignExpressionNode extends IAssignmentExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp1();
  /**
   * @return A non-null com.surelogic.ast.AssignOperator
   */
  public com.surelogic.ast.AssignOperator getOp();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp2();
}

