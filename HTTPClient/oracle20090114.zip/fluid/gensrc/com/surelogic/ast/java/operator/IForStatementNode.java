// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "for"
 *    "("
 *    <paren>
 *    init : IForInitNode
 *    <semi>
 *    ";"
 *    <li>
 *    cond : IExpressionNode
 *    <semi>
 *    ";"
 *    <li>
 *    update : IStatementExpressionListNode
 *    </paren>
 *    ")"
 *    <forloop>
 *    loop : IStatementNode
 *    </forloop>
 * 
 */
public interface IForStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IForInitNode getInit();
  /**
   * @return A non-null node
   */
  public IExpressionNode getCond();
  /**
   * @return A non-null node
   */
  public IStatementExpressionListNode getUpdate();
  /**
   * @return A non-null node
   */
  public IStatementNode getLoop();
}

