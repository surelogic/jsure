// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * The node inserted for implicit boxing of primitive values.
 * 
 * Syntax:
 *    op : IExpressionNode
 * 
 */
 public interface IBoxExpressionNode extends IUnopExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp();
}

