// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * use normal for loops and iterators instead.
 * No CFG.  Hard to analyze.
 * 
 * Syntax:
 *    "for"
 *    "("
 *    <paren>
 *    var : IParameterDeclarationNode
 *    ":"
 *    collection : IExpressionNode
 *    </paren>
 *    ")"
 *    <forloop>
 *    loop : IStatementNode
 *    </forloop>
 * 
 */
public interface IForEachStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IParameterDeclarationNode getVar();
  /**
   * @return A non-null node
   */
  public IExpressionNode getCollection();
  /**
   * @return A non-null node
   */
  public IStatementNode getLoop();
}

