// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 */
public interface IClassBodyDeclarationNode extends IDeclarationNode { 
  public BaseNodeType getNodeType();
}

