// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "null"
 * 
 * Binds to the type represented by INullTypeBinding
 */
public interface INullLiteralNode extends IRefLiteralNode, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the NullLiteral
   */
  public INullType resolveType();

}

