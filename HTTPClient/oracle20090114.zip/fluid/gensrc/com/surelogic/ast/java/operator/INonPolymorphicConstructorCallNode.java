// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * A very special form of call: legal only as the first statement expression
 * of a constructor.  The object must be "this" or "super".
 * 
 * Syntax:
 *    object : IConstructionObjectNode
 *    argsList : List<IExpressionNode>
 *    <>
 * 
 */
public interface INonPolymorphicConstructorCallNode extends IConstructorCallNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IConstructionObjectNode getObject();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

