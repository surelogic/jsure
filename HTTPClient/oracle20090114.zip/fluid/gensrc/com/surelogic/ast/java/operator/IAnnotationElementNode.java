// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    modifiers : Modifiers (int)
 *    type : ITypeNode
 *    id : Info (String)
 *    "()"
 *    value : IOptDefaultValueNode
 * 
 */
public interface IAnnotationElementNode extends IClassBodyDeclarationNode { 
  public BaseNodeType getNodeType();
  public boolean isPublic();
  public boolean isAbstract();
  /**
   * @return A non-null node
   */
  public ITypeNode getType();
  /**
   * @return A node, or null
   */
  public IDefaultValueNode getValue();
}

