// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * The class of variable initializers (including all expressions).
 * By default, any subexpressions are executed in order.
 * @see Expression
 * 
 * This is an abstract node (i.e., never instantiated)

 */
public interface IInitializerNode extends IJavaOperatorNode, IElementValueNode { 
}

