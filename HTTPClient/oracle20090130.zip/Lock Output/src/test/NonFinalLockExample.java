package test;

import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;

@RegionLock("L is this protects Instance")
public class NonFinalLockExample {
  private int val;
  
  @RequiresLock("L")
  public int get() {
    return val;
  }

  @RequiresLock("L")
  public void set(final int v) {
    val = v;
  }
  
  public static NonFinalLockExample getNF() {
    return new NonFinalLockExample();
  }
  
  public static void test() {
    NonFinalLockExample nf = new NonFinalLockExample();
    
    // Non-final lock acquisition
    synchronized (nf) {
      int x = nf.get();
      nf = new NonFinalLockExample();
      nf.set(x+1);
    }
    
    // Non-final lock acquisition
    synchronized (getNF()) {
      getNF().set(getNF().get()+1);
    }
  }
}
