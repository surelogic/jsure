package test;

import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;

@RegionLock("RL is this protects Instance")
public class RequiresLockExample {
  private int f;
  
  @RequiresLock("RL")
  public int get() { return f; }
  
  @RequiresLock("RL")
  public void set(final int v) { f = v; }
  
  public synchronized void doStuff() {
    //good
    set(
        // good
        get() + 10);
  }
  
  public void doMoreStuff(final int v) {
    synchronized (this) {
      // good
      set(v + 100);
    }
  }
  
  public int bad() {
    // bad
    return get();
  }
}
