package aggregate.fieldMustBeUnique;

import com.surelogic.Borrowed;

public class C {
  // Do nothing
  
  @Borrowed("this")
  public C() {
  	super();
  }
}
