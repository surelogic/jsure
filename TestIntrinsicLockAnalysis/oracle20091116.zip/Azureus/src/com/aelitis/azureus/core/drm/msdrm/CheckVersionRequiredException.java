package com.aelitis.azureus.core.drm.msdrm;

public class CheckVersionRequiredException extends Exception {
	
	public CheckVersionRequiredException(String message) {
		super(message);
	}

}
