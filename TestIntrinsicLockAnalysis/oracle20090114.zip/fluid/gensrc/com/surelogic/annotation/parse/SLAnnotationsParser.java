// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g 2008-09-25 15:48:48

package com.surelogic.annotation.parse;

import edu.cmu.cs.fluid.ir.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class SLAnnotationsParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "START_IMAGINARY", "TestResult", "LockDeclaration", "PolicyLockDeclaration", "QualifiedLockName", "RegionName", "QualifiedRegionName", "QualifiedClassLockExpression", "QualifiedThisExpression", "ImplicitClassLockExpression", "EffectSpecifications", "EffectSpecification", "RequiresLock", "ReturnsLock", "InRegion", "Aggregate", "RegionEffects", "Reads", "Writes", "IsLock", "BooleanType", "ByteType", "CharType", "ShortType", "IntType", "FloatType", "DoubleType", "LongType", "NamedType", "TypeRef", "ArrayType", "TypeQualifierPattern", "Annotations", "ThisExpression", "SuperExpression", "ReturnValueDeclaration", "FieldRef", "TypeExpression", "VariableUseExpression", "AnyInstanceExpression", "ClassExpression", "SimpleLockName", "LockNames", "StartsSpecification", "MappedRegionSpecification", "RegionMapping", "FieldMappings", "NewRegionDeclaration", "RegionSpecifications", "Nothing", "Expressions", "LockSpecifications", "ReadLock", "WriteLock", "ScopedPromise", "AndTarget", "OrTarget", "NotTarget", "ConstructorDeclPattern", "MethodDeclPattern", "FieldDeclPattern", "TypeDeclPattern", "NamedTypePattern", "Parameters", "Throws", "END_IMAGINARY", "LOCK", "LOCKS", "REQUIRESLOCK", "ISLOCK", "POLICYLOCK", "RETURNSLOCK", "INREGION", "MAPFIELDS", "MAPREGION", "AGGREGATE", "REGION", "READS", "WRITES", "PROTECTS", "NOTHING", "SUPER", "ANY", "IS", "INTO", "READ_LOCK", "WRITE_LOCK", "INSTANCE", "IDENTIFIER", "DOT", "CLASS", "EXTENDS", "LBRACKET", "RBRACKET", "THIS", "RETURN", "PUBLIC", "PROTECTED", "PRIVATE", "STATIC", "ABSTRACT", "BOOLEAN", "BREAK", "BYTE", "CASE", "CATCH", "CHAR", "CONST", "CONTINUE", "DEFAULT", "DO", "DOUBLE", "ELSE", "FALSE", "FINAL", "FINALLY", "FLOAT", "FOR", "GOTO", "IF", "IMPLEMENTS", "IMPORT", "INSTANCEOF", "INT", "INTERFACE", "LONG", "NATIVE", "NEW", "NULL", "ONLY", "PACKAGE", "SHORT", "SWITCH", "SYNCHRONIZED", "THROW", "THROWS", "TRANSIENT", "TRUE", "TRY", "VOID", "VOLATILE", "WHILE", "COLON", "SEMI", "AT", "LPAREN", "RPAREN", "QUOTE", "DQUOTE", "LBRACE", "RBRACE", "COMMA", "STAR", "DSTAR", "DASH", "LANGLE", "RANGLE", "EQUALS", "HexDigit", "IntegerTypeSuffix", "HexLiteral", "DecimalLiteral", "OctalLiteral", "Exponent", "FloatTypeSuffix", "FloatingPointLiteral", "EscapeSequence", "CharacterLiteral", "StringLiteral", "UnicodeEscape", "OctalEscape", "LETTER", "JavaIDDigit", "WS", "NEWLINE", "'&'", "'/*'", "'/**'", "'none'", "'reads'", "'writes'"
    };
    public static final int COMMA=155;
    public static final int CONST=111;
    public static final int InRegion=18;
    public static final int PolicyLockDeclaration=7;
    public static final int SYNCHRONIZED=137;
    public static final int HexDigit=162;
    public static final int DOUBLE=115;
    public static final int INTO=88;
    public static final int Throws=68;
    public static final int START_IMAGINARY=4;
    public static final int EffectSpecification=15;
    public static final int QualifiedLockName=8;
    public static final int FALSE=117;
    public static final int ImplicitClassLockExpression=13;
    public static final int RegionEffects=20;
    public static final int QualifiedClassLockExpression=11;
    public static final int FieldRef=40;
    public static final int ABSTRACT=104;
    public static final int READ_LOCK=89;
    public static final int IntType=28;
    public static final int NamedTypePattern=66;
    public static final int INSTANCE=91;
    public static final int QualifiedRegionName=10;
    public static final int MAPFIELDS=77;
    public static final int DQUOTE=152;
    public static final int IMPORT=125;
    public static final int PACKAGE=134;
    public static final int EffectSpecifications=14;
    public static final int CONTINUE=112;
    public static final int NEWLINE=178;
    public static final int DOT=93;
    public static final int PRIVATE=102;
    public static final int RANGLE=160;
    public static final int T__181=181;
    public static final int RequiresLock=16;
    public static final int POLICYLOCK=74;
    public static final int LOCKS=71;
    public static final int StartsSpecification=47;
    public static final int AndTarget=59;
    public static final int RBRACKET=97;
    public static final int FieldDeclPattern=64;
    public static final int RPAREN=150;
    public static final int LockSpecifications=55;
    public static final int LANGLE=159;
    public static final int LockDeclaration=6;
    public static final int WRITE_LOCK=90;
    public static final int Writes=22;
    public static final int VariableUseExpression=42;
    public static final int WRITES=82;
    public static final int FINALLY=119;
    public static final int FloatTypeSuffix=168;
    public static final int EXTENDS=95;
    public static final int AT=148;
    public static final int RegionSpecifications=52;
    public static final int IsLock=23;
    public static final int Expressions=54;
    public static final int MethodDeclPattern=63;
    public static final int SUPER=85;
    public static final int IntegerTypeSuffix=163;
    public static final int ClassExpression=44;
    public static final int WS=177;
    public static final int ConstructorDeclPattern=62;
    public static final int CHAR=110;
    public static final int SuperExpression=38;
    public static final int NEW=131;
    public static final int T__182=182;
    public static final int ReturnValueDeclaration=39;
    public static final int QualifiedThisExpression=12;
    public static final int FINAL=118;
    public static final int NamedType=32;
    public static final int TypeDeclPattern=65;
    public static final int ANY=86;
    public static final int SEMI=147;
    public static final int CATCH=109;
    public static final int STATIC=103;
    public static final int EQUALS=161;
    public static final int CASE=108;
    public static final int FloatType=29;
    public static final int UnicodeEscape=173;
    public static final int INTERFACE=128;
    public static final int HexLiteral=164;
    public static final int BOOLEAN=105;
    public static final int OrTarget=60;
    public static final int ELSE=116;
    public static final int AnyInstanceExpression=43;
    public static final int NewRegionDeclaration=51;
    public static final int REQUIRESLOCK=72;
    public static final int DecimalLiteral=165;
    public static final int BREAK=106;
    public static final int NULL=132;
    public static final int DoubleType=30;
    public static final int ScopedPromise=58;
    public static final int COLON=146;
    public static final int TypeQualifierPattern=35;
    public static final int Parameters=67;
    public static final int IDENTIFIER=92;
    public static final int LOCK=70;
    public static final int Reads=21;
    public static final int ReturnsLock=17;
    public static final int TRUE=141;
    public static final int THROW=138;
    public static final int SHORT=135;
    public static final int ThisExpression=37;
    public static final int AGGREGATE=79;
    public static final int PUBLIC=100;
    public static final int LONG=129;
    public static final int TypeExpression=41;
    public static final int OctalLiteral=166;
    public static final int TRANSIENT=140;
    public static final int FLOAT=120;
    public static final int RETURNSLOCK=75;
    public static final int THROWS=139;
    public static final int MAPREGION=78;
    public static final int LBRACKET=96;
    public static final int GOTO=122;
    public static final int DSTAR=157;
    public static final int LBRACE=153;
    public static final int RBRACE=154;
    public static final int PROTECTED=101;
    public static final int NotTarget=61;
    public static final int BooleanType=24;
    public static final int EscapeSequence=170;
    public static final int INT=127;
    public static final int VOID=143;
    public static final int INSTANCEOF=126;
    public static final int T__183=183;
    public static final int ISLOCK=73;
    public static final int LPAREN=149;
    public static final int RegionName=9;
    public static final int Nothing=53;
    public static final int FieldMappings=50;
    public static final int FloatingPointLiteral=169;
    public static final int SimpleLockName=45;
    public static final int ByteType=25;
    public static final int LETTER=175;
    public static final int INREGION=76;
    public static final int Exponent=167;
    public static final int DO=114;
    public static final int Annotations=36;
    public static final int IMPLEMENTS=124;
    public static final int WHILE=145;
    public static final int SWITCH=136;
    public static final int READS=81;
    public static final int NOTHING=84;
    public static final int CharType=26;
    public static final int END_IMAGINARY=69;
    public static final int CharacterLiteral=171;
    public static final int IS=87;
    public static final int ONLY=133;
    public static final int REGION=80;
    public static final int MappedRegionSpecification=48;
    public static final int StringLiteral=172;
    public static final int QUOTE=151;
    public static final int T__180=180;
    public static final int TestResult=5;
    public static final int PROTECTS=83;
    public static final int THIS=98;
    public static final int ShortType=27;
    public static final int JavaIDDigit=176;
    public static final int CLASS=94;
    public static final int TypeRef=33;
    public static final int NATIVE=130;
    public static final int RETURN=99;
    public static final int BYTE=107;
    public static final int VOLATILE=144;
    public static final int IF=123;
    public static final int T__179=179;
    public static final int EOF=-1;
    public static final int ReadLock=56;
    public static final int FOR=121;
    public static final int ArrayType=34;
    public static final int T__184=184;
    public static final int DEFAULT=113;
    public static final int LockNames=46;
    public static final int OctalEscape=174;
    public static final int DASH=158;
    public static final int STAR=156;
    public static final int LongType=31;
    public static final int RegionMapping=49;
    public static final int TRY=142;
    public static final int Aggregate=19;
    public static final int WriteLock=57;

    // delegates
    // delegators


        public SLAnnotationsParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SLAnnotationsParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SLAnnotationsParser.tokenNames; }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g"; }


    @Override
    protected void mismatch(IntStream input, int ttype, BitSet follow)
    	throws RecognitionException{
    	throw new MismatchedTokenException(ttype, input);
    }
    @Override
    public Object recoverFromMismatchedSet(IntStream input, RecognitionException e, BitSet follow)
    	throws RecognitionException{
    	reportError(e);
    	throw e;
    }

      IRNode context;
      
      void setContext(IRNode n) {
        context = n;
      }
      
      boolean isType(String prefix, Token id) { 
        return ParseUtil.isType(context, prefix, id.getText());
      }


    public static class testResult_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "testResult"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:164:1: testResult : ( 'is' IDENTIFIER '&' IDENTIFIER ':' -> ^( TestResult IDENTIFIER '&' IDENTIFIER ':' ) | 'is' IDENTIFIER ':' -> ^( TestResult IDENTIFIER ':' ) | 'is' IDENTIFIER '&' IDENTIFIER EOF -> ^( TestResult IDENTIFIER '&' IDENTIFIER ) | 'is' IDENTIFIER EOF -> ^( TestResult IDENTIFIER ) );
    public final SLAnnotationsParser.testResult_return testResult() throws RecognitionException {
        SLAnnotationsParser.testResult_return retval = new SLAnnotationsParser.testResult_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal1=null;
        Token IDENTIFIER2=null;
        Token char_literal3=null;
        Token IDENTIFIER4=null;
        Token char_literal5=null;
        Token string_literal6=null;
        Token IDENTIFIER7=null;
        Token char_literal8=null;
        Token string_literal9=null;
        Token IDENTIFIER10=null;
        Token char_literal11=null;
        Token IDENTIFIER12=null;
        Token EOF13=null;
        Token string_literal14=null;
        Token IDENTIFIER15=null;
        Token EOF16=null;

        Tree string_literal1_tree=null;
        Tree IDENTIFIER2_tree=null;
        Tree char_literal3_tree=null;
        Tree IDENTIFIER4_tree=null;
        Tree char_literal5_tree=null;
        Tree string_literal6_tree=null;
        Tree IDENTIFIER7_tree=null;
        Tree char_literal8_tree=null;
        Tree string_literal9_tree=null;
        Tree IDENTIFIER10_tree=null;
        Tree char_literal11_tree=null;
        Tree IDENTIFIER12_tree=null;
        Tree EOF13_tree=null;
        Tree string_literal14_tree=null;
        Tree IDENTIFIER15_tree=null;
        Tree EOF16_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_179=new RewriteRuleTokenStream(adaptor,"token 179");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleTokenStream stream_IS=new RewriteRuleTokenStream(adaptor,"token IS");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:169:3: ( 'is' IDENTIFIER '&' IDENTIFIER ':' -> ^( TestResult IDENTIFIER '&' IDENTIFIER ':' ) | 'is' IDENTIFIER ':' -> ^( TestResult IDENTIFIER ':' ) | 'is' IDENTIFIER '&' IDENTIFIER EOF -> ^( TestResult IDENTIFIER '&' IDENTIFIER ) | 'is' IDENTIFIER EOF -> ^( TestResult IDENTIFIER ) )
            int alt1=4;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==IS) ) {
                int LA1_1 = input.LA(2);

                if ( (LA1_1==IDENTIFIER) ) {
                    switch ( input.LA(3) ) {
                    case 179:
                        {
                        int LA1_3 = input.LA(4);

                        if ( (LA1_3==IDENTIFIER) ) {
                            int LA1_6 = input.LA(5);

                            if ( (LA1_6==COLON) ) {
                                alt1=1;
                            }
                            else if ( (LA1_6==EOF) ) {
                                alt1=3;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return retval;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 1, 6, input);

                                throw nvae;
                            }
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return retval;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 1, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    case COLON:
                        {
                        alt1=2;
                        }
                        break;
                    case EOF:
                        {
                        alt1=4;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 1, 2, input);

                        throw nvae;
                    }

                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:169:5: 'is' IDENTIFIER '&' IDENTIFIER ':'
                    {
                    string_literal1=(Token)match(input,IS,FOLLOW_IS_in_testResult549); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IS.add(string_literal1);

                    IDENTIFIER2=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult551); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER2);

                    char_literal3=(Token)match(input,179,FOLLOW_179_in_testResult553); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_179.add(char_literal3);

                    IDENTIFIER4=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult555); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER4);

                    char_literal5=(Token)match(input,COLON,FOLLOW_COLON_in_testResult557); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON.add(char_literal5);



                    // AST REWRITE
                    // elements: IDENTIFIER, 179, COLON, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 169:40: -> ^( TestResult IDENTIFIER '&' IDENTIFIER ':' )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:169:43: ^( TestResult IDENTIFIER '&' IDENTIFIER ':' )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_179.nextNode());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_COLON.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:170:5: 'is' IDENTIFIER ':'
                    {
                    string_literal6=(Token)match(input,IS,FOLLOW_IS_in_testResult577); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IS.add(string_literal6);

                    IDENTIFIER7=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult579); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER7);

                    char_literal8=(Token)match(input,COLON,FOLLOW_COLON_in_testResult581); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON.add(char_literal8);



                    // AST REWRITE
                    // elements: COLON, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 170:25: -> ^( TestResult IDENTIFIER ':' )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:170:28: ^( TestResult IDENTIFIER ':' )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_COLON.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:171:5: 'is' IDENTIFIER '&' IDENTIFIER EOF
                    {
                    string_literal9=(Token)match(input,IS,FOLLOW_IS_in_testResult597); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IS.add(string_literal9);

                    IDENTIFIER10=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult599); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER10);

                    char_literal11=(Token)match(input,179,FOLLOW_179_in_testResult601); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_179.add(char_literal11);

                    IDENTIFIER12=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult603); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER12);

                    EOF13=(Token)match(input,EOF,FOLLOW_EOF_in_testResult605); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF13);



                    // AST REWRITE
                    // elements: IDENTIFIER, 179, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 171:40: -> ^( TestResult IDENTIFIER '&' IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:171:43: ^( TestResult IDENTIFIER '&' IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_179.nextNode());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:172:5: 'is' IDENTIFIER EOF
                    {
                    string_literal14=(Token)match(input,IS,FOLLOW_IS_in_testResult623); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IS.add(string_literal14);

                    IDENTIFIER15=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_testResult625); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER15);

                    EOF16=(Token)match(input,EOF,FOLLOW_EOF_in_testResult627); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF16);



                    // AST REWRITE
                    // elements: IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 172:25: -> ^( TestResult IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:172:28: ^( TestResult IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TestResult, "TestResult"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "testResult"

    public static class testResultComment_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "testResultComment"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:175:1: testResultComment : ( '/*' | '/**' ) testResult -> testResult ;
    public final SLAnnotationsParser.testResultComment_return testResultComment() throws RecognitionException {
        SLAnnotationsParser.testResultComment_return retval = new SLAnnotationsParser.testResultComment_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal17=null;
        Token string_literal18=null;
        SLAnnotationsParser.testResult_return testResult19 = null;


        Tree string_literal17_tree=null;
        Tree string_literal18_tree=null;
        RewriteRuleTokenStream stream_181=new RewriteRuleTokenStream(adaptor,"token 181");
        RewriteRuleTokenStream stream_180=new RewriteRuleTokenStream(adaptor,"token 180");
        RewriteRuleSubtreeStream stream_testResult=new RewriteRuleSubtreeStream(adaptor,"rule testResult");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:176:3: ( ( '/*' | '/**' ) testResult -> testResult )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:176:5: ( '/*' | '/**' ) testResult
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:176:5: ( '/*' | '/**' )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==180) ) {
                alt2=1;
            }
            else if ( (LA2_0==181) ) {
                alt2=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:176:6: '/*'
                    {
                    string_literal17=(Token)match(input,180,FOLLOW_180_in_testResultComment651); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_180.add(string_literal17);


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:176:13: '/**'
                    {
                    string_literal18=(Token)match(input,181,FOLLOW_181_in_testResultComment655); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_181.add(string_literal18);


                    }
                    break;

            }

            pushFollow(FOLLOW_testResult_in_testResultComment663);
            testResult19=testResult();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_testResult.add(testResult19.getTree());


            // AST REWRITE
            // elements: testResult
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 177:16: -> testResult
            {
                adaptor.addChild(root_0, stream_testResult.nextTree());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "testResultComment"

    public static class borrowedFunction_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "borrowedFunction"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:180:1: borrowedFunction : thisExpr EOF -> thisExpr ;
    public final SLAnnotationsParser.borrowedFunction_return borrowedFunction() throws RecognitionException {
        SLAnnotationsParser.borrowedFunction_return retval = new SLAnnotationsParser.borrowedFunction_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF21=null;
        SLAnnotationsParser.thisExpr_return thisExpr20 = null;


        Tree EOF21_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_thisExpr=new RewriteRuleSubtreeStream(adaptor,"rule thisExpr");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:185:5: ( thisExpr EOF -> thisExpr )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:185:7: thisExpr EOF
            {
            pushFollow(FOLLOW_thisExpr_in_borrowedFunction688);
            thisExpr20=thisExpr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_thisExpr.add(thisExpr20.getTree());
            EOF21=(Token)match(input,EOF,FOLLOW_EOF_in_borrowedFunction690); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF21);



            // AST REWRITE
            // elements: thisExpr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 185:20: -> thisExpr
            {
                adaptor.addChild(root_0, stream_thisExpr.nextTree());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "borrowedFunction"

    public static class borrowedList_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "borrowedList"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:188:1: borrowedList : ( borrowedExpressionList EOF -> borrowedExpressionList | borrowedExpression EOF -> borrowedExpression );
    public final SLAnnotationsParser.borrowedList_return borrowedList() throws RecognitionException {
        SLAnnotationsParser.borrowedList_return retval = new SLAnnotationsParser.borrowedList_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF23=null;
        Token EOF25=null;
        SLAnnotationsParser.borrowedExpressionList_return borrowedExpressionList22 = null;

        SLAnnotationsParser.borrowedExpression_return borrowedExpression24 = null;


        Tree EOF23_tree=null;
        Tree EOF25_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_borrowedExpression=new RewriteRuleSubtreeStream(adaptor,"rule borrowedExpression");
        RewriteRuleSubtreeStream stream_borrowedExpressionList=new RewriteRuleSubtreeStream(adaptor,"rule borrowedExpressionList");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:189:5: ( borrowedExpressionList EOF -> borrowedExpressionList | borrowedExpression EOF -> borrowedExpression )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==IDENTIFIER) ) {
                int LA3_1 = input.LA(2);

                if ( (LA3_1==COMMA) ) {
                    alt3=1;
                }
                else if ( (LA3_1==EOF) ) {
                    alt3=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA3_0==THIS) ) {
                int LA3_2 = input.LA(2);

                if ( (LA3_2==EOF) ) {
                    alt3=2;
                }
                else if ( (LA3_2==COMMA) ) {
                    alt3=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:189:7: borrowedExpressionList EOF
                    {
                    pushFollow(FOLLOW_borrowedExpressionList_in_borrowedList715);
                    borrowedExpressionList22=borrowedExpressionList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_borrowedExpressionList.add(borrowedExpressionList22.getTree());
                    EOF23=(Token)match(input,EOF,FOLLOW_EOF_in_borrowedList717); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF23);



                    // AST REWRITE
                    // elements: borrowedExpressionList
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 189:34: -> borrowedExpressionList
                    {
                        adaptor.addChild(root_0, stream_borrowedExpressionList.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:190:7: borrowedExpression EOF
                    {
                    pushFollow(FOLLOW_borrowedExpression_in_borrowedList729);
                    borrowedExpression24=borrowedExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_borrowedExpression.add(borrowedExpression24.getTree());
                    EOF25=(Token)match(input,EOF,FOLLOW_EOF_in_borrowedList731); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF25);



                    // AST REWRITE
                    // elements: borrowedExpression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 190:30: -> borrowedExpression
                    {
                        adaptor.addChild(root_0, stream_borrowedExpression.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "borrowedList"

    public static class borrowedExpressionList_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "borrowedExpressionList"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:193:1: borrowedExpressionList : borrowedExpression ( ',' borrowedExpression )+ -> ^( Expressions ( borrowedExpression )+ ) ;
    public final SLAnnotationsParser.borrowedExpressionList_return borrowedExpressionList() throws RecognitionException {
        SLAnnotationsParser.borrowedExpressionList_return retval = new SLAnnotationsParser.borrowedExpressionList_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal27=null;
        SLAnnotationsParser.borrowedExpression_return borrowedExpression26 = null;

        SLAnnotationsParser.borrowedExpression_return borrowedExpression28 = null;


        Tree char_literal27_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_borrowedExpression=new RewriteRuleSubtreeStream(adaptor,"rule borrowedExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:194:4: ( borrowedExpression ( ',' borrowedExpression )+ -> ^( Expressions ( borrowedExpression )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:194:6: borrowedExpression ( ',' borrowedExpression )+
            {
            pushFollow(FOLLOW_borrowedExpression_in_borrowedExpressionList751);
            borrowedExpression26=borrowedExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_borrowedExpression.add(borrowedExpression26.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:194:25: ( ',' borrowedExpression )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==COMMA) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:194:26: ',' borrowedExpression
            	    {
            	    char_literal27=(Token)match(input,COMMA,FOLLOW_COMMA_in_borrowedExpressionList754); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal27);

            	    pushFollow(FOLLOW_borrowedExpression_in_borrowedExpressionList756);
            	    borrowedExpression28=borrowedExpression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_borrowedExpression.add(borrowedExpression28.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);



            // AST REWRITE
            // elements: borrowedExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 194:51: -> ^( Expressions ( borrowedExpression )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:194:54: ^( Expressions ( borrowedExpression )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Expressions, "Expressions"), root_1);

                if ( !(stream_borrowedExpression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_borrowedExpression.hasNext() ) {
                    adaptor.addChild(root_1, stream_borrowedExpression.nextTree());

                }
                stream_borrowedExpression.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "borrowedExpressionList"

    public static class borrowedExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "borrowedExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:197:1: borrowedExpression : ( varUse | thisExpr );
    public final SLAnnotationsParser.borrowedExpression_return borrowedExpression() throws RecognitionException {
        SLAnnotationsParser.borrowedExpression_return retval = new SLAnnotationsParser.borrowedExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.varUse_return varUse29 = null;

        SLAnnotationsParser.thisExpr_return thisExpr30 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:198:5: ( varUse | thisExpr )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==IDENTIFIER) ) {
                alt5=1;
            }
            else if ( (LA5_0==THIS) ) {
                alt5=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:198:7: varUse
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_varUse_in_borrowedExpression784);
                    varUse29=varUse();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, varUse29.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:198:16: thisExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_thisExpr_in_borrowedExpression788);
                    thisExpr30=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, thisExpr30.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "borrowedExpression"

    public static class uniqueJava5Method_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueJava5Method"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:201:1: uniqueJava5Method : ( thisExpr EOF -> thisExpr | returnValue EOF -> returnValue | thisExpr ',' returnValue EOF -> ^( Expressions thisExpr returnValue ) | returnValue ',' thisExpr EOF -> ^( Expressions thisExpr returnValue ) );
    public final SLAnnotationsParser.uniqueJava5Method_return uniqueJava5Method() throws RecognitionException {
        SLAnnotationsParser.uniqueJava5Method_return retval = new SLAnnotationsParser.uniqueJava5Method_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF32=null;
        Token EOF34=null;
        Token char_literal36=null;
        Token EOF38=null;
        Token char_literal40=null;
        Token EOF42=null;
        SLAnnotationsParser.thisExpr_return thisExpr31 = null;

        SLAnnotationsParser.returnValue_return returnValue33 = null;

        SLAnnotationsParser.thisExpr_return thisExpr35 = null;

        SLAnnotationsParser.returnValue_return returnValue37 = null;

        SLAnnotationsParser.returnValue_return returnValue39 = null;

        SLAnnotationsParser.thisExpr_return thisExpr41 = null;


        Tree EOF32_tree=null;
        Tree EOF34_tree=null;
        Tree char_literal36_tree=null;
        Tree EOF38_tree=null;
        Tree char_literal40_tree=null;
        Tree EOF42_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_thisExpr=new RewriteRuleSubtreeStream(adaptor,"rule thisExpr");
        RewriteRuleSubtreeStream stream_returnValue=new RewriteRuleSubtreeStream(adaptor,"rule returnValue");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:202:5: ( thisExpr EOF -> thisExpr | returnValue EOF -> returnValue | thisExpr ',' returnValue EOF -> ^( Expressions thisExpr returnValue ) | returnValue ',' thisExpr EOF -> ^( Expressions thisExpr returnValue ) )
            int alt6=4;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==THIS) ) {
                int LA6_1 = input.LA(2);

                if ( (LA6_1==EOF) ) {
                    alt6=1;
                }
                else if ( (LA6_1==COMMA) ) {
                    alt6=3;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA6_0==RETURN) ) {
                int LA6_2 = input.LA(2);

                if ( (LA6_2==COMMA) ) {
                    alt6=4;
                }
                else if ( (LA6_2==EOF) ) {
                    alt6=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:202:7: thisExpr EOF
                    {
                    pushFollow(FOLLOW_thisExpr_in_uniqueJava5Method810);
                    thisExpr31=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_thisExpr.add(thisExpr31.getTree());
                    EOF32=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJava5Method812); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF32);



                    // AST REWRITE
                    // elements: thisExpr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 202:20: -> thisExpr
                    {
                        adaptor.addChild(root_0, stream_thisExpr.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:203:7: returnValue EOF
                    {
                    pushFollow(FOLLOW_returnValue_in_uniqueJava5Method824);
                    returnValue33=returnValue();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_returnValue.add(returnValue33.getTree());
                    EOF34=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJava5Method826); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF34);



                    // AST REWRITE
                    // elements: returnValue
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 203:23: -> returnValue
                    {
                        adaptor.addChild(root_0, stream_returnValue.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:204:7: thisExpr ',' returnValue EOF
                    {
                    pushFollow(FOLLOW_thisExpr_in_uniqueJava5Method838);
                    thisExpr35=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_thisExpr.add(thisExpr35.getTree());
                    char_literal36=(Token)match(input,COMMA,FOLLOW_COMMA_in_uniqueJava5Method840); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COMMA.add(char_literal36);

                    pushFollow(FOLLOW_returnValue_in_uniqueJava5Method842);
                    returnValue37=returnValue();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_returnValue.add(returnValue37.getTree());
                    EOF38=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJava5Method844); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF38);



                    // AST REWRITE
                    // elements: thisExpr, returnValue
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 204:36: -> ^( Expressions thisExpr returnValue )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:204:39: ^( Expressions thisExpr returnValue )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Expressions, "Expressions"), root_1);

                        adaptor.addChild(root_1, stream_thisExpr.nextTree());
                        adaptor.addChild(root_1, stream_returnValue.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:205:7: returnValue ',' thisExpr EOF
                    {
                    pushFollow(FOLLOW_returnValue_in_uniqueJava5Method862);
                    returnValue39=returnValue();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_returnValue.add(returnValue39.getTree());
                    char_literal40=(Token)match(input,COMMA,FOLLOW_COMMA_in_uniqueJava5Method864); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COMMA.add(char_literal40);

                    pushFollow(FOLLOW_thisExpr_in_uniqueJava5Method866);
                    thisExpr41=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_thisExpr.add(thisExpr41.getTree());
                    EOF42=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJava5Method868); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF42);



                    // AST REWRITE
                    // elements: returnValue, thisExpr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 205:36: -> ^( Expressions thisExpr returnValue )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:205:39: ^( Expressions thisExpr returnValue )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Expressions, "Expressions"), root_1);

                        adaptor.addChild(root_1, stream_thisExpr.nextTree());
                        adaptor.addChild(root_1, stream_returnValue.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueJava5Method"

    public static class uniqueJavadocMethod_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueJavadocMethod"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:208:1: uniqueJavadocMethod : ( uniqueExpressionList EOF -> uniqueExpressionList | uniqueExpression EOF -> uniqueExpression );
    public final SLAnnotationsParser.uniqueJavadocMethod_return uniqueJavadocMethod() throws RecognitionException {
        SLAnnotationsParser.uniqueJavadocMethod_return retval = new SLAnnotationsParser.uniqueJavadocMethod_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF44=null;
        Token EOF46=null;
        SLAnnotationsParser.uniqueExpressionList_return uniqueExpressionList43 = null;

        SLAnnotationsParser.uniqueExpression_return uniqueExpression45 = null;


        Tree EOF44_tree=null;
        Tree EOF46_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_uniqueExpression=new RewriteRuleSubtreeStream(adaptor,"rule uniqueExpression");
        RewriteRuleSubtreeStream stream_uniqueExpressionList=new RewriteRuleSubtreeStream(adaptor,"rule uniqueExpressionList");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:209:5: ( uniqueExpressionList EOF -> uniqueExpressionList | uniqueExpression EOF -> uniqueExpression )
            int alt7=2;
            switch ( input.LA(1) ) {
            case IDENTIFIER:
                {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==COMMA) ) {
                    alt7=1;
                }
                else if ( (LA7_1==EOF) ) {
                    alt7=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }
                }
                break;
            case THIS:
                {
                int LA7_2 = input.LA(2);

                if ( (LA7_2==COMMA) ) {
                    alt7=1;
                }
                else if ( (LA7_2==EOF) ) {
                    alt7=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 2, input);

                    throw nvae;
                }
                }
                break;
            case RETURN:
                {
                int LA7_3 = input.LA(2);

                if ( (LA7_3==COMMA) ) {
                    alt7=1;
                }
                else if ( (LA7_3==EOF) ) {
                    alt7=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 3, input);

                    throw nvae;
                }
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:209:7: uniqueExpressionList EOF
                    {
                    pushFollow(FOLLOW_uniqueExpressionList_in_uniqueJavadocMethod895);
                    uniqueExpressionList43=uniqueExpressionList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_uniqueExpressionList.add(uniqueExpressionList43.getTree());
                    EOF44=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJavadocMethod897); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF44);



                    // AST REWRITE
                    // elements: uniqueExpressionList
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 209:32: -> uniqueExpressionList
                    {
                        adaptor.addChild(root_0, stream_uniqueExpressionList.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:210:7: uniqueExpression EOF
                    {
                    pushFollow(FOLLOW_uniqueExpression_in_uniqueJavadocMethod909);
                    uniqueExpression45=uniqueExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_uniqueExpression.add(uniqueExpression45.getTree());
                    EOF46=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJavadocMethod911); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF46);



                    // AST REWRITE
                    // elements: uniqueExpression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 210:28: -> uniqueExpression
                    {
                        adaptor.addChild(root_0, stream_uniqueExpression.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueJavadocMethod"

    public static class uniqueJavadocConstructor_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueJavadocConstructor"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:213:1: uniqueJavadocConstructor : ( uniqueConstructorExpressionList EOF -> uniqueConstructorExpressionList | uniqueConstructorExpression EOF -> uniqueConstructorExpression );
    public final SLAnnotationsParser.uniqueJavadocConstructor_return uniqueJavadocConstructor() throws RecognitionException {
        SLAnnotationsParser.uniqueJavadocConstructor_return retval = new SLAnnotationsParser.uniqueJavadocConstructor_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF48=null;
        Token EOF50=null;
        SLAnnotationsParser.uniqueConstructorExpressionList_return uniqueConstructorExpressionList47 = null;

        SLAnnotationsParser.uniqueConstructorExpression_return uniqueConstructorExpression49 = null;


        Tree EOF48_tree=null;
        Tree EOF50_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_uniqueConstructorExpression=new RewriteRuleSubtreeStream(adaptor,"rule uniqueConstructorExpression");
        RewriteRuleSubtreeStream stream_uniqueConstructorExpressionList=new RewriteRuleSubtreeStream(adaptor,"rule uniqueConstructorExpressionList");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:214:5: ( uniqueConstructorExpressionList EOF -> uniqueConstructorExpressionList | uniqueConstructorExpression EOF -> uniqueConstructorExpression )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==IDENTIFIER) ) {
                int LA8_1 = input.LA(2);

                if ( (LA8_1==COMMA) ) {
                    alt8=1;
                }
                else if ( (LA8_1==EOF) ) {
                    alt8=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 8, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:214:7: uniqueConstructorExpressionList EOF
                    {
                    pushFollow(FOLLOW_uniqueConstructorExpressionList_in_uniqueJavadocConstructor936);
                    uniqueConstructorExpressionList47=uniqueConstructorExpressionList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_uniqueConstructorExpressionList.add(uniqueConstructorExpressionList47.getTree());
                    EOF48=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJavadocConstructor938); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF48);



                    // AST REWRITE
                    // elements: uniqueConstructorExpressionList
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 214:43: -> uniqueConstructorExpressionList
                    {
                        adaptor.addChild(root_0, stream_uniqueConstructorExpressionList.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:215:7: uniqueConstructorExpression EOF
                    {
                    pushFollow(FOLLOW_uniqueConstructorExpression_in_uniqueJavadocConstructor950);
                    uniqueConstructorExpression49=uniqueConstructorExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_uniqueConstructorExpression.add(uniqueConstructorExpression49.getTree());
                    EOF50=(Token)match(input,EOF,FOLLOW_EOF_in_uniqueJavadocConstructor952); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EOF.add(EOF50);



                    // AST REWRITE
                    // elements: uniqueConstructorExpression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 215:39: -> uniqueConstructorExpression
                    {
                        adaptor.addChild(root_0, stream_uniqueConstructorExpression.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueJavadocConstructor"

    public static class uniqueExpressionList_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueExpressionList"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:218:1: uniqueExpressionList : uniqueExpression ( ',' uniqueExpression )+ -> ^( Expressions ( uniqueExpression )+ ) ;
    public final SLAnnotationsParser.uniqueExpressionList_return uniqueExpressionList() throws RecognitionException {
        SLAnnotationsParser.uniqueExpressionList_return retval = new SLAnnotationsParser.uniqueExpressionList_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal52=null;
        SLAnnotationsParser.uniqueExpression_return uniqueExpression51 = null;

        SLAnnotationsParser.uniqueExpression_return uniqueExpression53 = null;


        Tree char_literal52_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_uniqueExpression=new RewriteRuleSubtreeStream(adaptor,"rule uniqueExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:219:4: ( uniqueExpression ( ',' uniqueExpression )+ -> ^( Expressions ( uniqueExpression )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:219:6: uniqueExpression ( ',' uniqueExpression )+
            {
            pushFollow(FOLLOW_uniqueExpression_in_uniqueExpressionList972);
            uniqueExpression51=uniqueExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_uniqueExpression.add(uniqueExpression51.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:219:23: ( ',' uniqueExpression )+
            int cnt9=0;
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==COMMA) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:219:24: ',' uniqueExpression
            	    {
            	    char_literal52=(Token)match(input,COMMA,FOLLOW_COMMA_in_uniqueExpressionList975); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal52);

            	    pushFollow(FOLLOW_uniqueExpression_in_uniqueExpressionList977);
            	    uniqueExpression53=uniqueExpression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_uniqueExpression.add(uniqueExpression53.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt9 >= 1 ) break loop9;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(9, input);
                        throw eee;
                }
                cnt9++;
            } while (true);



            // AST REWRITE
            // elements: uniqueExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 219:47: -> ^( Expressions ( uniqueExpression )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:219:50: ^( Expressions ( uniqueExpression )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Expressions, "Expressions"), root_1);

                if ( !(stream_uniqueExpression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_uniqueExpression.hasNext() ) {
                    adaptor.addChild(root_1, stream_uniqueExpression.nextTree());

                }
                stream_uniqueExpression.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueExpressionList"

    public static class uniqueExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:222:1: uniqueExpression : ( varUse | thisExpr | returnValue );
    public final SLAnnotationsParser.uniqueExpression_return uniqueExpression() throws RecognitionException {
        SLAnnotationsParser.uniqueExpression_return retval = new SLAnnotationsParser.uniqueExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.varUse_return varUse54 = null;

        SLAnnotationsParser.thisExpr_return thisExpr55 = null;

        SLAnnotationsParser.returnValue_return returnValue56 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:223:5: ( varUse | thisExpr | returnValue )
            int alt10=3;
            switch ( input.LA(1) ) {
            case IDENTIFIER:
                {
                alt10=1;
                }
                break;
            case THIS:
                {
                alt10=2;
                }
                break;
            case RETURN:
                {
                alt10=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:223:7: varUse
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_varUse_in_uniqueExpression1005);
                    varUse54=varUse();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, varUse54.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:223:16: thisExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_thisExpr_in_uniqueExpression1009);
                    thisExpr55=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, thisExpr55.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:223:27: returnValue
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_returnValue_in_uniqueExpression1013);
                    returnValue56=returnValue();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, returnValue56.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueExpression"

    public static class uniqueConstructorExpressionList_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueConstructorExpressionList"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:226:1: uniqueConstructorExpressionList : uniqueConstructorExpression ( ',' uniqueConstructorExpression )+ -> ^( Expressions ( uniqueConstructorExpression )+ ) ;
    public final SLAnnotationsParser.uniqueConstructorExpressionList_return uniqueConstructorExpressionList() throws RecognitionException {
        SLAnnotationsParser.uniqueConstructorExpressionList_return retval = new SLAnnotationsParser.uniqueConstructorExpressionList_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal58=null;
        SLAnnotationsParser.uniqueConstructorExpression_return uniqueConstructorExpression57 = null;

        SLAnnotationsParser.uniqueConstructorExpression_return uniqueConstructorExpression59 = null;


        Tree char_literal58_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_uniqueConstructorExpression=new RewriteRuleSubtreeStream(adaptor,"rule uniqueConstructorExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:227:4: ( uniqueConstructorExpression ( ',' uniqueConstructorExpression )+ -> ^( Expressions ( uniqueConstructorExpression )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:227:6: uniqueConstructorExpression ( ',' uniqueConstructorExpression )+
            {
            pushFollow(FOLLOW_uniqueConstructorExpression_in_uniqueConstructorExpressionList1030);
            uniqueConstructorExpression57=uniqueConstructorExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_uniqueConstructorExpression.add(uniqueConstructorExpression57.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:227:34: ( ',' uniqueConstructorExpression )+
            int cnt11=0;
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==COMMA) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:227:35: ',' uniqueConstructorExpression
            	    {
            	    char_literal58=(Token)match(input,COMMA,FOLLOW_COMMA_in_uniqueConstructorExpressionList1033); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal58);

            	    pushFollow(FOLLOW_uniqueConstructorExpression_in_uniqueConstructorExpressionList1035);
            	    uniqueConstructorExpression59=uniqueConstructorExpression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_uniqueConstructorExpression.add(uniqueConstructorExpression59.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt11 >= 1 ) break loop11;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(11, input);
                        throw eee;
                }
                cnt11++;
            } while (true);



            // AST REWRITE
            // elements: uniqueConstructorExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 227:69: -> ^( Expressions ( uniqueConstructorExpression )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:227:72: ^( Expressions ( uniqueConstructorExpression )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Expressions, "Expressions"), root_1);

                if ( !(stream_uniqueConstructorExpression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_uniqueConstructorExpression.hasNext() ) {
                    adaptor.addChild(root_1, stream_uniqueConstructorExpression.nextTree());

                }
                stream_uniqueConstructorExpression.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueConstructorExpressionList"

    public static class uniqueConstructorExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "uniqueConstructorExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:230:1: uniqueConstructorExpression : varUse ;
    public final SLAnnotationsParser.uniqueConstructorExpression_return uniqueConstructorExpression() throws RecognitionException {
        SLAnnotationsParser.uniqueConstructorExpression_return retval = new SLAnnotationsParser.uniqueConstructorExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.varUse_return varUse60 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:231:5: ( varUse )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:231:7: varUse
            {
            root_0 = (Tree)adaptor.nil();

            pushFollow(FOLLOW_varUse_in_uniqueConstructorExpression1063);
            varUse60=varUse();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, varUse60.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "uniqueConstructorExpression"

    public static class starts_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "starts"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:234:1: starts : NOTHING EOF -> ^( StartsSpecification NOTHING ) ;
    public final SLAnnotationsParser.starts_return starts() throws RecognitionException {
        SLAnnotationsParser.starts_return retval = new SLAnnotationsParser.starts_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token NOTHING61=null;
        Token EOF62=null;

        Tree NOTHING61_tree=null;
        Tree EOF62_tree=null;
        RewriteRuleTokenStream stream_NOTHING=new RewriteRuleTokenStream(adaptor,"token NOTHING");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:239:6: ( NOTHING EOF -> ^( StartsSpecification NOTHING ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:239:8: NOTHING EOF
            {
            NOTHING61=(Token)match(input,NOTHING,FOLLOW_NOTHING_in_starts1090); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_NOTHING.add(NOTHING61);

            EOF62=(Token)match(input,EOF,FOLLOW_EOF_in_starts1092); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF62);



            // AST REWRITE
            // elements: NOTHING
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 239:20: -> ^( StartsSpecification NOTHING )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:239:23: ^( StartsSpecification NOTHING )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StartsSpecification, "StartsSpecification"), root_1);

                adaptor.addChild(root_1, stream_NOTHING.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "starts"

    public static class locks_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "locks"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:242:1: locks : '(' '{' lockJava5 ( ',' lockJava5 )* '}' ')' -> ( lockJava5 )+ ;
    public final SLAnnotationsParser.locks_return locks() throws RecognitionException {
        SLAnnotationsParser.locks_return retval = new SLAnnotationsParser.locks_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal63=null;
        Token char_literal64=null;
        Token char_literal66=null;
        Token char_literal68=null;
        Token char_literal69=null;
        SLAnnotationsParser.lockJava5_return lockJava565 = null;

        SLAnnotationsParser.lockJava5_return lockJava567 = null;


        Tree char_literal63_tree=null;
        Tree char_literal64_tree=null;
        Tree char_literal66_tree=null;
        Tree char_literal68_tree=null;
        Tree char_literal69_tree=null;
        RewriteRuleTokenStream stream_RBRACE=new RewriteRuleTokenStream(adaptor,"token RBRACE");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_LBRACE=new RewriteRuleTokenStream(adaptor,"token LBRACE");
        RewriteRuleSubtreeStream stream_lockJava5=new RewriteRuleSubtreeStream(adaptor,"rule lockJava5");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:247:5: ( '(' '{' lockJava5 ( ',' lockJava5 )* '}' ')' -> ( lockJava5 )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:247:7: '(' '{' lockJava5 ( ',' lockJava5 )* '}' ')'
            {
            char_literal63=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_locks1124); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LPAREN.add(char_literal63);

            char_literal64=(Token)match(input,LBRACE,FOLLOW_LBRACE_in_locks1126); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LBRACE.add(char_literal64);

            pushFollow(FOLLOW_lockJava5_in_locks1128);
            lockJava565=lockJava5();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lockJava5.add(lockJava565.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:247:25: ( ',' lockJava5 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==COMMA) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:247:26: ',' lockJava5
            	    {
            	    char_literal66=(Token)match(input,COMMA,FOLLOW_COMMA_in_locks1131); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal66);

            	    pushFollow(FOLLOW_lockJava5_in_locks1133);
            	    lockJava567=lockJava5();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_lockJava5.add(lockJava567.getTree());

            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            char_literal68=(Token)match(input,RBRACE,FOLLOW_RBRACE_in_locks1137); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RBRACE.add(char_literal68);

            char_literal69=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_locks1139); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RPAREN.add(char_literal69);



            // AST REWRITE
            // elements: lockJava5
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 247:50: -> ( lockJava5 )+
            {
                if ( !(stream_lockJava5.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_lockJava5.hasNext() ) {
                    adaptor.addChild(root_0, stream_lockJava5.nextTree());

                }
                stream_lockJava5.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "locks"

    public static class lockJava5_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lockJava5"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:250:1: lockJava5 : LOCK '(' '\"' lock '\"' ')' -> lock ;
    public final SLAnnotationsParser.lockJava5_return lockJava5() throws RecognitionException {
        SLAnnotationsParser.lockJava5_return retval = new SLAnnotationsParser.lockJava5_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token LOCK70=null;
        Token char_literal71=null;
        Token char_literal72=null;
        Token char_literal74=null;
        Token char_literal75=null;
        SLAnnotationsParser.lock_return lock73 = null;


        Tree LOCK70_tree=null;
        Tree char_literal71_tree=null;
        Tree char_literal72_tree=null;
        Tree char_literal74_tree=null;
        Tree char_literal75_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_LOCK=new RewriteRuleTokenStream(adaptor,"token LOCK");
        RewriteRuleTokenStream stream_DQUOTE=new RewriteRuleTokenStream(adaptor,"token DQUOTE");
        RewriteRuleSubtreeStream stream_lock=new RewriteRuleSubtreeStream(adaptor,"rule lock");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:251:2: ( LOCK '(' '\"' lock '\"' ')' -> lock )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:251:4: LOCK '(' '\"' lock '\"' ')'
            {
            LOCK70=(Token)match(input,LOCK,FOLLOW_LOCK_in_lockJava51155); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LOCK.add(LOCK70);

            char_literal71=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_lockJava51157); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LPAREN.add(char_literal71);

            char_literal72=(Token)match(input,DQUOTE,FOLLOW_DQUOTE_in_lockJava51159); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DQUOTE.add(char_literal72);

            pushFollow(FOLLOW_lock_in_lockJava51161);
            lock73=lock();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lock.add(lock73.getTree());
            char_literal74=(Token)match(input,DQUOTE,FOLLOW_DQUOTE_in_lockJava51163); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DQUOTE.add(char_literal74);

            char_literal75=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_lockJava51165); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RPAREN.add(char_literal75);



            // AST REWRITE
            // elements: lock
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 251:30: -> lock
            {
                adaptor.addChild(root_0, stream_lock.nextTree());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "lockJava5"

    public static class lock_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lock"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:254:1: lock : IDENTIFIER 'is' lockExpression PROTECTS regionName EOF -> ^( LockDeclaration IDENTIFIER lockExpression regionName ) ;
    public final SLAnnotationsParser.lock_return lock() throws RecognitionException {
        SLAnnotationsParser.lock_return retval = new SLAnnotationsParser.lock_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER76=null;
        Token string_literal77=null;
        Token PROTECTS79=null;
        Token EOF81=null;
        SLAnnotationsParser.lockExpression_return lockExpression78 = null;

        SLAnnotationsParser.regionName_return regionName80 = null;


        Tree IDENTIFIER76_tree=null;
        Tree string_literal77_tree=null;
        Tree PROTECTS79_tree=null;
        Tree EOF81_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_PROTECTS=new RewriteRuleTokenStream(adaptor,"token PROTECTS");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleTokenStream stream_IS=new RewriteRuleTokenStream(adaptor,"token IS");
        RewriteRuleSubtreeStream stream_lockExpression=new RewriteRuleSubtreeStream(adaptor,"rule lockExpression");
        RewriteRuleSubtreeStream stream_regionName=new RewriteRuleSubtreeStream(adaptor,"rule regionName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:255:2: ( IDENTIFIER 'is' lockExpression PROTECTS regionName EOF -> ^( LockDeclaration IDENTIFIER lockExpression regionName ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:255:3: IDENTIFIER 'is' lockExpression PROTECTS regionName EOF
            {
            IDENTIFIER76=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_lock1179); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER76);

            string_literal77=(Token)match(input,IS,FOLLOW_IS_in_lock1181); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IS.add(string_literal77);

            pushFollow(FOLLOW_lockExpression_in_lock1183);
            lockExpression78=lockExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lockExpression.add(lockExpression78.getTree());
            PROTECTS79=(Token)match(input,PROTECTS,FOLLOW_PROTECTS_in_lock1185); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_PROTECTS.add(PROTECTS79);

            pushFollow(FOLLOW_regionName_in_lock1187);
            regionName80=regionName();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionName.add(regionName80.getTree());
            EOF81=(Token)match(input,EOF,FOLLOW_EOF_in_lock1189); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF81);



            // AST REWRITE
            // elements: regionName, IDENTIFIER, lockExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 255:58: -> ^( LockDeclaration IDENTIFIER lockExpression regionName )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:255:61: ^( LockDeclaration IDENTIFIER lockExpression regionName )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(LockDeclaration, "LockDeclaration"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_lockExpression.nextTree());
                adaptor.addChild(root_1, stream_regionName.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "lock"

    public static class requiresLock_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "requiresLock"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:258:1: requiresLock : ( lockSpecifications -> ^( RequiresLock lockSpecifications ) | -> ^( RequiresLock ) );
    public final SLAnnotationsParser.requiresLock_return requiresLock() throws RecognitionException {
        SLAnnotationsParser.requiresLock_return retval = new SLAnnotationsParser.requiresLock_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.lockSpecifications_return lockSpecifications82 = null;


        RewriteRuleSubtreeStream stream_lockSpecifications=new RewriteRuleSubtreeStream(adaptor,"rule lockSpecifications");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:259:2: ( lockSpecifications -> ^( RequiresLock lockSpecifications ) | -> ^( RequiresLock ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==IDENTIFIER||LA13_0==THIS) ) {
                alt13=1;
            }
            else if ( (LA13_0==EOF) ) {
                alt13=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:259:4: lockSpecifications
                    {
                    pushFollow(FOLLOW_lockSpecifications_in_requiresLock1212);
                    lockSpecifications82=lockSpecifications();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_lockSpecifications.add(lockSpecifications82.getTree());


                    // AST REWRITE
                    // elements: lockSpecifications
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 259:23: -> ^( RequiresLock lockSpecifications )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:259:26: ^( RequiresLock lockSpecifications )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RequiresLock, "RequiresLock"), root_1);

                        adaptor.addChild(root_1, stream_lockSpecifications.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:260:4: 
                    {

                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 260:4: -> ^( RequiresLock )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:260:7: ^( RequiresLock )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RequiresLock, "RequiresLock"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "requiresLock"

    public static class isLock_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "isLock"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:263:1: isLock : simpleLockSpecification EOF -> ^( IsLock simpleLockSpecification ) ;
    public final SLAnnotationsParser.isLock_return isLock() throws RecognitionException {
        SLAnnotationsParser.isLock_return retval = new SLAnnotationsParser.isLock_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF84=null;
        SLAnnotationsParser.simpleLockSpecification_return simpleLockSpecification83 = null;


        Tree EOF84_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_simpleLockSpecification=new RewriteRuleSubtreeStream(adaptor,"rule simpleLockSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:264:2: ( simpleLockSpecification EOF -> ^( IsLock simpleLockSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:264:4: simpleLockSpecification EOF
            {
            pushFollow(FOLLOW_simpleLockSpecification_in_isLock1241);
            simpleLockSpecification83=simpleLockSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_simpleLockSpecification.add(simpleLockSpecification83.getTree());
            EOF84=(Token)match(input,EOF,FOLLOW_EOF_in_isLock1243); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF84);



            // AST REWRITE
            // elements: simpleLockSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 264:32: -> ^( IsLock simpleLockSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:264:35: ^( IsLock simpleLockSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(IsLock, "IsLock"), root_1);

                adaptor.addChild(root_1, stream_simpleLockSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "isLock"

    public static class policyLock_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "policyLock"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:267:1: policyLock : policyLockDeclaration EOF -> policyLockDeclaration ;
    public final SLAnnotationsParser.policyLock_return policyLock() throws RecognitionException {
        SLAnnotationsParser.policyLock_return retval = new SLAnnotationsParser.policyLock_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF86=null;
        SLAnnotationsParser.policyLockDeclaration_return policyLockDeclaration85 = null;


        Tree EOF86_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_policyLockDeclaration=new RewriteRuleSubtreeStream(adaptor,"rule policyLockDeclaration");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:268:2: ( policyLockDeclaration EOF -> policyLockDeclaration )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:268:4: policyLockDeclaration EOF
            {
            pushFollow(FOLLOW_policyLockDeclaration_in_policyLock1262);
            policyLockDeclaration85=policyLockDeclaration();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_policyLockDeclaration.add(policyLockDeclaration85.getTree());
            EOF86=(Token)match(input,EOF,FOLLOW_EOF_in_policyLock1264); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF86);



            // AST REWRITE
            // elements: policyLockDeclaration
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 268:30: -> policyLockDeclaration
            {
                adaptor.addChild(root_0, stream_policyLockDeclaration.nextTree());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "policyLock"

    public static class returnsLock_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "returnsLock"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:271:1: returnsLock : lockSpecification EOF -> ^( ReturnsLock lockSpecification ) ;
    public final SLAnnotationsParser.returnsLock_return returnsLock() throws RecognitionException {
        SLAnnotationsParser.returnsLock_return retval = new SLAnnotationsParser.returnsLock_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF88=null;
        SLAnnotationsParser.lockSpecification_return lockSpecification87 = null;


        Tree EOF88_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_lockSpecification=new RewriteRuleSubtreeStream(adaptor,"rule lockSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:272:6: ( lockSpecification EOF -> ^( ReturnsLock lockSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:272:8: lockSpecification EOF
            {
            pushFollow(FOLLOW_lockSpecification_in_returnsLock1283);
            lockSpecification87=lockSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lockSpecification.add(lockSpecification87.getTree());
            EOF88=(Token)match(input,EOF,FOLLOW_EOF_in_returnsLock1285); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF88);



            // AST REWRITE
            // elements: lockSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 272:30: -> ^( ReturnsLock lockSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:272:33: ^( ReturnsLock lockSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ReturnsLock, "ReturnsLock"), root_1);

                adaptor.addChild(root_1, stream_lockSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "returnsLock"

    public static class policyLockDeclaration_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "policyLockDeclaration"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:275:1: policyLockDeclaration : IDENTIFIER 'is' lockExpression EOF -> ^( PolicyLockDeclaration IDENTIFIER lockExpression ) ;
    public final SLAnnotationsParser.policyLockDeclaration_return policyLockDeclaration() throws RecognitionException {
        SLAnnotationsParser.policyLockDeclaration_return retval = new SLAnnotationsParser.policyLockDeclaration_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER89=null;
        Token string_literal90=null;
        Token EOF92=null;
        SLAnnotationsParser.lockExpression_return lockExpression91 = null;


        Tree IDENTIFIER89_tree=null;
        Tree string_literal90_tree=null;
        Tree EOF92_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleTokenStream stream_IS=new RewriteRuleTokenStream(adaptor,"token IS");
        RewriteRuleSubtreeStream stream_lockExpression=new RewriteRuleSubtreeStream(adaptor,"rule lockExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:278:2: ( IDENTIFIER 'is' lockExpression EOF -> ^( PolicyLockDeclaration IDENTIFIER lockExpression ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:278:4: IDENTIFIER 'is' lockExpression EOF
            {
            IDENTIFIER89=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_policyLockDeclaration1316); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER89);

            string_literal90=(Token)match(input,IS,FOLLOW_IS_in_policyLockDeclaration1318); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IS.add(string_literal90);

            pushFollow(FOLLOW_lockExpression_in_policyLockDeclaration1320);
            lockExpression91=lockExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lockExpression.add(lockExpression91.getTree());
            EOF92=(Token)match(input,EOF,FOLLOW_EOF_in_policyLockDeclaration1322); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF92);



            // AST REWRITE
            // elements: IDENTIFIER, lockExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 278:39: -> ^( PolicyLockDeclaration IDENTIFIER lockExpression )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:278:42: ^( PolicyLockDeclaration IDENTIFIER lockExpression )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(PolicyLockDeclaration, "PolicyLockDeclaration"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_lockExpression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "policyLockDeclaration"

    public static class lockSpecifications_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lockSpecifications"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:281:1: lockSpecifications : lockSpecification ( ',' lockSpecification )* -> ( lockSpecification )+ ;
    public final SLAnnotationsParser.lockSpecifications_return lockSpecifications() throws RecognitionException {
        SLAnnotationsParser.lockSpecifications_return retval = new SLAnnotationsParser.lockSpecifications_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal94=null;
        SLAnnotationsParser.lockSpecification_return lockSpecification93 = null;

        SLAnnotationsParser.lockSpecification_return lockSpecification95 = null;


        Tree char_literal94_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_lockSpecification=new RewriteRuleSubtreeStream(adaptor,"rule lockSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:282:2: ( lockSpecification ( ',' lockSpecification )* -> ( lockSpecification )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:282:4: lockSpecification ( ',' lockSpecification )*
            {
            pushFollow(FOLLOW_lockSpecification_in_lockSpecifications1343);
            lockSpecification93=lockSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lockSpecification.add(lockSpecification93.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:282:22: ( ',' lockSpecification )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==COMMA) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:282:23: ',' lockSpecification
            	    {
            	    char_literal94=(Token)match(input,COMMA,FOLLOW_COMMA_in_lockSpecifications1346); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal94);

            	    pushFollow(FOLLOW_lockSpecification_in_lockSpecifications1348);
            	    lockSpecification95=lockSpecification();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_lockSpecification.add(lockSpecification95.getTree());

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);



            // AST REWRITE
            // elements: lockSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 282:47: -> ( lockSpecification )+
            {
                if ( !(stream_lockSpecification.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_lockSpecification.hasNext() ) {
                    adaptor.addChild(root_0, stream_lockSpecification.nextTree());

                }
                stream_lockSpecification.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "lockSpecifications"

    public static class lockSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lockSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:285:1: lockSpecification : ( qualifiedLockSpecification | simpleLockSpecification );
    public final SLAnnotationsParser.lockSpecification_return lockSpecification() throws RecognitionException {
        SLAnnotationsParser.lockSpecification_return retval = new SLAnnotationsParser.lockSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedLockSpecification_return qualifiedLockSpecification96 = null;

        SLAnnotationsParser.simpleLockSpecification_return simpleLockSpecification97 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:286:3: ( qualifiedLockSpecification | simpleLockSpecification )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==THIS) ) {
                alt15=1;
            }
            else if ( (LA15_0==IDENTIFIER) ) {
                switch ( input.LA(2) ) {
                case DOT:
                    {
                    int LA15_3 = input.LA(3);

                    if ( (LA15_3==IDENTIFIER||LA15_3==THIS) ) {
                        alt15=1;
                    }
                    else if ( ((LA15_3>=READ_LOCK && LA15_3<=WRITE_LOCK)) ) {
                        alt15=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 15, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case COLON:
                    {
                    alt15=1;
                    }
                    break;
                case EOF:
                case COMMA:
                    {
                    alt15=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 15, 2, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:286:5: qualifiedLockSpecification
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedLockSpecification_in_lockSpecification1367);
                    qualifiedLockSpecification96=qualifiedLockSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedLockSpecification96.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:287:5: simpleLockSpecification
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleLockSpecification_in_lockSpecification1373);
                    simpleLockSpecification97=simpleLockSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleLockSpecification97.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "lockSpecification"

    public static class simpleLockSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleLockSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:290:1: simpleLockSpecification : ( simpleLockName DOT READ_LOCK '(' ')' -> ^( ReadLock simpleLockName ) | simpleLockName DOT WRITE_LOCK '(' ')' -> ^( WriteLock simpleLockName ) | simpleLockName );
    public final SLAnnotationsParser.simpleLockSpecification_return simpleLockSpecification() throws RecognitionException {
        SLAnnotationsParser.simpleLockSpecification_return retval = new SLAnnotationsParser.simpleLockSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token DOT99=null;
        Token READ_LOCK100=null;
        Token char_literal101=null;
        Token char_literal102=null;
        Token DOT104=null;
        Token WRITE_LOCK105=null;
        Token char_literal106=null;
        Token char_literal107=null;
        SLAnnotationsParser.simpleLockName_return simpleLockName98 = null;

        SLAnnotationsParser.simpleLockName_return simpleLockName103 = null;

        SLAnnotationsParser.simpleLockName_return simpleLockName108 = null;


        Tree DOT99_tree=null;
        Tree READ_LOCK100_tree=null;
        Tree char_literal101_tree=null;
        Tree char_literal102_tree=null;
        Tree DOT104_tree=null;
        Tree WRITE_LOCK105_tree=null;
        Tree char_literal106_tree=null;
        Tree char_literal107_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_READ_LOCK=new RewriteRuleTokenStream(adaptor,"token READ_LOCK");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_WRITE_LOCK=new RewriteRuleTokenStream(adaptor,"token WRITE_LOCK");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_simpleLockName=new RewriteRuleSubtreeStream(adaptor,"rule simpleLockName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:291:3: ( simpleLockName DOT READ_LOCK '(' ')' -> ^( ReadLock simpleLockName ) | simpleLockName DOT WRITE_LOCK '(' ')' -> ^( WriteLock simpleLockName ) | simpleLockName )
            int alt16=3;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==IDENTIFIER) ) {
                int LA16_1 = input.LA(2);

                if ( (LA16_1==EOF||LA16_1==COMMA) ) {
                    alt16=3;
                }
                else if ( (LA16_1==DOT) ) {
                    int LA16_3 = input.LA(3);

                    if ( (LA16_3==WRITE_LOCK) ) {
                        alt16=2;
                    }
                    else if ( (LA16_3==READ_LOCK) ) {
                        alt16=1;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 16, 3, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 16, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:291:5: simpleLockName DOT READ_LOCK '(' ')'
                    {
                    pushFollow(FOLLOW_simpleLockName_in_simpleLockSpecification1388);
                    simpleLockName98=simpleLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_simpleLockName.add(simpleLockName98.getTree());
                    DOT99=(Token)match(input,DOT,FOLLOW_DOT_in_simpleLockSpecification1390); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(DOT99);

                    READ_LOCK100=(Token)match(input,READ_LOCK,FOLLOW_READ_LOCK_in_simpleLockSpecification1392); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_READ_LOCK.add(READ_LOCK100);

                    char_literal101=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_simpleLockSpecification1394); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal101);

                    char_literal102=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_simpleLockSpecification1396); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal102);



                    // AST REWRITE
                    // elements: simpleLockName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 291:42: -> ^( ReadLock simpleLockName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:291:45: ^( ReadLock simpleLockName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ReadLock, "ReadLock"), root_1);

                        adaptor.addChild(root_1, stream_simpleLockName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:292:5: simpleLockName DOT WRITE_LOCK '(' ')'
                    {
                    pushFollow(FOLLOW_simpleLockName_in_simpleLockSpecification1410);
                    simpleLockName103=simpleLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_simpleLockName.add(simpleLockName103.getTree());
                    DOT104=(Token)match(input,DOT,FOLLOW_DOT_in_simpleLockSpecification1412); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(DOT104);

                    WRITE_LOCK105=(Token)match(input,WRITE_LOCK,FOLLOW_WRITE_LOCK_in_simpleLockSpecification1414); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WRITE_LOCK.add(WRITE_LOCK105);

                    char_literal106=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_simpleLockSpecification1416); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal106);

                    char_literal107=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_simpleLockSpecification1418); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal107);



                    // AST REWRITE
                    // elements: simpleLockName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 292:43: -> ^( WriteLock simpleLockName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:292:46: ^( WriteLock simpleLockName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(WriteLock, "WriteLock"), root_1);

                        adaptor.addChild(root_1, stream_simpleLockName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:293:5: simpleLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleLockName_in_simpleLockSpecification1432);
                    simpleLockName108=simpleLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleLockName108.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleLockSpecification"

    public static class qualifiedLockSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedLockSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:296:1: qualifiedLockSpecification : ( qualifiedLockName DOT READ_LOCK '(' ')' -> ^( ReadLock qualifiedLockName ) | qualifiedLockName DOT WRITE_LOCK '(' ')' -> ^( WriteLock qualifiedLockName ) | qualifiedLockName );
    public final SLAnnotationsParser.qualifiedLockSpecification_return qualifiedLockSpecification() throws RecognitionException {
        SLAnnotationsParser.qualifiedLockSpecification_return retval = new SLAnnotationsParser.qualifiedLockSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token DOT110=null;
        Token READ_LOCK111=null;
        Token char_literal112=null;
        Token char_literal113=null;
        Token DOT115=null;
        Token WRITE_LOCK116=null;
        Token char_literal117=null;
        Token char_literal118=null;
        SLAnnotationsParser.qualifiedLockName_return qualifiedLockName109 = null;

        SLAnnotationsParser.qualifiedLockName_return qualifiedLockName114 = null;

        SLAnnotationsParser.qualifiedLockName_return qualifiedLockName119 = null;


        Tree DOT110_tree=null;
        Tree READ_LOCK111_tree=null;
        Tree char_literal112_tree=null;
        Tree char_literal113_tree=null;
        Tree DOT115_tree=null;
        Tree WRITE_LOCK116_tree=null;
        Tree char_literal117_tree=null;
        Tree char_literal118_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_READ_LOCK=new RewriteRuleTokenStream(adaptor,"token READ_LOCK");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_WRITE_LOCK=new RewriteRuleTokenStream(adaptor,"token WRITE_LOCK");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_qualifiedLockName=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedLockName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:297:3: ( qualifiedLockName DOT READ_LOCK '(' ')' -> ^( ReadLock qualifiedLockName ) | qualifiedLockName DOT WRITE_LOCK '(' ')' -> ^( WriteLock qualifiedLockName ) | qualifiedLockName )
            int alt17=3;
            alt17 = dfa17.predict(input);
            switch (alt17) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:297:5: qualifiedLockName DOT READ_LOCK '(' ')'
                    {
                    pushFollow(FOLLOW_qualifiedLockName_in_qualifiedLockSpecification1447);
                    qualifiedLockName109=qualifiedLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_qualifiedLockName.add(qualifiedLockName109.getTree());
                    DOT110=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedLockSpecification1449); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(DOT110);

                    READ_LOCK111=(Token)match(input,READ_LOCK,FOLLOW_READ_LOCK_in_qualifiedLockSpecification1451); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_READ_LOCK.add(READ_LOCK111);

                    char_literal112=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_qualifiedLockSpecification1453); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal112);

                    char_literal113=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_qualifiedLockSpecification1455); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal113);



                    // AST REWRITE
                    // elements: qualifiedLockName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 297:45: -> ^( ReadLock qualifiedLockName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:297:48: ^( ReadLock qualifiedLockName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ReadLock, "ReadLock"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedLockName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:298:5: qualifiedLockName DOT WRITE_LOCK '(' ')'
                    {
                    pushFollow(FOLLOW_qualifiedLockName_in_qualifiedLockSpecification1469);
                    qualifiedLockName114=qualifiedLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_qualifiedLockName.add(qualifiedLockName114.getTree());
                    DOT115=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedLockSpecification1471); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(DOT115);

                    WRITE_LOCK116=(Token)match(input,WRITE_LOCK,FOLLOW_WRITE_LOCK_in_qualifiedLockSpecification1473); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WRITE_LOCK.add(WRITE_LOCK116);

                    char_literal117=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_qualifiedLockSpecification1475); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LPAREN.add(char_literal117);

                    char_literal118=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_qualifiedLockSpecification1477); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RPAREN.add(char_literal118);



                    // AST REWRITE
                    // elements: qualifiedLockName
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 298:46: -> ^( WriteLock qualifiedLockName )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:298:49: ^( WriteLock qualifiedLockName )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(WriteLock, "WriteLock"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedLockName.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:299:5: qualifiedLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedLockName_in_qualifiedLockSpecification1491);
                    qualifiedLockName119=qualifiedLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedLockName119.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedLockSpecification"

    public static class lockName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lockName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:303:1: lockName : ( qualifiedLockName | simpleLockName );
    public final SLAnnotationsParser.lockName_return lockName() throws RecognitionException {
        SLAnnotationsParser.lockName_return retval = new SLAnnotationsParser.lockName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedLockName_return qualifiedLockName120 = null;

        SLAnnotationsParser.simpleLockName_return simpleLockName121 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:304:2: ( qualifiedLockName | simpleLockName )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==THIS) ) {
                alt18=1;
            }
            else if ( (LA18_0==IDENTIFIER) ) {
                int LA18_2 = input.LA(2);

                if ( (LA18_2==DOT||LA18_2==COLON) ) {
                    alt18=1;
                }
                else if ( (LA18_2==EOF) ) {
                    alt18=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 18, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:304:4: qualifiedLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedLockName_in_lockName1507);
                    qualifiedLockName120=qualifiedLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedLockName120.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:305:4: simpleLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleLockName_in_lockName1512);
                    simpleLockName121=simpleLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleLockName121.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "lockName"

    public static class lockExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lockExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:308:1: lockExpression : ( qualifiedLockExpressian | simpleLockExpression );
    public final SLAnnotationsParser.lockExpression_return lockExpression() throws RecognitionException {
        SLAnnotationsParser.lockExpression_return retval = new SLAnnotationsParser.lockExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedLockExpressian_return qualifiedLockExpressian122 = null;

        SLAnnotationsParser.simpleLockExpression_return simpleLockExpression123 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:309:2: ( qualifiedLockExpressian | simpleLockExpression )
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==IDENTIFIER) ) {
                int LA19_1 = input.LA(2);

                if ( (LA19_1==DOT) ) {
                    alt19=1;
                }
                else if ( (LA19_1==EOF||LA19_1==PROTECTS) ) {
                    alt19=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA19_0==CLASS||LA19_0==THIS) ) {
                alt19=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:309:4: qualifiedLockExpressian
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedLockExpressian_in_lockExpression1524);
                    qualifiedLockExpressian122=qualifiedLockExpressian();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedLockExpressian122.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:310:4: simpleLockExpression
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleLockExpression_in_lockExpression1530);
                    simpleLockExpression123=simpleLockExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleLockExpression123.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "lockExpression"

    public static class qualifiedLockName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedLockName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:313:1: qualifiedLockName : ( ( parameterLockName )=> parameterLockName | typeQualifiedLockName | innerClassLockName );
    public final SLAnnotationsParser.qualifiedLockName_return qualifiedLockName() throws RecognitionException {
        SLAnnotationsParser.qualifiedLockName_return retval = new SLAnnotationsParser.qualifiedLockName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.parameterLockName_return parameterLockName124 = null;

        SLAnnotationsParser.typeQualifiedLockName_return typeQualifiedLockName125 = null;

        SLAnnotationsParser.innerClassLockName_return innerClassLockName126 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:314:2: ( ( parameterLockName )=> parameterLockName | typeQualifiedLockName | innerClassLockName )
            int alt20=3;
            alt20 = dfa20.predict(input);
            switch (alt20) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:314:4: ( parameterLockName )=> parameterLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_parameterLockName_in_qualifiedLockName1548);
                    parameterLockName124=parameterLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, parameterLockName124.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:315:4: typeQualifiedLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_typeQualifiedLockName_in_qualifiedLockName1553);
                    typeQualifiedLockName125=typeQualifiedLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, typeQualifiedLockName125.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:316:4: innerClassLockName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_innerClassLockName_in_qualifiedLockName1559);
                    innerClassLockName126=innerClassLockName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, innerClassLockName126.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedLockName"

    public static class parameterLockName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameterLockName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:319:1: parameterLockName : simpleExpression ':' IDENTIFIER -> ^( QualifiedLockName simpleExpression IDENTIFIER ) ;
    public final SLAnnotationsParser.parameterLockName_return parameterLockName() throws RecognitionException {
        SLAnnotationsParser.parameterLockName_return retval = new SLAnnotationsParser.parameterLockName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal128=null;
        Token IDENTIFIER129=null;
        SLAnnotationsParser.simpleExpression_return simpleExpression127 = null;


        Tree char_literal128_tree=null;
        Tree IDENTIFIER129_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_simpleExpression=new RewriteRuleSubtreeStream(adaptor,"rule simpleExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:320:3: ( simpleExpression ':' IDENTIFIER -> ^( QualifiedLockName simpleExpression IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:320:5: simpleExpression ':' IDENTIFIER
            {
            pushFollow(FOLLOW_simpleExpression_in_parameterLockName1572);
            simpleExpression127=simpleExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_simpleExpression.add(simpleExpression127.getTree());
            char_literal128=(Token)match(input,COLON,FOLLOW_COLON_in_parameterLockName1574); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_COLON.add(char_literal128);

            IDENTIFIER129=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_parameterLockName1576); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER129);



            // AST REWRITE
            // elements: simpleExpression, IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 320:37: -> ^( QualifiedLockName simpleExpression IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:320:40: ^( QualifiedLockName simpleExpression IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedLockName, "QualifiedLockName"), root_1);

                adaptor.addChild(root_1, stream_simpleExpression.nextTree());
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameterLockName"

    public static class qualifiedLockExpressian_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedLockExpressian"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:323:1: qualifiedLockExpressian : ( ( qualifiedClassLockExpression )=> qualifiedClassLockExpression | ( qualifiedThisExpression )=> qualifiedThisExpression | qualifiedFieldRef );
    public final SLAnnotationsParser.qualifiedLockExpressian_return qualifiedLockExpressian() throws RecognitionException {
        SLAnnotationsParser.qualifiedLockExpressian_return retval = new SLAnnotationsParser.qualifiedLockExpressian_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedClassLockExpression_return qualifiedClassLockExpression130 = null;

        SLAnnotationsParser.qualifiedThisExpression_return qualifiedThisExpression131 = null;

        SLAnnotationsParser.qualifiedFieldRef_return qualifiedFieldRef132 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:324:2: ( ( qualifiedClassLockExpression )=> qualifiedClassLockExpression | ( qualifiedThisExpression )=> qualifiedThisExpression | qualifiedFieldRef )
            int alt21=3;
            alt21 = dfa21.predict(input);
            switch (alt21) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:324:4: ( qualifiedClassLockExpression )=> qualifiedClassLockExpression
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedClassLockExpression_in_qualifiedLockExpressian1605);
                    qualifiedClassLockExpression130=qualifiedClassLockExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedClassLockExpression130.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:325:4: ( qualifiedThisExpression )=> qualifiedThisExpression
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedThisExpression_in_qualifiedLockExpressian1617);
                    qualifiedThisExpression131=qualifiedThisExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedThisExpression131.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:326:4: qualifiedFieldRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedFieldRef_in_qualifiedLockExpressian1622);
                    qualifiedFieldRef132=qualifiedFieldRef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedFieldRef132.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedLockExpressian"

    public static class qualifiedClassLockExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedClassLockExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:329:1: qualifiedClassLockExpression : namedType '.' CLASS -> ^( QualifiedClassLockExpression namedType ) ;
    public final SLAnnotationsParser.qualifiedClassLockExpression_return qualifiedClassLockExpression() throws RecognitionException {
        SLAnnotationsParser.qualifiedClassLockExpression_return retval = new SLAnnotationsParser.qualifiedClassLockExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal134=null;
        Token CLASS135=null;
        SLAnnotationsParser.namedType_return namedType133 = null;


        Tree char_literal134_tree=null;
        Tree CLASS135_tree=null;
        RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:330:2: ( namedType '.' CLASS -> ^( QualifiedClassLockExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:330:4: namedType '.' CLASS
            {
            pushFollow(FOLLOW_namedType_in_qualifiedClassLockExpression1634);
            namedType133=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType133.getTree());
            char_literal134=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedClassLockExpression1636); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOT.add(char_literal134);

            CLASS135=(Token)match(input,CLASS,FOLLOW_CLASS_in_qualifiedClassLockExpression1638); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLASS.add(CLASS135);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 330:24: -> ^( QualifiedClassLockExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:330:27: ^( QualifiedClassLockExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedClassLockExpression, "QualifiedClassLockExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedClassLockExpression"

    public static class simpleLockExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleLockExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:333:1: simpleLockExpression : ( classExpr | thisExpr | simpleFieldRef );
    public final SLAnnotationsParser.simpleLockExpression_return simpleLockExpression() throws RecognitionException {
        SLAnnotationsParser.simpleLockExpression_return retval = new SLAnnotationsParser.simpleLockExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.classExpr_return classExpr136 = null;

        SLAnnotationsParser.thisExpr_return thisExpr137 = null;

        SLAnnotationsParser.simpleFieldRef_return simpleFieldRef138 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:334:2: ( classExpr | thisExpr | simpleFieldRef )
            int alt22=3;
            switch ( input.LA(1) ) {
            case CLASS:
                {
                alt22=1;
                }
                break;
            case THIS:
                {
                int LA22_2 = input.LA(2);

                if ( (LA22_2==DOT) ) {
                    int LA22_4 = input.LA(3);

                    if ( (LA22_4==CLASS) ) {
                        alt22=1;
                    }
                    else if ( (LA22_4==IDENTIFIER) ) {
                        alt22=3;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 22, 4, input);

                        throw nvae;
                    }
                }
                else if ( (LA22_2==EOF||LA22_2==PROTECTS) ) {
                    alt22=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 22, 2, input);

                    throw nvae;
                }
                }
                break;
            case IDENTIFIER:
                {
                alt22=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }

            switch (alt22) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:334:4: classExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_classExpr_in_simpleLockExpression1657);
                    classExpr136=classExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, classExpr136.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:335:4: thisExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_thisExpr_in_simpleLockExpression1663);
                    thisExpr137=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, thisExpr137.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:336:4: simpleFieldRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleFieldRef_in_simpleLockExpression1668);
                    simpleFieldRef138=simpleFieldRef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleFieldRef138.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleLockExpression"

    public static class aggregate_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "aggregate"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:340:1: aggregate : mappedRegionSpecification EOF -> ^( Aggregate mappedRegionSpecification ) ;
    public final SLAnnotationsParser.aggregate_return aggregate() throws RecognitionException {
        SLAnnotationsParser.aggregate_return retval = new SLAnnotationsParser.aggregate_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF140=null;
        SLAnnotationsParser.mappedRegionSpecification_return mappedRegionSpecification139 = null;


        Tree EOF140_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_mappedRegionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule mappedRegionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:344:6: ( mappedRegionSpecification EOF -> ^( Aggregate mappedRegionSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:344:8: mappedRegionSpecification EOF
            {
            pushFollow(FOLLOW_mappedRegionSpecification_in_aggregate1688);
            mappedRegionSpecification139=mappedRegionSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_mappedRegionSpecification.add(mappedRegionSpecification139.getTree());
            EOF140=(Token)match(input,EOF,FOLLOW_EOF_in_aggregate1690); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF140);



            // AST REWRITE
            // elements: mappedRegionSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 344:38: -> ^( Aggregate mappedRegionSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:344:41: ^( Aggregate mappedRegionSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Aggregate, "Aggregate"), root_1);

                adaptor.addChild(root_1, stream_mappedRegionSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "aggregate"

    public static class region_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "region"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:347:1: region : ( fullRegionDecl -> fullRegionDecl | regionDecl -> regionDecl );
    public final SLAnnotationsParser.region_return region() throws RecognitionException {
        SLAnnotationsParser.region_return retval = new SLAnnotationsParser.region_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.fullRegionDecl_return fullRegionDecl141 = null;

        SLAnnotationsParser.regionDecl_return regionDecl142 = null;


        RewriteRuleSubtreeStream stream_regionDecl=new RewriteRuleSubtreeStream(adaptor,"rule regionDecl");
        RewriteRuleSubtreeStream stream_fullRegionDecl=new RewriteRuleSubtreeStream(adaptor,"rule fullRegionDecl");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:348:2: ( fullRegionDecl -> fullRegionDecl | regionDecl -> regionDecl )
            int alt23=2;
            switch ( input.LA(1) ) {
            case IDENTIFIER:
                {
                int LA23_1 = input.LA(2);

                if ( (LA23_1==EXTENDS) ) {
                    alt23=1;
                }
                else if ( (LA23_1==EOF) ) {
                    alt23=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 1, input);

                    throw nvae;
                }
                }
                break;
            case PUBLIC:
            case PROTECTED:
            case PRIVATE:
                {
                int LA23_2 = input.LA(2);

                if ( (LA23_2==STATIC) ) {
                    int LA23_3 = input.LA(3);

                    if ( (LA23_3==IDENTIFIER) ) {
                        int LA23_6 = input.LA(4);

                        if ( (LA23_6==EXTENDS) ) {
                            alt23=1;
                        }
                        else if ( (LA23_6==EOF) ) {
                            alt23=2;
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return retval;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 23, 6, input);

                            throw nvae;
                        }
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 3, input);

                        throw nvae;
                    }
                }
                else if ( (LA23_2==IDENTIFIER) ) {
                    int LA23_6 = input.LA(3);

                    if ( (LA23_6==EXTENDS) ) {
                        alt23=1;
                    }
                    else if ( (LA23_6==EOF) ) {
                        alt23=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 2, input);

                    throw nvae;
                }
                }
                break;
            case STATIC:
                {
                int LA23_3 = input.LA(2);

                if ( (LA23_3==IDENTIFIER) ) {
                    int LA23_6 = input.LA(3);

                    if ( (LA23_6==EXTENDS) ) {
                        alt23=1;
                    }
                    else if ( (LA23_6==EOF) ) {
                        alt23=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 3, input);

                    throw nvae;
                }
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:348:4: fullRegionDecl
                    {
                    pushFollow(FOLLOW_fullRegionDecl_in_region1718);
                    fullRegionDecl141=fullRegionDecl();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_fullRegionDecl.add(fullRegionDecl141.getTree());


                    // AST REWRITE
                    // elements: fullRegionDecl
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 348:19: -> fullRegionDecl
                    {
                        adaptor.addChild(root_0, stream_fullRegionDecl.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:349:4: regionDecl
                    {
                    pushFollow(FOLLOW_regionDecl_in_region1727);
                    regionDecl142=regionDecl();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_regionDecl.add(regionDecl142.getTree());


                    // AST REWRITE
                    // elements: regionDecl
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 349:15: -> regionDecl
                    {
                        adaptor.addChild(root_0, stream_regionDecl.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "region"

    public static class regionDecl_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionDecl"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:352:1: regionDecl : ( IDENTIFIER -> ^( NewRegionDeclaration IDENTIFIER ) | accessModifiers IDENTIFIER -> ^( NewRegionDeclaration accessModifiers IDENTIFIER ) );
    public final SLAnnotationsParser.regionDecl_return regionDecl() throws RecognitionException {
        SLAnnotationsParser.regionDecl_return retval = new SLAnnotationsParser.regionDecl_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER143=null;
        Token IDENTIFIER145=null;
        SLAnnotationsParser.accessModifiers_return accessModifiers144 = null;


        Tree IDENTIFIER143_tree=null;
        Tree IDENTIFIER145_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_accessModifiers=new RewriteRuleSubtreeStream(adaptor,"rule accessModifiers");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:353:3: ( IDENTIFIER -> ^( NewRegionDeclaration IDENTIFIER ) | accessModifiers IDENTIFIER -> ^( NewRegionDeclaration accessModifiers IDENTIFIER ) )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==IDENTIFIER) ) {
                alt24=1;
            }
            else if ( ((LA24_0>=PUBLIC && LA24_0<=STATIC)) ) {
                alt24=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:354:4: IDENTIFIER
                    {
                    IDENTIFIER143=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_regionDecl1749); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER143);



                    // AST REWRITE
                    // elements: IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 354:15: -> ^( NewRegionDeclaration IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:354:18: ^( NewRegionDeclaration IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NewRegionDeclaration, "NewRegionDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:355:5: accessModifiers IDENTIFIER
                    {
                    pushFollow(FOLLOW_accessModifiers_in_regionDecl1765);
                    accessModifiers144=accessModifiers();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_accessModifiers.add(accessModifiers144.getTree());
                    IDENTIFIER145=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_regionDecl1767); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER145);



                    // AST REWRITE
                    // elements: accessModifiers, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 355:32: -> ^( NewRegionDeclaration accessModifiers IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:355:35: ^( NewRegionDeclaration accessModifiers IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NewRegionDeclaration, "NewRegionDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_accessModifiers.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionDecl"

    public static class fullRegionDecl_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fullRegionDecl"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:358:1: fullRegionDecl : ( IDENTIFIER EXTENDS regionSpecification -> ^( NewRegionDeclaration IDENTIFIER regionSpecification ) | accessModifiers IDENTIFIER EXTENDS regionSpecification -> ^( NewRegionDeclaration accessModifiers IDENTIFIER regionSpecification ) );
    public final SLAnnotationsParser.fullRegionDecl_return fullRegionDecl() throws RecognitionException {
        SLAnnotationsParser.fullRegionDecl_return retval = new SLAnnotationsParser.fullRegionDecl_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER146=null;
        Token EXTENDS147=null;
        Token IDENTIFIER150=null;
        Token EXTENDS151=null;
        SLAnnotationsParser.regionSpecification_return regionSpecification148 = null;

        SLAnnotationsParser.accessModifiers_return accessModifiers149 = null;

        SLAnnotationsParser.regionSpecification_return regionSpecification152 = null;


        Tree IDENTIFIER146_tree=null;
        Tree EXTENDS147_tree=null;
        Tree IDENTIFIER150_tree=null;
        Tree EXTENDS151_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_EXTENDS=new RewriteRuleTokenStream(adaptor,"token EXTENDS");
        RewriteRuleSubtreeStream stream_accessModifiers=new RewriteRuleSubtreeStream(adaptor,"rule accessModifiers");
        RewriteRuleSubtreeStream stream_regionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:360:3: ( IDENTIFIER EXTENDS regionSpecification -> ^( NewRegionDeclaration IDENTIFIER regionSpecification ) | accessModifiers IDENTIFIER EXTENDS regionSpecification -> ^( NewRegionDeclaration accessModifiers IDENTIFIER regionSpecification ) )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==IDENTIFIER) ) {
                int LA25_1 = input.LA(2);

                if ( (LA25_1==EXTENDS) ) {
                    int LA25_3 = input.LA(3);

                    if ( (LA25_3==IDENTIFIER) ) {
                        alt25=1;
                    }
                    else if ( (LA25_3==LBRACKET) ) {
                        int LA25_5 = input.LA(4);

                        if ( (LA25_5==RBRACKET) ) {
                            alt25=1;
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return retval;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 25, 5, input);

                            throw nvae;
                        }
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 25, 3, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 25, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA25_0>=PUBLIC && LA25_0<=STATIC)) ) {
                alt25=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:360:5: IDENTIFIER EXTENDS regionSpecification
                    {
                    IDENTIFIER146=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fullRegionDecl1795); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER146);

                    EXTENDS147=(Token)match(input,EXTENDS,FOLLOW_EXTENDS_in_fullRegionDecl1797); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EXTENDS.add(EXTENDS147);

                    pushFollow(FOLLOW_regionSpecification_in_fullRegionDecl1799);
                    regionSpecification148=regionSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification148.getTree());


                    // AST REWRITE
                    // elements: regionSpecification, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 360:44: -> ^( NewRegionDeclaration IDENTIFIER regionSpecification )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:360:47: ^( NewRegionDeclaration IDENTIFIER regionSpecification )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NewRegionDeclaration, "NewRegionDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:361:5: accessModifiers IDENTIFIER EXTENDS regionSpecification
                    {
                    pushFollow(FOLLOW_accessModifiers_in_fullRegionDecl1815);
                    accessModifiers149=accessModifiers();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_accessModifiers.add(accessModifiers149.getTree());
                    IDENTIFIER150=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fullRegionDecl1817); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER150);

                    EXTENDS151=(Token)match(input,EXTENDS,FOLLOW_EXTENDS_in_fullRegionDecl1819); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EXTENDS.add(EXTENDS151);

                    pushFollow(FOLLOW_regionSpecification_in_fullRegionDecl1821);
                    regionSpecification152=regionSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification152.getTree());


                    // AST REWRITE
                    // elements: accessModifiers, regionSpecification, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 361:60: -> ^( NewRegionDeclaration accessModifiers IDENTIFIER regionSpecification )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:361:63: ^( NewRegionDeclaration accessModifiers IDENTIFIER regionSpecification )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NewRegionDeclaration, "NewRegionDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_accessModifiers.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                        adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "fullRegionDecl"

    public static class inRegion_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "inRegion"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:364:1: inRegion : regionSpecification EOF -> ^( InRegion regionSpecification ) ;
    public final SLAnnotationsParser.inRegion_return inRegion() throws RecognitionException {
        SLAnnotationsParser.inRegion_return retval = new SLAnnotationsParser.inRegion_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF154=null;
        SLAnnotationsParser.regionSpecification_return regionSpecification153 = null;


        Tree EOF154_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_regionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:365:2: ( regionSpecification EOF -> ^( InRegion regionSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:365:4: regionSpecification EOF
            {
            pushFollow(FOLLOW_regionSpecification_in_inRegion1846);
            regionSpecification153=regionSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification153.getTree());
            EOF154=(Token)match(input,EOF,FOLLOW_EOF_in_inRegion1848); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF154);



            // AST REWRITE
            // elements: regionSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 365:28: -> ^( InRegion regionSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:365:31: ^( InRegion regionSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InRegion, "InRegion"), root_1);

                adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "inRegion"

    public static class mapFields_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "mapFields"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:368:1: mapFields : fieldMappings EOF -> fieldMappings ;
    public final SLAnnotationsParser.mapFields_return mapFields() throws RecognitionException {
        SLAnnotationsParser.mapFields_return retval = new SLAnnotationsParser.mapFields_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF156=null;
        SLAnnotationsParser.fieldMappings_return fieldMappings155 = null;


        Tree EOF156_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_fieldMappings=new RewriteRuleSubtreeStream(adaptor,"rule fieldMappings");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:369:5: ( fieldMappings EOF -> fieldMappings )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:369:7: fieldMappings EOF
            {
            pushFollow(FOLLOW_fieldMappings_in_mapFields1870);
            fieldMappings155=fieldMappings();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_fieldMappings.add(fieldMappings155.getTree());
            EOF156=(Token)match(input,EOF,FOLLOW_EOF_in_mapFields1872); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF156);



            // AST REWRITE
            // elements: fieldMappings
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 369:25: -> fieldMappings
            {
                adaptor.addChild(root_0, stream_fieldMappings.nextTree());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "mapFields"

    public static class mapRegion_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "mapRegion"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:372:1: mapRegion : regionMapping EOF -> regionMapping ;
    public final SLAnnotationsParser.mapRegion_return mapRegion() throws RecognitionException {
        SLAnnotationsParser.mapRegion_return retval = new SLAnnotationsParser.mapRegion_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF158=null;
        SLAnnotationsParser.regionMapping_return regionMapping157 = null;


        Tree EOF158_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_regionMapping=new RewriteRuleSubtreeStream(adaptor,"rule regionMapping");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:373:5: ( regionMapping EOF -> regionMapping )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:373:7: regionMapping EOF
            {
            pushFollow(FOLLOW_regionMapping_in_mapRegion1893);
            regionMapping157=regionMapping();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionMapping.add(regionMapping157.getTree());
            EOF158=(Token)match(input,EOF,FOLLOW_EOF_in_mapRegion1895); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF158);



            // AST REWRITE
            // elements: regionMapping
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 373:25: -> regionMapping
            {
                adaptor.addChild(root_0, stream_regionMapping.nextTree());

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "mapRegion"

    public static class regionEffects_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionEffects"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:376:1: regionEffects : ( 'none' -> ^( RegionEffects ) | readsEffect ( ';' writesEffect )? -> ^( RegionEffects readsEffect ( writesEffect )? ) | writesEffect ( ';' readsEffect )? -> ^( RegionEffects writesEffect ( readsEffect )? ) );
    public final SLAnnotationsParser.regionEffects_return regionEffects() throws RecognitionException {
        SLAnnotationsParser.regionEffects_return retval = new SLAnnotationsParser.regionEffects_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal159=null;
        Token char_literal161=null;
        Token char_literal164=null;
        SLAnnotationsParser.readsEffect_return readsEffect160 = null;

        SLAnnotationsParser.writesEffect_return writesEffect162 = null;

        SLAnnotationsParser.writesEffect_return writesEffect163 = null;

        SLAnnotationsParser.readsEffect_return readsEffect165 = null;


        Tree string_literal159_tree=null;
        Tree char_literal161_tree=null;
        Tree char_literal164_tree=null;
        RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
        RewriteRuleTokenStream stream_182=new RewriteRuleTokenStream(adaptor,"token 182");
        RewriteRuleSubtreeStream stream_writesEffect=new RewriteRuleSubtreeStream(adaptor,"rule writesEffect");
        RewriteRuleSubtreeStream stream_readsEffect=new RewriteRuleSubtreeStream(adaptor,"rule readsEffect");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:377:2: ( 'none' -> ^( RegionEffects ) | readsEffect ( ';' writesEffect )? -> ^( RegionEffects readsEffect ( writesEffect )? ) | writesEffect ( ';' readsEffect )? -> ^( RegionEffects writesEffect ( readsEffect )? ) )
            int alt28=3;
            switch ( input.LA(1) ) {
            case 182:
                {
                alt28=1;
                }
                break;
            case 183:
                {
                alt28=2;
                }
                break;
            case 184:
                {
                alt28=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:377:4: 'none'
                    {
                    string_literal159=(Token)match(input,182,FOLLOW_182_in_regionEffects1913); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_182.add(string_literal159);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 377:11: -> ^( RegionEffects )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:377:14: ^( RegionEffects )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionEffects, "RegionEffects"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:378:4: readsEffect ( ';' writesEffect )?
                    {
                    pushFollow(FOLLOW_readsEffect_in_regionEffects1924);
                    readsEffect160=readsEffect();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_readsEffect.add(readsEffect160.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:378:16: ( ';' writesEffect )?
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==SEMI) ) {
                        alt26=1;
                    }
                    switch (alt26) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:378:17: ';' writesEffect
                            {
                            char_literal161=(Token)match(input,SEMI,FOLLOW_SEMI_in_regionEffects1927); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI.add(char_literal161);

                            pushFollow(FOLLOW_writesEffect_in_regionEffects1929);
                            writesEffect162=writesEffect();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_writesEffect.add(writesEffect162.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: writesEffect, readsEffect
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 378:36: -> ^( RegionEffects readsEffect ( writesEffect )? )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:378:39: ^( RegionEffects readsEffect ( writesEffect )? )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionEffects, "RegionEffects"), root_1);

                        adaptor.addChild(root_1, stream_readsEffect.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:378:67: ( writesEffect )?
                        if ( stream_writesEffect.hasNext() ) {
                            adaptor.addChild(root_1, stream_writesEffect.nextTree());

                        }
                        stream_writesEffect.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:379:4: writesEffect ( ';' readsEffect )?
                    {
                    pushFollow(FOLLOW_writesEffect_in_regionEffects1947);
                    writesEffect163=writesEffect();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_writesEffect.add(writesEffect163.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:379:17: ( ';' readsEffect )?
                    int alt27=2;
                    int LA27_0 = input.LA(1);

                    if ( (LA27_0==SEMI) ) {
                        alt27=1;
                    }
                    switch (alt27) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:379:18: ';' readsEffect
                            {
                            char_literal164=(Token)match(input,SEMI,FOLLOW_SEMI_in_regionEffects1950); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMI.add(char_literal164);

                            pushFollow(FOLLOW_readsEffect_in_regionEffects1952);
                            readsEffect165=readsEffect();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_readsEffect.add(readsEffect165.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: writesEffect, readsEffect
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 379:36: -> ^( RegionEffects writesEffect ( readsEffect )? )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:379:39: ^( RegionEffects writesEffect ( readsEffect )? )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionEffects, "RegionEffects"), root_1);

                        adaptor.addChild(root_1, stream_writesEffect.nextTree());
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:379:68: ( readsEffect )?
                        if ( stream_readsEffect.hasNext() ) {
                            adaptor.addChild(root_1, stream_readsEffect.nextTree());

                        }
                        stream_readsEffect.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionEffects"

    public static class regionSpecifications_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionSpecifications"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:383:1: regionSpecifications : regionSpecification ( ',' regionSpecification )* -> ^( RegionSpecifications ( regionSpecification )+ ) ;
    public final SLAnnotationsParser.regionSpecifications_return regionSpecifications() throws RecognitionException {
        SLAnnotationsParser.regionSpecifications_return retval = new SLAnnotationsParser.regionSpecifications_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal167=null;
        SLAnnotationsParser.regionSpecification_return regionSpecification166 = null;

        SLAnnotationsParser.regionSpecification_return regionSpecification168 = null;


        Tree char_literal167_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_regionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:387:2: ( regionSpecification ( ',' regionSpecification )* -> ^( RegionSpecifications ( regionSpecification )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:387:4: regionSpecification ( ',' regionSpecification )*
            {
            pushFollow(FOLLOW_regionSpecification_in_regionSpecifications1982);
            regionSpecification166=regionSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification166.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:387:24: ( ',' regionSpecification )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==COMMA) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:387:25: ',' regionSpecification
            	    {
            	    char_literal167=(Token)match(input,COMMA,FOLLOW_COMMA_in_regionSpecifications1985); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal167);

            	    pushFollow(FOLLOW_regionSpecification_in_regionSpecifications1987);
            	    regionSpecification168=regionSpecification();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification168.getTree());

            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);



            // AST REWRITE
            // elements: regionSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 387:51: -> ^( RegionSpecifications ( regionSpecification )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:387:54: ^( RegionSpecifications ( regionSpecification )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionSpecifications, "RegionSpecifications"), root_1);

                if ( !(stream_regionSpecification.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_regionSpecification.hasNext() ) {
                    adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                }
                stream_regionSpecification.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionSpecifications"

    public static class regionSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:390:1: regionSpecification : ( qualifiedRegionName | simpleRegionSpecification );
    public final SLAnnotationsParser.regionSpecification_return regionSpecification() throws RecognitionException {
        SLAnnotationsParser.regionSpecification_return retval = new SLAnnotationsParser.regionSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedRegionName_return qualifiedRegionName169 = null;

        SLAnnotationsParser.simpleRegionSpecification_return simpleRegionSpecification170 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:391:2: ( qualifiedRegionName | simpleRegionSpecification )
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==IDENTIFIER) ) {
                int LA30_1 = input.LA(2);

                if ( (LA30_1==DOT||LA30_1==COLON) ) {
                    alt30=1;
                }
                else if ( (LA30_1==EOF||LA30_1==INTO||LA30_1==COMMA) ) {
                    alt30=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 30, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA30_0==LBRACKET) ) {
                alt30=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }
            switch (alt30) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:391:4: qualifiedRegionName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedRegionName_in_regionSpecification2009);
                    qualifiedRegionName169=qualifiedRegionName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedRegionName169.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:392:4: simpleRegionSpecification
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleRegionSpecification_in_regionSpecification2015);
                    simpleRegionSpecification170=simpleRegionSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleRegionSpecification170.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionSpecification"

    public static class simpleRegionSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleRegionSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:395:1: simpleRegionSpecification : ( regionName | ( LBRACKET RBRACKET ) -> ^( RegionName LBRACKET RBRACKET ) );
    public final SLAnnotationsParser.simpleRegionSpecification_return simpleRegionSpecification() throws RecognitionException {
        SLAnnotationsParser.simpleRegionSpecification_return retval = new SLAnnotationsParser.simpleRegionSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token LBRACKET172=null;
        Token RBRACKET173=null;
        SLAnnotationsParser.regionName_return regionName171 = null;


        Tree LBRACKET172_tree=null;
        Tree RBRACKET173_tree=null;
        RewriteRuleTokenStream stream_LBRACKET=new RewriteRuleTokenStream(adaptor,"token LBRACKET");
        RewriteRuleTokenStream stream_RBRACKET=new RewriteRuleTokenStream(adaptor,"token RBRACKET");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:396:2: ( regionName | ( LBRACKET RBRACKET ) -> ^( RegionName LBRACKET RBRACKET ) )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==IDENTIFIER) ) {
                alt31=1;
            }
            else if ( (LA31_0==LBRACKET) ) {
                alt31=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:396:4: regionName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_regionName_in_simpleRegionSpecification2028);
                    regionName171=regionName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, regionName171.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:397:4: ( LBRACKET RBRACKET )
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:397:4: ( LBRACKET RBRACKET )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:397:5: LBRACKET RBRACKET
                    {
                    LBRACKET172=(Token)match(input,LBRACKET,FOLLOW_LBRACKET_in_simpleRegionSpecification2034); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_LBRACKET.add(LBRACKET172);

                    RBRACKET173=(Token)match(input,RBRACKET,FOLLOW_RBRACKET_in_simpleRegionSpecification2036); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_RBRACKET.add(RBRACKET173);


                    }



                    // AST REWRITE
                    // elements: LBRACKET, RBRACKET
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 397:24: -> ^( RegionName LBRACKET RBRACKET )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:397:27: ^( RegionName LBRACKET RBRACKET )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionName, "RegionName"), root_1);

                        adaptor.addChild(root_1, stream_LBRACKET.nextNode());
                        adaptor.addChild(root_1, stream_RBRACKET.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleRegionSpecification"

    public static class innerClassLockName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "innerClassLockName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:400:1: innerClassLockName : qualifiedThisExpression ':' IDENTIFIER -> ^( QualifiedLockName qualifiedThisExpression IDENTIFIER ) ;
    public final SLAnnotationsParser.innerClassLockName_return innerClassLockName() throws RecognitionException {
        SLAnnotationsParser.innerClassLockName_return retval = new SLAnnotationsParser.innerClassLockName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal175=null;
        Token IDENTIFIER176=null;
        SLAnnotationsParser.qualifiedThisExpression_return qualifiedThisExpression174 = null;


        Tree char_literal175_tree=null;
        Tree IDENTIFIER176_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_qualifiedThisExpression=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedThisExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:401:2: ( qualifiedThisExpression ':' IDENTIFIER -> ^( QualifiedLockName qualifiedThisExpression IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:401:4: qualifiedThisExpression ':' IDENTIFIER
            {
            pushFollow(FOLLOW_qualifiedThisExpression_in_innerClassLockName2058);
            qualifiedThisExpression174=qualifiedThisExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_qualifiedThisExpression.add(qualifiedThisExpression174.getTree());
            char_literal175=(Token)match(input,COLON,FOLLOW_COLON_in_innerClassLockName2060); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_COLON.add(char_literal175);

            IDENTIFIER176=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_innerClassLockName2062); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER176);



            // AST REWRITE
            // elements: IDENTIFIER, qualifiedThisExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 401:43: -> ^( QualifiedLockName qualifiedThisExpression IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:401:46: ^( QualifiedLockName qualifiedThisExpression IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedLockName, "QualifiedLockName"), root_1);

                adaptor.addChild(root_1, stream_qualifiedThisExpression.nextTree());
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "innerClassLockName"

    public static class typeQualifiedLockName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeQualifiedLockName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:404:1: typeQualifiedLockName : typeExpression ':' IDENTIFIER -> ^( QualifiedLockName typeExpression IDENTIFIER ) ;
    public final SLAnnotationsParser.typeQualifiedLockName_return typeQualifiedLockName() throws RecognitionException {
        SLAnnotationsParser.typeQualifiedLockName_return retval = new SLAnnotationsParser.typeQualifiedLockName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal178=null;
        Token IDENTIFIER179=null;
        SLAnnotationsParser.typeExpression_return typeExpression177 = null;


        Tree char_literal178_tree=null;
        Tree IDENTIFIER179_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_typeExpression=new RewriteRuleSubtreeStream(adaptor,"rule typeExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:405:2: ( typeExpression ':' IDENTIFIER -> ^( QualifiedLockName typeExpression IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:405:4: typeExpression ':' IDENTIFIER
            {
            pushFollow(FOLLOW_typeExpression_in_typeQualifiedLockName2083);
            typeExpression177=typeExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_typeExpression.add(typeExpression177.getTree());
            char_literal178=(Token)match(input,COLON,FOLLOW_COLON_in_typeQualifiedLockName2085); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_COLON.add(char_literal178);

            IDENTIFIER179=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_typeQualifiedLockName2087); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER179);



            // AST REWRITE
            // elements: IDENTIFIER, typeExpression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 405:34: -> ^( QualifiedLockName typeExpression IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:405:37: ^( QualifiedLockName typeExpression IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedLockName, "QualifiedLockName"), root_1);

                adaptor.addChild(root_1, stream_typeExpression.nextTree());
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeQualifiedLockName"

    public static class simpleLockName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleLockName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:408:1: simpleLockName : IDENTIFIER -> ^( SimpleLockName IDENTIFIER ) ;
    public final SLAnnotationsParser.simpleLockName_return simpleLockName() throws RecognitionException {
        SLAnnotationsParser.simpleLockName_return retval = new SLAnnotationsParser.simpleLockName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER180=null;

        Tree IDENTIFIER180_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:409:2: ( IDENTIFIER -> ^( SimpleLockName IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:409:4: IDENTIFIER
            {
            IDENTIFIER180=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleLockName2108); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER180);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 409:15: -> ^( SimpleLockName IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:409:18: ^( SimpleLockName IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(SimpleLockName, "SimpleLockName"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleLockName"

    public static class regionName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:412:1: regionName : IDENTIFIER -> ^( RegionName IDENTIFIER ) ;
    public final SLAnnotationsParser.regionName_return regionName() throws RecognitionException {
        SLAnnotationsParser.regionName_return retval = new SLAnnotationsParser.regionName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER181=null;

        Tree IDENTIFIER181_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:413:2: ( IDENTIFIER -> ^( RegionName IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:413:4: IDENTIFIER
            {
            IDENTIFIER181=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_regionName2128); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER181);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 413:15: -> ^( RegionName IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:413:18: ^( RegionName IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionName, "RegionName"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionName"

    public static class mappedRegionSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "mappedRegionSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:416:1: mappedRegionSpecification : regionMapping ( ',' regionMapping )* -> ^( MappedRegionSpecification ( regionMapping )+ ) ;
    public final SLAnnotationsParser.mappedRegionSpecification_return mappedRegionSpecification() throws RecognitionException {
        SLAnnotationsParser.mappedRegionSpecification_return retval = new SLAnnotationsParser.mappedRegionSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal183=null;
        SLAnnotationsParser.regionMapping_return regionMapping182 = null;

        SLAnnotationsParser.regionMapping_return regionMapping184 = null;


        Tree char_literal183_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_regionMapping=new RewriteRuleSubtreeStream(adaptor,"rule regionMapping");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:417:2: ( regionMapping ( ',' regionMapping )* -> ^( MappedRegionSpecification ( regionMapping )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:417:4: regionMapping ( ',' regionMapping )*
            {
            pushFollow(FOLLOW_regionMapping_in_mappedRegionSpecification2148);
            regionMapping182=regionMapping();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionMapping.add(regionMapping182.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:417:18: ( ',' regionMapping )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==COMMA) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:417:19: ',' regionMapping
            	    {
            	    char_literal183=(Token)match(input,COMMA,FOLLOW_COMMA_in_mappedRegionSpecification2151); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal183);

            	    pushFollow(FOLLOW_regionMapping_in_mappedRegionSpecification2153);
            	    regionMapping184=regionMapping();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_regionMapping.add(regionMapping184.getTree());

            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);



            // AST REWRITE
            // elements: regionMapping
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 417:39: -> ^( MappedRegionSpecification ( regionMapping )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:417:42: ^( MappedRegionSpecification ( regionMapping )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(MappedRegionSpecification, "MappedRegionSpecification"), root_1);

                if ( !(stream_regionMapping.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_regionMapping.hasNext() ) {
                    adaptor.addChild(root_1, stream_regionMapping.nextTree());

                }
                stream_regionMapping.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "mappedRegionSpecification"

    public static class fieldMappings_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldMappings"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:420:1: fieldMappings : regionSpecifications 'into' regionSpecification -> ^( FieldMappings regionSpecifications regionSpecification ) ;
    public final SLAnnotationsParser.fieldMappings_return fieldMappings() throws RecognitionException {
        SLAnnotationsParser.fieldMappings_return retval = new SLAnnotationsParser.fieldMappings_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal186=null;
        SLAnnotationsParser.regionSpecifications_return regionSpecifications185 = null;

        SLAnnotationsParser.regionSpecification_return regionSpecification187 = null;


        Tree string_literal186_tree=null;
        RewriteRuleTokenStream stream_INTO=new RewriteRuleTokenStream(adaptor,"token INTO");
        RewriteRuleSubtreeStream stream_regionSpecifications=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecifications");
        RewriteRuleSubtreeStream stream_regionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:421:2: ( regionSpecifications 'into' regionSpecification -> ^( FieldMappings regionSpecifications regionSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:421:4: regionSpecifications 'into' regionSpecification
            {
            pushFollow(FOLLOW_regionSpecifications_in_fieldMappings2176);
            regionSpecifications185=regionSpecifications();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionSpecifications.add(regionSpecifications185.getTree());
            string_literal186=(Token)match(input,INTO,FOLLOW_INTO_in_fieldMappings2178); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_INTO.add(string_literal186);

            pushFollow(FOLLOW_regionSpecification_in_fieldMappings2180);
            regionSpecification187=regionSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification187.getTree());


            // AST REWRITE
            // elements: regionSpecifications, regionSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 421:52: -> ^( FieldMappings regionSpecifications regionSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:421:55: ^( FieldMappings regionSpecifications regionSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldMappings, "FieldMappings"), root_1);

                adaptor.addChild(root_1, stream_regionSpecifications.nextTree());
                adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldMappings"

    public static class regionMapping_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "regionMapping"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:424:1: regionMapping : simpleRegionSpecification 'into' regionSpecification -> ^( RegionMapping simpleRegionSpecification regionSpecification ) ;
    public final SLAnnotationsParser.regionMapping_return regionMapping() throws RecognitionException {
        SLAnnotationsParser.regionMapping_return retval = new SLAnnotationsParser.regionMapping_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal189=null;
        SLAnnotationsParser.simpleRegionSpecification_return simpleRegionSpecification188 = null;

        SLAnnotationsParser.regionSpecification_return regionSpecification190 = null;


        Tree string_literal189_tree=null;
        RewriteRuleTokenStream stream_INTO=new RewriteRuleTokenStream(adaptor,"token INTO");
        RewriteRuleSubtreeStream stream_simpleRegionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule simpleRegionSpecification");
        RewriteRuleSubtreeStream stream_regionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule regionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:425:2: ( simpleRegionSpecification 'into' regionSpecification -> ^( RegionMapping simpleRegionSpecification regionSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:425:4: simpleRegionSpecification 'into' regionSpecification
            {
            pushFollow(FOLLOW_simpleRegionSpecification_in_regionMapping2201);
            simpleRegionSpecification188=simpleRegionSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_simpleRegionSpecification.add(simpleRegionSpecification188.getTree());
            string_literal189=(Token)match(input,INTO,FOLLOW_INTO_in_regionMapping2203); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_INTO.add(string_literal189);

            pushFollow(FOLLOW_regionSpecification_in_regionMapping2205);
            regionSpecification190=regionSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionSpecification.add(regionSpecification190.getTree());


            // AST REWRITE
            // elements: regionSpecification, simpleRegionSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 425:57: -> ^( RegionMapping simpleRegionSpecification regionSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:425:60: ^( RegionMapping simpleRegionSpecification regionSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(RegionMapping, "RegionMapping"), root_1);

                adaptor.addChild(root_1, stream_simpleRegionSpecification.nextTree());
                adaptor.addChild(root_1, stream_regionSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "regionMapping"

    public static class qualifiedRegionName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedRegionName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:428:1: qualifiedRegionName : ( qualifiedNamedType ':' IDENTIFIER -> ^( QualifiedRegionName qualifiedNamedType IDENTIFIER ) | simpleNamedType ':' IDENTIFIER -> ^( QualifiedRegionName simpleNamedType IDENTIFIER ) );
    public final SLAnnotationsParser.qualifiedRegionName_return qualifiedRegionName() throws RecognitionException {
        SLAnnotationsParser.qualifiedRegionName_return retval = new SLAnnotationsParser.qualifiedRegionName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal192=null;
        Token IDENTIFIER193=null;
        Token char_literal195=null;
        Token IDENTIFIER196=null;
        SLAnnotationsParser.qualifiedNamedType_return qualifiedNamedType191 = null;

        SLAnnotationsParser.simpleNamedType_return simpleNamedType194 = null;


        Tree char_literal192_tree=null;
        Tree IDENTIFIER193_tree=null;
        Tree char_literal195_tree=null;
        Tree IDENTIFIER196_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_qualifiedNamedType=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedNamedType");
        RewriteRuleSubtreeStream stream_simpleNamedType=new RewriteRuleSubtreeStream(adaptor,"rule simpleNamedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:429:2: ( qualifiedNamedType ':' IDENTIFIER -> ^( QualifiedRegionName qualifiedNamedType IDENTIFIER ) | simpleNamedType ':' IDENTIFIER -> ^( QualifiedRegionName simpleNamedType IDENTIFIER ) )
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==IDENTIFIER) ) {
                int LA33_1 = input.LA(2);

                if ( (LA33_1==DOT) ) {
                    alt33=1;
                }
                else if ( (LA33_1==COLON) ) {
                    alt33=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 33, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }
            switch (alt33) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:429:4: qualifiedNamedType ':' IDENTIFIER
                    {
                    pushFollow(FOLLOW_qualifiedNamedType_in_qualifiedRegionName2227);
                    qualifiedNamedType191=qualifiedNamedType();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_qualifiedNamedType.add(qualifiedNamedType191.getTree());
                    char_literal192=(Token)match(input,COLON,FOLLOW_COLON_in_qualifiedRegionName2229); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON.add(char_literal192);

                    IDENTIFIER193=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedRegionName2231); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER193);



                    // AST REWRITE
                    // elements: IDENTIFIER, qualifiedNamedType
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 429:38: -> ^( QualifiedRegionName qualifiedNamedType IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:429:41: ^( QualifiedRegionName qualifiedNamedType IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedRegionName, "QualifiedRegionName"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedNamedType.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:430:4: simpleNamedType ':' IDENTIFIER
                    {
                    pushFollow(FOLLOW_simpleNamedType_in_qualifiedRegionName2246);
                    simpleNamedType194=simpleNamedType();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_simpleNamedType.add(simpleNamedType194.getTree());
                    char_literal195=(Token)match(input,COLON,FOLLOW_COLON_in_qualifiedRegionName2248); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON.add(char_literal195);

                    IDENTIFIER196=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedRegionName2250); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER196);



                    // AST REWRITE
                    // elements: IDENTIFIER, simpleNamedType
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 430:35: -> ^( QualifiedRegionName simpleNamedType IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:430:38: ^( QualifiedRegionName simpleNamedType IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedRegionName, "QualifiedRegionName"), root_1);

                        adaptor.addChild(root_1, stream_simpleNamedType.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedRegionName"

    public static class effectsSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "effectsSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:433:1: effectsSpecification : ( NOTHING | effectSpecification ( ',' effectSpecification )* -> ( effectSpecification )+ );
    public final SLAnnotationsParser.effectsSpecification_return effectsSpecification() throws RecognitionException {
        SLAnnotationsParser.effectsSpecification_return retval = new SLAnnotationsParser.effectsSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token NOTHING197=null;
        Token char_literal199=null;
        SLAnnotationsParser.effectSpecification_return effectSpecification198 = null;

        SLAnnotationsParser.effectSpecification_return effectSpecification200 = null;


        Tree NOTHING197_tree=null;
        Tree char_literal199_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_effectSpecification=new RewriteRuleSubtreeStream(adaptor,"rule effectSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:434:2: ( NOTHING | effectSpecification ( ',' effectSpecification )* -> ( effectSpecification )+ )
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==NOTHING) ) {
                alt35=1;
            }
            else if ( (LA35_0==ANY||LA35_0==IDENTIFIER||LA35_0==THIS) ) {
                alt35=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }
            switch (alt35) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:434:4: NOTHING
                    {
                    root_0 = (Tree)adaptor.nil();

                    NOTHING197=(Token)match(input,NOTHING,FOLLOW_NOTHING_in_effectsSpecification2272); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    NOTHING197_tree = (Tree)adaptor.create(NOTHING197);
                    adaptor.addChild(root_0, NOTHING197_tree);
                    }

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:435:4: effectSpecification ( ',' effectSpecification )*
                    {
                    pushFollow(FOLLOW_effectSpecification_in_effectsSpecification2277);
                    effectSpecification198=effectSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_effectSpecification.add(effectSpecification198.getTree());
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:435:24: ( ',' effectSpecification )*
                    loop34:
                    do {
                        int alt34=2;
                        int LA34_0 = input.LA(1);

                        if ( (LA34_0==COMMA) ) {
                            alt34=1;
                        }


                        switch (alt34) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:435:25: ',' effectSpecification
                    	    {
                    	    char_literal199=(Token)match(input,COMMA,FOLLOW_COMMA_in_effectsSpecification2280); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_COMMA.add(char_literal199);

                    	    pushFollow(FOLLOW_effectSpecification_in_effectsSpecification2282);
                    	    effectSpecification200=effectSpecification();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_effectSpecification.add(effectSpecification200.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop34;
                        }
                    } while (true);



                    // AST REWRITE
                    // elements: effectSpecification
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 435:51: -> ( effectSpecification )+
                    {
                        if ( !(stream_effectSpecification.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_effectSpecification.hasNext() ) {
                            adaptor.addChild(root_0, stream_effectSpecification.nextTree());

                        }
                        stream_effectSpecification.reset();

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "effectsSpecification"

    public static class effectSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "effectSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:438:1: effectSpecification : ( simpleEffectExpression ':' simpleRegionSpecification -> ^( EffectSpecification simpleEffectExpression simpleRegionSpecification ) | implicitThisEffectSpecification );
    public final SLAnnotationsParser.effectSpecification_return effectSpecification() throws RecognitionException {
        SLAnnotationsParser.effectSpecification_return retval = new SLAnnotationsParser.effectSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal202=null;
        SLAnnotationsParser.simpleEffectExpression_return simpleEffectExpression201 = null;

        SLAnnotationsParser.simpleRegionSpecification_return simpleRegionSpecification203 = null;

        SLAnnotationsParser.implicitThisEffectSpecification_return implicitThisEffectSpecification204 = null;


        Tree char_literal202_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleSubtreeStream stream_simpleEffectExpression=new RewriteRuleSubtreeStream(adaptor,"rule simpleEffectExpression");
        RewriteRuleSubtreeStream stream_simpleRegionSpecification=new RewriteRuleSubtreeStream(adaptor,"rule simpleRegionSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:439:2: ( simpleEffectExpression ':' simpleRegionSpecification -> ^( EffectSpecification simpleEffectExpression simpleRegionSpecification ) | implicitThisEffectSpecification )
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==ANY||LA36_0==THIS) ) {
                alt36=1;
            }
            else if ( (LA36_0==IDENTIFIER) ) {
                int LA36_2 = input.LA(2);

                if ( (LA36_2==DOT||LA36_2==COLON) ) {
                    alt36=1;
                }
                else if ( (LA36_2==EOF||LA36_2==SEMI||LA36_2==COMMA) ) {
                    alt36=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 36, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }
            switch (alt36) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:439:4: simpleEffectExpression ':' simpleRegionSpecification
                    {
                    pushFollow(FOLLOW_simpleEffectExpression_in_effectSpecification2301);
                    simpleEffectExpression201=simpleEffectExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_simpleEffectExpression.add(simpleEffectExpression201.getTree());
                    char_literal202=(Token)match(input,COLON,FOLLOW_COLON_in_effectSpecification2303); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON.add(char_literal202);

                    pushFollow(FOLLOW_simpleRegionSpecification_in_effectSpecification2305);
                    simpleRegionSpecification203=simpleRegionSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_simpleRegionSpecification.add(simpleRegionSpecification203.getTree());


                    // AST REWRITE
                    // elements: simpleEffectExpression, simpleRegionSpecification
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 439:57: -> ^( EffectSpecification simpleEffectExpression simpleRegionSpecification )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:439:60: ^( EffectSpecification simpleEffectExpression simpleRegionSpecification )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(EffectSpecification, "EffectSpecification"), root_1);

                        adaptor.addChild(root_1, stream_simpleEffectExpression.nextTree());
                        adaptor.addChild(root_1, stream_simpleRegionSpecification.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:440:4: implicitThisEffectSpecification
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_implicitThisEffectSpecification_in_effectSpecification2320);
                    implicitThisEffectSpecification204=implicitThisEffectSpecification();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, implicitThisEffectSpecification204.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "effectSpecification"

    public static class implicitThisEffectSpecification_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "implicitThisEffectSpecification"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:443:1: implicitThisEffectSpecification : regionName -> ^( EffectSpecification ^( ThisExpression THIS ) regionName ) ;
    public final SLAnnotationsParser.implicitThisEffectSpecification_return implicitThisEffectSpecification() throws RecognitionException {
        SLAnnotationsParser.implicitThisEffectSpecification_return retval = new SLAnnotationsParser.implicitThisEffectSpecification_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.regionName_return regionName205 = null;


        RewriteRuleSubtreeStream stream_regionName=new RewriteRuleSubtreeStream(adaptor,"rule regionName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:444:2: ( regionName -> ^( EffectSpecification ^( ThisExpression THIS ) regionName ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:444:4: regionName
            {
            pushFollow(FOLLOW_regionName_in_implicitThisEffectSpecification2331);
            regionName205=regionName();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_regionName.add(regionName205.getTree());


            // AST REWRITE
            // elements: regionName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 444:15: -> ^( EffectSpecification ^( ThisExpression THIS ) regionName )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:444:18: ^( EffectSpecification ^( ThisExpression THIS ) regionName )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(EffectSpecification, "EffectSpecification"), root_1);

                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:444:40: ^( ThisExpression THIS )
                {
                Tree root_2 = (Tree)adaptor.nil();
                root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ThisExpression, "ThisExpression"), root_2);

                adaptor.addChild(root_2, (Tree)adaptor.create(THIS, "THIS"));

                adaptor.addChild(root_1, root_2);
                }
                adaptor.addChild(root_1, stream_regionName.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "implicitThisEffectSpecification"

    public static class simpleEffectExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleEffectExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:447:1: simpleEffectExpression : ( anyInstanceExpression | qualifiedThisExpression | qualifiedNamedType -> ^( TypeExpression qualifiedNamedType ) | simpleExpression );
    public final SLAnnotationsParser.simpleEffectExpression_return simpleEffectExpression() throws RecognitionException {
        SLAnnotationsParser.simpleEffectExpression_return retval = new SLAnnotationsParser.simpleEffectExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.anyInstanceExpression_return anyInstanceExpression206 = null;

        SLAnnotationsParser.qualifiedThisExpression_return qualifiedThisExpression207 = null;

        SLAnnotationsParser.qualifiedNamedType_return qualifiedNamedType208 = null;

        SLAnnotationsParser.simpleExpression_return simpleExpression209 = null;


        RewriteRuleSubtreeStream stream_qualifiedNamedType=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedNamedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:448:2: ( anyInstanceExpression | qualifiedThisExpression | qualifiedNamedType -> ^( TypeExpression qualifiedNamedType ) | simpleExpression )
            int alt37=4;
            alt37 = dfa37.predict(input);
            switch (alt37) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:448:4: anyInstanceExpression
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_anyInstanceExpression_in_simpleEffectExpression2356);
                    anyInstanceExpression206=anyInstanceExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, anyInstanceExpression206.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:449:4: qualifiedThisExpression
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedThisExpression_in_simpleEffectExpression2361);
                    qualifiedThisExpression207=qualifiedThisExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedThisExpression207.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:450:4: qualifiedNamedType
                    {
                    pushFollow(FOLLOW_qualifiedNamedType_in_simpleEffectExpression2366);
                    qualifiedNamedType208=qualifiedNamedType();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_qualifiedNamedType.add(qualifiedNamedType208.getTree());


                    // AST REWRITE
                    // elements: qualifiedNamedType
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 450:23: -> ^( TypeExpression qualifiedNamedType )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:450:26: ^( TypeExpression qualifiedNamedType )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeExpression, "TypeExpression"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedNamedType.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:451:4: simpleExpression
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleExpression_in_simpleEffectExpression2379);
                    simpleExpression209=simpleExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleExpression209.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleEffectExpression"

    public static class anyInstanceExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "anyInstanceExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:454:1: anyInstanceExpression : ANY '(' namedType ')' -> ^( AnyInstanceExpression namedType ) ;
    public final SLAnnotationsParser.anyInstanceExpression_return anyInstanceExpression() throws RecognitionException {
        SLAnnotationsParser.anyInstanceExpression_return retval = new SLAnnotationsParser.anyInstanceExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token ANY210=null;
        Token char_literal211=null;
        Token char_literal213=null;
        SLAnnotationsParser.namedType_return namedType212 = null;


        Tree ANY210_tree=null;
        Tree char_literal211_tree=null;
        Tree char_literal213_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_ANY=new RewriteRuleTokenStream(adaptor,"token ANY");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:455:2: ( ANY '(' namedType ')' -> ^( AnyInstanceExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:455:4: ANY '(' namedType ')'
            {
            ANY210=(Token)match(input,ANY,FOLLOW_ANY_in_anyInstanceExpression2391); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ANY.add(ANY210);

            char_literal211=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_anyInstanceExpression2393); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_LPAREN.add(char_literal211);

            pushFollow(FOLLOW_namedType_in_anyInstanceExpression2395);
            namedType212=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType212.getTree());
            char_literal213=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_anyInstanceExpression2397); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RPAREN.add(char_literal213);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 455:26: -> ^( AnyInstanceExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:455:29: ^( AnyInstanceExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(AnyInstanceExpression, "AnyInstanceExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "anyInstanceExpression"

    public static class readsEffect_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "readsEffect"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:458:1: readsEffect : 'reads' effectsSpecification -> ^( Reads effectsSpecification ) ;
    public final SLAnnotationsParser.readsEffect_return readsEffect() throws RecognitionException {
        SLAnnotationsParser.readsEffect_return retval = new SLAnnotationsParser.readsEffect_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal214=null;
        SLAnnotationsParser.effectsSpecification_return effectsSpecification215 = null;


        Tree string_literal214_tree=null;
        RewriteRuleTokenStream stream_183=new RewriteRuleTokenStream(adaptor,"token 183");
        RewriteRuleSubtreeStream stream_effectsSpecification=new RewriteRuleSubtreeStream(adaptor,"rule effectsSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:459:2: ( 'reads' effectsSpecification -> ^( Reads effectsSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:459:3: 'reads' effectsSpecification
            {
            string_literal214=(Token)match(input,183,FOLLOW_183_in_readsEffect2416); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_183.add(string_literal214);

            pushFollow(FOLLOW_effectsSpecification_in_readsEffect2418);
            effectsSpecification215=effectsSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_effectsSpecification.add(effectsSpecification215.getTree());


            // AST REWRITE
            // elements: effectsSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 459:32: -> ^( Reads effectsSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:459:35: ^( Reads effectsSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Reads, "Reads"), root_1);

                adaptor.addChild(root_1, stream_effectsSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "readsEffect"

    public static class writesEffect_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "writesEffect"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:461:1: writesEffect : 'writes' effectsSpecification -> ^( Writes effectsSpecification ) ;
    public final SLAnnotationsParser.writesEffect_return writesEffect() throws RecognitionException {
        SLAnnotationsParser.writesEffect_return retval = new SLAnnotationsParser.writesEffect_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal216=null;
        SLAnnotationsParser.effectsSpecification_return effectsSpecification217 = null;


        Tree string_literal216_tree=null;
        RewriteRuleTokenStream stream_184=new RewriteRuleTokenStream(adaptor,"token 184");
        RewriteRuleSubtreeStream stream_effectsSpecification=new RewriteRuleSubtreeStream(adaptor,"rule effectsSpecification");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:462:2: ( 'writes' effectsSpecification -> ^( Writes effectsSpecification ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:462:3: 'writes' effectsSpecification
            {
            string_literal216=(Token)match(input,184,FOLLOW_184_in_writesEffect2435); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_184.add(string_literal216);

            pushFollow(FOLLOW_effectsSpecification_in_writesEffect2437);
            effectsSpecification217=effectsSpecification();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_effectsSpecification.add(effectsSpecification217.getTree());


            // AST REWRITE
            // elements: effectsSpecification
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 462:33: -> ^( Writes effectsSpecification )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:462:36: ^( Writes effectsSpecification )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Writes, "Writes"), root_1);

                adaptor.addChild(root_1, stream_effectsSpecification.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "writesEffect"

    public static class qualifiedClassExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedClassExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:466:1: qualifiedClassExpression : namedType '.' CLASS -> ^( ClassExpression namedType ) ;
    public final SLAnnotationsParser.qualifiedClassExpression_return qualifiedClassExpression() throws RecognitionException {
        SLAnnotationsParser.qualifiedClassExpression_return retval = new SLAnnotationsParser.qualifiedClassExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal219=null;
        Token CLASS220=null;
        SLAnnotationsParser.namedType_return namedType218 = null;


        Tree char_literal219_tree=null;
        Tree CLASS220_tree=null;
        RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:471:2: ( namedType '.' CLASS -> ^( ClassExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:471:4: namedType '.' CLASS
            {
            pushFollow(FOLLOW_namedType_in_qualifiedClassExpression2462);
            namedType218=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType218.getTree());
            char_literal219=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedClassExpression2464); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOT.add(char_literal219);

            CLASS220=(Token)match(input,CLASS,FOLLOW_CLASS_in_qualifiedClassExpression2466); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLASS.add(CLASS220);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 471:24: -> ^( ClassExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:471:27: ^( ClassExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ClassExpression, "ClassExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedClassExpression"

    public static class qualifiedThisExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedThisExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:474:1: qualifiedThisExpression : namedType '.' THIS -> ^( QualifiedThisExpression namedType ) ;
    public final SLAnnotationsParser.qualifiedThisExpression_return qualifiedThisExpression() throws RecognitionException {
        SLAnnotationsParser.qualifiedThisExpression_return retval = new SLAnnotationsParser.qualifiedThisExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal222=null;
        Token THIS223=null;
        SLAnnotationsParser.namedType_return namedType221 = null;


        Tree char_literal222_tree=null;
        Tree THIS223_tree=null;
        RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:475:2: ( namedType '.' THIS -> ^( QualifiedThisExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:475:4: namedType '.' THIS
            {
            pushFollow(FOLLOW_namedType_in_qualifiedThisExpression2487);
            namedType221=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType221.getTree());
            char_literal222=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedThisExpression2489); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOT.add(char_literal222);

            THIS223=(Token)match(input,THIS,FOLLOW_THIS_in_qualifiedThisExpression2491); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_THIS.add(THIS223);



            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 475:23: -> ^( QualifiedThisExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:475:26: ^( QualifiedThisExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(QualifiedThisExpression, "QualifiedThisExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedThisExpression"

    public static class typeExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:478:1: typeExpression : namedType -> ^( TypeExpression namedType ) ;
    public final SLAnnotationsParser.typeExpression_return typeExpression() throws RecognitionException {
        SLAnnotationsParser.typeExpression_return retval = new SLAnnotationsParser.typeExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.namedType_return namedType224 = null;


        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:479:2: ( namedType -> ^( TypeExpression namedType ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:479:4: namedType
            {
            pushFollow(FOLLOW_namedType_in_typeExpression2512);
            namedType224=namedType();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_namedType.add(namedType224.getTree());


            // AST REWRITE
            // elements: namedType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 479:14: -> ^( TypeExpression namedType )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:479:17: ^( TypeExpression namedType )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeExpression, "TypeExpression"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeExpression"

    public static class fieldRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:482:1: fieldRef : ( qualifiedFieldRef | simpleFieldRef );
    public final SLAnnotationsParser.fieldRef_return fieldRef() throws RecognitionException {
        SLAnnotationsParser.fieldRef_return retval = new SLAnnotationsParser.fieldRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedFieldRef_return qualifiedFieldRef225 = null;

        SLAnnotationsParser.simpleFieldRef_return simpleFieldRef226 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:483:3: ( qualifiedFieldRef | simpleFieldRef )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==IDENTIFIER) ) {
                int LA38_1 = input.LA(2);

                if ( (LA38_1==EOF) ) {
                    alt38=2;
                }
                else if ( (LA38_1==DOT) ) {
                    alt38=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 38, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA38_0==THIS) ) {
                alt38=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:483:5: qualifiedFieldRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedFieldRef_in_fieldRef2532);
                    qualifiedFieldRef225=qualifiedFieldRef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedFieldRef225.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:484:5: simpleFieldRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleFieldRef_in_fieldRef2538);
                    simpleFieldRef226=simpleFieldRef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleFieldRef226.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldRef"

    public static class qualifiedFieldRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedFieldRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:487:1: qualifiedFieldRef : ( typeExpression '.' IDENTIFIER -> ^( FieldRef typeExpression IDENTIFIER ) | qualifiedThisExpression '.' IDENTIFIER -> ^( FieldRef qualifiedThisExpression IDENTIFIER ) );
    public final SLAnnotationsParser.qualifiedFieldRef_return qualifiedFieldRef() throws RecognitionException {
        SLAnnotationsParser.qualifiedFieldRef_return retval = new SLAnnotationsParser.qualifiedFieldRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal228=null;
        Token IDENTIFIER229=null;
        Token char_literal231=null;
        Token IDENTIFIER232=null;
        SLAnnotationsParser.typeExpression_return typeExpression227 = null;

        SLAnnotationsParser.qualifiedThisExpression_return qualifiedThisExpression230 = null;


        Tree char_literal228_tree=null;
        Tree IDENTIFIER229_tree=null;
        Tree char_literal231_tree=null;
        Tree IDENTIFIER232_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_typeExpression=new RewriteRuleSubtreeStream(adaptor,"rule typeExpression");
        RewriteRuleSubtreeStream stream_qualifiedThisExpression=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedThisExpression");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:488:2: ( typeExpression '.' IDENTIFIER -> ^( FieldRef typeExpression IDENTIFIER ) | qualifiedThisExpression '.' IDENTIFIER -> ^( FieldRef qualifiedThisExpression IDENTIFIER ) )
            int alt39=2;
            alt39 = dfa39.predict(input);
            switch (alt39) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:488:4: typeExpression '.' IDENTIFIER
                    {
                    pushFollow(FOLLOW_typeExpression_in_qualifiedFieldRef2550);
                    typeExpression227=typeExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_typeExpression.add(typeExpression227.getTree());
                    char_literal228=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedFieldRef2552); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(char_literal228);

                    IDENTIFIER229=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedFieldRef2554); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER229);



                    // AST REWRITE
                    // elements: IDENTIFIER, typeExpression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 488:34: -> ^( FieldRef typeExpression IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:488:37: ^( FieldRef typeExpression IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                        adaptor.addChild(root_1, stream_typeExpression.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:489:4: qualifiedThisExpression '.' IDENTIFIER
                    {
                    pushFollow(FOLLOW_qualifiedThisExpression_in_qualifiedFieldRef2569);
                    qualifiedThisExpression230=qualifiedThisExpression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_qualifiedThisExpression.add(qualifiedThisExpression230.getTree());
                    char_literal231=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedFieldRef2571); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(char_literal231);

                    IDENTIFIER232=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedFieldRef2573); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER232);



                    // AST REWRITE
                    // elements: qualifiedThisExpression, IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 489:43: -> ^( FieldRef qualifiedThisExpression IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:489:46: ^( FieldRef qualifiedThisExpression IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                        adaptor.addChild(root_1, stream_qualifiedThisExpression.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedFieldRef"

    public static class namedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "namedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:492:1: namedType : ( simpleNamedType | qualifiedNamedType );
    public final SLAnnotationsParser.namedType_return namedType() throws RecognitionException {
        SLAnnotationsParser.namedType_return retval = new SLAnnotationsParser.namedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.simpleNamedType_return simpleNamedType233 = null;

        SLAnnotationsParser.qualifiedNamedType_return qualifiedNamedType234 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:493:4: ( simpleNamedType | qualifiedNamedType )
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==IDENTIFIER) ) {
                int LA40_1 = input.LA(2);

                if ( (LA40_1==DOT) ) {
                    int LA40_2 = input.LA(3);

                    if ( (LA40_2==CLASS||LA40_2==THIS) ) {
                        alt40=1;
                    }
                    else if ( (LA40_2==IDENTIFIER) ) {
                        int LA40_4 = input.LA(4);

                        if ( (LA40_4==DOT||LA40_4==COLON||LA40_4==RPAREN) ) {
                            alt40=2;
                        }
                        else if ( (LA40_4==EOF||LA40_4==PROTECTS) ) {
                            alt40=1;
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return retval;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 40, 4, input);

                            throw nvae;
                        }
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 40, 2, input);

                        throw nvae;
                    }
                }
                else if ( (LA40_1==COLON||LA40_1==RPAREN) ) {
                    alt40=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 40, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }
            switch (alt40) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:493:6: simpleNamedType
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_simpleNamedType_in_namedType2596);
                    simpleNamedType233=simpleNamedType();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleNamedType233.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:494:6: qualifiedNamedType
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedNamedType_in_namedType2603);
                    qualifiedNamedType234=qualifiedNamedType();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedNamedType234.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "namedType"

    public static class qualifiedNamedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedNamedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:497:1: qualifiedNamedType : qualifiedName -> ^( NamedType qualifiedName ) ;
    public final SLAnnotationsParser.qualifiedNamedType_return qualifiedNamedType() throws RecognitionException {
        SLAnnotationsParser.qualifiedNamedType_return retval = new SLAnnotationsParser.qualifiedNamedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.qualifiedName_return qualifiedName235 = null;


        RewriteRuleSubtreeStream stream_qualifiedName=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:498:2: ( qualifiedName -> ^( NamedType qualifiedName ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:498:4: qualifiedName
            {
            pushFollow(FOLLOW_qualifiedName_in_qualifiedNamedType2624);
            qualifiedName235=qualifiedName();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_qualifiedName.add(qualifiedName235.getTree());


            // AST REWRITE
            // elements: qualifiedName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 498:18: -> ^( NamedType qualifiedName )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:498:21: ^( NamedType qualifiedName )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedType, "NamedType"), root_1);

                adaptor.addChild(root_1, stream_qualifiedName.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedNamedType"

    public static class typeName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:501:1: typeName : ({...}? IDENTIFIER | qualifiedTypeName );
    public final SLAnnotationsParser.typeName_return typeName() throws RecognitionException {
        SLAnnotationsParser.typeName_return retval = new SLAnnotationsParser.typeName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER236=null;
        SLAnnotationsParser.qualifiedTypeName_return qualifiedTypeName237 = null;


        Tree IDENTIFIER236_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:502:4: ({...}? IDENTIFIER | qualifiedTypeName )
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==IDENTIFIER) ) {
                int LA41_1 = input.LA(2);

                if ( ((isType("", SLAnnotationsParser.this.input.LT(1)))) ) {
                    alt41=1;
                }
                else if ( (true) ) {
                    alt41=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 41, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 41, 0, input);

                throw nvae;
            }
            switch (alt41) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:502:6: {...}? IDENTIFIER
                    {
                    root_0 = (Tree)adaptor.nil();

                    if ( !((isType("", SLAnnotationsParser.this.input.LT(1)))) ) {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        throw new FailedPredicateException(input, "typeName", "isType(\"\", SLAnnotationsParser.this.input.LT(1))");
                    }
                    IDENTIFIER236=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_typeName2647); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IDENTIFIER236_tree = (Tree)adaptor.create(IDENTIFIER236);
                    adaptor.addChild(root_0, IDENTIFIER236_tree);
                    }

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:503:6: qualifiedTypeName
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_qualifiedTypeName_in_typeName2654);
                    qualifiedTypeName237=qualifiedTypeName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedTypeName237.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeName"

    public static class qualifiedTypeName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedTypeName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:506:1: qualifiedTypeName : IDENTIFIER ({...}? '.' IDENTIFIER )* ;
    public final SLAnnotationsParser.qualifiedTypeName_return qualifiedTypeName() throws RecognitionException {
        SLAnnotationsParser.qualifiedTypeName_return retval = new SLAnnotationsParser.qualifiedTypeName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER238=null;
        Token char_literal239=null;
        Token IDENTIFIER240=null;

        Tree IDENTIFIER238_tree=null;
        Tree char_literal239_tree=null;
        Tree IDENTIFIER240_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:507:2: ( IDENTIFIER ({...}? '.' IDENTIFIER )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:507:4: IDENTIFIER ({...}? '.' IDENTIFIER )*
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER238=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedTypeName2672); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER238_tree = (Tree)adaptor.create(IDENTIFIER238);
            adaptor.addChild(root_0, IDENTIFIER238_tree);
            }
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:507:15: ({...}? '.' IDENTIFIER )*
            loop42:
            do {
                int alt42=2;
                int LA42_0 = input.LA(1);

                if ( (LA42_0==DOT) ) {
                    alt42=1;
                }


                switch (alt42) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:507:16: {...}? '.' IDENTIFIER
            	    {
            	    if ( !((isType(input.toString(retval.start,input.LT(-1)), SLAnnotationsParser.this.input.LT(2)))) ) {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        throw new FailedPredicateException(input, "qualifiedTypeName", "isType($qualifiedTypeName.text, SLAnnotationsParser.this.input.LT(2))");
            	    }
            	    char_literal239=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedTypeName2693); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal239_tree = (Tree)adaptor.create(char_literal239);
            	    adaptor.addChild(root_0, char_literal239_tree);
            	    }
            	    IDENTIFIER240=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedTypeName2695); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    IDENTIFIER240_tree = (Tree)adaptor.create(IDENTIFIER240);
            	    adaptor.addChild(root_0, IDENTIFIER240_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop42;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedTypeName"

    public static class simpleNamedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleNamedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:511:1: simpleNamedType : IDENTIFIER -> ^( NamedType IDENTIFIER ) ;
    public final SLAnnotationsParser.simpleNamedType_return simpleNamedType() throws RecognitionException {
        SLAnnotationsParser.simpleNamedType_return retval = new SLAnnotationsParser.simpleNamedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER241=null;

        Tree IDENTIFIER241_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:512:2: ( IDENTIFIER -> ^( NamedType IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:512:4: IDENTIFIER
            {
            IDENTIFIER241=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleNamedType2724); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER241);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 512:15: -> ^( NamedType IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:512:18: ^( NamedType IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedType, "NamedType"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleNamedType"

    public static class simpleFieldRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleFieldRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:515:1: simpleFieldRef : ( thisExpr DOT IDENTIFIER -> ^( FieldRef thisExpr IDENTIFIER ) | IDENTIFIER -> ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER ) );
    public final SLAnnotationsParser.simpleFieldRef_return simpleFieldRef() throws RecognitionException {
        SLAnnotationsParser.simpleFieldRef_return retval = new SLAnnotationsParser.simpleFieldRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token DOT243=null;
        Token IDENTIFIER244=null;
        Token IDENTIFIER245=null;
        SLAnnotationsParser.thisExpr_return thisExpr242 = null;


        Tree DOT243_tree=null;
        Tree IDENTIFIER244_tree=null;
        Tree IDENTIFIER245_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_thisExpr=new RewriteRuleSubtreeStream(adaptor,"rule thisExpr");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:516:3: ( thisExpr DOT IDENTIFIER -> ^( FieldRef thisExpr IDENTIFIER ) | IDENTIFIER -> ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER ) )
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==THIS) ) {
                alt43=1;
            }
            else if ( (LA43_0==IDENTIFIER) ) {
                alt43=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 43, 0, input);

                throw nvae;
            }
            switch (alt43) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:516:5: thisExpr DOT IDENTIFIER
                    {
                    pushFollow(FOLLOW_thisExpr_in_simpleFieldRef2745);
                    thisExpr242=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_thisExpr.add(thisExpr242.getTree());
                    DOT243=(Token)match(input,DOT,FOLLOW_DOT_in_simpleFieldRef2747); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(DOT243);

                    IDENTIFIER244=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleFieldRef2749); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER244);



                    // AST REWRITE
                    // elements: IDENTIFIER, thisExpr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 516:29: -> ^( FieldRef thisExpr IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:516:32: ^( FieldRef thisExpr IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                        adaptor.addChild(root_1, stream_thisExpr.nextTree());
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:517:4: IDENTIFIER
                    {
                    IDENTIFIER245=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleFieldRef2765); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER245);



                    // AST REWRITE
                    // elements: IDENTIFIER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 517:15: -> ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:517:18: ^( FieldRef ^( ThisExpression THIS ) IDENTIFIER )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(FieldRef, "FieldRef"), root_1);

                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:517:29: ^( ThisExpression THIS )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ThisExpression, "ThisExpression"), root_2);

                        adaptor.addChild(root_2, (Tree)adaptor.create(THIS, "THIS"));

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleFieldRef"

    public static class simpleExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleExpression"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:520:1: simpleExpression : ( thisExpr | varUse );
    public final SLAnnotationsParser.simpleExpression_return simpleExpression() throws RecognitionException {
        SLAnnotationsParser.simpleExpression_return retval = new SLAnnotationsParser.simpleExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        SLAnnotationsParser.thisExpr_return thisExpr246 = null;

        SLAnnotationsParser.varUse_return varUse247 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:525:2: ( thisExpr | varUse )
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==THIS) ) {
                alt44=1;
            }
            else if ( (LA44_0==IDENTIFIER) ) {
                alt44=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 44, 0, input);

                throw nvae;
            }
            switch (alt44) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:525:4: thisExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_thisExpr_in_simpleExpression2796);
                    thisExpr246=thisExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, thisExpr246.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:526:4: varUse
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_varUse_in_simpleExpression2802);
                    varUse247=varUse();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, varUse247.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleExpression"

    public static class varUse_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "varUse"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:529:1: varUse : IDENTIFIER -> ^( VariableUseExpression IDENTIFIER ) ;
    public final SLAnnotationsParser.varUse_return varUse() throws RecognitionException {
        SLAnnotationsParser.varUse_return retval = new SLAnnotationsParser.varUse_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER248=null;

        Tree IDENTIFIER248_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:530:6: ( IDENTIFIER -> ^( VariableUseExpression IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:530:8: IDENTIFIER
            {
            IDENTIFIER248=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_varUse2817); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IDENTIFIER.add(IDENTIFIER248);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 530:19: -> ^( VariableUseExpression IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:530:22: ^( VariableUseExpression IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(VariableUseExpression, "VariableUseExpression"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "varUse"

    public static class classExpr_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classExpr"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:533:1: classExpr : ( CLASS -> ^( ImplicitClassLockExpression THIS ) | ( THIS '.' CLASS ) -> ^( ImplicitClassLockExpression THIS ) );
    public final SLAnnotationsParser.classExpr_return classExpr() throws RecognitionException {
        SLAnnotationsParser.classExpr_return retval = new SLAnnotationsParser.classExpr_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token CLASS249=null;
        Token THIS250=null;
        Token char_literal251=null;
        Token CLASS252=null;

        Tree CLASS249_tree=null;
        Tree THIS250_tree=null;
        Tree char_literal251_tree=null;
        Tree CLASS252_tree=null;
        RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
        RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:534:5: ( CLASS -> ^( ImplicitClassLockExpression THIS ) | ( THIS '.' CLASS ) -> ^( ImplicitClassLockExpression THIS ) )
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==CLASS) ) {
                alt45=1;
            }
            else if ( (LA45_0==THIS) ) {
                alt45=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 45, 0, input);

                throw nvae;
            }
            switch (alt45) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:534:7: CLASS
                    {
                    CLASS249=(Token)match(input,CLASS,FOLLOW_CLASS_in_classExpr2844); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLASS.add(CLASS249);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 534:13: -> ^( ImplicitClassLockExpression THIS )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:534:16: ^( ImplicitClassLockExpression THIS )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ImplicitClassLockExpression, "ImplicitClassLockExpression"), root_1);

                        adaptor.addChild(root_1, (Tree)adaptor.create(THIS, "THIS"));

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:535:7: ( THIS '.' CLASS )
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:535:7: ( THIS '.' CLASS )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:535:8: THIS '.' CLASS
                    {
                    THIS250=(Token)match(input,THIS,FOLLOW_THIS_in_classExpr2861); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_THIS.add(THIS250);

                    char_literal251=(Token)match(input,DOT,FOLLOW_DOT_in_classExpr2863); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOT.add(char_literal251);

                    CLASS252=(Token)match(input,CLASS,FOLLOW_CLASS_in_classExpr2865); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLASS.add(CLASS252);


                    }



                    // AST REWRITE
                    // elements: THIS
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 535:24: -> ^( ImplicitClassLockExpression THIS )
                    {
                        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:535:27: ^( ImplicitClassLockExpression THIS )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ImplicitClassLockExpression, "ImplicitClassLockExpression"), root_1);

                        adaptor.addChild(root_1, stream_THIS.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "classExpr"

    public static class thisExpr_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "thisExpr"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:538:1: thisExpr : THIS -> ^( ThisExpression THIS ) ;
    public final SLAnnotationsParser.thisExpr_return thisExpr() throws RecognitionException {
        SLAnnotationsParser.thisExpr_return retval = new SLAnnotationsParser.thisExpr_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token THIS253=null;

        Tree THIS253_tree=null;
        RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:539:5: ( THIS -> ^( ThisExpression THIS ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:539:7: THIS
            {
            THIS253=(Token)match(input,THIS,FOLLOW_THIS_in_thisExpr2894); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_THIS.add(THIS253);



            // AST REWRITE
            // elements: THIS
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 539:12: -> ^( ThisExpression THIS )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:539:15: ^( ThisExpression THIS )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ThisExpression, "ThisExpression"), root_1);

                adaptor.addChild(root_1, stream_THIS.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "thisExpr"

    public static class returnValue_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "returnValue"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:542:1: returnValue : RETURN -> ^( ReturnValueDeclaration RETURN ) ;
    public final SLAnnotationsParser.returnValue_return returnValue() throws RecognitionException {
        SLAnnotationsParser.returnValue_return retval = new SLAnnotationsParser.returnValue_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token RETURN254=null;

        Tree RETURN254_tree=null;
        RewriteRuleTokenStream stream_RETURN=new RewriteRuleTokenStream(adaptor,"token RETURN");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:543:5: ( RETURN -> ^( ReturnValueDeclaration RETURN ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:543:7: RETURN
            {
            RETURN254=(Token)match(input,RETURN,FOLLOW_RETURN_in_returnValue2923); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_RETURN.add(RETURN254);



            // AST REWRITE
            // elements: RETURN
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 543:14: -> ^( ReturnValueDeclaration RETURN )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:543:17: ^( ReturnValueDeclaration RETURN )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ReturnValueDeclaration, "ReturnValueDeclaration"), root_1);

                adaptor.addChild(root_1, stream_RETURN.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "returnValue"

    public static class nothing_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nothing"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:546:1: nothing : EOF -> ^( Nothing ) ;
    public final SLAnnotationsParser.nothing_return nothing() throws RecognitionException {
        SLAnnotationsParser.nothing_return retval = new SLAnnotationsParser.nothing_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF255=null;

        Tree EOF255_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:547:5: ( EOF -> ^( Nothing ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:547:7: EOF
            {
            EOF255=(Token)match(input,EOF,FOLLOW_EOF_in_nothing2952); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF255);



            // AST REWRITE
            // elements: 
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 547:11: -> ^( Nothing )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:547:14: ^( Nothing )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Nothing, "Nothing"), root_1);

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "nothing"

    public static class accessModifiers_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "accessModifiers"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:550:1: accessModifiers : ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? ;
    public final SLAnnotationsParser.accessModifiers_return accessModifiers() throws RecognitionException {
        SLAnnotationsParser.accessModifiers_return retval = new SLAnnotationsParser.accessModifiers_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token set256=null;
        Token STATIC257=null;

        Tree set256_tree=null;
        Tree STATIC257_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:551:2: ( ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:551:4: ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )?
            {
            root_0 = (Tree)adaptor.nil();

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:551:4: ( PUBLIC | PROTECTED | PRIVATE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( ((LA46_0>=PUBLIC && LA46_0<=PRIVATE)) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:
                    {
                    set256=(Token)input.LT(1);
                    if ( (input.LA(1)>=PUBLIC && input.LA(1)<=PRIVATE) ) {
                        input.consume();
                        if ( state.backtracking==0 ) adaptor.addChild(root_0, (Tree)adaptor.create(set256));
                        state.errorRecovery=false;state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:551:36: ( STATIC )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==STATIC) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:551:36: STATIC
                    {
                    STATIC257=(Token)match(input,STATIC,FOLLOW_STATIC_in_accessModifiers2987); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STATIC257_tree = (Tree)adaptor.create(STATIC257);
                    adaptor.addChild(root_0, STATIC257_tree);
                    }

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "accessModifiers"

    public static class qualifiedName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:554:1: qualifiedName : IDENTIFIER ( options {greedy=false; } : ( '.' IDENTIFIER ) )+ ;
    public final SLAnnotationsParser.qualifiedName_return qualifiedName() throws RecognitionException {
        SLAnnotationsParser.qualifiedName_return retval = new SLAnnotationsParser.qualifiedName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER258=null;
        Token char_literal259=null;
        Token IDENTIFIER260=null;

        Tree IDENTIFIER258_tree=null;
        Tree char_literal259_tree=null;
        Tree IDENTIFIER260_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:559:2: ( IDENTIFIER ( options {greedy=false; } : ( '.' IDENTIFIER ) )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:559:4: IDENTIFIER ( options {greedy=false; } : ( '.' IDENTIFIER ) )+
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER258=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName3003); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER258_tree = (Tree)adaptor.create(IDENTIFIER258);
            adaptor.addChild(root_0, IDENTIFIER258_tree);
            }
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:559:15: ( options {greedy=false; } : ( '.' IDENTIFIER ) )+
            int cnt48=0;
            loop48:
            do {
                int alt48=2;
                int LA48_0 = input.LA(1);

                if ( (LA48_0==COLON||LA48_0==RPAREN) ) {
                    alt48=2;
                }
                else if ( (LA48_0==DOT) ) {
                    int LA48_2 = input.LA(2);

                    if ( (LA48_2==CLASS||LA48_2==THIS) ) {
                        alt48=2;
                    }
                    else if ( (LA48_2==IDENTIFIER) ) {
                        int LA48_3 = input.LA(3);

                        if ( (LA48_3==EOF||LA48_3==PROTECTS) ) {
                            alt48=2;
                        }
                        else if ( (LA48_3==DOT||LA48_3==COLON||LA48_3==RPAREN) ) {
                            alt48=1;
                        }


                    }


                }


                switch (alt48) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:559:43: ( '.' IDENTIFIER )
            	    {
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:559:43: ( '.' IDENTIFIER )
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:559:44: '.' IDENTIFIER
            	    {
            	    char_literal259=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedName3017); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal259_tree = (Tree)adaptor.create(char_literal259);
            	    adaptor.addChild(root_0, char_literal259_tree);
            	    }
            	    IDENTIFIER260=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName3019); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    IDENTIFIER260_tree = (Tree)adaptor.create(IDENTIFIER260);
            	    adaptor.addChild(root_0, IDENTIFIER260_tree);
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt48 >= 1 ) break loop48;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(48, input);
                        throw eee;
                }
                cnt48++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedName"

    public static class simpleName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:562:1: simpleName : IDENTIFIER ;
    public final SLAnnotationsParser.simpleName_return simpleName() throws RecognitionException {
        SLAnnotationsParser.simpleName_return retval = new SLAnnotationsParser.simpleName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER261=null;

        Tree IDENTIFIER261_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:563:7: ( IDENTIFIER )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:563:9: IDENTIFIER
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER261=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleName3040); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IDENTIFIER261_tree = (Tree)adaptor.create(IDENTIFIER261);
            adaptor.addChild(root_0, IDENTIFIER261_tree);
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }

        	catch(RecognitionException e){
        		throw e;
        	}
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleName"

    // $ANTLR start synpred1_SLAnnotations
    public final void synpred1_SLAnnotations_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:314:4: ( parameterLockName )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:314:5: parameterLockName
        {
        pushFollow(FOLLOW_parameterLockName_in_synpred1_SLAnnotations1543);
        parameterLockName();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_SLAnnotations

    // $ANTLR start synpred2_SLAnnotations
    public final void synpred2_SLAnnotations_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:324:4: ( qualifiedClassLockExpression )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:324:5: qualifiedClassLockExpression
        {
        pushFollow(FOLLOW_qualifiedClassLockExpression_in_synpred2_SLAnnotations1600);
        qualifiedClassLockExpression();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_SLAnnotations

    // $ANTLR start synpred3_SLAnnotations
    public final void synpred3_SLAnnotations_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:325:4: ( qualifiedThisExpression )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:325:5: qualifiedThisExpression
        {
        pushFollow(FOLLOW_qualifiedThisExpression_in_synpred3_SLAnnotations1612);
        qualifiedThisExpression();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred3_SLAnnotations

    // Delegated rules

    public final boolean synpred1_SLAnnotations() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_SLAnnotations_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_SLAnnotations() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_SLAnnotations_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred3_SLAnnotations() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred3_SLAnnotations_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA17 dfa17 = new DFA17(this);
    protected DFA20 dfa20 = new DFA20(this);
    protected DFA21 dfa21 = new DFA21(this);
    protected DFA37 dfa37 = new DFA37(this);
    protected DFA39 dfa39 = new DFA39(this);
    static final String DFA17_eotS =
        "\22\uffff";
    static final String DFA17_eofS =
        "\6\uffff\2\13\10\uffff\2\13";
    static final String DFA17_minS =
        "\1\134\1\u0092\1\135\3\134\3\135\1\u0092\1\131\1\uffff\2\134\2\uffff"+
        "\2\135";
    static final String DFA17_maxS =
        "\1\142\2\u0092\2\134\1\142\2\u009b\2\u0092\1\132\1\uffff\2\134\2"+
        "\uffff\2\u009b";
    static final String DFA17_acceptS =
        "\13\uffff\1\3\2\uffff\1\2\1\1\2\uffff";
    static final String DFA17_specialS =
        "\22\uffff}>";
    static final String[] DFA17_transitionS = {
            "\1\2\5\uffff\1\1",
            "\1\3",
            "\1\5\64\uffff\1\4",
            "\1\6",
            "\1\7",
            "\1\10\5\uffff\1\11",
            "\1\12\75\uffff\1\13",
            "\1\12\75\uffff\1\13",
            "\1\5\64\uffff\1\14",
            "\1\15",
            "\1\17\1\16",
            "",
            "\1\20",
            "\1\21",
            "",
            "",
            "\1\12\75\uffff\1\13",
            "\1\12\75\uffff\1\13"
    };

    static final short[] DFA17_eot = DFA.unpackEncodedString(DFA17_eotS);
    static final short[] DFA17_eof = DFA.unpackEncodedString(DFA17_eofS);
    static final char[] DFA17_min = DFA.unpackEncodedStringToUnsignedChars(DFA17_minS);
    static final char[] DFA17_max = DFA.unpackEncodedStringToUnsignedChars(DFA17_maxS);
    static final short[] DFA17_accept = DFA.unpackEncodedString(DFA17_acceptS);
    static final short[] DFA17_special = DFA.unpackEncodedString(DFA17_specialS);
    static final short[][] DFA17_transition;

    static {
        int numStates = DFA17_transitionS.length;
        DFA17_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA17_transition[i] = DFA.unpackEncodedString(DFA17_transitionS[i]);
        }
    }

    class DFA17 extends DFA {

        public DFA17(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 17;
            this.eot = DFA17_eot;
            this.eof = DFA17_eof;
            this.min = DFA17_min;
            this.max = DFA17_max;
            this.accept = DFA17_accept;
            this.special = DFA17_special;
            this.transition = DFA17_transition;
        }
        public String getDescription() {
            return "296:1: qualifiedLockSpecification : ( qualifiedLockName DOT READ_LOCK '(' ')' -> ^( ReadLock qualifiedLockName ) | qualifiedLockName DOT WRITE_LOCK '(' ')' -> ^( WriteLock qualifiedLockName ) | qualifiedLockName );";
        }
    }
    static final String DFA20_eotS =
        "\11\uffff";
    static final String DFA20_eofS =
        "\11\uffff";
    static final String DFA20_minS =
        "\1\134\1\uffff\1\135\2\134\1\uffff\1\135\1\0\1\uffff";
    static final String DFA20_maxS =
        "\1\142\1\uffff\1\u0092\1\142\1\134\1\uffff\1\u0092\1\0\1\uffff";
    static final String DFA20_acceptS =
        "\1\uffff\1\1\3\uffff\1\3\2\uffff\1\2";
    static final String DFA20_specialS =
        "\1\1\6\uffff\1\0\1\uffff}>";
    static final String[] DFA20_transitionS = {
            "\1\2\5\uffff\1\1",
            "",
            "\1\3\64\uffff\1\4",
            "\1\6\5\uffff\1\5",
            "\1\7",
            "",
            "\1\3\64\uffff\1\10",
            "\1\uffff",
            ""
    };

    static final short[] DFA20_eot = DFA.unpackEncodedString(DFA20_eotS);
    static final short[] DFA20_eof = DFA.unpackEncodedString(DFA20_eofS);
    static final char[] DFA20_min = DFA.unpackEncodedStringToUnsignedChars(DFA20_minS);
    static final char[] DFA20_max = DFA.unpackEncodedStringToUnsignedChars(DFA20_maxS);
    static final short[] DFA20_accept = DFA.unpackEncodedString(DFA20_acceptS);
    static final short[] DFA20_special = DFA.unpackEncodedString(DFA20_specialS);
    static final short[][] DFA20_transition;

    static {
        int numStates = DFA20_transitionS.length;
        DFA20_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA20_transition[i] = DFA.unpackEncodedString(DFA20_transitionS[i]);
        }
    }

    class DFA20 extends DFA {

        public DFA20(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 20;
            this.eot = DFA20_eot;
            this.eof = DFA20_eof;
            this.min = DFA20_min;
            this.max = DFA20_max;
            this.accept = DFA20_accept;
            this.special = DFA20_special;
            this.transition = DFA20_transition;
        }
        public String getDescription() {
            return "313:1: qualifiedLockName : ( ( parameterLockName )=> parameterLockName | typeQualifiedLockName | innerClassLockName );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA20_7 = input.LA(1);

                         
                        int index20_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred1_SLAnnotations()) ) {s = 1;}

                        else if ( (true) ) {s = 8;}

                         
                        input.seek(index20_7);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA20_0 = input.LA(1);

                         
                        int index20_0 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA20_0==THIS) && (synpred1_SLAnnotations())) {s = 1;}

                        else if ( (LA20_0==IDENTIFIER) ) {s = 2;}

                         
                        input.seek(index20_0);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 20, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA21_eotS =
        "\11\uffff";
    static final String DFA21_eofS =
        "\3\uffff\1\6\1\10\4\uffff";
    static final String DFA21_minS =
        "\1\134\1\135\1\134\2\123\4\uffff";
    static final String DFA21_maxS =
        "\1\134\1\135\1\142\2\135\4\uffff";
    static final String DFA21_acceptS =
        "\5\uffff\1\1\1\3\2\2";
    static final String DFA21_specialS =
        "\2\uffff\1\1\1\uffff\1\0\4\uffff}>";
    static final String[] DFA21_transitionS = {
            "\1\1",
            "\1\2",
            "\1\3\1\uffff\1\5\3\uffff\1\4",
            "\1\6\11\uffff\1\2",
            "\1\7\11\uffff\1\6",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "323:1: qualifiedLockExpressian : ( ( qualifiedClassLockExpression )=> qualifiedClassLockExpression | ( qualifiedThisExpression )=> qualifiedThisExpression | qualifiedFieldRef );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA21_4 = input.LA(1);

                         
                        int index21_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA21_4==DOT) ) {s = 6;}

                        else if ( (LA21_4==PROTECTS) && (synpred3_SLAnnotations())) {s = 7;}

                        else if ( (LA21_4==EOF) && (synpred3_SLAnnotations())) {s = 8;}

                         
                        input.seek(index21_4);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA21_2 = input.LA(1);

                         
                        int index21_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA21_2==IDENTIFIER) ) {s = 3;}

                        else if ( (LA21_2==THIS) ) {s = 4;}

                        else if ( (LA21_2==CLASS) && (synpred2_SLAnnotations())) {s = 5;}

                         
                        input.seek(index21_2);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 21, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA37_eotS =
        "\10\uffff";
    static final String DFA37_eofS =
        "\10\uffff";
    static final String DFA37_minS =
        "\1\126\1\uffff\1\135\1\uffff\1\134\1\135\2\uffff";
    static final String DFA37_maxS =
        "\1\142\1\uffff\1\u0092\1\uffff\1\142\1\u0092\2\uffff";
    static final String DFA37_acceptS =
        "\1\uffff\1\1\1\uffff\1\4\2\uffff\1\2\1\3";
    static final String DFA37_specialS =
        "\10\uffff}>";
    static final String[] DFA37_transitionS = {
            "\1\1\5\uffff\1\2\5\uffff\1\3",
            "",
            "\1\4\64\uffff\1\3",
            "",
            "\1\5\5\uffff\1\6",
            "\1\4\64\uffff\1\7",
            "",
            ""
    };

    static final short[] DFA37_eot = DFA.unpackEncodedString(DFA37_eotS);
    static final short[] DFA37_eof = DFA.unpackEncodedString(DFA37_eofS);
    static final char[] DFA37_min = DFA.unpackEncodedStringToUnsignedChars(DFA37_minS);
    static final char[] DFA37_max = DFA.unpackEncodedStringToUnsignedChars(DFA37_maxS);
    static final short[] DFA37_accept = DFA.unpackEncodedString(DFA37_acceptS);
    static final short[] DFA37_special = DFA.unpackEncodedString(DFA37_specialS);
    static final short[][] DFA37_transition;

    static {
        int numStates = DFA37_transitionS.length;
        DFA37_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA37_transition[i] = DFA.unpackEncodedString(DFA37_transitionS[i]);
        }
    }

    class DFA37 extends DFA {

        public DFA37(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 37;
            this.eot = DFA37_eot;
            this.eof = DFA37_eof;
            this.min = DFA37_min;
            this.max = DFA37_max;
            this.accept = DFA37_accept;
            this.special = DFA37_special;
            this.transition = DFA37_transition;
        }
        public String getDescription() {
            return "447:1: simpleEffectExpression : ( anyInstanceExpression | qualifiedThisExpression | qualifiedNamedType -> ^( TypeExpression qualifiedNamedType ) | simpleExpression );";
        }
    }
    static final String DFA39_eotS =
        "\6\uffff";
    static final String DFA39_eofS =
        "\3\uffff\1\5\2\uffff";
    static final String DFA39_minS =
        "\1\134\1\135\1\134\1\123\2\uffff";
    static final String DFA39_maxS =
        "\1\134\1\135\1\142\1\135\2\uffff";
    static final String DFA39_acceptS =
        "\4\uffff\1\2\1\1";
    static final String DFA39_specialS =
        "\6\uffff}>";
    static final String[] DFA39_transitionS = {
            "\1\1",
            "\1\2",
            "\1\3\5\uffff\1\4",
            "\1\5\11\uffff\1\2",
            "",
            ""
    };

    static final short[] DFA39_eot = DFA.unpackEncodedString(DFA39_eotS);
    static final short[] DFA39_eof = DFA.unpackEncodedString(DFA39_eofS);
    static final char[] DFA39_min = DFA.unpackEncodedStringToUnsignedChars(DFA39_minS);
    static final char[] DFA39_max = DFA.unpackEncodedStringToUnsignedChars(DFA39_maxS);
    static final short[] DFA39_accept = DFA.unpackEncodedString(DFA39_acceptS);
    static final short[] DFA39_special = DFA.unpackEncodedString(DFA39_specialS);
    static final short[][] DFA39_transition;

    static {
        int numStates = DFA39_transitionS.length;
        DFA39_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA39_transition[i] = DFA.unpackEncodedString(DFA39_transitionS[i]);
        }
    }

    class DFA39 extends DFA {

        public DFA39(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 39;
            this.eot = DFA39_eot;
            this.eof = DFA39_eof;
            this.min = DFA39_min;
            this.max = DFA39_max;
            this.accept = DFA39_accept;
            this.special = DFA39_special;
            this.transition = DFA39_transition;
        }
        public String getDescription() {
            return "487:1: qualifiedFieldRef : ( typeExpression '.' IDENTIFIER -> ^( FieldRef typeExpression IDENTIFIER ) | qualifiedThisExpression '.' IDENTIFIER -> ^( FieldRef qualifiedThisExpression IDENTIFIER ) );";
        }
    }
 

    public static final BitSet FOLLOW_IS_in_testResult549 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult551 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0008000000000000L});
    public static final BitSet FOLLOW_179_in_testResult553 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult555 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_testResult557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IS_in_testResult577 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult579 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_testResult581 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IS_in_testResult597 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult599 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0008000000000000L});
    public static final BitSet FOLLOW_179_in_testResult601 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult603 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_testResult605 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IS_in_testResult623 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_testResult625 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_testResult627 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_180_in_testResultComment651 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_181_in_testResultComment655 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_testResult_in_testResultComment663 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_borrowedFunction688 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_borrowedFunction690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_borrowedExpressionList_in_borrowedList715 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_borrowedList717 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_borrowedExpression_in_borrowedList729 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_borrowedList731 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_borrowedExpression_in_borrowedExpressionList751 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_borrowedExpressionList754 = new BitSet(new long[]{0x0000000000000000L,0x0000000410000000L});
    public static final BitSet FOLLOW_borrowedExpression_in_borrowedExpressionList756 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_varUse_in_borrowedExpression784 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_borrowedExpression788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_uniqueJava5Method810 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJava5Method812 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_returnValue_in_uniqueJava5Method824 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJava5Method826 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_uniqueJava5Method838 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_uniqueJava5Method840 = new BitSet(new long[]{0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_returnValue_in_uniqueJava5Method842 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJava5Method844 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_returnValue_in_uniqueJava5Method862 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_uniqueJava5Method864 = new BitSet(new long[]{0x0000000000000000L,0x0000000410000000L});
    public static final BitSet FOLLOW_thisExpr_in_uniqueJava5Method866 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJava5Method868 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_uniqueExpressionList_in_uniqueJavadocMethod895 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJavadocMethod897 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_uniqueExpression_in_uniqueJavadocMethod909 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJavadocMethod911 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_uniqueConstructorExpressionList_in_uniqueJavadocConstructor936 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJavadocConstructor938 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_uniqueConstructorExpression_in_uniqueJavadocConstructor950 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_uniqueJavadocConstructor952 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_uniqueExpression_in_uniqueExpressionList972 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_uniqueExpressionList975 = new BitSet(new long[]{0x0000000000000000L,0x0000000C10000000L});
    public static final BitSet FOLLOW_uniqueExpression_in_uniqueExpressionList977 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_varUse_in_uniqueExpression1005 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_uniqueExpression1009 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_returnValue_in_uniqueExpression1013 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_uniqueConstructorExpression_in_uniqueConstructorExpressionList1030 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_uniqueConstructorExpressionList1033 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_uniqueConstructorExpression_in_uniqueConstructorExpressionList1035 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_varUse_in_uniqueConstructorExpression1063 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOTHING_in_starts1090 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_starts1092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_locks1124 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_LBRACE_in_locks1126 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_lockJava5_in_locks1128 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000000000C000000L});
    public static final BitSet FOLLOW_COMMA_in_locks1131 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_lockJava5_in_locks1133 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000000000C000000L});
    public static final BitSet FOLLOW_RBRACE_in_locks1137 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_locks1139 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LOCK_in_lockJava51155 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_LPAREN_in_lockJava51157 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_DQUOTE_in_lockJava51159 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_lock_in_lockJava51161 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_DQUOTE_in_lockJava51163 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_lockJava51165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_lock1179 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_IS_in_lock1181 = new BitSet(new long[]{0x0000000000000000L,0x0000000450000000L});
    public static final BitSet FOLLOW_lockExpression_in_lock1183 = new BitSet(new long[]{0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_PROTECTS_in_lock1185 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_regionName_in_lock1187 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_lock1189 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lockSpecifications_in_requiresLock1212 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockSpecification_in_isLock1241 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_isLock1243 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_policyLockDeclaration_in_policyLock1262 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_policyLock1264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lockSpecification_in_returnsLock1283 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_returnsLock1285 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_policyLockDeclaration1316 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_IS_in_policyLockDeclaration1318 = new BitSet(new long[]{0x0000000000000000L,0x0000000450000000L});
    public static final BitSet FOLLOW_lockExpression_in_policyLockDeclaration1320 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_policyLockDeclaration1322 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lockSpecification_in_lockSpecifications1343 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_lockSpecifications1346 = new BitSet(new long[]{0x0000000000000000L,0x0000000410000000L});
    public static final BitSet FOLLOW_lockSpecification_in_lockSpecifications1348 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_qualifiedLockSpecification_in_lockSpecification1367 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockSpecification_in_lockSpecification1373 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockName_in_simpleLockSpecification1388 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_simpleLockSpecification1390 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_READ_LOCK_in_simpleLockSpecification1392 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_LPAREN_in_simpleLockSpecification1394 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_simpleLockSpecification1396 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockName_in_simpleLockSpecification1410 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_simpleLockSpecification1412 = new BitSet(new long[]{0x0000000000000000L,0x0000000004000000L});
    public static final BitSet FOLLOW_WRITE_LOCK_in_simpleLockSpecification1414 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_LPAREN_in_simpleLockSpecification1416 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_simpleLockSpecification1418 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockName_in_simpleLockSpecification1432 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedLockName_in_qualifiedLockSpecification1447 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedLockSpecification1449 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_READ_LOCK_in_qualifiedLockSpecification1451 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_LPAREN_in_qualifiedLockSpecification1453 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_qualifiedLockSpecification1455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedLockName_in_qualifiedLockSpecification1469 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedLockSpecification1471 = new BitSet(new long[]{0x0000000000000000L,0x0000000004000000L});
    public static final BitSet FOLLOW_WRITE_LOCK_in_qualifiedLockSpecification1473 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_LPAREN_in_qualifiedLockSpecification1475 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_qualifiedLockSpecification1477 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedLockName_in_qualifiedLockSpecification1491 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedLockName_in_lockName1507 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockName_in_lockName1512 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedLockExpressian_in_lockExpression1524 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleLockExpression_in_lockExpression1530 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameterLockName_in_qualifiedLockName1548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeQualifiedLockName_in_qualifiedLockName1553 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_innerClassLockName_in_qualifiedLockName1559 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleExpression_in_parameterLockName1572 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_parameterLockName1574 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_parameterLockName1576 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedClassLockExpression_in_qualifiedLockExpressian1605 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedThisExpression_in_qualifiedLockExpressian1617 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedFieldRef_in_qualifiedLockExpressian1622 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_qualifiedClassLockExpression1634 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedClassLockExpression1636 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_CLASS_in_qualifiedClassLockExpression1638 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_classExpr_in_simpleLockExpression1657 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_simpleLockExpression1663 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleFieldRef_in_simpleLockExpression1668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_mappedRegionSpecification_in_aggregate1688 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_aggregate1690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fullRegionDecl_in_region1718 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionDecl_in_region1727 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_regionDecl1749 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_accessModifiers_in_regionDecl1765 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_regionDecl1767 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fullRegionDecl1795 = new BitSet(new long[]{0x0000000000000000L,0x0000000080000000L});
    public static final BitSet FOLLOW_EXTENDS_in_fullRegionDecl1797 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_regionSpecification_in_fullRegionDecl1799 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_accessModifiers_in_fullRegionDecl1815 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fullRegionDecl1817 = new BitSet(new long[]{0x0000000000000000L,0x0000000080000000L});
    public static final BitSet FOLLOW_EXTENDS_in_fullRegionDecl1819 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_regionSpecification_in_fullRegionDecl1821 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionSpecification_in_inRegion1846 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_inRegion1848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldMappings_in_mapFields1870 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_mapFields1872 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionMapping_in_mapRegion1893 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_mapRegion1895 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_182_in_regionEffects1913 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_readsEffect_in_regionEffects1924 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_SEMI_in_regionEffects1927 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0100000000000000L});
    public static final BitSet FOLLOW_writesEffect_in_regionEffects1929 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_writesEffect_in_regionEffects1947 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_SEMI_in_regionEffects1950 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0080000000000000L});
    public static final BitSet FOLLOW_readsEffect_in_regionEffects1952 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionSpecification_in_regionSpecifications1982 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_regionSpecifications1985 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_regionSpecification_in_regionSpecifications1987 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_qualifiedRegionName_in_regionSpecification2009 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleRegionSpecification_in_regionSpecification2015 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionName_in_simpleRegionSpecification2028 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LBRACKET_in_simpleRegionSpecification2034 = new BitSet(new long[]{0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_RBRACKET_in_simpleRegionSpecification2036 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedThisExpression_in_innerClassLockName2058 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_innerClassLockName2060 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_innerClassLockName2062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeExpression_in_typeQualifiedLockName2083 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_typeQualifiedLockName2085 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_typeQualifiedLockName2087 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleLockName2108 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_regionName2128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionMapping_in_mappedRegionSpecification2148 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_mappedRegionSpecification2151 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_regionMapping_in_mappedRegionSpecification2153 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_regionSpecifications_in_fieldMappings2176 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_INTO_in_fieldMappings2178 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_regionSpecification_in_fieldMappings2180 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleRegionSpecification_in_regionMapping2201 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_INTO_in_regionMapping2203 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_regionSpecification_in_regionMapping2205 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedNamedType_in_qualifiedRegionName2227 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_qualifiedRegionName2229 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedRegionName2231 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleNamedType_in_qualifiedRegionName2246 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_qualifiedRegionName2248 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedRegionName2250 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOTHING_in_effectsSpecification2272 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_effectSpecification_in_effectsSpecification2277 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_COMMA_in_effectsSpecification2280 = new BitSet(new long[]{0x0000000000000000L,0x0000000410400000L});
    public static final BitSet FOLLOW_effectSpecification_in_effectsSpecification2282 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_simpleEffectExpression_in_effectSpecification2301 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_COLON_in_effectSpecification2303 = new BitSet(new long[]{0x0000000000000000L,0x0000000510000000L});
    public static final BitSet FOLLOW_simpleRegionSpecification_in_effectSpecification2305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_implicitThisEffectSpecification_in_effectSpecification2320 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_regionName_in_implicitThisEffectSpecification2331 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_anyInstanceExpression_in_simpleEffectExpression2356 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedThisExpression_in_simpleEffectExpression2361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedNamedType_in_simpleEffectExpression2366 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleExpression_in_simpleEffectExpression2379 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ANY_in_anyInstanceExpression2391 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_LPAREN_in_anyInstanceExpression2393 = new BitSet(new long[]{0x0000000000000000L,0x0000000410000000L});
    public static final BitSet FOLLOW_namedType_in_anyInstanceExpression2395 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_RPAREN_in_anyInstanceExpression2397 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_183_in_readsEffect2416 = new BitSet(new long[]{0x0000000000000000L,0x0000000410500000L});
    public static final BitSet FOLLOW_effectsSpecification_in_readsEffect2418 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_184_in_writesEffect2435 = new BitSet(new long[]{0x0000000000000000L,0x0000000410500000L});
    public static final BitSet FOLLOW_effectsSpecification_in_writesEffect2437 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_qualifiedClassExpression2462 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedClassExpression2464 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_CLASS_in_qualifiedClassExpression2466 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_qualifiedThisExpression2487 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedThisExpression2489 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
    public static final BitSet FOLLOW_THIS_in_qualifiedThisExpression2491 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_typeExpression2512 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedFieldRef_in_fieldRef2532 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleFieldRef_in_fieldRef2538 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeExpression_in_qualifiedFieldRef2550 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedFieldRef2552 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedFieldRef2554 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedThisExpression_in_qualifiedFieldRef2569 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedFieldRef2571 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedFieldRef2573 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleNamedType_in_namedType2596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedNamedType_in_namedType2603 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedName_in_qualifiedNamedType2624 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_typeName2647 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedTypeName_in_typeName2654 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedTypeName2672 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedTypeName2693 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedTypeName2695 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleNamedType2724 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_simpleFieldRef2745 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_simpleFieldRef2747 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleFieldRef2749 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleFieldRef2765 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_simpleExpression2796 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_varUse_in_simpleExpression2802 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_varUse2817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLASS_in_classExpr2844 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_THIS_in_classExpr2861 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_classExpr2863 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_CLASS_in_classExpr2865 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_THIS_in_thisExpr2894 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_in_returnValue2923 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EOF_in_nothing2952 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_accessModifiers2974 = new BitSet(new long[]{0x0000000000000002L,0x0000008000000000L});
    public static final BitSet FOLLOW_STATIC_in_accessModifiers2987 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName3003 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_DOT_in_qualifiedName3017 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName3019 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleName3040 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameterLockName_in_synpred1_SLAnnotations1543 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedClassLockExpression_in_synpred2_SLAnnotations1600 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedThisExpression_in_synpred3_SLAnnotations1612 = new BitSet(new long[]{0x0000000000000002L});

}
