// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Note that the class/field/method/constructor to which this anno
 * applies (it's "target") is "part of the API" of the module in which
 * it is nested. If a module is named, it must match the inner-most
 * module that contains the target of this anno.
 * 
 * Syntax:
 *    "API"
 *    id : Info (String)
 * 
 */
public interface IAPINode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getId();
}

