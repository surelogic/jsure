// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

/**
 * Has every method in INodeVisitor do nothing
 */
@SuppressWarnings("deprecation")
public class DefaultPromiseVisitor<T> extends DefaultBaseVisitor<T> implements IPromiseNodeVisitor<T> {
  public DefaultPromiseVisitor(T defaultVal) {
    super(defaultVal);
  }

  public DefaultPromiseVisitor() {
    super(null);
  }

  public T visit(IColorRenameNode n) {
    return defaultValue;
  }
  public T visit(IColorRequireNode n) {
    return defaultValue;
  }
  public T visit(IColorCardNNode n) {
    return defaultValue;
  }
  public T visit(IColorAndParenNode n) {
    return defaultValue;
  }
  public T visit(IQualifiedRegionNameNode n) {
    return defaultValue;
  }
  public T visit(IInitDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IEnclosingModuleNode n) {
    return defaultValue;
  }
  public T visit(ITaintedNode n) {
    return defaultValue;
  }
  public T visit(IStartsSpecificationNode n) {
    return defaultValue;
  }
  public T visit(IAndTargetNode n) {
    return defaultValue;
  }
  public T visit(IColorNameNode n) {
    return defaultValue;
  }
  public T visit(IColorDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IConstructorDeclPatternNode n) {
    return defaultValue;
  }
  public T visit(IReturnValueDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IColorCard1Node n) {
    return defaultValue;
  }
  public T visit(IColorAndNode n) {
    return defaultValue;
  }
  public T visit(IInvariantDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IScopedModuleNode n) {
    return defaultValue;
  }
  public T visit(IColorExprNode n) {
    return defaultValue;
  }
  public T visit(IModuleNode n) {
    return defaultValue;
  }
  public T visit(ITransparentNode n) {
    return defaultValue;
  }
  public T visit(IAPINode n) {
    return defaultValue;
  }
  public T visit(IColorIncompatibleNode n) {
    return defaultValue;
  }
  public T visit(IRegionMappingNode n) {
    return defaultValue;
  }
  public T visit(IColorRevokeNode n) {
    return defaultValue;
  }
  public T visit(ISubtypedBySpecificationNode n) {
    return defaultValue;
  }
  public T visit(INotTaintedNode n) {
    return defaultValue;
  }
  public T visit(IEffectSpecificationNode n) {
    return defaultValue;
  }
  public T visit(IColorOrParenNode n) {
    return defaultValue;
  }
  public T visit(IIntOrNNode n) {
    return defaultValue;
  }
  public T visit(IFieldDeclPatternNode n) {
    return defaultValue;
  }
  public T visit(IColorConstrainedRegionsNode n) {
    return defaultValue;
  }
  public T visit(IEffectsSpecificationNode n) {
    return defaultValue;
  }
  public T visit(IMethodDeclPatternNode n) {
    return defaultValue;
  }
  public T visit(IColorOrNode n) {
    return defaultValue;
  }
  public T visit(ITypeDeclPatternNode n) {
    return defaultValue;
  }
  public T visit(IColorImportNode n) {
    return defaultValue;
  }
  public T visit(IUsedBySpecificationNode n) {
    return defaultValue;
  }
  public T visit(IOrTargetNode n) {
    return defaultValue;
  }
  public T visit(IAnyInstanceExpressionNode n) {
    return defaultValue;
  }
  public T visit(INewRegionDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IScopedPromiseNode n) {
    return defaultValue;
  }
  public T visit(ITypeQualifierPatternNode n) {
    return defaultValue;
  }
  public T visit(IColorGrantNode n) {
    return defaultValue;
  }
  public T visit(IColorContextNode n) {
    return defaultValue;
  }
  public T visit(IColorCardinalityNode n) {
    return defaultValue;
  }
  public T visit(IClassInitDeclarationNode n) {
    return defaultValue;
  }
  public T visit(INotTargetNode n) {
    return defaultValue;
  }
  public T visit(IColorNoteNode n) {
    return defaultValue;
  }
  public T visit(IRegionNameNode n) {
    return defaultValue;
  }
  public T visit(IFieldMappingsNode n) {
    return defaultValue;
  }
  public T visit(IConditionNode n) {
    return defaultValue;
  }
  public T visit(IColorNotNode n) {
    return defaultValue;
  }
  public T visit(IColorizedRegionNode n) {
    return defaultValue;
  }
  public T visit(IReceiverDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IMappedRegionSpecificationNode n) {
    return defaultValue;
  }
  public T visit(IQualifiedReceiverDeclarationNode n) {
    return defaultValue;
  }
}
