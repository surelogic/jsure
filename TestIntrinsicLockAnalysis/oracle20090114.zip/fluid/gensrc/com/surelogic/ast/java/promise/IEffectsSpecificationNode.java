// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    Zero or more of:
 *      effectList : List<IEffectSpecificationNode>
 *    Separated by:
 *      ","
 * 
 */
public interface IEffectsSpecificationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IEffectSpecificationNode> getEffectList();
}

