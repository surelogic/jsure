// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "field"
 *    mods : Modifiers (int)
 *    ftype : ITypeNode
 *    type : ITypeQualifierPatternNode
 *    name : Info (String)
 * 
 */
public interface IFieldDeclPatternNode extends IPromiseTargetNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null int
   */
  public int getMods();
  /**
   * @return A non-null node
   */
  public ITypeNode getFtype();
  /**
   * @return A non-null node
   */
  public ITypeQualifierPatternNode getType();
  /**
   * @return A non-null String
   */
  public String getName();
}

