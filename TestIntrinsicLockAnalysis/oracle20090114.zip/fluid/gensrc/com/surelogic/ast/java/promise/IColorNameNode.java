// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * A use of a named color.  Binding uses standard scoping
 * rules to determine which color is indicated.
 * 
 * Syntax:
 *    id : Info (String)
 * 
 */
public interface IColorNameNode extends IJavaOperatorNode, IColorSpecNode, IColorOrElemNode, IColorAndElemNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getId();
}

