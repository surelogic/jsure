// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 */
public interface IDataColoringAnnotationNode extends IColoringAnnotationNode { 
  public PromiseNodeType getNodeType();
}

