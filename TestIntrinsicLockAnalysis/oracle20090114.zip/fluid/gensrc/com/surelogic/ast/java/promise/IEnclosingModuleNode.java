// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "module"
 *    id : Info (String)
 *    "encloses"
 *    modulesList : List<IModuleNode>
 * 
 */
public interface IEnclosingModuleNode extends IModuleNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IModuleNode> getModulesList();
}

