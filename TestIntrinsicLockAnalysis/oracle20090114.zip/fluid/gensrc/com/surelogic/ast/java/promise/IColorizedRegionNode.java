// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "colorizedRegion"
 *    cRegionsList : List<IRegionSpecificationNode>
 * 
 */
public interface IColorizedRegionNode extends IDataColoringAnnotationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IRegionSpecificationNode> getCRegionsList();
}

