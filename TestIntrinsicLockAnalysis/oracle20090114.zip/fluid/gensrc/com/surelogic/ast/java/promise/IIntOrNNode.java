// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Declare the cardinality of a thread color
 * 
 * Syntax:
 * 
 */
public interface IIntOrNNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

