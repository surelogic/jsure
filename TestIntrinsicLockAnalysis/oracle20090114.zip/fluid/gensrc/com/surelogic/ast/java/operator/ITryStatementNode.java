// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "try"
 *    block : IBlockStatementNode
 *    catchPartList : List<ICatchClauseNode>
 *    finallyPart : IOptFinallyNode
 * 
 */
public interface ITryStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IBlockStatementNode getBlock();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ICatchClauseNode> getCatchPartList();
  /**
   * @return A node, or null
   */
  public IFinallyNode getFinallyPart();
}

