// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "{"
 *    <block>
 *    Zero or more of:
 *      stmtList : List<IStatementNode>
 *    Separated by:
 *      <li>
 *    </block>
 *    "}"
 * 
 */
public interface IBlockStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IStatementNode> getStmtList();
}

