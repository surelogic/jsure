// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    One or more of:
 *      andElemsList : List<IColorAndElemNode>
 *    Separated by:
 *      "&"
 * 
 */
public interface IColorAndNode extends IJavaOperatorNode, IColorSpecNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IColorAndElemNode> getAndElemsList();
}

