// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    "package"
 *    id : Info (String)
 *    <semi>
 *    ";"
 *    <br>
 * 
 * Computes the value of the 'id' attribute
 */
public interface INamedPackageDeclarationNode extends IPackageDeclarationNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
}

