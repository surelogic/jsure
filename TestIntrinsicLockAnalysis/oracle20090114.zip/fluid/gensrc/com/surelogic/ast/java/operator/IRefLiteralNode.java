// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 */
public interface IRefLiteralNode extends ILiteralExpressionNode { 
  public BaseNodeType getNodeType();
}

