// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Declare two or more Thead colors to be incompatible
 * 
 * Syntax:
 *    "incompatibleColors"
 *    Zero or more of:
 *      colorList : List<IColorNameNode>
 *    Separated by:
 *      ","
 * 
 */
public interface IColorIncompatibleNode extends IColoringAnnotationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IColorNameNode> getColorList();
}

