// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "while"
 *    "("
 *    <paren>
 *    cond : IExpressionNode
 *    </paren>
 *    ")"
 *    <while>
 *    loop : IStatementNode
 *    </while>
 * 
 */
public interface IWhileStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getCond();
  /**
   * @return A non-null node
   */
  public IStatementNode getLoop();
}

