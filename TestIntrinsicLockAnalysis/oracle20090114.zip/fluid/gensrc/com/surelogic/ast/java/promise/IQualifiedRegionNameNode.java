// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.*;
import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A named region to be found looking in a particular class.
 * Qualified region names are used to circumvent name conflicts.
 * @see RegionName
 * 
 * Syntax:
 *    type : INamedTypeNode
 *    ":"
 *    id : Info (String)
 * 
 * Binds this name to IRegionBinding
 */
public interface IQualifiedRegionNameNode extends IRegionSpecificationNode, IHasBinding { 
  public PromiseNodeType getNodeType();
  public boolean bindingExists();

  public IRegionBinding resolveBinding();

  /**
   * @return A non-null node
   */
  public INamedTypeNode getType();
}

