// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * For importing inner classes
 * 
 * Syntax:
 *    type : INamedTypeNode
 *    <>
 *    "."
 *    <>
 *    "*"
 * 
 */
public interface ITypedDemandNameNode extends IImportNameNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public INamedTypeNode getType();
}

