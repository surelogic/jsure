// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Note that the class to which this anno applies is "part of" the
 * named module.  For the moment, we'll restrict this anno to appear
 * only in package-info.java or package.xml files.
 * 
 * Syntax:
 *    "module"
 *    id : Info (String)
 * 
 */
public interface IModuleNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getId();
}

