// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    id : Info (String)
 *    typesList : List<ITypeFormalNode>
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 */
public interface INestedTypeDeclarationNode extends IClassBodyDeclarationNode, ITypeDeclarationNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isAbstract();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeFormalNode> getTypesList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassBodyDeclarationNode> getBodyList();
}

