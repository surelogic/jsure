package com.surelogic.common;

public final class JavaConstants {

	public static final String DEFAULT_PACKAGE = "(default package)";

	private JavaConstants() {
		// no instances
	}
}
