package com.surelogic.common.jobs;

public enum Local {
  CANCEL
}
