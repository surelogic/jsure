package com.surelogic.common.jobs;

public enum Remote {
  TASK, SUBTASK, WORK, WARNING, FAILED, DONE
}
