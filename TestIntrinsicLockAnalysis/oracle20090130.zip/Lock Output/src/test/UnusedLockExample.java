package test;

import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.RegionLock;
import com.surelogic.Regions;

@Regions({
  @Region("R"),
  @Region("Q")})
@RegionLock("L is this protects R")
public class UnusedLockExample {
  @InRegion("R")
  private int f;
  
  @InRegion("Q")
  private int g;
  
  public synchronized int getF() {
    return f;
  }
  
  public synchronized int getG() {
    return g;
  }
  
  public void setBoth(final int a, final int b) {
    synchronized (this) {
      f = a;
      g = b;
    }
  }
}
