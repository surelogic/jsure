package aggregateInRegion.dstRegionExists;

import com.surelogic.Unique;

public class C {
  @Unique("return")
  public C() {
  	super();
  }
}
