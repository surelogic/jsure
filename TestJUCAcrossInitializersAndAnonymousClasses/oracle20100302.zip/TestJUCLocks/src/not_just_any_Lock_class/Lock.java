package not_just_any_Lock_class;

/**
 * Bogus lock class used by class main().  
 */
public class Lock {
  public void lock() {}
  public void unlock() {}
}
