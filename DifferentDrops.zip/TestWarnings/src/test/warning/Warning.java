package test.warning;

public class Warning {
	synchronized Object warn() {
		return null;
	}
}
