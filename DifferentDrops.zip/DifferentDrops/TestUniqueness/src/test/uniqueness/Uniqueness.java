package test.uniqueness;

import com.surelogic.*;

public class Uniqueness {
	@Unique
	@Aggregate
	Object field;
}
