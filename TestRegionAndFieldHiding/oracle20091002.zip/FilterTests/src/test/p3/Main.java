package test.p3;

import test.p2.D;

public class Main {
  private static int s;
  
  public static void main(final String[] args) {
    final D d = new D();
    d.f = 1;
    d.g = 2;
    
    s = 3;
  }
}
