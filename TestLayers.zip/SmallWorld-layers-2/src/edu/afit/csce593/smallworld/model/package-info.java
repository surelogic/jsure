@Promise("@InLayer(edu.afit.csce593.smallworld.MODEL)")
package edu.afit.csce593.smallworld.model;

import com.surelogic.*;