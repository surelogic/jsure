@TypeSets({
	@TypeSet("SWING = java.awt+ | javax.swing+"),
	@TypeSet("IO = java.io")
})
@Layers({
	@Layer("CONSOLE_UI may refer to edu.afit.csce593.smallworld.{MODEL, CONTROLLER} | IO"),
	@Layer("SWING_UI   may refer to edu.afit.csce593.smallworld.{MODEL, CONTROLLER} | SWING")
})
@Promise("@InLayer(CONSOLE_UI, SWING_UI)")
package edu.afit.csce593.smallworld.textui;

import com.surelogic.*;