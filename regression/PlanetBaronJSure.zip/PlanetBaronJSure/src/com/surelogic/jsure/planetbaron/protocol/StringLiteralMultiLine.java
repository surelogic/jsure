package com.surelogic.jsure.planetbaron.protocol;

public final class StringLiteralMultiLine extends ASTNode {

	private final String f_value; // not quoted or escaped

	/**
	 * Constructs an instance with the given (unquoted) value.
	 * 
	 * @param value
	 *            the string the new instance represents.
	 * 
	 * @see StringLiteral#removeQuotesAndEscapes(String)
	 */
	public StringLiteralMultiLine(String value) {
		assert value != null && value.length() != 0;
		f_value = value;
	}

	public String getValue() {
		return f_value;
	}

	public String getQuotedAndEscapedName() {
		return StringLiteral.addQuotesAndEscapes(f_value);
	}

	@Override
	public void accept(ASTVisitor v) {
		v.preVisit(this);
		v.visit(this);
		v.endVisit(this);
		v.postVisit(this);
	}

	@Override
	public String toString() {
		return getQuotedAndEscapedName();
	}
}
