package test;

import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;

@RegionLock("L1 is this protects Instance")
public class SimpleLockExample {
  private int f;
  private int g;
  
  public synchronized int getF() {
    // Good
    return f;
  }
  
  public void setF(final int v) {
    synchronized (this) {
      // Good
      f = v;
    }
  }
  
  @RequiresLock("L1")
  public void doStuff() {
    // Good
    f = 0;
  }
  
  public int getG() {
    // Bad
    return g;
  }
}
