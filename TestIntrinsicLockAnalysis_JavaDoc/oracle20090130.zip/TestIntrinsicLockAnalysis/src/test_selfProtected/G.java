package test_selfProtected;

/**
 * Says nothing about being self-protected, and it isn't.
 */
public class G extends C {

}
