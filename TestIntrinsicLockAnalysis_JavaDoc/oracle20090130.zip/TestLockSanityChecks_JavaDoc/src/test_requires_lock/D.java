package test_requires_lock;

/**
 * @Region private static S
 * @RegionLock PrivateStaticLock is class protects S
 * @PolicyLock PrivateStaticPolicyLock is class
 */
public class D {

}
