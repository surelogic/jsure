package test;

public class D {
  public static int fromD;
}
