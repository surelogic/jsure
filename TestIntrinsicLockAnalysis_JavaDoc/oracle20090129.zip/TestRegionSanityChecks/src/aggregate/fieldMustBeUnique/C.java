package aggregate.fieldMustBeUnique;

public class C {
  // Do nothing
}
