package testInst;

public class Phantom {
  public Phantom() {}
}
