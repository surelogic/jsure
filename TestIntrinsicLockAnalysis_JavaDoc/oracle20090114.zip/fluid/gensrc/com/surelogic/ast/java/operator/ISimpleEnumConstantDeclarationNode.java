// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    id : Info (String)
 * 
 */
public interface ISimpleEnumConstantDeclarationNode extends IEnumConstantDeclarationNode { 
  public BaseNodeType getNodeType();
}

