// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    value : IExpressionNode
 *    "instanceof"
 *    type : ITypeNode
 * 
 */
public interface IInstanceOfExpressionNode extends IExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getValue();
  /**
   * @return A non-null node
   */
  public ITypeNode getType();
}

