// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * An explicit declaration of the initialization method for the class.
 * @see ClassDeclaration
 * 
 * Syntax:
 *    "<clinit>"
 * 
 */
public interface IClassInitDeclarationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

