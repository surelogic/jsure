// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "short"
 * 
 */
public interface IShortTypeNode extends IIntegralTypeNode { 
  public BaseNodeType getNodeType();
}

