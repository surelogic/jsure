// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "1"
 * 
 */
public interface IColorCard1Node extends IColorCardChoiceNode { 
  public PromiseNodeType getNodeType();
}

