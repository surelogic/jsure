// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

public interface IColorExprNode extends IJavaOperatorNode, IColorSpecNode { 
  public PromiseNodeType getNodeType();
}

