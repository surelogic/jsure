// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * A specification of the region or regions for a field.
 * A potentially shared field can only have a region specification;
 * an unshared field may have a mapped region specification.
 * @see RegionSpecification
 * @see MappedRegionSpecification
 * 
 * This is an abstract node (i.e., never instantiated)

 */
public interface IFieldRegionSpecificationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

