// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * An "abstract" operator that covers both method and constructor declarations.
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    modifiers : Modifiers (int)
 *    typesList : List<ITypeFormalNode>
 *    id : Info (String)
 *    paramsList : List<IParameterDeclarationNode>
 *    exceptionsList : List<IClassTypeNode>
 *    body : IOptMethodBodyNode
 * 
 * 
 */
public interface ISomeFunctionDeclarationNode extends IClassBodyDeclarationNode, IFunctionBinding { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isNative();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeFormalNode> getTypesList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IParameterDeclarationNode> getParamsList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassTypeNode> getExceptionsList();
  /**
   * @return A non-null node
   */
  public IOptMethodBodyNode getBody();
}

