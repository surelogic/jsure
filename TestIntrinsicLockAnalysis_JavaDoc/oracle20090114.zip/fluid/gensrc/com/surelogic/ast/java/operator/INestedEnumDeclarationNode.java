// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    "enum"
 *    id : Info (String)
 *    implsList : List<IClassTypeNode>
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * 
 */
public interface INestedEnumDeclarationNode extends IEnumDeclarationNode, IDeclaredType { 
  public BaseNodeType getNodeType();
  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isStrictfp();
}

