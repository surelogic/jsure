// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    compUnit : ICompilationUnitNode
 * 
 */
public interface ISuperRootNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ICompilationUnitNode getCompUnit();
}

