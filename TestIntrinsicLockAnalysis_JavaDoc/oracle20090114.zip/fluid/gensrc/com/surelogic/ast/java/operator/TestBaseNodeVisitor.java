// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

@SuppressWarnings("deprecation")
public class TestBaseNodeVisitor<T> implements IBaseNodeVisitor<T> {
  protected final boolean testBindings;

  public TestBaseNodeVisitor(boolean bind) {
    testBindings = bind;
  }
  public T doAccept(IJavaOperatorNode node) {
    if (node == null) { return null; }
    return node.accept(this);
  }

  protected void checkOwnParent(StringBuilder sb, IJavaOperatorNode n) {
    @SuppressWarnings("unused")    IJavaOperatorNode parent = n.getParent();
  }

  protected void handleChild(IJavaOperatorNode n, IJavaOperatorNode child) {
    if (child == null) { return; }
    IJavaOperatorNode parent = child.getParent();
    if (parent != n) {
      throw new IllegalArgumentException("parent didn't match: "+n+", "+parent);
    }
    doAccept(child);
  }

  protected void checkOverride(IMethodDeclarationNode od, IMethodDeclarationNode n) {
    if (od != null) {
      if (!n.getId().equals(od.getId())) {
        throw new NullPointerException("method does not override: "+n.getId()+", "+od.getId());
      }
      if (n.getParamsList().size() != od.getParamsList().size()) {
        throw new NullPointerException("method does not override: "+n.getParamsList().size()+", "+od.getParamsList().size());
      }
      if (!n.resolveType().isAssignmentCompatibleTo(od.resolveType())) {
        throw new NullPointerException("method does not override: return types aren't assignment compatible");
      }
    }
  }

  public T visit(IJavaOperatorNode node) { return null; }

  public T visit(ISomeFunctionCallNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getObject());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ILabeledBreakStatementNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IConstructorCallNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getObject());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IAssignExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IUnsignedRightShiftExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ISomeThisExpressionNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    handleChild(n, n.getType());
    return null;
  }
  public T visit(IParameterizedTypeNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBase());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IWildcardExtendsTypeNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getLower());
    return null;
  }
  public T visit(IUnnamedPackageDeclarationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IBoxExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IAndExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IClassTypeNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(IReturnTypeNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(IFieldRefNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    handleChild(n, n.getObject());
    n.getId();
    return null;
  }
  public T visit(IFloatLiteralNode n) {
    checkOwnParent(null, n);
    n.getToken();
    return null;
  }
  public T visit(ITypeDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IRefLiteralNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IDivRemExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IElementValuePairNode n) {
    checkOwnParent(null, n);
    n.getId();
    handleChild(n, n.getValue());
    return null;
  }
  public T visit(ITypedDemandNameNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    return null;
  }
  public T visit(IStaticDemandNameNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    return null;
  }
  public T visit(ISubExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IDemandNameNode n) {
    checkOwnParent(null, n);
    n.getPkg();
    return null;
  }
  public T visit(IAssertMessageStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getAssertion());
    handleChild(n, n.getMessage());
    return null;
  }
  public T visit(IArrayCreationExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBase());
    for(IJavaOperatorNode c : n.getAllocatedList()) {
      handleChild(n, c);
    }
    n.getUnallocated();
    handleChild(n, n.getInit());
    return null;
  }
  public T visit(INotExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(ILiteralExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IOptInitializationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IAllocationCallExpressionNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ISuperRootNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCompUnit());
    return null;
  }
  public T visit(IInterfaceDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isAbstract();
    n.getId();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getExtensionsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IDoStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getLoop());
    handleChild(n, n.getCond());
    return null;
  }
  public T visit(ICompareExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IBreakStatementNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ICharLiteralNode n) {
    checkOwnParent(null, n);
    n.getToken();
    return null;
  }
  public T visit(IVarArgsExpressionNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getArgList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ISuperExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(INullLiteralNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(IWhileStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCond());
    handleChild(n, n.getLoop());
    return null;
  }
  public T visit(ICompilationUnitNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getPkg());
    for(IJavaOperatorNode c : n.getImpsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getDeclsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ILabeledStatementNode n) {
    checkOwnParent(null, n);
    n.getLabel();
    handleChild(n, n.getStmt());
    return null;
  }
  public T visit(IExprStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getExpr());
    return null;
  }
  public T visit(IRelopExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IFloatTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IInitializerNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ISimpleEnumConstantDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IPrimLiteralNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IMulExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ICastExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    handleChild(n, n.getExpr());
    return null;
  }
  public T visit(INoMethodBodyNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(INotEqExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ILogUnopExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ICatchClauseNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getParam());
    handleChild(n, n.getBody());
    return null;
  }
  public T visit(IThisExpressionNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(IIntLiteralNode n) {
    checkOwnParent(null, n);
    n.getToken();
    return null;
  }
  public T visit(IAddExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IStatementNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IVariableDeclListNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isFinal();
    handleChild(n, n.getType());
    for(IJavaOperatorNode c : n.getVarsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IAnnotationDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isAbstract();
    n.getId();
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IAssertStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getAssertion());
    return null;
  }
  public T visit(IMarkerAnnotationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(ISomeBreakStatementNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IPolymorphicMethodCallNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getObject());
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    n.getMethod();
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IOpAssignExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    n.getOp();
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IEnumConstantDeclarationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    n.getId();
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IPolymorphicNewExpressionNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getType());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IElseClauseNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getElseStmt());
    return null;
  }
  public T visit(IBinopExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IAssignmentExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ISwitchLabelNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IElementValueArrayInitializerNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getValueList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ISwitchElementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getLabel());
    for(IJavaOperatorNode c : n.getStmtsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(INestedInterfaceDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isAbstract();
    n.getId();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getExtensionsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IEnumBodyDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IPackageRootNode n) {
    checkOwnParent(null, n);
    n.getName();
    for(IJavaOperatorNode c : n.getCompUnitList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IVoidReturnStatementNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IQualifiedSuperExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    return null;
  }
  public T visit(ILogBinopExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(INamedPackageDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.getId();
    return null;
  }
  public T visit(IAnnotationElementNode n) {
    checkOwnParent(null, n);
    n.isPublic();
    n.isAbstract();
    handleChild(n, n.getType());
    n.getId();
    handleChild(n, n.getValue());
    return null;
  }
  public T visit(IFieldDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isStatic();
    n.isFinal();
    handleChild(n, n.getType());
    for(IJavaOperatorNode c : n.getVarsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(INewExpressionNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getType());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IPrimaryExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IBlockStatementNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getStmtList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ISwitchBlockNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getElementList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IMethodBodyNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBlock());
    return null;
  }
  public T visit(ITypeDeclarationStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getTypedec());
    return null;
  }
  public T visit(IShortTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IWildcardSuperTypeNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getUpper());
    return null;
  }
  public T visit(IClassInitializerNode n) {
    checkOwnParent(null, n);
    n.isStatic();
    handleChild(n, n.getBlock());
    return null;
  }
  public T visit(IUnopExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IXorExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IAnonClassExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getAlloc());
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IAllocationExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IForStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getInit());
    handleChild(n, n.getCond());
    handleChild(n, n.getUpdate());
    handleChild(n, n.getLoop());
    return null;
  }
  public T visit(IOptFinallyNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IVariableDeclaratorNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    n.getId();
    n.getDims();
    handleChild(n, n.getInit());
    return null;
  }
  public T visit(IEmptyStatementNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IParameterDeclarationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isFinal();
    handleChild(n, n.getType());
    n.getId();
    return null;
  }
  public T visit(IExpressionNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(IEnumConstantClassDeclarationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    n.getId();
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IOptArrayInitializerNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ILongTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IPostIncrementExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IUnboxExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(ICrementExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ISwitchStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getExpr());
    handleChild(n, n.getBlock());
    return null;
  }
  public T visit(IImportNameNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ISynchronizedStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getLock());
    handleChild(n, n.getBlock());
    return null;
  }
  public T visit(INumericTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IMinusExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IReturnStatementNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    handleChild(n, n.getValue());
    return null;
  }
  public T visit(IStatementExpressionListNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getExprList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ILessThanExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IReferenceTypeNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(ITrueExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IIntTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IOuterObjectSpecifierNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getObject());
    handleChild(n, n.getCall());
    return null;
  }
  public T visit(IGreaterThanEqualExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IComplementExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IDivExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(INestedEnumDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isStrictfp();
    n.getId();
    for(IJavaOperatorNode c : n.getImplsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IDeclStatementNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isFinal();
    handleChild(n, n.getType());
    for(IJavaOperatorNode c : n.getVarsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IOrExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(INormalAnnotationNode n) {
    checkOwnParent(null, n);
    n.getId();
    for(IJavaOperatorNode c : n.getPairsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IEnumDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isStrictfp();
    n.getId();
    for(IJavaOperatorNode c : n.getImplsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IPostDecrementExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IForEachStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getVar());
    handleChild(n, n.getCollection());
    handleChild(n, n.getLoop());
    return null;
  }
  public T visit(IDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IPolymorphicConstructorCallNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getObject());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IArrayRefExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getArray());
    handleChild(n, n.getIndex());
    return null;
  }
  public T visit(INonPolymorphicConstructorCallNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getObject());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IFloatingPointTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IContinueStatementNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IAnnotationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    n.getId();
    return null;
  }
  public T visit(IVariableUseExpressionNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    n.getId();
    return null;
  }
  public T visit(IShiftExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IOptElseClauseNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ITypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IConstructionObjectNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IClassExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    return null;
  }
  public T visit(IStatementExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ILeftShiftExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ICompiledMethodBodyNode n) {
    checkOwnParent(null, n);
    n.getCode();
    return null;
  }
  public T visit(ILabeledContinueStatementNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IForInitNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ICaptureTypeNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getBoundsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IConditionalExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCond());
    handleChild(n, n.getIftrue());
    handleChild(n, n.getIffalse());
    return null;
  }
  public T visit(IInitializationNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getValue());
    return null;
  }
  public T visit(IQualifiedThisExpressionNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    handleChild(n, n.getType());
    return null;
  }
  public T visit(INamedTypeNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    n.getType();
    return null;
  }
  public T visit(IPlusExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IRemExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IEqExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IConstructorDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isNative();
    n.isStrictfp();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    n.getId();
    for(IJavaOperatorNode c : n.getParamsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getExceptionsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getBody());
    return null;
  }
  public T visit(IBooleanLiteralNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ICallNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IRightShiftExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(INonPolymorphicNewExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IDoubleTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IArithUnopExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IIfStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCond());
    handleChild(n, n.getThenPart());
    handleChild(n, n.getElsePart());
    return null;
  }
  public T visit(IGreaterThanExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IPreDecrementExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IOptDefaultValueNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ITypeExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    return null;
  }
  public T visit(ITryStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBlock());
    for(IJavaOperatorNode c : n.getCatchPartList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getFinallyPart());
    return null;
  }
  public T visit(INestedClassDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isStatic();
    n.isAbstract();
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isFinal();
    n.isStrictfp();
    n.getId();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getExtension());
    for(IJavaOperatorNode c : n.getImplsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IConditionalAndExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ISingleElementAnnotationNode n) {
    checkOwnParent(null, n);
    n.getId();
    handleChild(n, n.getElt());
    return null;
  }
  public T visit(IMethodCallNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    handleChild(n, n.getObject());
    for(IJavaOperatorNode c : n.getTypeArgsList()) {
      handleChild(n, c);
    }
    n.getMethod();
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ITypeFormalNode n) {
    checkOwnParent(null, n);
    n.getId();
    for(IJavaOperatorNode c : n.getBoundsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IFinallyNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBody());
    return null;
  }
  public T visit(IFalseExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(INestedTypeDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isAbstract();
    n.getId();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IBooleanTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IPrimitiveTypeNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(ISomeAssertStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getAssertion());
    handleChild(n, n.getMessage());
    return null;
  }
  public T visit(IAssignmentNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IThrowStatementNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getValue());
    return null;
  }
  public T visit(IVariableDeclarationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    n.getId();
    return null;
  }
  public T visit(IDefaultValueNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getValue());
    return null;
  }
  public T visit(IPreIncrementExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp());
    return null;
  }
  public T visit(IStaticImportNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    n.getRef();
    return null;
  }
  public T visit(INonPolymorphicMethodCallNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getObject());
    n.getMethod();
    for(IJavaOperatorNode c : n.getArgsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IDefaultLabelNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IImportDeclarationNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getItem());
    return null;
  }
  public T visit(IWildcardTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IMethodDeclarationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    checkOverride(n.getOverriddenMethod(), n);
    for(IMethodDeclarationNode od : n.getAllOverriddenMethods()) {
      checkOverride(od, n);
    }
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isAbstract();
    n.isFinal();
    n.isStatic();
    n.isNative();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getReturnType());
    n.getId();
    for(IJavaOperatorNode c : n.getParamsList()) {
      handleChild(n, c);
    }
    n.getDims();
    for(IJavaOperatorNode c : n.getExceptionsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getBody());
    return null;
  }
  public T visit(IArrayInitializerNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getInitList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IVarArgsTypeNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBase());
    return null;
  }
  public T visit(IByteTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IElementValueNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IOmittedMethodBodyNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ICharTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IClassDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isAbstract();
    n.isPublic();
    n.isFinal();
    n.isStrictfp();
    n.getId();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getExtension());
    for(IJavaOperatorNode c : n.getImplsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getBodyList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IStringLiteralNode n) {
    checkOwnParent(null, n);
    n.getToken();
    return null;
  }
  public T visit(IStringConcatNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IArithBinopExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IClassBodyDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IInstanceOfExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getValue());
    handleChild(n, n.getType());
    return null;
  }
  public T visit(ILessThanEqualExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(ISomeFunctionDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAnnosList()) {
      handleChild(n, c);
    }
    n.isPublic();
    n.isProtected();
    n.isPrivate();
    n.isNative();
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    n.getId();
    for(IJavaOperatorNode c : n.getParamsList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getExceptionsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getBody());
    return null;
  }
  public T visit(ITypeRefNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    handleChild(n, n.getBase());
    n.getId();
    return null;
  }
  public T visit(IVoidTypeNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    return null;
  }
  public T visit(ISomeContinueStatementNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IOptMethodBodyNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IIntegralTypeNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IArrayTypeNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBase());
    n.getDims();
    return null;
  }
  public T visit(IArrayLengthNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getObject());
    return null;
  }
  public T visit(IConstantLabelNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getExpr());
    return null;
  }
  public T visit(IConditionalOrExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getOp1());
    handleChild(n, n.getOp2());
    return null;
  }
  public T visit(IEqualityExpressionNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IPackageDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
}
