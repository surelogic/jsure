// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

/**
 * Has every method in INodeVisitor do nothing
 */
@SuppressWarnings("deprecation")
public class DefaultBaseVisitor<T> implements IBaseNodeVisitor<T> {
  protected final T defaultValue;

  public DefaultBaseVisitor(T defaultVal) {
    defaultValue = defaultVal;
  }

  public DefaultBaseVisitor() {
    this(null);
  }

  public T visit(ILabeledBreakStatementNode n) {
    return defaultValue;
  }
  public T visit(IAssignExpressionNode n) {
    return defaultValue;
  }
  public T visit(IUnsignedRightShiftExpressionNode n) {
    return defaultValue;
  }
  public T visit(IParameterizedTypeNode n) {
    return defaultValue;
  }
  public T visit(IWildcardExtendsTypeNode n) {
    return defaultValue;
  }
  public T visit(IUnnamedPackageDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IBoxExpressionNode n) {
    return defaultValue;
  }
  public T visit(IAndExpressionNode n) {
    return defaultValue;
  }
  public T visit(IFieldRefNode n) {
    return defaultValue;
  }
  public T visit(IFloatLiteralNode n) {
    return defaultValue;
  }
  public T visit(IElementValuePairNode n) {
    return defaultValue;
  }
  public T visit(ITypedDemandNameNode n) {
    return defaultValue;
  }
  public T visit(IStaticDemandNameNode n) {
    return defaultValue;
  }
  public T visit(ISubExpressionNode n) {
    return defaultValue;
  }
  public T visit(IDemandNameNode n) {
    return defaultValue;
  }
  public T visit(IAssertMessageStatementNode n) {
    return defaultValue;
  }
  public T visit(IArrayCreationExpressionNode n) {
    return defaultValue;
  }
  public T visit(INotExpressionNode n) {
    return defaultValue;
  }
  public T visit(ISuperRootNode n) {
    return defaultValue;
  }
  public T visit(IInterfaceDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IDoStatementNode n) {
    return defaultValue;
  }
  public T visit(IBreakStatementNode n) {
    return defaultValue;
  }
  public T visit(ICharLiteralNode n) {
    return defaultValue;
  }
  public T visit(IVarArgsExpressionNode n) {
    return defaultValue;
  }
  public T visit(ISuperExpressionNode n) {
    return defaultValue;
  }
  public T visit(INullLiteralNode n) {
    return defaultValue;
  }
  public T visit(IWhileStatementNode n) {
    return defaultValue;
  }
  public T visit(ICompilationUnitNode n) {
    return defaultValue;
  }
  public T visit(ILabeledStatementNode n) {
    return defaultValue;
  }
  public T visit(IExprStatementNode n) {
    return defaultValue;
  }
  public T visit(IFloatTypeNode n) {
    return defaultValue;
  }
  public T visit(ISimpleEnumConstantDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IMulExpressionNode n) {
    return defaultValue;
  }
  public T visit(ICastExpressionNode n) {
    return defaultValue;
  }
  public T visit(INoMethodBodyNode n) {
    return defaultValue;
  }
  public T visit(INotEqExpressionNode n) {
    return defaultValue;
  }
  public T visit(ICatchClauseNode n) {
    return defaultValue;
  }
  public T visit(IThisExpressionNode n) {
    return defaultValue;
  }
  public T visit(IIntLiteralNode n) {
    return defaultValue;
  }
  public T visit(IAddExpressionNode n) {
    return defaultValue;
  }
  public T visit(IAnnotationDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IAssertStatementNode n) {
    return defaultValue;
  }
  public T visit(IMarkerAnnotationNode n) {
    return defaultValue;
  }
  public T visit(IPolymorphicMethodCallNode n) {
    return defaultValue;
  }
  public T visit(IOpAssignExpressionNode n) {
    return defaultValue;
  }
  public T visit(IEnumConstantDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IPolymorphicNewExpressionNode n) {
    return defaultValue;
  }
  public T visit(IElseClauseNode n) {
    return defaultValue;
  }
  public T visit(IElementValueArrayInitializerNode n) {
    return defaultValue;
  }
  public T visit(ISwitchElementNode n) {
    return defaultValue;
  }
  public T visit(INestedInterfaceDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IPackageRootNode n) {
    return defaultValue;
  }
  public T visit(IVoidReturnStatementNode n) {
    return defaultValue;
  }
  public T visit(IQualifiedSuperExpressionNode n) {
    return defaultValue;
  }
  public T visit(INamedPackageDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IAnnotationElementNode n) {
    return defaultValue;
  }
  public T visit(IFieldDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IBlockStatementNode n) {
    return defaultValue;
  }
  public T visit(ISwitchBlockNode n) {
    return defaultValue;
  }
  public T visit(IMethodBodyNode n) {
    return defaultValue;
  }
  public T visit(ITypeDeclarationStatementNode n) {
    return defaultValue;
  }
  public T visit(IShortTypeNode n) {
    return defaultValue;
  }
  public T visit(IWildcardSuperTypeNode n) {
    return defaultValue;
  }
  public T visit(IClassInitializerNode n) {
    return defaultValue;
  }
  public T visit(IXorExpressionNode n) {
    return defaultValue;
  }
  public T visit(IAnonClassExpressionNode n) {
    return defaultValue;
  }
  public T visit(IForStatementNode n) {
    return defaultValue;
  }
  public T visit(IVariableDeclaratorNode n) {
    return defaultValue;
  }
  public T visit(IEmptyStatementNode n) {
    return defaultValue;
  }
  public T visit(IParameterDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IEnumConstantClassDeclarationNode n) {
    return defaultValue;
  }
  public T visit(ILongTypeNode n) {
    return defaultValue;
  }
  public T visit(IPostIncrementExpressionNode n) {
    return defaultValue;
  }
  public T visit(IUnboxExpressionNode n) {
    return defaultValue;
  }
  public T visit(ISwitchStatementNode n) {
    return defaultValue;
  }
  public T visit(ISynchronizedStatementNode n) {
    return defaultValue;
  }
  public T visit(IMinusExpressionNode n) {
    return defaultValue;
  }
  public T visit(IReturnStatementNode n) {
    return defaultValue;
  }
  public T visit(IStatementExpressionListNode n) {
    return defaultValue;
  }
  public T visit(ILessThanExpressionNode n) {
    return defaultValue;
  }
  public T visit(ITrueExpressionNode n) {
    return defaultValue;
  }
  public T visit(IIntTypeNode n) {
    return defaultValue;
  }
  public T visit(IOuterObjectSpecifierNode n) {
    return defaultValue;
  }
  public T visit(IGreaterThanEqualExpressionNode n) {
    return defaultValue;
  }
  public T visit(IComplementExpressionNode n) {
    return defaultValue;
  }
  public T visit(IDivExpressionNode n) {
    return defaultValue;
  }
  public T visit(INestedEnumDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IDeclStatementNode n) {
    return defaultValue;
  }
  public T visit(IOrExpressionNode n) {
    return defaultValue;
  }
  public T visit(INormalAnnotationNode n) {
    return defaultValue;
  }
  public T visit(IEnumDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IPostDecrementExpressionNode n) {
    return defaultValue;
  }
  public T visit(IForEachStatementNode n) {
    return defaultValue;
  }
  public T visit(IPolymorphicConstructorCallNode n) {
    return defaultValue;
  }
  public T visit(IArrayRefExpressionNode n) {
    return defaultValue;
  }
  public T visit(INonPolymorphicConstructorCallNode n) {
    return defaultValue;
  }
  public T visit(IContinueStatementNode n) {
    return defaultValue;
  }
  public T visit(IAnnotationNode n) {
    return defaultValue;
  }
  public T visit(IVariableUseExpressionNode n) {
    return defaultValue;
  }
  public T visit(IClassExpressionNode n) {
    return defaultValue;
  }
  public T visit(ILeftShiftExpressionNode n) {
    return defaultValue;
  }
  public T visit(ICompiledMethodBodyNode n) {
    return defaultValue;
  }
  public T visit(ILabeledContinueStatementNode n) {
    return defaultValue;
  }
  public T visit(ICaptureTypeNode n) {
    return defaultValue;
  }
  public T visit(IConditionalExpressionNode n) {
    return defaultValue;
  }
  public T visit(IInitializationNode n) {
    return defaultValue;
  }
  public T visit(IQualifiedThisExpressionNode n) {
    return defaultValue;
  }
  public T visit(INamedTypeNode n) {
    return defaultValue;
  }
  public T visit(IPlusExpressionNode n) {
    return defaultValue;
  }
  public T visit(IRemExpressionNode n) {
    return defaultValue;
  }
  public T visit(IEqExpressionNode n) {
    return defaultValue;
  }
  public T visit(IConstructorDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IRightShiftExpressionNode n) {
    return defaultValue;
  }
  public T visit(INonPolymorphicNewExpressionNode n) {
    return defaultValue;
  }
  public T visit(IDoubleTypeNode n) {
    return defaultValue;
  }
  public T visit(IIfStatementNode n) {
    return defaultValue;
  }
  public T visit(IGreaterThanExpressionNode n) {
    return defaultValue;
  }
  public T visit(IPreDecrementExpressionNode n) {
    return defaultValue;
  }
  public T visit(ITypeExpressionNode n) {
    return defaultValue;
  }
  public T visit(ITryStatementNode n) {
    return defaultValue;
  }
  public T visit(INestedClassDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IConditionalAndExpressionNode n) {
    return defaultValue;
  }
  public T visit(ISingleElementAnnotationNode n) {
    return defaultValue;
  }
  public T visit(ITypeFormalNode n) {
    return defaultValue;
  }
  public T visit(IFinallyNode n) {
    return defaultValue;
  }
  public T visit(IFalseExpressionNode n) {
    return defaultValue;
  }
  public T visit(IBooleanTypeNode n) {
    return defaultValue;
  }
  public T visit(IThrowStatementNode n) {
    return defaultValue;
  }
  public T visit(IDefaultValueNode n) {
    return defaultValue;
  }
  public T visit(IPreIncrementExpressionNode n) {
    return defaultValue;
  }
  public T visit(IStaticImportNode n) {
    return defaultValue;
  }
  public T visit(INonPolymorphicMethodCallNode n) {
    return defaultValue;
  }
  public T visit(IDefaultLabelNode n) {
    return defaultValue;
  }
  public T visit(IImportDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IMethodDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IArrayInitializerNode n) {
    return defaultValue;
  }
  public T visit(IVarArgsTypeNode n) {
    return defaultValue;
  }
  public T visit(IByteTypeNode n) {
    return defaultValue;
  }
  public T visit(IOmittedMethodBodyNode n) {
    return defaultValue;
  }
  public T visit(ICharTypeNode n) {
    return defaultValue;
  }
  public T visit(IClassDeclarationNode n) {
    return defaultValue;
  }
  public T visit(IStringLiteralNode n) {
    return defaultValue;
  }
  public T visit(IStringConcatNode n) {
    return defaultValue;
  }
  public T visit(IInstanceOfExpressionNode n) {
    return defaultValue;
  }
  public T visit(ILessThanEqualExpressionNode n) {
    return defaultValue;
  }
  public T visit(ITypeRefNode n) {
    return defaultValue;
  }
  public T visit(IVoidTypeNode n) {
    return defaultValue;
  }
  public T visit(IArrayTypeNode n) {
    return defaultValue;
  }
  public T visit(IArrayLengthNode n) {
    return defaultValue;
  }
  public T visit(IConstantLabelNode n) {
    return defaultValue;
  }
  public T visit(IConditionalOrExpressionNode n) {
    return defaultValue;
  }
}
