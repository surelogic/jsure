// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A map from one region to another.   Used in unshared field region
 * specifications and in class declarations.
 * 
 * Syntax:
 *    from : IRegionSpecificationNode
 *    "into"
 *    to : IRegionSpecificationNode
 * 
 */
public interface IRegionMappingNode extends IRegionDeclarationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IRegionSpecificationNode getFrom();
  /**
   * @return A non-null node
   */
  public IRegionSpecificationNode getTo();
}

