// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 *    bodyList : List<IClassBodyDeclarationNode> or null
 * 
 */
public interface ITypeDeclarationNode extends IDeclarationNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassBodyDeclarationNode> getBodyList();
}

