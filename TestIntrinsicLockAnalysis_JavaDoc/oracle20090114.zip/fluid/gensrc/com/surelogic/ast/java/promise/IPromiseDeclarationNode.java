// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Parent of all declarations of promised entities (locks, regions, etc.)
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 */
public interface IPromiseDeclarationNode extends IDeclarationNode { 
  public PromiseNodeType getNodeType();
}

