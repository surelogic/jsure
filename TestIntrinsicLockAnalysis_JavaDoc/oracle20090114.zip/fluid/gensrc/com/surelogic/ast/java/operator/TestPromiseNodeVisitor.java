// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

@SuppressWarnings("deprecation")
public class TestPromiseNodeVisitor<T> extends TestBaseNodeVisitor<T> implements IPromiseNodeVisitor<T> {
  public TestPromiseNodeVisitor(boolean bind) {
    super(bind);
  }
  public T visit(IColorRenameNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getColor());
    handleChild(n, n.getCSpec());
    return null;
  }
  public T visit(IColorRequireNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCSpec());
    return null;
  }
  public T visit(IColorCardNNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IColorAndParenNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAndElemsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IQualifiedRegionNameNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    handleChild(n, n.getType());
    n.getId();
    return null;
  }
  public T visit(IInitDeclarationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IEnclosingModuleNode n) {
    checkOwnParent(null, n);
    n.getId();
    for(IJavaOperatorNode c : n.getModulesList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ITaintedNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IStartsSpecificationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IAndTargetNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getTarget1());
    handleChild(n, n.getTarget2());
    return null;
  }
  public T visit(IColorNameNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IColorDeclarationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getColorList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IConstructorDeclPatternNode n) {
    checkOwnParent(null, n);
    n.getMods();
    n.getPkg();
    n.getType();
    for(IJavaOperatorNode c : n.getSigList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getThrowsCList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IReturnValueDeclarationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IColorCard1Node n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IColorAndNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getAndElemsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IInvariantDeclarationNode n) {
    checkOwnParent(null, n);
    n.getMods();
    n.getId();
    handleChild(n, n.getCond());
    return null;
  }
  public T visit(IScopedModuleNode n) {
    checkOwnParent(null, n);
    n.getId();
    handleChild(n, n.getTargets());
    return null;
  }
  public T visit(IColorExprNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IModuleNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IComplexTargetNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(ITransparentNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IFieldRegionSpecificationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IRegionDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IAPINode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IRegionSpecificationNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    n.getId();
    return null;
  }
  public T visit(IColorIncompatibleNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getColorList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IColorOrElemNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IColoringAnnotationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IColorSpecNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IRegionMappingNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getFrom());
    handleChild(n, n.getTo());
    return null;
  }
  public T visit(IColorRevokeNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getColorList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ISubtypedBySpecificationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ITargetedAnnotationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(INotTaintedNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IEffectSpecificationNode n) {
    checkOwnParent(null, n);
    n.getIsWrite();
    handleChild(n, n.getContext());
    handleChild(n, n.getRegion());
    return null;
  }
  public T visit(IColorOrParenNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getOrElemsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IIntOrNNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IPromiseTargetNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IFieldDeclPatternNode n) {
    checkOwnParent(null, n);
    n.getMods();
    handleChild(n, n.getFtype());
    handleChild(n, n.getType());
    n.getName();
    return null;
  }
  public T visit(IColorConstrainedRegionsNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCSpec());
    for(IJavaOperatorNode c : n.getCRegionsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IEffectsSpecificationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getEffectList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IMethodDeclPatternNode n) {
    checkOwnParent(null, n);
    n.getMods();
    handleChild(n, n.getRtype());
    handleChild(n, n.getType());
    n.getName();
    for(IJavaOperatorNode c : n.getSigList()) {
      handleChild(n, c);
    }
    for(IJavaOperatorNode c : n.getThrowsCList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IColorOrNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getOrElemsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(ITypeDeclPatternNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveType() == null) {
      throw new NullPointerException("type binding was null");
    }
    n.getMods();
    n.getPkg();
    n.getType();
    return null;
  }
  public T visit(IColorImportNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getItem());
    return null;
  }
  public T visit(IColorCardChoiceNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IUsedBySpecificationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getTypesList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IOrTargetNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getTarget1());
    handleChild(n, n.getTarget2());
    return null;
  }
  public T visit(IAnyInstanceExpressionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getType());
    return null;
  }
  public T visit(INewRegionDeclarationNode n) {
    checkOwnParent(null, n);
    n.getModifiers();
    n.getId();
    handleChild(n, n.getParent());
    return null;
  }
  public T visit(IScopedPromiseNode n) {
    checkOwnParent(null, n);
    n.getPromise();
    handleChild(n, n.getTargets());
    return null;
  }
  public T visit(ITypeQualifierPatternNode n) {
    checkOwnParent(null, n);
    n.getPkg();
    n.getType();
    return null;
  }
  public T visit(IColorGrantNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getColorList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IColorContextNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCSpec());
    return null;
  }
  public T visit(IColorCardinalityNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getColor());
    handleChild(n, n.getCard());
    return null;
  }
  public T visit(IClassInitDeclarationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(INotTargetNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getTarget());
    return null;
  }
  public T visit(IColorNoteNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getCnamesList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IRegionNameNode n) {
    checkOwnParent(null, n);
    if (testBindings && n.resolveBinding() == null) {
      throw new NullPointerException("binding was null");
    }
    n.getId();
    return null;
  }
  public T visit(IFieldMappingsNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getFieldsList()) {
      handleChild(n, c);
    }
    handleChild(n, n.getTo());
    return null;
  }
  public T visit(IConditionNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getCond());
    return null;
  }
  public T visit(IPromiseDeclarationNode n) {
    checkOwnParent(null, n);
    n.getId();
    return null;
  }
  public T visit(IColorNotNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getTarget());
    return null;
  }
  public T visit(IColorizedRegionNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getCRegionsList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IReceiverDeclarationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IMappedRegionSpecificationNode n) {
    checkOwnParent(null, n);
    for(IJavaOperatorNode c : n.getMappingList()) {
      handleChild(n, c);
    }
    return null;
  }
  public T visit(IDataColoringAnnotationNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IColorAndElemNode n) {
    checkOwnParent(null, n);
    return null;
  }
  public T visit(IQualifiedReceiverDeclarationNode n) {
    checkOwnParent(null, n);
    handleChild(n, n.getBase());
    return null;
  }
}
