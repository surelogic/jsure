// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    typeArgsList : List<IReferenceTypeNode>
 *    argsList : List<IExpressionNode>
 * 
 * Binds this name to IFunctionBinding
 */
public interface ICallNode extends IJavaOperatorNode, IHasBinding { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IFunctionBinding resolveBinding();

  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IReferenceTypeNode> getTypeArgsList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

