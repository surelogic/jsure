// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    "enum"
 *    id : Info (String)
 *    implsList : List<IClassTypeNode>
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * 
 */
public interface IEnumDeclarationNode extends ITypeDeclarationNode, IClassBodyDeclarationNode, IDeclaredType { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
  public boolean isPublic();
  public boolean isStrictfp();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassTypeNode> getImplsList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassBodyDeclarationNode> getBodyList();
}

