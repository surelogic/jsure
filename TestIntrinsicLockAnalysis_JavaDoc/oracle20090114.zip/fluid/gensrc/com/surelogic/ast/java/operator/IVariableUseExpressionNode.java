// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    id : Info (String)
 * 
 * Binds this name to IVariableBinding
 */
public interface IVariableUseExpressionNode extends IPrimaryExpressionNode, IHasBinding { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IVariableBinding resolveBinding();

  /**
   * @return A non-null String
   */
  public String getId();
}

