// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    type : IClassTypeNode
 *    <>
 *    "."
 *    <>
 *    "this"
 * 
 * Binds to the type represented by ISourceRefTypeBinding
 * Binds this name to IVariableBinding
 */
public interface IQualifiedThisExpressionNode extends ISomeThisExpressionNode, IHasBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IVariableBinding resolveBinding();

  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the QualifiedThisExpression
   */
  public ISourceRefType resolveType();

  /**
   * @return A non-null node
   */
  public IClassTypeNode getType();
}

