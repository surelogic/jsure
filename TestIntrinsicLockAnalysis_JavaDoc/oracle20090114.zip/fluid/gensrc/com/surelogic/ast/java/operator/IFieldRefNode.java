// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    <?>
 *    object : IExpressionNode
 *    <>
 *    "."
 *    <>
 *    </?>
 *    id : Info (String)
 * 
 * Binds this name to IVariableBinding
 */
public interface IFieldRefNode extends IPrimaryExpressionNode, IHasBinding { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IVariableBinding resolveBinding();

  /**
   * @return A non-null node
   */
  public IExpressionNode getObject();
  /**
   * @return A non-null String
   */
  public String getId();
}

