// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "static"
 *    type : IClassTypeNode
 *    <>
 *    "."
 *    <>
 *    ref : Info (String)
 * 
 */
public interface IStaticImportNode extends IImportNameNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IClassTypeNode getType();
  /**
   * @return A non-null String
   */
  public String getRef();
}

