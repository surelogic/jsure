// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "!"
 *    target : IPromiseTargetNode
 * 
 */
public interface INotTargetNode extends IComplexTargetNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IPromiseTargetNode getTarget();
}

