// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    base : ITypeNode
 *    dims : DimInfo (int)
 * 
 */
public interface IArrayTypeNode extends IReferenceTypeNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ITypeNode getBase();
  /**
   * @return A non-null int
   */
  public int getDims();
}

