// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g 2008-09-25 15:48:58

package com.surelogic.annotation.parse;

import com.surelogic.parse.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class SLColorAnnotationsLexer extends Lexer {
    public static final int COLORREVOKE=43;
    public static final int ColorRename=21;
    public static final int HexDigit=70;
    public static final int ExportTo=36;
    public static final int T__80=80;
    public static final int START_IMAGINARY=4;
    public static final int COLORIMPORT=47;
    public static final int Names=38;
    public static final int ColorExpr=19;
    public static final int LBRACKET=63;
    public static final int QualifiedRegionName=6;
    public static final int EXPORT=55;
    public static final int INSTANCE=61;
    public static final int COLORIZED=49;
    public static final int ModuleWrapper=30;
    public static final int T__74=74;
    public static final int TO=60;
    public static final int ColorCR=24;
    public static final int ModuleChoice=31;
    public static final int NOVIS=54;
    public static final int COLORINCOMPATIBLE=45;
    public static final int Transparent=27;
    public static final int VIS=53;
    public static final int COLORCONSTRAINEDREGIONS=50;
    public static final int RBRACKET=64;
    public static final int MODULE=52;
    public static final int RPAREN=66;
    public static final int CONTAINS=57;
    public static final int LPAREN=65;
    public static final int COLORDECLARE=40;
    public static final int RegionName=8;
    public static final int Nothing=28;
    public static final int BlockImport=35;
    public static final int VisClause=32;
    public static final int Export=34;
    public static final int BLOCKIMPORT=56;
    public static final int ColorSimpleNames=11;
    public static final int COLORGRANT=42;
    public static final int COLORTRANSPARENT=51;
    public static final int FROM=58;
    public static final int ID=73;
    public static final int RegionSpecifications=7;
    public static final int ColorName=10;
    public static final int OfNamesClause=37;
    public static final int Color=26;
    public static final int LETTER=71;
    public static final int ColorizedRegion=23;
    public static final int ColorNot=16;
    public static final int T__78=78;
    public static final int ColorDeclaration=12;
    public static final int ColorConstraint=25;
    public static final int NoVisClause=33;
    public static final int END_IMAGINARY=39;
    public static final int ColorOr=18;
    public static final int T__79=79;
    public static final int ColorIncompatible=15;
    public static final int OF=59;
    public static final int NamedType=9;
    public static final int ColorCardSpec=22;
    public static final int COLORCARD=48;
    public static final int QUOTE=68;
    public static final int T__77=77;
    public static final int COLORRENAME=46;
    public static final int TestResult=5;
    public static final int JavaIDDigit=72;
    public static final int ColorImport=20;
    public static final int COLORCONSTRAINT=44;
    public static final int T__75=75;
    public static final int EOF=-1;
    public static final int COLOR=41;
    public static final int T__76=76;
    public static final int FOR=67;
    public static final int T__82=82;
    public static final int T__81=81;
    public static final int IDENTIFIER=62;
    public static final int STAR=69;
    public static final int T__83=83;
    public static final int ModulePromise=29;
    public static final int ColorGrant=13;
    public static final int ColorAnd=17;
    public static final int ColorRevoke=14;

      /**
       * Makes it create TreeTokens, instead of CommonTokens
       */
      @Override 
      public Token emit() {
        Token t = new TreeToken(input, state.type, state.channel, state.tokenStartCharIndex, getCharIndex()-1);
        t.setLine(state.tokenStartLine);
        t.setText(state.text);
        t.setCharPositionInLine(state.tokenStartCharPositionInLine);
        emit(t);
        return t;
      }


    // delegates
    // delegators

    public SLColorAnnotationsLexer() {;} 
    public SLColorAnnotationsLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public SLColorAnnotationsLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g"; }

    // $ANTLR start "COLORDECLARE"
    public final void mCOLORDECLARE() throws RecognitionException {
        try {
            int _type = COLORDECLARE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:27:14: ( '@ColorDeclare' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:27:16: '@ColorDeclare'
            {
            match("@ColorDeclare"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORDECLARE"

    // $ANTLR start "COLOR"
    public final void mCOLOR() throws RecognitionException {
        try {
            int _type = COLOR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:28:7: ( '@Color' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:28:9: '@Color'
            {
            match("@Color"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLOR"

    // $ANTLR start "COLORGRANT"
    public final void mCOLORGRANT() throws RecognitionException {
        try {
            int _type = COLORGRANT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:29:12: ( '@Grant' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:29:14: '@Grant'
            {
            match("@Grant"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORGRANT"

    // $ANTLR start "COLORREVOKE"
    public final void mCOLORREVOKE() throws RecognitionException {
        try {
            int _type = COLORREVOKE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:30:13: ( '@Revoke' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:30:15: '@Revoke'
            {
            match("@Revoke"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORREVOKE"

    // $ANTLR start "COLORCONSTRAINT"
    public final void mCOLORCONSTRAINT() throws RecognitionException {
        try {
            int _type = COLORCONSTRAINT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:31:17: ( '@ColorConstraint' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:31:19: '@ColorConstraint'
            {
            match("@ColorConstraint"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORCONSTRAINT"

    // $ANTLR start "COLORINCOMPATIBLE"
    public final void mCOLORINCOMPATIBLE() throws RecognitionException {
        try {
            int _type = COLORINCOMPATIBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:32:19: ( '@IncompatibleColors' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:32:21: '@IncompatibleColors'
            {
            match("@IncompatibleColors"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORINCOMPATIBLE"

    // $ANTLR start "COLORRENAME"
    public final void mCOLORRENAME() throws RecognitionException {
        try {
            int _type = COLORRENAME;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:33:13: ( '@ColorRename' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:33:15: '@ColorRename'
            {
            match("@ColorRename"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORRENAME"

    // $ANTLR start "COLORIMPORT"
    public final void mCOLORIMPORT() throws RecognitionException {
        try {
            int _type = COLORIMPORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:34:13: ( '@ColorImport' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:34:15: '@ColorImport'
            {
            match("@ColorImport"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORIMPORT"

    // $ANTLR start "COLORCARD"
    public final void mCOLORCARD() throws RecognitionException {
        try {
            int _type = COLORCARD;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:35:11: ( '@ColorCardinality' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:35:13: '@ColorCardinality'
            {
            match("@ColorCardinality"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORCARD"

    // $ANTLR start "COLORIZED"
    public final void mCOLORIZED() throws RecognitionException {
        try {
            int _type = COLORIZED;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:36:11: ( '@ColorizedRegion' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:36:13: '@ColorizedRegion'
            {
            match("@ColorizedRegion"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORIZED"

    // $ANTLR start "COLORCONSTRAINEDREGIONS"
    public final void mCOLORCONSTRAINEDREGIONS() throws RecognitionException {
        try {
            int _type = COLORCONSTRAINEDREGIONS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:37:25: ( '@ColorConstrainedRegions' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:37:27: '@ColorConstrainedRegions'
            {
            match("@ColorConstrainedRegions"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORCONSTRAINEDREGIONS"

    // $ANTLR start "COLORTRANSPARENT"
    public final void mCOLORTRANSPARENT() throws RecognitionException {
        try {
            int _type = COLORTRANSPARENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:38:18: ( '@Transparent' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:38:20: '@Transparent'
            {
            match("@Transparent"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLORTRANSPARENT"

    // $ANTLR start "MODULE"
    public final void mMODULE() throws RecognitionException {
        try {
            int _type = MODULE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:39:8: ( '@Module' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:39:10: '@Module'
            {
            match("@Module"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MODULE"

    // $ANTLR start "VIS"
    public final void mVIS() throws RecognitionException {
        try {
            int _type = VIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:40:5: ( '@Vis' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:40:7: '@Vis'
            {
            match("@Vis"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "VIS"

    // $ANTLR start "NOVIS"
    public final void mNOVIS() throws RecognitionException {
        try {
            int _type = NOVIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:41:7: ( '@NoVis' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:41:9: '@NoVis'
            {
            match("@NoVis"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NOVIS"

    // $ANTLR start "EXPORT"
    public final void mEXPORT() throws RecognitionException {
        try {
            int _type = EXPORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:42:8: ( '@Export' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:42:10: '@Export'
            {
            match("@Export"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EXPORT"

    // $ANTLR start "BLOCKIMPORT"
    public final void mBLOCKIMPORT() throws RecognitionException {
        try {
            int _type = BLOCKIMPORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:43:13: ( '@BlockImport' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:43:15: '@BlockImport'
            {
            match("@BlockImport"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BLOCKIMPORT"

    // $ANTLR start "CONTAINS"
    public final void mCONTAINS() throws RecognitionException {
        try {
            int _type = CONTAINS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:44:10: ( 'contains' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:44:12: 'contains'
            {
            match("contains"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CONTAINS"

    // $ANTLR start "FROM"
    public final void mFROM() throws RecognitionException {
        try {
            int _type = FROM;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:45:6: ( 'from' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:45:8: 'from'
            {
            match("from"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FROM"

    // $ANTLR start "OF"
    public final void mOF() throws RecognitionException {
        try {
            int _type = OF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:46:4: ( 'of' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:46:6: 'of'
            {
            match("of"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "OF"

    // $ANTLR start "TO"
    public final void mTO() throws RecognitionException {
        try {
            int _type = TO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:47:4: ( 'to' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:47:6: 'to'
            {
            match("to"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TO"

    // $ANTLR start "T__74"
    public final void mT__74() throws RecognitionException {
        try {
            int _type = T__74;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:48:7: ( 'is' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:48:9: 'is'
            {
            match("is"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__74"

    // $ANTLR start "T__75"
    public final void mT__75() throws RecognitionException {
        try {
            int _type = T__75;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:49:7: ( '&' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:49:9: '&'
            {
            match('&'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__75"

    // $ANTLR start "T__76"
    public final void mT__76() throws RecognitionException {
        try {
            int _type = T__76;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:50:7: ( ':' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:50:9: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__76"

    // $ANTLR start "T__77"
    public final void mT__77() throws RecognitionException {
        try {
            int _type = T__77;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:51:7: ( '/*' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:51:9: '/*'
            {
            match("/*"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__77"

    // $ANTLR start "T__78"
    public final void mT__78() throws RecognitionException {
        try {
            int _type = T__78;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:52:7: ( '/**' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:52:9: '/**'
            {
            match("/**"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__78"

    // $ANTLR start "T__79"
    public final void mT__79() throws RecognitionException {
        try {
            int _type = T__79;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:53:7: ( '.' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:53:9: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__79"

    // $ANTLR start "T__80"
    public final void mT__80() throws RecognitionException {
        try {
            int _type = T__80;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:54:7: ( ',' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:54:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__80"

    // $ANTLR start "T__81"
    public final void mT__81() throws RecognitionException {
        try {
            int _type = T__81;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:55:7: ( '!' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:55:9: '!'
            {
            match('!'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__81"

    // $ANTLR start "T__82"
    public final void mT__82() throws RecognitionException {
        try {
            int _type = T__82;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:56:7: ( '|' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:56:9: '|'
            {
            match('|'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__82"

    // $ANTLR start "T__83"
    public final void mT__83() throws RecognitionException {
        try {
            int _type = T__83;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:57:7: ( '1' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:57:9: '1'
            {
            match('1'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__83"

    // $ANTLR start "FOR"
    public final void mFOR() throws RecognitionException {
        try {
            int _type = FOR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:374:5: ( 'for' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:374:7: 'for'
            {
            match("for"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FOR"

    // $ANTLR start "LBRACKET"
    public final void mLBRACKET() throws RecognitionException {
        try {
            int _type = LBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:393:10: ( '[' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:393:12: '['
            {
            match('['); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACKET"

    // $ANTLR start "RBRACKET"
    public final void mRBRACKET() throws RecognitionException {
        try {
            int _type = RBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:394:10: ( ']' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:394:12: ']'
            {
            match(']'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACKET"

    // $ANTLR start "LPAREN"
    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:396:8: ( '(' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:396:10: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LPAREN"

    // $ANTLR start "RPAREN"
    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:397:8: ( ')' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:397:10: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RPAREN"

    // $ANTLR start "QUOTE"
    public final void mQUOTE() throws RecognitionException {
        try {
            int _type = QUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:398:7: ( '\\'' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:398:9: '\\''
            {
            match('\''); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "QUOTE"

    // $ANTLR start "STAR"
    public final void mSTAR() throws RecognitionException {
        try {
            int _type = STAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:403:7: ( '*' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:403:9: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STAR"

    // $ANTLR start "HexDigit"
    public final void mHexDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:414:10: ( ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:414:12: ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' )
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='F')||(input.LA(1)>='a' && input.LA(1)<='f') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "HexDigit"

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:461:5: ( LETTER ( LETTER | JavaIDDigit )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:461:7: LETTER ( LETTER | JavaIDDigit )*
            {
            mLETTER(); 
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:461:14: ( LETTER | JavaIDDigit )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0=='$'||(LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='Z')||LA1_0=='_'||(LA1_0>='a' && LA1_0<='z')||(LA1_0>='\u00C0' && LA1_0<='\u00D6')||(LA1_0>='\u00D8' && LA1_0<='\u00F6')||(LA1_0>='\u00F8' && LA1_0<='\u1FFF')||(LA1_0>='\u3040' && LA1_0<='\u318F')||(LA1_0>='\u3300' && LA1_0<='\u337F')||(LA1_0>='\u3400' && LA1_0<='\u3D2D')||(LA1_0>='\u4E00' && LA1_0<='\u9FFF')||(LA1_0>='\uF900' && LA1_0<='\uFAFF')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "IDENTIFIER"
    public final void mIDENTIFIER() throws RecognitionException {
        try {
            int _type = IDENTIFIER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:476:5: ( ID )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:476:7: ID
            {
            mID(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IDENTIFIER"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:484:5: ( '\\u0024' | '\\u0041' .. '\\u005a' | '\\u005f' | '\\u0061' .. '\\u007a' | '\\u00c0' .. '\\u00d6' | '\\u00d8' .. '\\u00f6' | '\\u00f8' .. '\\u00ff' | '\\u0100' .. '\\u1fff' | '\\u3040' .. '\\u318f' | '\\u3300' .. '\\u337f' | '\\u3400' .. '\\u3d2d' | '\\u4e00' .. '\\u9fff' | '\\uf900' .. '\\ufaff' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:
            {
            if ( input.LA(1)=='$'||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "JavaIDDigit"
    public final void mJavaIDDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:501:5: ( '\\u0030' .. '\\u0039' | '\\u0660' .. '\\u0669' | '\\u06f0' .. '\\u06f9' | '\\u0966' .. '\\u096f' | '\\u09e6' .. '\\u09ef' | '\\u0a66' .. '\\u0a6f' | '\\u0ae6' .. '\\u0aef' | '\\u0b66' .. '\\u0b6f' | '\\u0be7' .. '\\u0bef' | '\\u0c66' .. '\\u0c6f' | '\\u0ce6' .. '\\u0cef' | '\\u0d66' .. '\\u0d6f' | '\\u0e50' .. '\\u0e59' | '\\u0ed0' .. '\\u0ed9' | '\\u1040' .. '\\u1049' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='\u0660' && input.LA(1)<='\u0669')||(input.LA(1)>='\u06F0' && input.LA(1)<='\u06F9')||(input.LA(1)>='\u0966' && input.LA(1)<='\u096F')||(input.LA(1)>='\u09E6' && input.LA(1)<='\u09EF')||(input.LA(1)>='\u0A66' && input.LA(1)<='\u0A6F')||(input.LA(1)>='\u0AE6' && input.LA(1)<='\u0AEF')||(input.LA(1)>='\u0B66' && input.LA(1)<='\u0B6F')||(input.LA(1)>='\u0BE7' && input.LA(1)<='\u0BEF')||(input.LA(1)>='\u0C66' && input.LA(1)<='\u0C6F')||(input.LA(1)>='\u0CE6' && input.LA(1)<='\u0CEF')||(input.LA(1)>='\u0D66' && input.LA(1)<='\u0D6F')||(input.LA(1)>='\u0E50' && input.LA(1)<='\u0E59')||(input.LA(1)>='\u0ED0' && input.LA(1)<='\u0ED9')||(input.LA(1)>='\u1040' && input.LA(1)<='\u1049') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "JavaIDDigit"

    public void mTokens() throws RecognitionException {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:8: ( COLORDECLARE | COLOR | COLORGRANT | COLORREVOKE | COLORCONSTRAINT | COLORINCOMPATIBLE | COLORRENAME | COLORIMPORT | COLORCARD | COLORIZED | COLORCONSTRAINEDREGIONS | COLORTRANSPARENT | MODULE | VIS | NOVIS | EXPORT | BLOCKIMPORT | CONTAINS | FROM | OF | TO | T__74 | T__75 | T__76 | T__77 | T__78 | T__79 | T__80 | T__81 | T__82 | T__83 | FOR | LBRACKET | RBRACKET | LPAREN | RPAREN | QUOTE | STAR | IDENTIFIER )
        int alt2=39;
        alt2 = dfa2.predict(input);
        switch (alt2) {
            case 1 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:10: COLORDECLARE
                {
                mCOLORDECLARE(); 

                }
                break;
            case 2 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:23: COLOR
                {
                mCOLOR(); 

                }
                break;
            case 3 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:29: COLORGRANT
                {
                mCOLORGRANT(); 

                }
                break;
            case 4 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:40: COLORREVOKE
                {
                mCOLORREVOKE(); 

                }
                break;
            case 5 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:52: COLORCONSTRAINT
                {
                mCOLORCONSTRAINT(); 

                }
                break;
            case 6 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:68: COLORINCOMPATIBLE
                {
                mCOLORINCOMPATIBLE(); 

                }
                break;
            case 7 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:86: COLORRENAME
                {
                mCOLORRENAME(); 

                }
                break;
            case 8 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:98: COLORIMPORT
                {
                mCOLORIMPORT(); 

                }
                break;
            case 9 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:110: COLORCARD
                {
                mCOLORCARD(); 

                }
                break;
            case 10 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:120: COLORIZED
                {
                mCOLORIZED(); 

                }
                break;
            case 11 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:130: COLORCONSTRAINEDREGIONS
                {
                mCOLORCONSTRAINEDREGIONS(); 

                }
                break;
            case 12 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:154: COLORTRANSPARENT
                {
                mCOLORTRANSPARENT(); 

                }
                break;
            case 13 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:171: MODULE
                {
                mMODULE(); 

                }
                break;
            case 14 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:178: VIS
                {
                mVIS(); 

                }
                break;
            case 15 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:182: NOVIS
                {
                mNOVIS(); 

                }
                break;
            case 16 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:188: EXPORT
                {
                mEXPORT(); 

                }
                break;
            case 17 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:195: BLOCKIMPORT
                {
                mBLOCKIMPORT(); 

                }
                break;
            case 18 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:207: CONTAINS
                {
                mCONTAINS(); 

                }
                break;
            case 19 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:216: FROM
                {
                mFROM(); 

                }
                break;
            case 20 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:221: OF
                {
                mOF(); 

                }
                break;
            case 21 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:224: TO
                {
                mTO(); 

                }
                break;
            case 22 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:227: T__74
                {
                mT__74(); 

                }
                break;
            case 23 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:233: T__75
                {
                mT__75(); 

                }
                break;
            case 24 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:239: T__76
                {
                mT__76(); 

                }
                break;
            case 25 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:245: T__77
                {
                mT__77(); 

                }
                break;
            case 26 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:251: T__78
                {
                mT__78(); 

                }
                break;
            case 27 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:257: T__79
                {
                mT__79(); 

                }
                break;
            case 28 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:263: T__80
                {
                mT__80(); 

                }
                break;
            case 29 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:269: T__81
                {
                mT__81(); 

                }
                break;
            case 30 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:275: T__82
                {
                mT__82(); 

                }
                break;
            case 31 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:281: T__83
                {
                mT__83(); 

                }
                break;
            case 32 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:287: FOR
                {
                mFOR(); 

                }
                break;
            case 33 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:291: LBRACKET
                {
                mLBRACKET(); 

                }
                break;
            case 34 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:300: RBRACKET
                {
                mRBRACKET(); 

                }
                break;
            case 35 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:309: LPAREN
                {
                mLPAREN(); 

                }
                break;
            case 36 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:316: RPAREN
                {
                mRPAREN(); 

                }
                break;
            case 37 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:323: QUOTE
                {
                mQUOTE(); 

                }
                break;
            case 38 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:329: STAR
                {
                mSTAR(); 

                }
                break;
            case 39 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLColorAnnotations.g:1:334: IDENTIFIER
                {
                mIDENTIFIER(); 

                }
                break;

        }

    }


    protected DFA2 dfa2 = new DFA2(this);
    static final String DFA2_eotS =
        "\2\uffff\5\25\31\uffff\3\25\1\53\1\54\1\55\1\57\1\uffff\2\25\1\63"+
        "\6\uffff\1\25\1\66\2\uffff\1\25\1\uffff\1\76\1\25\6\uffff\1\25\2"+
        "\uffff\1\104\12\uffff";
    static final String DFA2_eofS =
        "\115\uffff";
    static final String DFA2_minS =
        "\1\41\1\102\2\157\1\146\1\157\1\163\2\uffff\1\52\14\uffff\1\157"+
        "\11\uffff\1\156\1\157\1\162\3\44\1\52\1\154\1\164\1\155\1\44\5\uffff"+
        "\1\157\1\141\1\44\1\uffff\1\162\1\151\1\uffff\1\103\1\156\1\uffff"+
        "\1\141\4\uffff\1\163\1\156\1\uffff\1\44\1\163\1\uffff\1\164\1\162"+
        "\1\141\1\151\1\156\1\145\2\uffff";
    static final String DFA2_maxS =
        "\1\ufaff\1\126\1\157\1\162\1\146\1\157\1\163\2\uffff\1\52\14\uffff"+
        "\1\157\11\uffff\1\156\1\157\1\162\3\ufaff\1\52\1\154\1\164\1\155"+
        "\1\ufaff\5\uffff\1\157\1\141\1\ufaff\1\uffff\1\162\1\151\1\uffff"+
        "\1\151\1\156\1\uffff\1\157\4\uffff\1\163\1\156\1\uffff\1\ufaff\1"+
        "\163\1\uffff\1\164\1\162\1\141\1\151\1\156\1\164\2\uffff";
    static final String DFA2_acceptS =
        "\7\uffff\1\27\1\30\1\uffff\1\33\1\34\1\35\1\36\1\37\1\41\1\42\1"+
        "\43\1\44\1\45\1\46\1\47\1\uffff\1\3\1\4\1\6\1\14\1\15\1\16\1\17"+
        "\1\20\1\21\13\uffff\1\24\1\25\1\26\1\32\1\31\3\uffff\1\40\2\uffff"+
        "\1\23\2\uffff\1\1\1\uffff\1\7\1\10\1\12\1\2\2\uffff\1\11\2\uffff"+
        "\1\22\6\uffff\1\5\1\13";
    static final String DFA2_specialS =
        "\115\uffff}>";
    static final String[] DFA2_transitionS = {
            "\1\14\2\uffff\1\25\1\uffff\1\7\1\23\1\21\1\22\1\24\1\uffff\1"+
            "\13\1\uffff\1\12\1\11\1\uffff\1\16\10\uffff\1\10\5\uffff\1\1"+
            "\32\25\1\17\1\uffff\1\20\1\uffff\1\25\1\uffff\2\25\1\2\2\25"+
            "\1\3\2\25\1\6\5\25\1\4\4\25\1\5\6\25\1\uffff\1\15\103\uffff"+
            "\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff\u0150\25\u0170"+
            "\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff\u5200\25\u5900"+
            "\uffff\u0200\25",
            "\1\37\1\26\1\uffff\1\36\1\uffff\1\27\1\uffff\1\31\3\uffff\1"+
            "\33\1\35\3\uffff\1\30\1\uffff\1\32\1\uffff\1\34",
            "\1\40",
            "\1\42\2\uffff\1\41",
            "\1\43",
            "\1\44",
            "\1\45",
            "",
            "",
            "\1\46",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\47",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\50",
            "\1\51",
            "\1\52",
            "\1\25\13\uffff\12\25\7\uffff\32\25\4\uffff\1\25\1\uffff\32"+
            "\25\105\uffff\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff"+
            "\u0150\25\u0170\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff"+
            "\u5200\25\u5900\uffff\u0200\25",
            "\1\25\13\uffff\12\25\7\uffff\32\25\4\uffff\1\25\1\uffff\32"+
            "\25\105\uffff\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff"+
            "\u0150\25\u0170\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff"+
            "\u5200\25\u5900\uffff\u0200\25",
            "\1\25\13\uffff\12\25\7\uffff\32\25\4\uffff\1\25\1\uffff\32"+
            "\25\105\uffff\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff"+
            "\u0150\25\u0170\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff"+
            "\u5200\25\u5900\uffff\u0200\25",
            "\1\56",
            "\1\60",
            "\1\61",
            "\1\62",
            "\1\25\13\uffff\12\25\7\uffff\32\25\4\uffff\1\25\1\uffff\32"+
            "\25\105\uffff\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff"+
            "\u0150\25\u0170\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff"+
            "\u5200\25\u5900\uffff\u0200\25",
            "",
            "",
            "",
            "",
            "",
            "\1\64",
            "\1\65",
            "\1\25\13\uffff\12\25\7\uffff\32\25\4\uffff\1\25\1\uffff\32"+
            "\25\105\uffff\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff"+
            "\u0150\25\u0170\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff"+
            "\u5200\25\u5900\uffff\u0200\25",
            "",
            "\1\67",
            "\1\70",
            "",
            "\1\72\1\71\4\uffff\1\74\10\uffff\1\73\26\uffff\1\75",
            "\1\77",
            "",
            "\1\101\15\uffff\1\100",
            "",
            "",
            "",
            "",
            "\1\102",
            "\1\103",
            "",
            "\1\25\13\uffff\12\25\7\uffff\32\25\4\uffff\1\25\1\uffff\32"+
            "\25\105\uffff\27\25\1\uffff\37\25\1\uffff\u1f08\25\u1040\uffff"+
            "\u0150\25\u0170\uffff\u0080\25\u0080\uffff\u092e\25\u10d2\uffff"+
            "\u5200\25\u5900\uffff\u0200\25",
            "\1\105",
            "",
            "\1\106",
            "\1\107",
            "\1\110",
            "\1\111",
            "\1\112",
            "\1\114\16\uffff\1\113",
            "",
            ""
    };

    static final short[] DFA2_eot = DFA.unpackEncodedString(DFA2_eotS);
    static final short[] DFA2_eof = DFA.unpackEncodedString(DFA2_eofS);
    static final char[] DFA2_min = DFA.unpackEncodedStringToUnsignedChars(DFA2_minS);
    static final char[] DFA2_max = DFA.unpackEncodedStringToUnsignedChars(DFA2_maxS);
    static final short[] DFA2_accept = DFA.unpackEncodedString(DFA2_acceptS);
    static final short[] DFA2_special = DFA.unpackEncodedString(DFA2_specialS);
    static final short[][] DFA2_transition;

    static {
        int numStates = DFA2_transitionS.length;
        DFA2_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA2_transition[i] = DFA.unpackEncodedString(DFA2_transitionS[i]);
        }
    }

    class DFA2 extends DFA {

        public DFA2(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 2;
            this.eot = DFA2_eot;
            this.eof = DFA2_eof;
            this.min = DFA2_min;
            this.max = DFA2_max;
            this.accept = DFA2_accept;
            this.special = DFA2_special;
            this.transition = DFA2_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( COLORDECLARE | COLOR | COLORGRANT | COLORREVOKE | COLORCONSTRAINT | COLORINCOMPATIBLE | COLORRENAME | COLORIMPORT | COLORCARD | COLORIZED | COLORCONSTRAINEDREGIONS | COLORTRANSPARENT | MODULE | VIS | NOVIS | EXPORT | BLOCKIMPORT | CONTAINS | FROM | OF | TO | T__74 | T__75 | T__76 | T__77 | T__78 | T__79 | T__80 | T__81 | T__82 | T__83 | FOR | LBRACKET | RBRACKET | LPAREN | RPAREN | QUOTE | STAR | IDENTIFIER );";
        }
    }
 

}
