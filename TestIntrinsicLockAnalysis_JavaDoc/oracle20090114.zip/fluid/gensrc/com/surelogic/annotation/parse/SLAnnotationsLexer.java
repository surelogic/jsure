// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g 2008-09-25 15:48:49

package com.surelogic.annotation.parse;

import com.surelogic.parse.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class SLAnnotationsLexer extends Lexer {
    public static final int InRegion=18;
    public static final int CONST=111;
    public static final int COMMA=155;
    public static final int PolicyLockDeclaration=7;
    public static final int SYNCHRONIZED=137;
    public static final int HexDigit=162;
    public static final int DOUBLE=115;
    public static final int INTO=88;
    public static final int Throws=68;
    public static final int START_IMAGINARY=4;
    public static final int EffectSpecification=15;
    public static final int QualifiedLockName=8;
    public static final int FALSE=117;
    public static final int ImplicitClassLockExpression=13;
    public static final int RegionEffects=20;
    public static final int FieldRef=40;
    public static final int QualifiedClassLockExpression=11;
    public static final int READ_LOCK=89;
    public static final int ABSTRACT=104;
    public static final int IntType=28;
    public static final int NamedTypePattern=66;
    public static final int MAPFIELDS=77;
    public static final int QualifiedRegionName=10;
    public static final int INSTANCE=91;
    public static final int IMPORT=125;
    public static final int DQUOTE=152;
    public static final int PACKAGE=134;
    public static final int EffectSpecifications=14;
    public static final int CONTINUE=112;
    public static final int DOT=93;
    public static final int NEWLINE=178;
    public static final int PRIVATE=102;
    public static final int RANGLE=160;
    public static final int T__181=181;
    public static final int POLICYLOCK=74;
    public static final int RequiresLock=16;
    public static final int LOCKS=71;
    public static final int AndTarget=59;
    public static final int StartsSpecification=47;
    public static final int RBRACKET=97;
    public static final int FieldDeclPattern=64;
    public static final int RPAREN=150;
    public static final int LockSpecifications=55;
    public static final int LANGLE=159;
    public static final int LockDeclaration=6;
    public static final int WRITE_LOCK=90;
    public static final int Writes=22;
    public static final int VariableUseExpression=42;
    public static final int WRITES=82;
    public static final int FINALLY=119;
    public static final int FloatTypeSuffix=168;
    public static final int EXTENDS=95;
    public static final int AT=148;
    public static final int RegionSpecifications=52;
    public static final int IsLock=23;
    public static final int Expressions=54;
    public static final int MethodDeclPattern=63;
    public static final int SUPER=85;
    public static final int IntegerTypeSuffix=163;
    public static final int ClassExpression=44;
    public static final int WS=177;
    public static final int ConstructorDeclPattern=62;
    public static final int CHAR=110;
    public static final int SuperExpression=38;
    public static final int NEW=131;
    public static final int T__182=182;
    public static final int ReturnValueDeclaration=39;
    public static final int QualifiedThisExpression=12;
    public static final int FINAL=118;
    public static final int NamedType=32;
    public static final int TypeDeclPattern=65;
    public static final int ANY=86;
    public static final int SEMI=147;
    public static final int CATCH=109;
    public static final int STATIC=103;
    public static final int EQUALS=161;
    public static final int CASE=108;
    public static final int FloatType=29;
    public static final int UnicodeEscape=173;
    public static final int INTERFACE=128;
    public static final int HexLiteral=164;
    public static final int BOOLEAN=105;
    public static final int OrTarget=60;
    public static final int ELSE=116;
    public static final int AnyInstanceExpression=43;
    public static final int NewRegionDeclaration=51;
    public static final int REQUIRESLOCK=72;
    public static final int BREAK=106;
    public static final int DecimalLiteral=165;
    public static final int NULL=132;
    public static final int DoubleType=30;
    public static final int ScopedPromise=58;
    public static final int COLON=146;
    public static final int Parameters=67;
    public static final int TypeQualifierPattern=35;
    public static final int LOCK=70;
    public static final int IDENTIFIER=92;
    public static final int Reads=21;
    public static final int ReturnsLock=17;
    public static final int TRUE=141;
    public static final int THROW=138;
    public static final int SHORT=135;
    public static final int AGGREGATE=79;
    public static final int ThisExpression=37;
    public static final int PUBLIC=100;
    public static final int LONG=129;
    public static final int TypeExpression=41;
    public static final int OctalLiteral=166;
    public static final int TRANSIENT=140;
    public static final int FLOAT=120;
    public static final int RETURNSLOCK=75;
    public static final int THROWS=139;
    public static final int MAPREGION=78;
    public static final int LBRACKET=96;
    public static final int GOTO=122;
    public static final int DSTAR=157;
    public static final int LBRACE=153;
    public static final int RBRACE=154;
    public static final int PROTECTED=101;
    public static final int NotTarget=61;
    public static final int BooleanType=24;
    public static final int EscapeSequence=170;
    public static final int INT=127;
    public static final int INSTANCEOF=126;
    public static final int VOID=143;
    public static final int ISLOCK=73;
    public static final int T__183=183;
    public static final int LPAREN=149;
    public static final int Nothing=53;
    public static final int RegionName=9;
    public static final int FieldMappings=50;
    public static final int FloatingPointLiteral=169;
    public static final int SimpleLockName=45;
    public static final int ByteType=25;
    public static final int INREGION=76;
    public static final int LETTER=175;
    public static final int Exponent=167;
    public static final int Annotations=36;
    public static final int DO=114;
    public static final int IMPLEMENTS=124;
    public static final int SWITCH=136;
    public static final int WHILE=145;
    public static final int READS=81;
    public static final int NOTHING=84;
    public static final int END_IMAGINARY=69;
    public static final int CharType=26;
    public static final int IS=87;
    public static final int CharacterLiteral=171;
    public static final int REGION=80;
    public static final int ONLY=133;
    public static final int MappedRegionSpecification=48;
    public static final int StringLiteral=172;
    public static final int QUOTE=151;
    public static final int T__180=180;
    public static final int PROTECTS=83;
    public static final int TestResult=5;
    public static final int THIS=98;
    public static final int ShortType=27;
    public static final int JavaIDDigit=176;
    public static final int TypeRef=33;
    public static final int CLASS=94;
    public static final int NATIVE=130;
    public static final int RETURN=99;
    public static final int BYTE=107;
    public static final int VOLATILE=144;
    public static final int T__179=179;
    public static final int IF=123;
    public static final int EOF=-1;
    public static final int ReadLock=56;
    public static final int FOR=121;
    public static final int T__184=184;
    public static final int ArrayType=34;
    public static final int LockNames=46;
    public static final int DEFAULT=113;
    public static final int OctalEscape=174;
    public static final int DASH=158;
    public static final int STAR=156;
    public static final int LongType=31;
    public static final int RegionMapping=49;
    public static final int TRY=142;
    public static final int Aggregate=19;
    public static final int WriteLock=57;

      /**
       * Makes it create TreeTokens, instead of CommonTokens
       */
      @Override 
      public Token emit() {
        Token t = new TreeToken(input, state.type, state.channel, state.tokenStartCharIndex, getCharIndex()-1);
        t.setLine(state.tokenStartLine);
        t.setText(state.text);
        t.setCharPositionInLine(state.tokenStartCharPositionInLine);
        emit(t);
        return t;
      }


    // delegates
    // delegators

    public SLAnnotationsLexer() {;} 
    public SLAnnotationsLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public SLAnnotationsLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g"; }

    // $ANTLR start "LOCK"
    public final void mLOCK() throws RecognitionException {
        try {
            int _type = LOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:27:6: ( '@Lock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:27:8: '@Lock'
            {
            match("@Lock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LOCK"

    // $ANTLR start "LOCKS"
    public final void mLOCKS() throws RecognitionException {
        try {
            int _type = LOCKS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:28:7: ( '@Locks' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:28:9: '@Locks'
            {
            match("@Locks"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LOCKS"

    // $ANTLR start "REQUIRESLOCK"
    public final void mREQUIRESLOCK() throws RecognitionException {
        try {
            int _type = REQUIRESLOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:29:14: ( '@RequiresLock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:29:16: '@RequiresLock'
            {
            match("@RequiresLock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "REQUIRESLOCK"

    // $ANTLR start "ISLOCK"
    public final void mISLOCK() throws RecognitionException {
        try {
            int _type = ISLOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:30:8: ( '@IsLock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:30:10: '@IsLock'
            {
            match("@IsLock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ISLOCK"

    // $ANTLR start "POLICYLOCK"
    public final void mPOLICYLOCK() throws RecognitionException {
        try {
            int _type = POLICYLOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:31:12: ( '@PolicyLock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:31:14: '@PolicyLock'
            {
            match("@PolicyLock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "POLICYLOCK"

    // $ANTLR start "RETURNSLOCK"
    public final void mRETURNSLOCK() throws RecognitionException {
        try {
            int _type = RETURNSLOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:32:13: ( '@ReturnsLock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:32:15: '@ReturnsLock'
            {
            match("@ReturnsLock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RETURNSLOCK"

    // $ANTLR start "INREGION"
    public final void mINREGION() throws RecognitionException {
        try {
            int _type = INREGION;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:33:10: ( '@InRegion' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:33:12: '@InRegion'
            {
            match("@InRegion"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INREGION"

    // $ANTLR start "MAPFIELDS"
    public final void mMAPFIELDS() throws RecognitionException {
        try {
            int _type = MAPFIELDS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:34:11: ( '@MapFields' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:34:13: '@MapFields'
            {
            match("@MapFields"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MAPFIELDS"

    // $ANTLR start "MAPREGION"
    public final void mMAPREGION() throws RecognitionException {
        try {
            int _type = MAPREGION;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:35:11: ( '@MapRegion' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:35:13: '@MapRegion'
            {
            match("@MapRegion"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MAPREGION"

    // $ANTLR start "AGGREGATE"
    public final void mAGGREGATE() throws RecognitionException {
        try {
            int _type = AGGREGATE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:36:11: ( '@Aggregate' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:36:13: '@Aggregate'
            {
            match("@Aggregate"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "AGGREGATE"

    // $ANTLR start "REGION"
    public final void mREGION() throws RecognitionException {
        try {
            int _type = REGION;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:37:8: ( '@Region' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:37:10: '@Region'
            {
            match("@Region"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "REGION"

    // $ANTLR start "READS"
    public final void mREADS() throws RecognitionException {
        try {
            int _type = READS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:38:7: ( '@Reads' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:38:9: '@Reads'
            {
            match("@Reads"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "READS"

    // $ANTLR start "WRITES"
    public final void mWRITES() throws RecognitionException {
        try {
            int _type = WRITES;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:39:8: ( '@Writes' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:39:10: '@Writes'
            {
            match("@Writes"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WRITES"

    // $ANTLR start "PROTECTS"
    public final void mPROTECTS() throws RecognitionException {
        try {
            int _type = PROTECTS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:40:10: ( 'protects' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:40:12: 'protects'
            {
            match("protects"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PROTECTS"

    // $ANTLR start "NOTHING"
    public final void mNOTHING() throws RecognitionException {
        try {
            int _type = NOTHING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:41:9: ( 'nothing' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:41:11: 'nothing'
            {
            match("nothing"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NOTHING"

    // $ANTLR start "ANY"
    public final void mANY() throws RecognitionException {
        try {
            int _type = ANY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:42:5: ( 'any' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:42:7: 'any'
            {
            match("any"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ANY"

    // $ANTLR start "IS"
    public final void mIS() throws RecognitionException {
        try {
            int _type = IS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:43:4: ( 'is' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:43:6: 'is'
            {
            match("is"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IS"

    // $ANTLR start "INTO"
    public final void mINTO() throws RecognitionException {
        try {
            int _type = INTO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:44:6: ( 'into' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:44:8: 'into'
            {
            match("into"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INTO"

    // $ANTLR start "READ_LOCK"
    public final void mREAD_LOCK() throws RecognitionException {
        try {
            int _type = READ_LOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:45:11: ( 'readLock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:45:13: 'readLock'
            {
            match("readLock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "READ_LOCK"

    // $ANTLR start "WRITE_LOCK"
    public final void mWRITE_LOCK() throws RecognitionException {
        try {
            int _type = WRITE_LOCK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:46:12: ( 'writeLock' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:46:14: 'writeLock'
            {
            match("writeLock"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WRITE_LOCK"

    // $ANTLR start "T__179"
    public final void mT__179() throws RecognitionException {
        try {
            int _type = T__179;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:47:8: ( '&' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:47:10: '&'
            {
            match('&'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__179"

    // $ANTLR start "T__180"
    public final void mT__180() throws RecognitionException {
        try {
            int _type = T__180;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:48:8: ( '/*' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:48:10: '/*'
            {
            match("/*"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__180"

    // $ANTLR start "T__181"
    public final void mT__181() throws RecognitionException {
        try {
            int _type = T__181;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:49:8: ( '/**' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:49:10: '/**'
            {
            match("/**"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__181"

    // $ANTLR start "T__182"
    public final void mT__182() throws RecognitionException {
        try {
            int _type = T__182;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:50:8: ( 'none' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:50:10: 'none'
            {
            match("none"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__182"

    // $ANTLR start "T__183"
    public final void mT__183() throws RecognitionException {
        try {
            int _type = T__183;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:51:8: ( 'reads' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:51:10: 'reads'
            {
            match("reads"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__183"

    // $ANTLR start "T__184"
    public final void mT__184() throws RecognitionException {
        try {
            int _type = T__184;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:52:8: ( 'writes' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:52:10: 'writes'
            {
            match("writes"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__184"

    // $ANTLR start "ABSTRACT"
    public final void mABSTRACT() throws RecognitionException {
        try {
            int _type = ABSTRACT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:570:10: ( 'abstract' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:570:12: 'abstract'
            {
            match("abstract"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ABSTRACT"

    // $ANTLR start "BOOLEAN"
    public final void mBOOLEAN() throws RecognitionException {
        try {
            int _type = BOOLEAN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:571:9: ( 'boolean' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:571:11: 'boolean'
            {
            match("boolean"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BOOLEAN"

    // $ANTLR start "BREAK"
    public final void mBREAK() throws RecognitionException {
        try {
            int _type = BREAK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:572:7: ( 'break' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:572:9: 'break'
            {
            match("break"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BREAK"

    // $ANTLR start "BYTE"
    public final void mBYTE() throws RecognitionException {
        try {
            int _type = BYTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:573:6: ( 'byte' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:573:8: 'byte'
            {
            match("byte"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BYTE"

    // $ANTLR start "CASE"
    public final void mCASE() throws RecognitionException {
        try {
            int _type = CASE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:574:6: ( 'case' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:574:8: 'case'
            {
            match("case"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CASE"

    // $ANTLR start "CATCH"
    public final void mCATCH() throws RecognitionException {
        try {
            int _type = CATCH;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:575:7: ( 'catch' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:575:9: 'catch'
            {
            match("catch"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CATCH"

    // $ANTLR start "CHAR"
    public final void mCHAR() throws RecognitionException {
        try {
            int _type = CHAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:576:6: ( 'char' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:576:8: 'char'
            {
            match("char"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CHAR"

    // $ANTLR start "CLASS"
    public final void mCLASS() throws RecognitionException {
        try {
            int _type = CLASS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:577:7: ( 'class' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:577:9: 'class'
            {
            match("class"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CLASS"

    // $ANTLR start "CONST"
    public final void mCONST() throws RecognitionException {
        try {
            int _type = CONST;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:578:7: ( 'const' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:578:9: 'const'
            {
            match("const"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CONST"

    // $ANTLR start "CONTINUE"
    public final void mCONTINUE() throws RecognitionException {
        try {
            int _type = CONTINUE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:579:10: ( 'continue' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:579:12: 'continue'
            {
            match("continue"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CONTINUE"

    // $ANTLR start "DEFAULT"
    public final void mDEFAULT() throws RecognitionException {
        try {
            int _type = DEFAULT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:580:9: ( 'default' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:580:11: 'default'
            {
            match("default"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DEFAULT"

    // $ANTLR start "DO"
    public final void mDO() throws RecognitionException {
        try {
            int _type = DO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:581:4: ( 'do' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:581:6: 'do'
            {
            match("do"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DO"

    // $ANTLR start "DOUBLE"
    public final void mDOUBLE() throws RecognitionException {
        try {
            int _type = DOUBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:582:8: ( 'double' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:582:10: 'double'
            {
            match("double"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOUBLE"

    // $ANTLR start "ELSE"
    public final void mELSE() throws RecognitionException {
        try {
            int _type = ELSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:583:6: ( 'else' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:583:8: 'else'
            {
            match("else"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ELSE"

    // $ANTLR start "EXTENDS"
    public final void mEXTENDS() throws RecognitionException {
        try {
            int _type = EXTENDS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:584:9: ( 'extends' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:584:11: 'extends'
            {
            match("extends"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EXTENDS"

    // $ANTLR start "FALSE"
    public final void mFALSE() throws RecognitionException {
        try {
            int _type = FALSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:585:7: ( 'false' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:585:9: 'false'
            {
            match("false"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FALSE"

    // $ANTLR start "FINAL"
    public final void mFINAL() throws RecognitionException {
        try {
            int _type = FINAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:586:7: ( 'final' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:586:9: 'final'
            {
            match("final"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FINAL"

    // $ANTLR start "FINALLY"
    public final void mFINALLY() throws RecognitionException {
        try {
            int _type = FINALLY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:587:9: ( 'finally' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:587:11: 'finally'
            {
            match("finally"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FINALLY"

    // $ANTLR start "FLOAT"
    public final void mFLOAT() throws RecognitionException {
        try {
            int _type = FLOAT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:588:7: ( 'float' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:588:9: 'float'
            {
            match("float"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FLOAT"

    // $ANTLR start "FOR"
    public final void mFOR() throws RecognitionException {
        try {
            int _type = FOR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:589:5: ( 'for' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:589:7: 'for'
            {
            match("for"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FOR"

    // $ANTLR start "GOTO"
    public final void mGOTO() throws RecognitionException {
        try {
            int _type = GOTO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:590:6: ( 'goto' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:590:8: 'goto'
            {
            match("goto"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "GOTO"

    // $ANTLR start "IF"
    public final void mIF() throws RecognitionException {
        try {
            int _type = IF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:591:4: ( 'if' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:591:6: 'if'
            {
            match("if"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IF"

    // $ANTLR start "IMPLEMENTS"
    public final void mIMPLEMENTS() throws RecognitionException {
        try {
            int _type = IMPLEMENTS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:592:12: ( 'implements' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:592:14: 'implements'
            {
            match("implements"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IMPLEMENTS"

    // $ANTLR start "IMPORT"
    public final void mIMPORT() throws RecognitionException {
        try {
            int _type = IMPORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:593:8: ( 'import' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:593:10: 'import'
            {
            match("import"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IMPORT"

    // $ANTLR start "INSTANCEOF"
    public final void mINSTANCEOF() throws RecognitionException {
        try {
            int _type = INSTANCEOF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:594:12: ( 'instanceof' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:594:14: 'instanceof'
            {
            match("instanceof"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INSTANCEOF"

    // $ANTLR start "INT"
    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:595:5: ( 'int' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:595:7: 'int'
            {
            match("int"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT"

    // $ANTLR start "INTERFACE"
    public final void mINTERFACE() throws RecognitionException {
        try {
            int _type = INTERFACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:596:11: ( 'interface' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:596:13: 'interface'
            {
            match("interface"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INTERFACE"

    // $ANTLR start "LONG"
    public final void mLONG() throws RecognitionException {
        try {
            int _type = LONG;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:597:6: ( 'long' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:597:8: 'long'
            {
            match("long"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LONG"

    // $ANTLR start "NATIVE"
    public final void mNATIVE() throws RecognitionException {
        try {
            int _type = NATIVE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:598:8: ( 'native' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:598:10: 'native'
            {
            match("native"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NATIVE"

    // $ANTLR start "NEW"
    public final void mNEW() throws RecognitionException {
        try {
            int _type = NEW;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:599:5: ( 'new' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:599:7: 'new'
            {
            match("new"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEW"

    // $ANTLR start "NULL"
    public final void mNULL() throws RecognitionException {
        try {
            int _type = NULL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:600:6: ( 'null' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:600:8: 'null'
            {
            match("null"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NULL"

    // $ANTLR start "ONLY"
    public final void mONLY() throws RecognitionException {
        try {
            int _type = ONLY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:601:6: ( 'only' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:601:8: 'only'
            {
            match("only"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ONLY"

    // $ANTLR start "PACKAGE"
    public final void mPACKAGE() throws RecognitionException {
        try {
            int _type = PACKAGE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:602:9: ( 'package' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:602:11: 'package'
            {
            match("package"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PACKAGE"

    // $ANTLR start "PRIVATE"
    public final void mPRIVATE() throws RecognitionException {
        try {
            int _type = PRIVATE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:603:9: ( 'private' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:603:11: 'private'
            {
            match("private"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PRIVATE"

    // $ANTLR start "PROTECTED"
    public final void mPROTECTED() throws RecognitionException {
        try {
            int _type = PROTECTED;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:604:11: ( 'protected' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:604:13: 'protected'
            {
            match("protected"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PROTECTED"

    // $ANTLR start "PUBLIC"
    public final void mPUBLIC() throws RecognitionException {
        try {
            int _type = PUBLIC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:605:8: ( 'public' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:605:10: 'public'
            {
            match("public"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PUBLIC"

    // $ANTLR start "RETURN"
    public final void mRETURN() throws RecognitionException {
        try {
            int _type = RETURN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:606:8: ( 'return' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:606:10: 'return'
            {
            match("return"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RETURN"

    // $ANTLR start "SHORT"
    public final void mSHORT() throws RecognitionException {
        try {
            int _type = SHORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:607:7: ( 'short' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:607:9: 'short'
            {
            match("short"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SHORT"

    // $ANTLR start "STATIC"
    public final void mSTATIC() throws RecognitionException {
        try {
            int _type = STATIC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:608:8: ( 'static' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:608:10: 'static'
            {
            match("static"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STATIC"

    // $ANTLR start "SUPER"
    public final void mSUPER() throws RecognitionException {
        try {
            int _type = SUPER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:609:7: ( 'super' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:609:9: 'super'
            {
            match("super"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SUPER"

    // $ANTLR start "SWITCH"
    public final void mSWITCH() throws RecognitionException {
        try {
            int _type = SWITCH;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:610:8: ( 'switch' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:610:10: 'switch'
            {
            match("switch"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SWITCH"

    // $ANTLR start "SYNCHRONIZED"
    public final void mSYNCHRONIZED() throws RecognitionException {
        try {
            int _type = SYNCHRONIZED;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:611:14: ( 'synchronized' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:611:16: 'synchronized'
            {
            match("synchronized"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SYNCHRONIZED"

    // $ANTLR start "THIS"
    public final void mTHIS() throws RecognitionException {
        try {
            int _type = THIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:612:6: ( 'this' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:612:8: 'this'
            {
            match("this"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THIS"

    // $ANTLR start "THROW"
    public final void mTHROW() throws RecognitionException {
        try {
            int _type = THROW;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:613:7: ( 'throw' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:613:9: 'throw'
            {
            match("throw"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THROW"

    // $ANTLR start "THROWS"
    public final void mTHROWS() throws RecognitionException {
        try {
            int _type = THROWS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:614:8: ( 'throws' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:614:10: 'throws'
            {
            match("throws"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THROWS"

    // $ANTLR start "TRANSIENT"
    public final void mTRANSIENT() throws RecognitionException {
        try {
            int _type = TRANSIENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:615:11: ( 'transient' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:615:13: 'transient'
            {
            match("transient"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TRANSIENT"

    // $ANTLR start "TRUE"
    public final void mTRUE() throws RecognitionException {
        try {
            int _type = TRUE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:616:6: ( 'true' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:616:8: 'true'
            {
            match("true"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TRUE"

    // $ANTLR start "TRY"
    public final void mTRY() throws RecognitionException {
        try {
            int _type = TRY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:617:5: ( 'try' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:617:7: 'try'
            {
            match("try"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TRY"

    // $ANTLR start "VOID"
    public final void mVOID() throws RecognitionException {
        try {
            int _type = VOID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:618:6: ( 'void' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:618:8: 'void'
            {
            match("void"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "VOID"

    // $ANTLR start "VOLATILE"
    public final void mVOLATILE() throws RecognitionException {
        try {
            int _type = VOLATILE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:619:10: ( 'volatile' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:619:12: 'volatile'
            {
            match("volatile"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "VOLATILE"

    // $ANTLR start "WHILE"
    public final void mWHILE() throws RecognitionException {
        try {
            int _type = WHILE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:620:7: ( 'while' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:620:9: 'while'
            {
            match("while"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WHILE"

    // $ANTLR start "COLON"
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:622:7: ( ':' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:622:9: ':'
            {
            match(':'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLON"

    // $ANTLR start "SEMI"
    public final void mSEMI() throws RecognitionException {
        try {
            int _type = SEMI;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:623:7: ( ';' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:623:9: ';'
            {
            match(';'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SEMI"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:624:7: ( '.' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:624:9: '.'
            {
            match('.'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "LBRACKET"
    public final void mLBRACKET() throws RecognitionException {
        try {
            int _type = LBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:625:10: ( '[' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:625:12: '['
            {
            match('['); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACKET"

    // $ANTLR start "RBRACKET"
    public final void mRBRACKET() throws RecognitionException {
        try {
            int _type = RBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:626:10: ( ']' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:626:12: ']'
            {
            match(']'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACKET"

    // $ANTLR start "AT"
    public final void mAT() throws RecognitionException {
        try {
            int _type = AT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:627:4: ( '@' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:627:6: '@'
            {
            match('@'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "AT"

    // $ANTLR start "LPAREN"
    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:628:8: ( '(' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:628:10: '('
            {
            match('('); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LPAREN"

    // $ANTLR start "RPAREN"
    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:629:8: ( ')' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:629:10: ')'
            {
            match(')'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RPAREN"

    // $ANTLR start "QUOTE"
    public final void mQUOTE() throws RecognitionException {
        try {
            int _type = QUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:630:7: ( '\\'' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:630:9: '\\''
            {
            match('\''); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "QUOTE"

    // $ANTLR start "DQUOTE"
    public final void mDQUOTE() throws RecognitionException {
        try {
            int _type = DQUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:631:8: ( '\"' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:631:10: '\"'
            {
            match('\"'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DQUOTE"

    // $ANTLR start "LBRACE"
    public final void mLBRACE() throws RecognitionException {
        try {
            int _type = LBRACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:632:8: ( '{' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:632:10: '{'
            {
            match('{'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACE"

    // $ANTLR start "RBRACE"
    public final void mRBRACE() throws RecognitionException {
        try {
            int _type = RBRACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:633:8: ( '}' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:633:10: '}'
            {
            match('}'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACE"

    // $ANTLR start "COMMA"
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:634:7: ( ',' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:634:9: ','
            {
            match(','); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMA"

    // $ANTLR start "STAR"
    public final void mSTAR() throws RecognitionException {
        try {
            int _type = STAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:635:7: ( '*' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:635:9: '*'
            {
            match('*'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STAR"

    // $ANTLR start "DSTAR"
    public final void mDSTAR() throws RecognitionException {
        try {
            int _type = DSTAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:636:7: ( '**' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:636:9: '**'
            {
            match("**"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DSTAR"

    // $ANTLR start "DASH"
    public final void mDASH() throws RecognitionException {
        try {
            int _type = DASH;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:637:6: ( '-' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:637:8: '-'
            {
            match('-'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DASH"

    // $ANTLR start "LANGLE"
    public final void mLANGLE() throws RecognitionException {
        try {
            int _type = LANGLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:638:8: ( '<' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:638:10: '<'
            {
            match('<'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LANGLE"

    // $ANTLR start "RANGLE"
    public final void mRANGLE() throws RecognitionException {
        try {
            int _type = RANGLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:639:8: ( '>' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:639:10: '>'
            {
            match('>'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RANGLE"

    // $ANTLR start "EQUALS"
    public final void mEQUALS() throws RecognitionException {
        try {
            int _type = EQUALS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:640:8: ( '=' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:640:10: '='
            {
            match('='); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EQUALS"

    // $ANTLR start "HexLiteral"
    public final void mHexLiteral() throws RecognitionException {
        try {
            int _type = HexLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:642:12: ( '0' ( 'x' | 'X' ) ( HexDigit )+ ( IntegerTypeSuffix )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:642:14: '0' ( 'x' | 'X' ) ( HexDigit )+ ( IntegerTypeSuffix )?
            {
            match('0'); if (state.failed) return ;
            if ( input.LA(1)=='X'||input.LA(1)=='x' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:642:28: ( HexDigit )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='F')||(LA1_0>='a' && LA1_0<='f')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:642:28: HexDigit
            	    {
            	    mHexDigit(); if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:642:38: ( IntegerTypeSuffix )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='L'||LA2_0=='l') ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:642:38: IntegerTypeSuffix
                    {
                    mIntegerTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "HexLiteral"

    // $ANTLR start "DecimalLiteral"
    public final void mDecimalLiteral() throws RecognitionException {
        try {
            int _type = DecimalLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:16: ( ( '0' | '1' .. '9' ( '0' .. '9' )* ) ( IntegerTypeSuffix )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:18: ( '0' | '1' .. '9' ( '0' .. '9' )* ) ( IntegerTypeSuffix )?
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:18: ( '0' | '1' .. '9' ( '0' .. '9' )* )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0=='0') ) {
                alt4=1;
            }
            else if ( ((LA4_0>='1' && LA4_0<='9')) ) {
                alt4=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:19: '0'
                    {
                    match('0'); if (state.failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:25: '1' .. '9' ( '0' .. '9' )*
                    {
                    matchRange('1','9'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:34: ( '0' .. '9' )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( ((LA3_0>='0' && LA3_0<='9')) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:34: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:45: ( IntegerTypeSuffix )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0=='L'||LA5_0=='l') ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:644:45: IntegerTypeSuffix
                    {
                    mIntegerTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DecimalLiteral"

    // $ANTLR start "OctalLiteral"
    public final void mOctalLiteral() throws RecognitionException {
        try {
            int _type = OctalLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:646:14: ( '0' ( '0' .. '7' )+ ( IntegerTypeSuffix )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:646:16: '0' ( '0' .. '7' )+ ( IntegerTypeSuffix )?
            {
            match('0'); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:646:20: ( '0' .. '7' )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='0' && LA6_0<='7')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:646:21: '0' .. '7'
            	    {
            	    matchRange('0','7'); if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:646:32: ( IntegerTypeSuffix )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0=='L'||LA7_0=='l') ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:646:32: IntegerTypeSuffix
                    {
                    mIntegerTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "OctalLiteral"

    // $ANTLR start "HexDigit"
    public final void mHexDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:649:10: ( ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:649:12: ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' )
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='F')||(input.LA(1)>='a' && input.LA(1)<='f') ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "HexDigit"

    // $ANTLR start "IntegerTypeSuffix"
    public final void mIntegerTypeSuffix() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:652:19: ( ( 'l' | 'L' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:652:21: ( 'l' | 'L' )
            {
            if ( input.LA(1)=='L'||input.LA(1)=='l' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "IntegerTypeSuffix"

    // $ANTLR start "FloatingPointLiteral"
    public final void mFloatingPointLiteral() throws RecognitionException {
        try {
            int _type = FloatingPointLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:5: ( ( ( '0' .. '9' )+ '.' )=> ( '0' .. '9' ) '.' ( '0' .. '9' )* ( Exponent )? ( FloatTypeSuffix )? | '.' ( '0' .. '9' )+ ( Exponent )? ( FloatTypeSuffix )? | ( ( '0' .. '9' )+ Exponent )=> ( '0' .. '9' )+ Exponent ( FloatTypeSuffix )? | ( '0' .. '9' )+ ( Exponent )? FloatTypeSuffix )
            int alt18=4;
            alt18 = dfa18.predict(input);
            switch (alt18) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:9: ( ( '0' .. '9' )+ '.' )=> ( '0' .. '9' ) '.' ( '0' .. '9' )* ( Exponent )? ( FloatTypeSuffix )?
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:30: ( '0' .. '9' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:31: '0' .. '9'
                    {
                    matchRange('0','9'); if (state.failed) return ;

                    }

                    match('.'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:45: ( '0' .. '9' )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:46: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:57: ( Exponent )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0=='E'||LA9_0=='e') ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:57: Exponent
                            {
                            mExponent(); if (state.failed) return ;

                            }
                            break;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:67: ( FloatTypeSuffix )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0=='D'||LA10_0=='F'||LA10_0=='d'||LA10_0=='f') ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:67: FloatTypeSuffix
                            {
                            mFloatTypeSuffix(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:9: '.' ( '0' .. '9' )+ ( Exponent )? ( FloatTypeSuffix )?
                    {
                    match('.'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:13: ( '0' .. '9' )+
                    int cnt11=0;
                    loop11:
                    do {
                        int alt11=2;
                        int LA11_0 = input.LA(1);

                        if ( ((LA11_0>='0' && LA11_0<='9')) ) {
                            alt11=1;
                        }


                        switch (alt11) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:14: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt11 >= 1 ) break loop11;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(11, input);
                                throw eee;
                        }
                        cnt11++;
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:25: ( Exponent )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0=='E'||LA12_0=='e') ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:25: Exponent
                            {
                            mExponent(); if (state.failed) return ;

                            }
                            break;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:35: ( FloatTypeSuffix )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0=='D'||LA13_0=='F'||LA13_0=='d'||LA13_0=='f') ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:656:35: FloatTypeSuffix
                            {
                            mFloatTypeSuffix(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:9: ( ( '0' .. '9' )+ Exponent )=> ( '0' .. '9' )+ Exponent ( FloatTypeSuffix )?
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:36: ( '0' .. '9' )+
                    int cnt14=0;
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( ((LA14_0>='0' && LA14_0<='9')) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:37: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt14 >= 1 ) break loop14;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(14, input);
                                throw eee;
                        }
                        cnt14++;
                    } while (true);

                    mExponent(); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:57: ( FloatTypeSuffix )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0=='D'||LA15_0=='F'||LA15_0=='d'||LA15_0=='f') ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:57: FloatTypeSuffix
                            {
                            mFloatTypeSuffix(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:658:9: ( '0' .. '9' )+ ( Exponent )? FloatTypeSuffix
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:658:9: ( '0' .. '9' )+
                    int cnt16=0;
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( ((LA16_0>='0' && LA16_0<='9')) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:658:10: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt16 >= 1 ) break loop16;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(16, input);
                                throw eee;
                        }
                        cnt16++;
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:658:21: ( Exponent )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0=='E'||LA17_0=='e') ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:658:21: Exponent
                            {
                            mExponent(); if (state.failed) return ;

                            }
                            break;

                    }

                    mFloatTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FloatingPointLiteral"

    // $ANTLR start "Exponent"
    public final void mExponent() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:662:10: ( ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:662:12: ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:662:22: ( '+' | '-' )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0=='+'||LA19_0=='-') ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();
                    state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return ;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:662:33: ( '0' .. '9' )+
            int cnt20=0;
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>='0' && LA20_0<='9')) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:662:34: '0' .. '9'
            	    {
            	    matchRange('0','9'); if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    if ( cnt20 >= 1 ) break loop20;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(20, input);
                        throw eee;
                }
                cnt20++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "Exponent"

    // $ANTLR start "FloatTypeSuffix"
    public final void mFloatTypeSuffix() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:665:17: ( ( 'f' | 'F' | 'd' | 'D' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:665:19: ( 'f' | 'F' | 'd' | 'D' )
            {
            if ( input.LA(1)=='D'||input.LA(1)=='F'||input.LA(1)=='d'||input.LA(1)=='f' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "FloatTypeSuffix"

    // $ANTLR start "CharacterLiteral"
    public final void mCharacterLiteral() throws RecognitionException {
        try {
            int _type = CharacterLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:668:5: ( '\\'' ( EscapeSequence | ~ ( '\\'' | '\\\\' ) ) '\\'' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:668:9: '\\'' ( EscapeSequence | ~ ( '\\'' | '\\\\' ) ) '\\''
            {
            match('\''); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:668:14: ( EscapeSequence | ~ ( '\\'' | '\\\\' ) )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0=='\\') ) {
                alt21=1;
            }
            else if ( ((LA21_0>='\u0000' && LA21_0<='&')||(LA21_0>='(' && LA21_0<='[')||(LA21_0>=']' && LA21_0<='\uFFFE')) ) {
                alt21=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:668:16: EscapeSequence
                    {
                    mEscapeSequence(); if (state.failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:668:33: ~ ( '\\'' | '\\\\' )
                    {
                    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
                        input.consume();
                    state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return ;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            match('\''); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CharacterLiteral"

    // $ANTLR start "StringLiteral"
    public final void mStringLiteral() throws RecognitionException {
        try {
            int _type = StringLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:672:5: ( '\"' ( EscapeSequence | ~ ( '\\\\' | '\"' ) )* '\"' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:672:8: '\"' ( EscapeSequence | ~ ( '\\\\' | '\"' ) )* '\"'
            {
            match('\"'); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:672:12: ( EscapeSequence | ~ ( '\\\\' | '\"' ) )*
            loop22:
            do {
                int alt22=3;
                int LA22_0 = input.LA(1);

                if ( (LA22_0=='\\') ) {
                    alt22=1;
                }
                else if ( ((LA22_0>='\u0000' && LA22_0<='!')||(LA22_0>='#' && LA22_0<='[')||(LA22_0>=']' && LA22_0<='\uFFFE')) ) {
                    alt22=2;
                }


                switch (alt22) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:672:14: EscapeSequence
            	    {
            	    mEscapeSequence(); if (state.failed) return ;

            	    }
            	    break;
            	case 2 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:672:31: ~ ( '\\\\' | '\"' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();
            	    state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return ;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            match('\"'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "StringLiteral"

    // $ANTLR start "EscapeSequence"
    public final void mEscapeSequence() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:677:5: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | UnicodeEscape | OctalEscape )
            int alt23=3;
            int LA23_0 = input.LA(1);

            if ( (LA23_0=='\\') ) {
                switch ( input.LA(2) ) {
                case '\"':
                case '\'':
                case '\\':
                case 'b':
                case 'f':
                case 'n':
                case 'r':
                case 't':
                    {
                    alt23=1;
                    }
                    break;
                case 'u':
                    {
                    alt23=2;
                    }
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                    {
                    alt23=3;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 1, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:677:9: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' )
                    {
                    match('\\'); if (state.failed) return ;
                    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                        input.consume();
                    state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return ;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:678:9: UnicodeEscape
                    {
                    mUnicodeEscape(); if (state.failed) return ;

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:679:9: OctalEscape
                    {
                    mOctalEscape(); if (state.failed) return ;

                    }
                    break;

            }
        }
        finally {
        }
    }
    // $ANTLR end "EscapeSequence"

    // $ANTLR start "OctalEscape"
    public final void mOctalEscape() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:5: ( '\\\\' ( '0' .. '3' ) ( '0' .. '7' ) ( '0' .. '7' ) | '\\\\' ( '0' .. '7' ) ( '0' .. '7' ) | '\\\\' ( '0' .. '7' ) )
            int alt24=3;
            int LA24_0 = input.LA(1);

            if ( (LA24_0=='\\') ) {
                int LA24_1 = input.LA(2);

                if ( ((LA24_1>='0' && LA24_1<='3')) ) {
                    int LA24_2 = input.LA(3);

                    if ( ((LA24_2>='0' && LA24_2<='7')) ) {
                        int LA24_4 = input.LA(4);

                        if ( ((LA24_4>='0' && LA24_4<='7')) ) {
                            alt24=1;
                        }
                        else {
                            alt24=2;}
                    }
                    else {
                        alt24=3;}
                }
                else if ( ((LA24_1>='4' && LA24_1<='7')) ) {
                    int LA24_3 = input.LA(3);

                    if ( ((LA24_3>='0' && LA24_3<='7')) ) {
                        alt24=2;
                    }
                    else {
                        alt24=3;}
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 24, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:9: '\\\\' ( '0' .. '3' ) ( '0' .. '7' ) ( '0' .. '7' )
                    {
                    match('\\'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:14: ( '0' .. '3' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:15: '0' .. '3'
                    {
                    matchRange('0','3'); if (state.failed) return ;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:25: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:26: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:36: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:684:37: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:685:9: '\\\\' ( '0' .. '7' ) ( '0' .. '7' )
                    {
                    match('\\'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:685:14: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:685:15: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:685:25: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:685:26: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }


                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:686:9: '\\\\' ( '0' .. '7' )
                    {
                    match('\\'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:686:14: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:686:15: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }


                    }
                    break;

            }
        }
        finally {
        }
    }
    // $ANTLR end "OctalEscape"

    // $ANTLR start "UnicodeEscape"
    public final void mUnicodeEscape() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:691:5: ( '\\\\' 'u' HexDigit HexDigit HexDigit HexDigit )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:691:9: '\\\\' 'u' HexDigit HexDigit HexDigit HexDigit
            {
            match('\\'); if (state.failed) return ;
            match('u'); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;

            }

        }
        finally {
        }
    }
    // $ANTLR end "UnicodeEscape"

    // $ANTLR start "IDENTIFIER"
    public final void mIDENTIFIER() throws RecognitionException {
        try {
            int _type = IDENTIFIER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:695:5: ( LETTER ( LETTER | JavaIDDigit )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:695:7: LETTER ( LETTER | JavaIDDigit )*
            {
            mLETTER(); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:695:14: ( LETTER | JavaIDDigit )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0=='$'||(LA25_0>='0' && LA25_0<='9')||(LA25_0>='A' && LA25_0<='Z')||LA25_0=='_'||(LA25_0>='a' && LA25_0<='z')||(LA25_0>='\u00C0' && LA25_0<='\u00D6')||(LA25_0>='\u00D8' && LA25_0<='\u00F6')||(LA25_0>='\u00F8' && LA25_0<='\u1FFF')||(LA25_0>='\u3040' && LA25_0<='\u318F')||(LA25_0>='\u3300' && LA25_0<='\u337F')||(LA25_0>='\u3400' && LA25_0<='\u3D2D')||(LA25_0>='\u4E00' && LA25_0<='\u9FFF')||(LA25_0>='\uF900' && LA25_0<='\uFAFF')) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
            	        input.consume();
            	    state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return ;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IDENTIFIER"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:703:5: ( '\\u0024' | '\\u0041' .. '\\u005a' | '\\u005f' | '\\u0061' .. '\\u007a' | '\\u00c0' .. '\\u00d6' | '\\u00d8' .. '\\u00f6' | '\\u00f8' .. '\\u00ff' | '\\u0100' .. '\\u1fff' | '\\u3040' .. '\\u318f' | '\\u3300' .. '\\u337f' | '\\u3400' .. '\\u3d2d' | '\\u4e00' .. '\\u9fff' | '\\uf900' .. '\\ufaff' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:
            {
            if ( input.LA(1)=='$'||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "JavaIDDigit"
    public final void mJavaIDDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:720:5: ( '\\u0030' .. '\\u0039' | '\\u0660' .. '\\u0669' | '\\u06f0' .. '\\u06f9' | '\\u0966' .. '\\u096f' | '\\u09e6' .. '\\u09ef' | '\\u0a66' .. '\\u0a6f' | '\\u0ae6' .. '\\u0aef' | '\\u0b66' .. '\\u0b6f' | '\\u0be7' .. '\\u0bef' | '\\u0c66' .. '\\u0c6f' | '\\u0ce6' .. '\\u0cef' | '\\u0d66' .. '\\u0d6f' | '\\u0e50' .. '\\u0e59' | '\\u0ed0' .. '\\u0ed9' | '\\u1040' .. '\\u1049' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='\u0660' && input.LA(1)<='\u0669')||(input.LA(1)>='\u06F0' && input.LA(1)<='\u06F9')||(input.LA(1)>='\u0966' && input.LA(1)<='\u096F')||(input.LA(1)>='\u09E6' && input.LA(1)<='\u09EF')||(input.LA(1)>='\u0A66' && input.LA(1)<='\u0A6F')||(input.LA(1)>='\u0AE6' && input.LA(1)<='\u0AEF')||(input.LA(1)>='\u0B66' && input.LA(1)<='\u0B6F')||(input.LA(1)>='\u0BE7' && input.LA(1)<='\u0BEF')||(input.LA(1)>='\u0C66' && input.LA(1)<='\u0C6F')||(input.LA(1)>='\u0CE6' && input.LA(1)<='\u0CEF')||(input.LA(1)>='\u0D66' && input.LA(1)<='\u0D6F')||(input.LA(1)>='\u0E50' && input.LA(1)<='\u0E59')||(input.LA(1)>='\u0ED0' && input.LA(1)<='\u0ED9')||(input.LA(1)>='\u1040' && input.LA(1)<='\u1049') ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "JavaIDDigit"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:737:5: ( ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:737:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            if ( state.backtracking==0 ) {
              skip();
            }

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "NEWLINE"
    public final void mNEWLINE() throws RecognitionException {
        try {
            int _type = NEWLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:740:9: ( ( '\\r' )? '\\n' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:740:13: ( '\\r' )? '\\n'
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:740:13: ( '\\r' )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0=='\r') ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:740:13: '\\r'
                    {
                    match('\r'); if (state.failed) return ;

                    }
                    break;

            }

            match('\n'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEWLINE"

    public void mTokens() throws RecognitionException {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:8: ( LOCK | LOCKS | REQUIRESLOCK | ISLOCK | POLICYLOCK | RETURNSLOCK | INREGION | MAPFIELDS | MAPREGION | AGGREGATE | REGION | READS | WRITES | PROTECTS | NOTHING | ANY | IS | INTO | READ_LOCK | WRITE_LOCK | T__179 | T__180 | T__181 | T__182 | T__183 | T__184 | ABSTRACT | BOOLEAN | BREAK | BYTE | CASE | CATCH | CHAR | CLASS | CONST | CONTINUE | DEFAULT | DO | DOUBLE | ELSE | EXTENDS | FALSE | FINAL | FINALLY | FLOAT | FOR | GOTO | IF | IMPLEMENTS | IMPORT | INSTANCEOF | INT | INTERFACE | LONG | NATIVE | NEW | NULL | ONLY | PACKAGE | PRIVATE | PROTECTED | PUBLIC | RETURN | SHORT | STATIC | SUPER | SWITCH | SYNCHRONIZED | THIS | THROW | THROWS | TRANSIENT | TRUE | TRY | VOID | VOLATILE | WHILE | COLON | SEMI | DOT | LBRACKET | RBRACKET | AT | LPAREN | RPAREN | QUOTE | DQUOTE | LBRACE | RBRACE | COMMA | STAR | DSTAR | DASH | LANGLE | RANGLE | EQUALS | HexLiteral | DecimalLiteral | OctalLiteral | FloatingPointLiteral | CharacterLiteral | StringLiteral | IDENTIFIER | WS | NEWLINE )
        int alt27=105;
        alt27 = dfa27.predict(input);
        switch (alt27) {
            case 1 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:10: LOCK
                {
                mLOCK(); if (state.failed) return ;

                }
                break;
            case 2 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:15: LOCKS
                {
                mLOCKS(); if (state.failed) return ;

                }
                break;
            case 3 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:21: REQUIRESLOCK
                {
                mREQUIRESLOCK(); if (state.failed) return ;

                }
                break;
            case 4 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:34: ISLOCK
                {
                mISLOCK(); if (state.failed) return ;

                }
                break;
            case 5 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:41: POLICYLOCK
                {
                mPOLICYLOCK(); if (state.failed) return ;

                }
                break;
            case 6 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:52: RETURNSLOCK
                {
                mRETURNSLOCK(); if (state.failed) return ;

                }
                break;
            case 7 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:64: INREGION
                {
                mINREGION(); if (state.failed) return ;

                }
                break;
            case 8 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:73: MAPFIELDS
                {
                mMAPFIELDS(); if (state.failed) return ;

                }
                break;
            case 9 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:83: MAPREGION
                {
                mMAPREGION(); if (state.failed) return ;

                }
                break;
            case 10 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:93: AGGREGATE
                {
                mAGGREGATE(); if (state.failed) return ;

                }
                break;
            case 11 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:103: REGION
                {
                mREGION(); if (state.failed) return ;

                }
                break;
            case 12 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:110: READS
                {
                mREADS(); if (state.failed) return ;

                }
                break;
            case 13 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:116: WRITES
                {
                mWRITES(); if (state.failed) return ;

                }
                break;
            case 14 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:123: PROTECTS
                {
                mPROTECTS(); if (state.failed) return ;

                }
                break;
            case 15 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:132: NOTHING
                {
                mNOTHING(); if (state.failed) return ;

                }
                break;
            case 16 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:140: ANY
                {
                mANY(); if (state.failed) return ;

                }
                break;
            case 17 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:144: IS
                {
                mIS(); if (state.failed) return ;

                }
                break;
            case 18 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:147: INTO
                {
                mINTO(); if (state.failed) return ;

                }
                break;
            case 19 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:152: READ_LOCK
                {
                mREAD_LOCK(); if (state.failed) return ;

                }
                break;
            case 20 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:162: WRITE_LOCK
                {
                mWRITE_LOCK(); if (state.failed) return ;

                }
                break;
            case 21 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:173: T__179
                {
                mT__179(); if (state.failed) return ;

                }
                break;
            case 22 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:180: T__180
                {
                mT__180(); if (state.failed) return ;

                }
                break;
            case 23 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:187: T__181
                {
                mT__181(); if (state.failed) return ;

                }
                break;
            case 24 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:194: T__182
                {
                mT__182(); if (state.failed) return ;

                }
                break;
            case 25 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:201: T__183
                {
                mT__183(); if (state.failed) return ;

                }
                break;
            case 26 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:208: T__184
                {
                mT__184(); if (state.failed) return ;

                }
                break;
            case 27 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:215: ABSTRACT
                {
                mABSTRACT(); if (state.failed) return ;

                }
                break;
            case 28 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:224: BOOLEAN
                {
                mBOOLEAN(); if (state.failed) return ;

                }
                break;
            case 29 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:232: BREAK
                {
                mBREAK(); if (state.failed) return ;

                }
                break;
            case 30 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:238: BYTE
                {
                mBYTE(); if (state.failed) return ;

                }
                break;
            case 31 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:243: CASE
                {
                mCASE(); if (state.failed) return ;

                }
                break;
            case 32 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:248: CATCH
                {
                mCATCH(); if (state.failed) return ;

                }
                break;
            case 33 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:254: CHAR
                {
                mCHAR(); if (state.failed) return ;

                }
                break;
            case 34 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:259: CLASS
                {
                mCLASS(); if (state.failed) return ;

                }
                break;
            case 35 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:265: CONST
                {
                mCONST(); if (state.failed) return ;

                }
                break;
            case 36 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:271: CONTINUE
                {
                mCONTINUE(); if (state.failed) return ;

                }
                break;
            case 37 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:280: DEFAULT
                {
                mDEFAULT(); if (state.failed) return ;

                }
                break;
            case 38 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:288: DO
                {
                mDO(); if (state.failed) return ;

                }
                break;
            case 39 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:291: DOUBLE
                {
                mDOUBLE(); if (state.failed) return ;

                }
                break;
            case 40 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:298: ELSE
                {
                mELSE(); if (state.failed) return ;

                }
                break;
            case 41 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:303: EXTENDS
                {
                mEXTENDS(); if (state.failed) return ;

                }
                break;
            case 42 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:311: FALSE
                {
                mFALSE(); if (state.failed) return ;

                }
                break;
            case 43 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:317: FINAL
                {
                mFINAL(); if (state.failed) return ;

                }
                break;
            case 44 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:323: FINALLY
                {
                mFINALLY(); if (state.failed) return ;

                }
                break;
            case 45 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:331: FLOAT
                {
                mFLOAT(); if (state.failed) return ;

                }
                break;
            case 46 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:337: FOR
                {
                mFOR(); if (state.failed) return ;

                }
                break;
            case 47 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:341: GOTO
                {
                mGOTO(); if (state.failed) return ;

                }
                break;
            case 48 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:346: IF
                {
                mIF(); if (state.failed) return ;

                }
                break;
            case 49 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:349: IMPLEMENTS
                {
                mIMPLEMENTS(); if (state.failed) return ;

                }
                break;
            case 50 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:360: IMPORT
                {
                mIMPORT(); if (state.failed) return ;

                }
                break;
            case 51 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:367: INSTANCEOF
                {
                mINSTANCEOF(); if (state.failed) return ;

                }
                break;
            case 52 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:378: INT
                {
                mINT(); if (state.failed) return ;

                }
                break;
            case 53 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:382: INTERFACE
                {
                mINTERFACE(); if (state.failed) return ;

                }
                break;
            case 54 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:392: LONG
                {
                mLONG(); if (state.failed) return ;

                }
                break;
            case 55 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:397: NATIVE
                {
                mNATIVE(); if (state.failed) return ;

                }
                break;
            case 56 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:404: NEW
                {
                mNEW(); if (state.failed) return ;

                }
                break;
            case 57 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:408: NULL
                {
                mNULL(); if (state.failed) return ;

                }
                break;
            case 58 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:413: ONLY
                {
                mONLY(); if (state.failed) return ;

                }
                break;
            case 59 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:418: PACKAGE
                {
                mPACKAGE(); if (state.failed) return ;

                }
                break;
            case 60 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:426: PRIVATE
                {
                mPRIVATE(); if (state.failed) return ;

                }
                break;
            case 61 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:434: PROTECTED
                {
                mPROTECTED(); if (state.failed) return ;

                }
                break;
            case 62 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:444: PUBLIC
                {
                mPUBLIC(); if (state.failed) return ;

                }
                break;
            case 63 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:451: RETURN
                {
                mRETURN(); if (state.failed) return ;

                }
                break;
            case 64 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:458: SHORT
                {
                mSHORT(); if (state.failed) return ;

                }
                break;
            case 65 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:464: STATIC
                {
                mSTATIC(); if (state.failed) return ;

                }
                break;
            case 66 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:471: SUPER
                {
                mSUPER(); if (state.failed) return ;

                }
                break;
            case 67 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:477: SWITCH
                {
                mSWITCH(); if (state.failed) return ;

                }
                break;
            case 68 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:484: SYNCHRONIZED
                {
                mSYNCHRONIZED(); if (state.failed) return ;

                }
                break;
            case 69 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:497: THIS
                {
                mTHIS(); if (state.failed) return ;

                }
                break;
            case 70 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:502: THROW
                {
                mTHROW(); if (state.failed) return ;

                }
                break;
            case 71 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:508: THROWS
                {
                mTHROWS(); if (state.failed) return ;

                }
                break;
            case 72 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:515: TRANSIENT
                {
                mTRANSIENT(); if (state.failed) return ;

                }
                break;
            case 73 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:525: TRUE
                {
                mTRUE(); if (state.failed) return ;

                }
                break;
            case 74 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:530: TRY
                {
                mTRY(); if (state.failed) return ;

                }
                break;
            case 75 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:534: VOID
                {
                mVOID(); if (state.failed) return ;

                }
                break;
            case 76 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:539: VOLATILE
                {
                mVOLATILE(); if (state.failed) return ;

                }
                break;
            case 77 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:548: WHILE
                {
                mWHILE(); if (state.failed) return ;

                }
                break;
            case 78 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:554: COLON
                {
                mCOLON(); if (state.failed) return ;

                }
                break;
            case 79 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:560: SEMI
                {
                mSEMI(); if (state.failed) return ;

                }
                break;
            case 80 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:565: DOT
                {
                mDOT(); if (state.failed) return ;

                }
                break;
            case 81 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:569: LBRACKET
                {
                mLBRACKET(); if (state.failed) return ;

                }
                break;
            case 82 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:578: RBRACKET
                {
                mRBRACKET(); if (state.failed) return ;

                }
                break;
            case 83 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:587: AT
                {
                mAT(); if (state.failed) return ;

                }
                break;
            case 84 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:590: LPAREN
                {
                mLPAREN(); if (state.failed) return ;

                }
                break;
            case 85 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:597: RPAREN
                {
                mRPAREN(); if (state.failed) return ;

                }
                break;
            case 86 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:604: QUOTE
                {
                mQUOTE(); if (state.failed) return ;

                }
                break;
            case 87 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:610: DQUOTE
                {
                mDQUOTE(); if (state.failed) return ;

                }
                break;
            case 88 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:617: LBRACE
                {
                mLBRACE(); if (state.failed) return ;

                }
                break;
            case 89 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:624: RBRACE
                {
                mRBRACE(); if (state.failed) return ;

                }
                break;
            case 90 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:631: COMMA
                {
                mCOMMA(); if (state.failed) return ;

                }
                break;
            case 91 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:637: STAR
                {
                mSTAR(); if (state.failed) return ;

                }
                break;
            case 92 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:642: DSTAR
                {
                mDSTAR(); if (state.failed) return ;

                }
                break;
            case 93 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:648: DASH
                {
                mDASH(); if (state.failed) return ;

                }
                break;
            case 94 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:653: LANGLE
                {
                mLANGLE(); if (state.failed) return ;

                }
                break;
            case 95 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:660: RANGLE
                {
                mRANGLE(); if (state.failed) return ;

                }
                break;
            case 96 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:667: EQUALS
                {
                mEQUALS(); if (state.failed) return ;

                }
                break;
            case 97 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:674: HexLiteral
                {
                mHexLiteral(); if (state.failed) return ;

                }
                break;
            case 98 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:685: DecimalLiteral
                {
                mDecimalLiteral(); if (state.failed) return ;

                }
                break;
            case 99 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:700: OctalLiteral
                {
                mOctalLiteral(); if (state.failed) return ;

                }
                break;
            case 100 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:713: FloatingPointLiteral
                {
                mFloatingPointLiteral(); if (state.failed) return ;

                }
                break;
            case 101 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:734: CharacterLiteral
                {
                mCharacterLiteral(); if (state.failed) return ;

                }
                break;
            case 102 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:751: StringLiteral
                {
                mStringLiteral(); if (state.failed) return ;

                }
                break;
            case 103 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:765: IDENTIFIER
                {
                mIDENTIFIER(); if (state.failed) return ;

                }
                break;
            case 104 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:776: WS
                {
                mWS(); if (state.failed) return ;

                }
                break;
            case 105 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:1:779: NEWLINE
                {
                mNEWLINE(); if (state.failed) return ;

                }
                break;

        }

    }

    // $ANTLR start synpred1_SLAnnotations
    public final void synpred1_SLAnnotations_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:9: ( ( '0' .. '9' )+ '.' )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:10: ( '0' .. '9' )+ '.'
        {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:10: ( '0' .. '9' )+
        int cnt28=0;
        loop28:
        do {
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( ((LA28_0>='0' && LA28_0<='9')) ) {
                alt28=1;
            }


            switch (alt28) {
        	case 1 :
        	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:655:11: '0' .. '9'
        	    {
        	    matchRange('0','9'); if (state.failed) return ;

        	    }
        	    break;

        	default :
        	    if ( cnt28 >= 1 ) break loop28;
        	    if (state.backtracking>0) {state.failed=true; return ;}
                    EarlyExitException eee =
                        new EarlyExitException(28, input);
                    throw eee;
            }
            cnt28++;
        } while (true);

        match('.'); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_SLAnnotations

    // $ANTLR start synpred2_SLAnnotations
    public final void synpred2_SLAnnotations_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:9: ( ( '0' .. '9' )+ Exponent )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:10: ( '0' .. '9' )+ Exponent
        {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:10: ( '0' .. '9' )+
        int cnt29=0;
        loop29:
        do {
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( ((LA29_0>='0' && LA29_0<='9')) ) {
                alt29=1;
            }


            switch (alt29) {
        	case 1 :
        	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/SLAnnotations.g:657:11: '0' .. '9'
        	    {
        	    matchRange('0','9'); if (state.failed) return ;

        	    }
        	    break;

        	default :
        	    if ( cnt29 >= 1 ) break loop29;
        	    if (state.backtracking>0) {state.failed=true; return ;}
                    EarlyExitException eee =
                        new EarlyExitException(29, input);
                    throw eee;
            }
            cnt29++;
        } while (true);

        mExponent(); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_SLAnnotations

    public final boolean synpred1_SLAnnotations() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_SLAnnotations_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_SLAnnotations() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_SLAnnotations_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA18 dfa18 = new DFA18(this);
    protected DFA27 dfa27 = new DFA27(this);
    static final String DFA18_eotS =
        "\10\uffff\1\11\2\uffff";
    static final String DFA18_eofS =
        "\13\uffff";
    static final String DFA18_minS =
        "\2\56\2\uffff\1\53\1\uffff\3\60\1\uffff\1\0";
    static final String DFA18_maxS =
        "\1\71\1\146\2\uffff\1\71\1\uffff\1\146\1\71\1\146\1\uffff\1\0";
    static final String DFA18_acceptS =
        "\2\uffff\1\2\1\1\1\uffff\1\4\3\uffff\1\3\1\uffff";
    static final String DFA18_specialS =
        "\1\uffff\1\0\6\uffff\1\2\1\uffff\1\1}>";
    static final String[] DFA18_transitionS = {
            "\1\2\1\uffff\12\1",
            "\1\3\1\uffff\12\6\12\uffff\1\5\1\4\1\5\35\uffff\1\5\1\4\1\5",
            "",
            "",
            "\1\7\1\uffff\1\7\2\uffff\12\10",
            "",
            "\12\6\12\uffff\1\5\1\4\1\5\35\uffff\1\5\1\4\1\5",
            "\12\10",
            "\12\10\12\uffff\1\12\1\uffff\1\12\35\uffff\1\12\1\uffff\1\12",
            "",
            "\1\uffff"
    };

    static final short[] DFA18_eot = DFA.unpackEncodedString(DFA18_eotS);
    static final short[] DFA18_eof = DFA.unpackEncodedString(DFA18_eofS);
    static final char[] DFA18_min = DFA.unpackEncodedStringToUnsignedChars(DFA18_minS);
    static final char[] DFA18_max = DFA.unpackEncodedStringToUnsignedChars(DFA18_maxS);
    static final short[] DFA18_accept = DFA.unpackEncodedString(DFA18_acceptS);
    static final short[] DFA18_special = DFA.unpackEncodedString(DFA18_specialS);
    static final short[][] DFA18_transition;

    static {
        int numStates = DFA18_transitionS.length;
        DFA18_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA18_transition[i] = DFA.unpackEncodedString(DFA18_transitionS[i]);
        }
    }

    class DFA18 extends DFA {

        public DFA18(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 18;
            this.eot = DFA18_eot;
            this.eof = DFA18_eof;
            this.min = DFA18_min;
            this.max = DFA18_max;
            this.accept = DFA18_accept;
            this.special = DFA18_special;
            this.transition = DFA18_transition;
        }
        public String getDescription() {
            return "654:1: FloatingPointLiteral : ( ( ( '0' .. '9' )+ '.' )=> ( '0' .. '9' ) '.' ( '0' .. '9' )* ( Exponent )? ( FloatTypeSuffix )? | '.' ( '0' .. '9' )+ ( Exponent )? ( FloatTypeSuffix )? | ( ( '0' .. '9' )+ Exponent )=> ( '0' .. '9' )+ Exponent ( FloatTypeSuffix )? | ( '0' .. '9' )+ ( Exponent )? FloatTypeSuffix );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA18_1 = input.LA(1);

                         
                        int index18_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA18_1=='.') && (synpred1_SLAnnotations())) {s = 3;}

                        else if ( (LA18_1=='E'||LA18_1=='e') ) {s = 4;}

                        else if ( (LA18_1=='D'||LA18_1=='F'||LA18_1=='d'||LA18_1=='f') ) {s = 5;}

                        else if ( ((LA18_1>='0' && LA18_1<='9')) ) {s = 6;}

                         
                        input.seek(index18_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA18_10 = input.LA(1);

                         
                        int index18_10 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred2_SLAnnotations()) ) {s = 9;}

                        else if ( (true) ) {s = 5;}

                         
                        input.seek(index18_10);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA18_8 = input.LA(1);

                         
                        int index18_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA18_8=='D'||LA18_8=='F'||LA18_8=='d'||LA18_8=='f') ) {s = 10;}

                        else if ( ((LA18_8>='0' && LA18_8<='9')) ) {s = 8;}

                        else s = 9;

                         
                        input.seek(index18_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 18, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA27_eotS =
        "\1\uffff\1\63\6\50\2\uffff\13\50\2\uffff\1\140\4\uffff\1\142\1\144"+
        "\3\uffff\1\146\4\uffff\2\151\1\uffff\1\53\12\uffff\11\50\1\174\1"+
        "\50\1\177\4\50\1\u0086\10\50\1\u0091\21\50\11\uffff\1\u00a7\1\uffff"+
        "\1\151\6\uffff\7\50\1\u00b5\1\50\1\u00b7\1\50\1\uffff\1\u00bb\1"+
        "\50\1\uffff\5\50\2\uffff\12\50\1\uffff\5\50\1\u00d3\14\50\1\u00e0"+
        "\2\50\7\uffff\5\50\1\u00eb\1\50\1\uffff\1\u00ed\1\uffff\1\50\1\u00ef"+
        "\1\50\1\uffff\11\50\1\u00fb\1\u00fc\1\50\1\u00fe\5\50\1\u0104\4"+
        "\50\1\uffff\1\u0109\1\u010a\1\u010b\5\50\1\u0111\2\50\1\u0114\1"+
        "\uffff\1\u0115\1\50\1\u0118\2\uffff\5\50\1\uffff\1\50\1\uffff\1"+
        "\50\1\uffff\5\50\1\u0125\2\50\1\u0129\1\50\1\u012b\2\uffff\1\u012c"+
        "\1\uffff\1\u012d\1\u012e\3\50\1\uffff\1\50\1\u0133\1\u0135\1\u0136"+
        "\3\uffff\1\u0137\1\50\1\u0139\2\50\1\uffff\1\u013d\1\50\2\uffff"+
        "\1\50\2\uffff\3\50\1\u0143\1\50\1\u0145\4\50\1\u014a\1\50\1\uffff"+
        "\1\u014c\1\50\1\u014e\1\uffff\1\50\4\uffff\2\50\1\u0152\1\50\1\uffff"+
        "\1\50\3\uffff\1\u0155\1\uffff\1\u0156\1\50\1\u0158\1\uffff\3\50"+
        "\1\u015d\1\u015e\1\uffff\1\u015f\1\uffff\4\50\1\uffff\1\50\1\uffff"+
        "\1\50\1\uffff\1\u0166\1\50\1\u0168\1\uffff\1\u0169\1\u016a\2\uffff"+
        "\1\50\1\uffff\2\50\1\u016e\1\50\3\uffff\1\u0170\3\50\1\u0174\1\50"+
        "\1\uffff\1\u0176\3\uffff\2\50\1\u0179\1\uffff\1\u017a\1\uffff\1"+
        "\u017b\2\50\1\uffff\1\u017e\1\uffff\1\50\1\u0180\3\uffff\1\u0181"+
        "\1\u0182\1\uffff\1\50\3\uffff\1\50\1\u0185\1\uffff";
    static final String DFA27_eofS =
        "\u0186\uffff";
    static final String DFA27_minS =
        "\1\11\1\101\2\141\1\142\1\146\1\145\1\150\1\uffff\1\52\1\157\1\141"+
        "\1\145\1\154\1\141\2\157\1\156\2\150\1\157\2\uffff\1\60\4\uffff"+
        "\2\0\3\uffff\1\52\4\uffff\2\56\1\uffff\1\12\2\uffff\1\157\1\145"+
        "\1\156\1\uffff\1\141\3\uffff\1\151\1\143\1\142\1\156\1\164\1\167"+
        "\1\154\1\171\1\163\1\44\1\163\1\44\1\160\1\141\2\151\1\52\1\157"+
        "\1\145\1\164\1\163\2\141\1\156\1\146\1\44\1\163\1\164\1\154\1\156"+
        "\1\157\1\162\1\164\1\156\1\154\1\157\1\141\1\160\1\151\1\156\1\151"+
        "\1\141\1\151\11\uffff\1\60\1\uffff\1\60\1\uffff\1\143\1\141\2\uffff"+
        "\1\160\1\164\1\166\1\153\1\154\1\150\1\145\1\151\1\44\1\154\1\44"+
        "\1\164\1\uffff\1\44\1\164\1\uffff\1\154\1\144\1\165\1\164\1\154"+
        "\2\uffff\1\154\1\141\2\145\1\143\1\162\2\163\1\141\1\142\1\uffff"+
        "\2\145\1\163\2\141\1\44\1\157\1\147\1\171\1\162\1\164\1\145\1\164"+
        "\1\143\1\163\1\157\1\156\1\145\1\44\1\144\1\141\1\uffff\1\153\4"+
        "\uffff\1\106\1\145\2\141\2\151\1\44\1\166\1\uffff\1\44\1\uffff\1"+
        "\162\1\44\1\162\1\uffff\1\141\1\145\1\162\1\114\1\162\3\145\1\153"+
        "\2\44\1\150\1\44\1\163\1\164\1\151\1\165\1\154\1\44\1\156\1\145"+
        "\1\154\1\164\1\uffff\3\44\1\164\1\151\1\162\1\143\1\150\1\44\1\167"+
        "\1\163\1\44\1\uffff\1\44\1\164\1\163\2\uffff\1\143\1\164\1\147\1"+
        "\143\1\156\1\uffff\1\145\1\uffff\1\141\1\uffff\1\146\1\156\1\155"+
        "\1\164\1\157\1\44\1\156\1\114\1\44\1\141\1\44\2\uffff\1\44\1\uffff"+
        "\2\44\1\156\1\154\1\145\1\uffff\1\144\3\44\3\uffff\1\44\1\143\1"+
        "\44\1\150\1\162\1\uffff\1\44\1\151\2\uffff\1\151\2\uffff\1\164\2"+
        "\145\1\44\1\147\1\44\1\143\1\141\1\143\1\145\1\44\1\143\1\uffff"+
        "\1\44\1\157\1\44\1\uffff\1\156\4\uffff\1\165\1\164\1\44\1\163\1"+
        "\uffff\1\171\3\uffff\1\44\1\uffff\1\44\1\157\1\44\1\uffff\1\145"+
        "\1\154\1\145\2\44\1\uffff\1\44\1\uffff\1\164\1\143\1\145\1\156\1"+
        "\uffff\1\153\1\uffff\1\143\1\uffff\1\44\1\145\1\44\1\uffff\2\44"+
        "\2\uffff\1\156\1\uffff\1\156\1\145\1\44\1\144\3\uffff\1\44\1\145"+
        "\1\157\1\164\1\44\1\153\1\uffff\1\44\3\uffff\1\151\1\164\1\44\1"+
        "\uffff\1\44\1\uffff\1\44\1\146\1\163\1\uffff\1\44\1\uffff\1\172"+
        "\1\44\3\uffff\2\44\1\uffff\1\145\3\uffff\1\144\1\44\1\uffff";
    static final String DFA27_maxS =
        "\1\ufaff\1\127\2\165\1\156\1\163\1\145\1\162\1\uffff\1\52\1\171"+
        "\2\157\1\170\3\157\1\156\1\171\1\162\1\157\2\uffff\1\71\4\uffff"+
        "\2\ufffe\3\uffff\1\52\4\uffff\1\170\1\146\1\uffff\1\12\2\uffff\1"+
        "\157\1\145\1\163\1\uffff\1\141\3\uffff\1\157\1\143\1\142\2\164\1"+
        "\167\1\154\1\171\1\163\1\ufaff\1\164\1\ufaff\1\160\1\164\2\151\1"+
        "\52\1\157\1\145\2\164\2\141\1\156\1\146\1\ufaff\1\163\1\164\1\154"+
        "\1\156\1\157\1\162\1\164\1\156\1\154\1\157\1\141\1\160\1\151\1\156"+
        "\1\162\1\171\1\154\11\uffff\1\146\1\uffff\1\146\1\uffff\1\143\1"+
        "\164\2\uffff\1\160\1\164\1\166\1\153\1\154\1\150\1\145\1\151\1\ufaff"+
        "\1\154\1\ufaff\1\164\1\uffff\1\ufaff\1\164\1\uffff\1\157\1\144\1"+
        "\165\1\164\1\154\2\uffff\1\154\1\141\2\145\1\143\1\162\1\163\1\164"+
        "\1\141\1\142\1\uffff\2\145\1\163\2\141\1\ufaff\1\157\1\147\1\171"+
        "\1\162\1\164\1\145\1\164\1\143\1\163\1\157\1\156\1\145\1\ufaff\1"+
        "\144\1\141\1\uffff\1\153\4\uffff\1\122\1\145\2\141\2\151\1\ufaff"+
        "\1\166\1\uffff\1\ufaff\1\uffff\1\162\1\ufaff\1\162\1\uffff\1\141"+
        "\1\145\1\162\1\163\1\162\3\145\1\153\2\ufaff\1\150\1\ufaff\1\163"+
        "\1\164\1\151\1\165\1\154\1\ufaff\1\156\1\145\1\154\1\164\1\uffff"+
        "\3\ufaff\1\164\1\151\1\162\1\143\1\150\1\ufaff\1\167\1\163\1\ufaff"+
        "\1\uffff\1\ufaff\1\164\1\163\2\uffff\1\143\1\164\1\147\1\143\1\156"+
        "\1\uffff\1\145\1\uffff\1\141\1\uffff\1\146\1\156\1\155\1\164\1\157"+
        "\1\ufaff\1\156\1\163\1\ufaff\1\141\1\ufaff\2\uffff\1\ufaff\1\uffff"+
        "\2\ufaff\1\156\1\154\1\145\1\uffff\1\144\3\ufaff\3\uffff\1\ufaff"+
        "\1\143\1\ufaff\1\150\1\162\1\uffff\1\ufaff\1\151\2\uffff\1\151\2"+
        "\uffff\1\164\2\145\1\ufaff\1\147\1\ufaff\1\143\1\141\1\143\1\145"+
        "\1\ufaff\1\143\1\uffff\1\ufaff\1\157\1\ufaff\1\uffff\1\156\4\uffff"+
        "\1\165\1\164\1\ufaff\1\163\1\uffff\1\171\3\uffff\1\ufaff\1\uffff"+
        "\1\ufaff\1\157\1\ufaff\1\uffff\1\145\1\154\1\163\2\ufaff\1\uffff"+
        "\1\ufaff\1\uffff\1\164\1\143\1\145\1\156\1\uffff\1\153\1\uffff\1"+
        "\143\1\uffff\1\ufaff\1\145\1\ufaff\1\uffff\2\ufaff\2\uffff\1\156"+
        "\1\uffff\1\156\1\145\1\ufaff\1\144\3\uffff\1\ufaff\1\145\1\157\1"+
        "\164\1\ufaff\1\153\1\uffff\1\ufaff\3\uffff\1\151\1\164\1\ufaff\1"+
        "\uffff\1\ufaff\1\uffff\1\ufaff\1\146\1\163\1\uffff\1\ufaff\1\uffff"+
        "\1\172\1\ufaff\3\uffff\2\ufaff\1\uffff\1\145\3\uffff\1\144\1\ufaff"+
        "\1\uffff";
    static final String DFA27_acceptS =
        "\10\uffff\1\25\14\uffff\1\116\1\117\1\uffff\1\121\1\122\1\124\1"+
        "\125\2\uffff\1\130\1\131\1\132\1\uffff\1\135\1\136\1\137\1\140\2"+
        "\uffff\1\147\1\uffff\2\150\3\uffff\1\5\1\uffff\1\12\1\15\1\123\53"+
        "\uffff\1\144\1\120\1\145\1\126\1\146\1\127\1\134\1\133\1\141\1\uffff"+
        "\1\142\1\uffff\1\151\2\uffff\1\4\1\7\14\uffff\1\21\2\uffff\1\60"+
        "\5\uffff\1\27\1\26\12\uffff\1\46\25\uffff\1\143\1\uffff\1\3\1\6"+
        "\1\13\1\14\10\uffff\1\70\1\uffff\1\20\3\uffff\1\64\27\uffff\1\56"+
        "\14\uffff\1\112\3\uffff\1\10\1\11\5\uffff\1\30\1\uffff\1\71\1\uffff"+
        "\1\22\13\uffff\1\36\1\37\1\uffff\1\41\5\uffff\1\50\4\uffff\1\57"+
        "\1\66\1\72\5\uffff\1\105\2\uffff\1\111\1\113\1\uffff\1\2\1\1\14"+
        "\uffff\1\31\3\uffff\1\115\1\uffff\1\35\1\40\1\42\1\43\4\uffff\1"+
        "\52\1\uffff\1\53\1\55\1\100\1\uffff\1\102\3\uffff\1\106\5\uffff"+
        "\1\76\1\uffff\1\67\4\uffff\1\62\1\uffff\1\77\1\uffff\1\32\3\uffff"+
        "\1\47\2\uffff\1\101\1\103\1\uffff\1\107\4\uffff\1\74\1\73\1\17\6"+
        "\uffff\1\34\1\uffff\1\45\1\51\1\54\3\uffff\1\16\1\uffff\1\33\3\uffff"+
        "\1\23\1\uffff\1\44\2\uffff\1\114\1\75\1\65\2\uffff\1\24\1\uffff"+
        "\1\110\1\63\1\61\2\uffff\1\104";
    static final String DFA27_specialS =
        "\u0186\uffff}>";
    static final String[] DFA27_transitionS = {
            "\1\53\1\52\1\uffff\1\53\1\51\22\uffff\1\53\1\uffff\1\35\1\uffff"+
            "\1\50\1\uffff\1\10\1\34\1\32\1\33\1\41\1\uffff\1\40\1\42\1\27"+
            "\1\11\1\46\11\47\1\25\1\26\1\43\1\45\1\44\1\uffff\1\1\32\50"+
            "\1\30\1\uffff\1\31\1\uffff\1\50\1\uffff\1\4\1\12\1\13\1\14\1"+
            "\15\1\16\1\17\1\50\1\5\2\50\1\20\1\50\1\3\1\21\1\2\1\50\1\6"+
            "\1\22\1\23\1\50\1\24\1\7\3\50\1\36\1\uffff\1\37\102\uffff\27"+
            "\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff\u0150\50\u0170"+
            "\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff\u5200\50\u5900"+
            "\uffff\u0200\50",
            "\1\61\7\uffff\1\56\2\uffff\1\54\1\60\2\uffff\1\57\1\uffff\1"+
            "\55\4\uffff\1\62",
            "\1\65\20\uffff\1\64\2\uffff\1\66",
            "\1\70\3\uffff\1\71\11\uffff\1\67\5\uffff\1\72",
            "\1\74\13\uffff\1\73",
            "\1\77\6\uffff\1\100\1\76\4\uffff\1\75",
            "\1\101",
            "\1\103\11\uffff\1\102",
            "",
            "\1\104",
            "\1\105\2\uffff\1\106\6\uffff\1\107",
            "\1\110\6\uffff\1\111\3\uffff\1\112\2\uffff\1\113",
            "\1\114\11\uffff\1\115",
            "\1\116\13\uffff\1\117",
            "\1\120\7\uffff\1\121\2\uffff\1\122\2\uffff\1\123",
            "\1\124",
            "\1\125",
            "\1\126",
            "\1\127\13\uffff\1\130\1\131\1\uffff\1\132\1\uffff\1\133",
            "\1\134\11\uffff\1\135",
            "\1\136",
            "",
            "",
            "\12\137",
            "",
            "",
            "",
            "",
            "\47\141\1\uffff\uffd7\141",
            "\uffff\143",
            "",
            "",
            "",
            "\1\145",
            "",
            "",
            "",
            "",
            "\1\137\1\uffff\10\150\2\137\12\uffff\3\137\21\uffff\1\147\13"+
            "\uffff\3\137\21\uffff\1\147",
            "\1\137\1\uffff\12\152\12\uffff\3\137\35\uffff\3\137",
            "",
            "\1\153",
            "",
            "",
            "\1\154",
            "\1\155",
            "\1\157\4\uffff\1\156",
            "",
            "\1\160",
            "",
            "",
            "",
            "\1\162\5\uffff\1\161",
            "\1\163",
            "\1\164",
            "\1\166\5\uffff\1\165",
            "\1\167",
            "\1\170",
            "\1\171",
            "\1\172",
            "\1\173",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\176\1\175",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0080",
            "\1\u0081\22\uffff\1\u0082",
            "\1\u0083",
            "\1\u0084",
            "\1\u0085",
            "\1\u0087",
            "\1\u0088",
            "\1\u0089",
            "\1\u008a\1\u008b",
            "\1\u008c",
            "\1\u008d",
            "\1\u008e",
            "\1\u008f",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\24"+
            "\50\1\u0090\5\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08"+
            "\50\u1040\uffff\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e"+
            "\50\u10d2\uffff\u5200\50\u5900\uffff\u0200\50",
            "\1\u0092",
            "\1\u0093",
            "\1\u0094",
            "\1\u0095",
            "\1\u0096",
            "\1\u0097",
            "\1\u0098",
            "\1\u0099",
            "\1\u009a",
            "\1\u009b",
            "\1\u009c",
            "\1\u009d",
            "\1\u009e",
            "\1\u009f",
            "\1\u00a0\10\uffff\1\u00a1",
            "\1\u00a2\23\uffff\1\u00a3\3\uffff\1\u00a4",
            "\1\u00a5\2\uffff\1\u00a6",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\10\150\2\137\12\uffff\3\137\35\uffff\3\137",
            "",
            "\12\152\12\uffff\3\137\35\uffff\3\137",
            "",
            "\1\u00a8",
            "\1\u00ac\5\uffff\1\u00ab\11\uffff\1\u00a9\2\uffff\1\u00aa",
            "",
            "",
            "\1\u00ad",
            "\1\u00ae",
            "\1\u00af",
            "\1\u00b0",
            "\1\u00b1",
            "\1\u00b2",
            "\1\u00b3",
            "\1\u00b4",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00b6",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00b8",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\4\50"+
            "\1\u00ba\11\50\1\u00b9\13\50\105\uffff\27\50\1\uffff\37\50\1"+
            "\uffff\u1f08\50\u1040\uffff\u0150\50\u0170\uffff\u0080\50\u0080"+
            "\uffff\u092e\50\u10d2\uffff\u5200\50\u5900\uffff\u0200\50",
            "\1\u00bc",
            "",
            "\1\u00bd\2\uffff\1\u00be",
            "\1\u00bf",
            "\1\u00c0",
            "\1\u00c1",
            "\1\u00c2",
            "",
            "",
            "\1\u00c3",
            "\1\u00c4",
            "\1\u00c5",
            "\1\u00c6",
            "\1\u00c7",
            "\1\u00c8",
            "\1\u00c9",
            "\1\u00ca\1\u00cb",
            "\1\u00cc",
            "\1\u00cd",
            "",
            "\1\u00ce",
            "\1\u00cf",
            "\1\u00d0",
            "\1\u00d1",
            "\1\u00d2",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00d4",
            "\1\u00d5",
            "\1\u00d6",
            "\1\u00d7",
            "\1\u00d8",
            "\1\u00d9",
            "\1\u00da",
            "\1\u00db",
            "\1\u00dc",
            "\1\u00dd",
            "\1\u00de",
            "\1\u00df",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00e1",
            "\1\u00e2",
            "",
            "\1\u00e3",
            "",
            "",
            "",
            "",
            "\1\u00e4\13\uffff\1\u00e5",
            "\1\u00e6",
            "\1\u00e7",
            "\1\u00e8",
            "\1\u00e9",
            "\1\u00ea",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00ec",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\u00ee",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00f0",
            "",
            "\1\u00f1",
            "\1\u00f2",
            "\1\u00f3",
            "\1\u00f4\46\uffff\1\u00f5",
            "\1\u00f6",
            "\1\u00f7",
            "\1\u00f8",
            "\1\u00f9",
            "\1\u00fa",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00fd",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u00ff",
            "\1\u0100",
            "\1\u0101",
            "\1\u0102",
            "\1\u0103",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0105",
            "\1\u0106",
            "\1\u0107",
            "\1\u0108",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u010c",
            "\1\u010d",
            "\1\u010e",
            "\1\u010f",
            "\1\u0110",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0112",
            "\1\u0113",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0116",
            "\1\u0117",
            "",
            "",
            "\1\u0119",
            "\1\u011a",
            "\1\u011b",
            "\1\u011c",
            "\1\u011d",
            "",
            "\1\u011e",
            "",
            "\1\u011f",
            "",
            "\1\u0120",
            "\1\u0121",
            "\1\u0122",
            "\1\u0123",
            "\1\u0124",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0126",
            "\1\u0127\46\uffff\1\u0128",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u012a",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u012f",
            "\1\u0130",
            "\1\u0131",
            "",
            "\1\u0132",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\13"+
            "\50\1\u0134\16\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08"+
            "\50\u1040\uffff\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e"+
            "\50\u10d2\uffff\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0138",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u013a",
            "\1\u013b",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\22"+
            "\50\1\u013c\7\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08"+
            "\50\u1040\uffff\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e"+
            "\50\u10d2\uffff\u5200\50\u5900\uffff\u0200\50",
            "\1\u013e",
            "",
            "",
            "\1\u013f",
            "",
            "",
            "\1\u0140",
            "\1\u0141",
            "\1\u0142",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0144",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0146",
            "\1\u0147",
            "\1\u0148",
            "\1\u0149",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u014b",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u014d",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\u014f",
            "",
            "",
            "",
            "",
            "\1\u0150",
            "\1\u0151",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0153",
            "",
            "\1\u0154",
            "",
            "",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0157",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\u0159",
            "\1\u015a",
            "\1\u015c\15\uffff\1\u015b",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\u0160",
            "\1\u0161",
            "\1\u0162",
            "\1\u0163",
            "",
            "\1\u0164",
            "",
            "\1\u0165",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0167",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "",
            "\1\u016b",
            "",
            "\1\u016c",
            "\1\u016d",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u016f",
            "",
            "",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0171",
            "\1\u0172",
            "\1\u0173",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u0175",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "",
            "",
            "\1\u0177",
            "\1\u0178",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\u017c",
            "\1\u017d",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\u017f",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "",
            "",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            "",
            "\1\u0183",
            "",
            "",
            "",
            "\1\u0184",
            "\1\50\13\uffff\12\50\7\uffff\32\50\4\uffff\1\50\1\uffff\32"+
            "\50\105\uffff\27\50\1\uffff\37\50\1\uffff\u1f08\50\u1040\uffff"+
            "\u0150\50\u0170\uffff\u0080\50\u0080\uffff\u092e\50\u10d2\uffff"+
            "\u5200\50\u5900\uffff\u0200\50",
            ""
    };

    static final short[] DFA27_eot = DFA.unpackEncodedString(DFA27_eotS);
    static final short[] DFA27_eof = DFA.unpackEncodedString(DFA27_eofS);
    static final char[] DFA27_min = DFA.unpackEncodedStringToUnsignedChars(DFA27_minS);
    static final char[] DFA27_max = DFA.unpackEncodedStringToUnsignedChars(DFA27_maxS);
    static final short[] DFA27_accept = DFA.unpackEncodedString(DFA27_acceptS);
    static final short[] DFA27_special = DFA.unpackEncodedString(DFA27_specialS);
    static final short[][] DFA27_transition;

    static {
        int numStates = DFA27_transitionS.length;
        DFA27_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA27_transition[i] = DFA.unpackEncodedString(DFA27_transitionS[i]);
        }
    }

    class DFA27 extends DFA {

        public DFA27(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 27;
            this.eot = DFA27_eot;
            this.eof = DFA27_eof;
            this.min = DFA27_min;
            this.max = DFA27_max;
            this.accept = DFA27_accept;
            this.special = DFA27_special;
            this.transition = DFA27_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( LOCK | LOCKS | REQUIRESLOCK | ISLOCK | POLICYLOCK | RETURNSLOCK | INREGION | MAPFIELDS | MAPREGION | AGGREGATE | REGION | READS | WRITES | PROTECTS | NOTHING | ANY | IS | INTO | READ_LOCK | WRITE_LOCK | T__179 | T__180 | T__181 | T__182 | T__183 | T__184 | ABSTRACT | BOOLEAN | BREAK | BYTE | CASE | CATCH | CHAR | CLASS | CONST | CONTINUE | DEFAULT | DO | DOUBLE | ELSE | EXTENDS | FALSE | FINAL | FINALLY | FLOAT | FOR | GOTO | IF | IMPLEMENTS | IMPORT | INSTANCEOF | INT | INTERFACE | LONG | NATIVE | NEW | NULL | ONLY | PACKAGE | PRIVATE | PROTECTED | PUBLIC | RETURN | SHORT | STATIC | SUPER | SWITCH | SYNCHRONIZED | THIS | THROW | THROWS | TRANSIENT | TRUE | TRY | VOID | VOLATILE | WHILE | COLON | SEMI | DOT | LBRACKET | RBRACKET | AT | LPAREN | RPAREN | QUOTE | DQUOTE | LBRACE | RBRACE | COMMA | STAR | DSTAR | DASH | LANGLE | RANGLE | EQUALS | HexLiteral | DecimalLiteral | OctalLiteral | FloatingPointLiteral | CharacterLiteral | StringLiteral | IDENTIFIER | WS | NEWLINE );";
        }
    }
 

}
