package com.aelitis.azureus.core.drm.msdrm;

public class ExceededDRMDeliveryLimitException extends Exception {
	
	public ExceededDRMDeliveryLimitException(String message) {
		super(message);
	}

}
