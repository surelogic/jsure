package test_implicitThis;

import com.surelogic.Region;

@Region("public static RegionFromD")
public class D {

}
