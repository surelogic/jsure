package test;

public class Test {
  private int x;
  
  private class Inner {
    public void doStuff() {
      synchronized (Test.this) {
        System.out.println(x);
      }
    }
  }
  
  
  public static void main(final String[] args) {
    (new Test()).new Inner().doStuff();
  }
}
