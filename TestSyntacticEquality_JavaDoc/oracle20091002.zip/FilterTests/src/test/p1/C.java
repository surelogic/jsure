package test.p1;

public class C {
  public int f;
  
  public void doStuff() {
    f = 1;
  }
}
