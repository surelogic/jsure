package test_class;

import com.surelogic.Region;

@Region("public static RegionFromD")
public class D {

}
