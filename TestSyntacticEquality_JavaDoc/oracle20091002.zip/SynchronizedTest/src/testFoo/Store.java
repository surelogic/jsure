package testFoo;

class Store {
  public static void foo() { }
}
