package edu.afit.planetbaron.protocol;

public abstract class ServerCommand extends ASTNode {
}
