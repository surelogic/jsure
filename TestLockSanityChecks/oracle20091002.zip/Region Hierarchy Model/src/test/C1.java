package test;

import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.Regions;

@Regions({
  @Region("public A"),
  @Region("public D extends A"),
  @Region("public static S1")
})
public class C1 {
  @InRegion("S1")
  protected static int static1;
  
  @InRegion("D")
  protected int f;
}
