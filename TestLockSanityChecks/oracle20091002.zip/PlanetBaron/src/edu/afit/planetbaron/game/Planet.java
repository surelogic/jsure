package edu.afit.planetbaron.game;

/**
 * Represents a planet on the game map. A lock on the object is required to
 * access instance fields.
 * 
 * @author T.J. Halloran
 */
public final class Planet extends Reporter {

  /**
   * The player who currently controls this planet, or <code>null</code> if no
   * player controls the planet.
   */
  private Player f_owner;

  /**
   * The immutable and unique name of this planet.
   */
  private final String f_name;

  /**
   * The immutable location of this planet.
   */
  private final Location f_location;

  /**
   * Constructs a planet at the specified location. Only intended to be called
   * from {@link GameMap}. It is the responsibility of the caller to ensure
   * that the name of the planet is unique and that the location does not
   * already contain another planet.
   * 
   * @param map
   *          the containing game map.
   * @param name
   *          the planet name.
   * @param location
   *          the planet location.
   */
  Planet(GameMap map, String name, Location location) {
    super(map);
    assert name != null && location != null;
    f_location = location;
    f_name = name;
  }

  /**
   * Returns the location of this planet.
   * 
   * @return the location of this planet.
   */
  public Location getLocation() {
    return f_location; // immutable data no need for a lock
  }

  /**
   * Returns the name of this planet.
   * 
   * @return the name of this planet.
   */
  public String getName() {
    return f_name; // immutable data no need for a lock
  }

  /**
   * Returns the player who currently controls, or owns, this planet, or
   * <code>null</code> if no player owns the planet.
   * 
   * @return the player who currently controls, or owns, this planet, or
   *         <code>null</code> if no player owns the planet.
   */
  public Player getOwner() {
    f_lock.readLock().lock();
    try {
      return f_owner;
    } finally {
      f_lock.readLock().unlock();
    }
  }

  /**
   * Sets the player who controls, or owns, this planet.
   * 
   * @param owner
   *          the player who owns this planet.
   */
  public void setOwner(Player owner) {
    // first check if the owner already owns this planet
    f_lock.readLock().lock();
    try {
      if (owner == f_owner)
        return;
    } finally {
      f_lock.readLock().unlock();
    }
    f_lock.writeLock().lock();
    try {
      f_owner = owner;
      sendReport(); // OK to invoke holding a write lock
    } finally {
      f_lock.writeLock().unlock();
    }
  }
}
