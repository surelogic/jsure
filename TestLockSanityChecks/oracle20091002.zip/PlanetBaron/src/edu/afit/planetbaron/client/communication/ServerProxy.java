package edu.afit.planetbaron.client.communication;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.surelogic.Aggregate;
import com.surelogic.Region;
import com.surelogic.RegionLock;
import com.surelogic.Unique;

import edu.afit.planetbaron.protocol.ProtocolFacade;
import edu.afit.planetbaron.protocol.ServerCommand;
import edu.afit.planetbaron.protocol.ServerResponse;
import edu.afit.planetbaron.util.Common;
import edu.afit.planetbaron.util.ConciseFormatter;

/**
 * This class acts as a proxy for the game server to client applications.
 * Clients submit commands to be sent to the server and receive (for processing)
 * the server's responses. A client can register a callback to be notified if
 * the connection to the server is disconnected for any reason.
 * <p>
 * The client constructs an AST-based command, which is a subclass of
 * {@link ServerCommand}, and sends it to the server via a call to the
 * {@link #sendCommand(ServerCommand, IResponse)} method. The callback to the
 * client passes an AST-based response in the form of a subclass of the
 * {@link ServerResponse} class.
 * <p>
 * <b>Implementation note:</b> This class uses a background thread, started in
 * the constructor, to communicate with the game server, hence it is important
 * to call the {@link #shutdown()} method to stop the thread.
 * 
 * @author T.J. Halloran
 */
@Region("private Observers")
@RegionLock("ObserversLock is f_disconnectObservers protects Observers")
public final class ServerProxy extends Thread {

  private static final Logger LOG = ConciseFormatter.getLogger("client");

  /**
   * <code>false</code> if the proxy is running, <code>true</code> if the
   * proxy is trying to shutdown. When this field is set to <code>true</code>
   * this thread should complete as quickly as possible and exit. This field is
   * volatile because it is intended to set by another thread and read from
   * within this thread. Once this field is set to <code>true</code> it should
   * never again be set to <code>false</code> (i.e., it is monotonic toward
   * <code>true</code>).
   */
  private volatile boolean f_shutdown = false;

  /**
   * The communication channel to a game server.
   */
  private final Socket f_socket;

  /**
   * Constructs a new server proxy talking to the server connected on the passed
   * socket. After creating this object the caller is responsible for calling
   * {@link #shutdown()} when it wants the proxy to stop communication. This is
   * required because this class internally uses a separate thread to
   * communicate with the game server (which is started by this constructor).
   * 
   * @param socket
   *          the communication channel to a game server.
   */
  public ServerProxy(Socket socket) {
    assert socket != null;
    f_socket = socket;
    setName("server proxy to " + f_socket.getInetAddress() + ":"
        + f_socket.getPort());
    start();
  }

  /**
   * The separate thread of execution for the server proxy.
   */
  @Override
  public void run() {
    try {
      BufferedReader inputStream = new BufferedReader(new InputStreamReader(
          f_socket.getInputStream()));
      BufferedWriter outputStream = new BufferedWriter(new OutputStreamWriter(
          f_socket.getOutputStream()));

      // the server sends a welcome message when we first connect
      readAndCheckServerWelcomeMessage(inputStream);
      try {
        while (!f_shutdown) {
          Outgoing command = null;
          try {
            /*
             * Wait until somebody wants to send a message to the server. A
             * message to the server is enqueued by the sendMessage() method.
             */
            command = f_outgoingQueue.take(); // blocks
          } catch (InterruptedException e) {
            /*
             * Ignore, we interrupt this thread from shutdown() so shutdown
             * occurs quickly.
             */
          }
          if (f_shutdown)
            break; // bail out if we are done
          /*
           * The protocol with the server is such that we always send a command
           * and subsequently await a reply. The game server response will be an
           * unknown number of lines ended by a line containing "OK".
           */
          outputStream.write(command.getCommand() + "\n"); // send
          outputStream.flush();
          ServerResponse serverResponse = readServerResponse(inputStream);
          /*
           * The client can now process the response from the server.
           */
          command.getResponseHandler().process(this, command.getCommand(),
              serverResponse);
        }
      } catch (IOException e) {
        // ignore as this means the server closed our connection
      }
    } catch (IOException e) {
      LOG.log(Level.SEVERE, "general I/O failure on socket to "
          + f_socket.getInetAddress() + ":" + f_socket.getPort(), e);
    } finally {
      notifyDisconnectListeners();
    }
  }

  /**
   * Flags if the welcome message was read from the game server. This flag is
   * used to signal to the welcome timer that we haven't blocked forever.
   */
  private volatile boolean f_welcomeMessageRead = false;

  /**
   * Reads and checks that the welcome message from the server when we first
   * connect looks correct. We want to be careful we didn't connect to another
   * server port, such as connecting to a web server on port 80.
   * 
   * @param inputStream
   *          the input stream from the server to this client.
   * @throws IOException
   *           if the welcome message doesn't match or communication fails for
   *           any reason.
   */
  private void readAndCheckServerWelcomeMessage(final BufferedReader inputStream)
      throws IOException {
    boolean welcomeMessageMatches = false; // assume the worst
    /*
     * We'll give the server about a second to return the correct welcome
     * message. This timeout will prevent us from waiting forever, as many
     * protocols (e.g., HTTP) do not send an initial message.
     */
    Timer welcomeTimer = new Timer("Welcome Message Timer");
    welcomeTimer.schedule(new TimerTask() {
      public void run() {
        LOG.info("welcome message timer fired");
        if (!f_welcomeMessageRead) {
          // no answer, probably not a game server...stop blocking
          try {
            f_socket.close();
          } catch (IOException e) {
            LOG.log(Level.WARNING,
                "welcome message timer failed to close input stream", e);
          }
        }
      }
    }, 1000);
    try {
      String welcomeLine = inputStream.readLine(); // blocks
      f_welcomeMessageRead = true;
      welcomeTimer.cancel(); // terminate the welcome timer
      if (welcomeLine != null) {
        if (welcomeLine.startsWith(Common.serverWelcomeMessage)) {
          welcomeMessageMatches = true;
        }
      }
    } catch (SocketException e) {
      /*
       * Ignore, this exception is thrown if the welcome timer closed our socket
       * so we didn't hang forever waiting for the server. Note that we'll
       * output the correct error below.
       */
    }
    if (!welcomeMessageMatches) {
      LOG.log(Level.SEVERE,
          "bad protocol: welcome message from the server doesn't match the expected \""
              + Common.serverWelcomeMessage + "\"");
      throw new IOException(
          "bad protocol: welcome message from the server doesn't match the expected \""
              + Common.serverWelcomeMessage + "\"");
    }
  }

  /**
   * Represents a single server command which has been issued by this client and
   * is outgoing to the game server.
   * 
   * @see ServerProxy#f_outgoingQueue
   */
  private static class Outgoing {
    /**
     * The command to send to the game server.
     */
    private final ServerCommand f_command;

    /**
     * The callback to send the server's response to.
     */
    private final IResponse f_responseHandler;

    Outgoing(ServerCommand command, IResponse responseHandler) {
      assert command != null && responseHandler != null;
      f_command = command;
      f_responseHandler = responseHandler;
    }

    public ServerCommand getCommand() {
      return f_command;
    }

    public IResponse getResponseHandler() {
      return f_responseHandler;
    }
  }

  /**
   * Holds commands queued to be send to the server.
   */
  private final BlockingQueue<Outgoing> f_outgoingQueue = new ArrayBlockingQueue<Outgoing>(
      5);

  /**
   * Directs this proxy to send the specified command to the game server to be
   * processed. The proxy uses a separate thread to communicate with the server,
   * thus this call doesn't block unless the queue to that thread is full. Thus,
   * normally, the call returns immediately and the caller is (later) notified
   * of the server response via a callback to the passed response handler. If
   * this server proxy has shutdown this call is ignored.
   * 
   * @param command
   *          the command to send to the game server.
   * @param responseHandler
   *          object to callback with the server response to this message, may
   *          be <code>null</code> if the response is not of interest.
   */
  public void sendCommand(ServerCommand command, IResponse responseHandler) {
    assert command != null;
    if (responseHandler == null) {
      // avoid a null pointer exception by "doing nothing"
      responseHandler = new IResponse() {
        public void process(ServerProxy proxy, ServerCommand command,
            ServerResponse response) {
          // do nothing
        }
      };
    }
    if (f_shutdown)
      return; // ignore the attempt to send a message
    try {
      /*
       * Enqueue the command so that it can be sent to the server.
       */
      Outgoing sm = new Outgoing(command, responseHandler);
      f_outgoingQueue.put(sm);
    } catch (InterruptedException e) {
      LOG.log(Level.WARNING, "unexpected interrupt while queueing a"
          + " command for the game server", e);
    }
  }

  /**
   * Reads a response from the game server to an (already sent) game command.
   * 
   * @param inputStream
   *          the communication stream to the game server
   * @return the server response
   * @throws IOException
   *           if a communication failure to the server occurs
   */
  private ServerResponse readServerResponse(BufferedReader inputStream)
      throws IOException {
    StringBuilder response = new StringBuilder();
    String lineFromServer = "";
    while (!lineFromServer.equalsIgnoreCase("OK")) {
      lineFromServer = inputStream.readLine(); // blocks
      if (lineFromServer == null) {
        throw new IOException(
            "null received from the game server, did it shutdown?");
      }
      if (!lineFromServer.trim().equals("")) { // ignore blank lines
        response.append(lineFromServer + " ");
      }
    }
    return ProtocolFacade.parseServerResponse(response.toString());
  }

  /**
   * The set of disconnect observers for this server proxy. Access to the set
   * must always be protected by a lock on itself.
   */
  @Unique
  @Aggregate("Instance into Observers")
  private final Set<IDisconnect> f_disconnectObservers = new HashSet<IDisconnect>();

  /**
   * Guard against double notifications due to exception logic of the proxy
   * server. Access to this flag must always be protected by a lock on the
   * {@link #f_disconnectObservers}.
   */
  private boolean f_disconnectObserversNotified = false;

  /**
   * Notifies all disconnect listeners that our connection has been
   * disconnected. Note that the field {@link #f_disconnectObserversNotified} is
   * used to guard against double notification.
   */
  private void notifyDisconnectListeners() {
    synchronized (f_disconnectObservers) {
      if (!f_disconnectObserversNotified) {
        f_disconnectObserversNotified = true;
        for (IDisconnect l : f_disconnectObservers) {
          l.disconnected(this);
        }
      }
    }
  }

  /**
   * Registers a disconnect observer with this proxy.
   * 
   * @param observer
   *          the disconnect listener
   */
  public void register(IDisconnect observer) {
    assert observer != null;
    synchronized (f_disconnectObservers) {
      f_disconnectObservers.add(observer);
    }
  }

  /**
   * Causes this thread to die as quickly as possible (if it has not already).
   * The method does not wait for the death to occur it simply notes the request
   * (which will be processed) and returns. This method closes the socket passed
   * to the constructor of this proxy.
   */
  public void shutdown() {
    f_shutdown = true;
    try {
      f_socket.close(); // shutdown the connection to the game server
    } catch (IOException e) {
      LOG.log(Level.SEVERE, "general I/O failure trying to close socket to "
          + f_socket.getInetAddress() + ":" + f_socket.getPort(), e);
    } finally {
      this.interrupt(); // might be waiting for a command enqueue
    }
  }
}
