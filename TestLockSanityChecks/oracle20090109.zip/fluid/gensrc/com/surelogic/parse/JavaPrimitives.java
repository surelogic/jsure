// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g 2008-09-25 15:48:47

package com.surelogic.parse;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class JavaPrimitives extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ABSTRACT", "BOOLEAN", "BREAK", "BYTE", "CASE", "CATCH", "CHAR", "CLASS", "CONST", "CONTINUE", "DEFAULT", "DO", "DOUBLE", "ELSE", "EXTENDS", "FALSE", "FINAL", "FINALLY", "FLOAT", "FOR", "GOTO", "IF", "IMPLEMENTS", "IMPORT", "INSTANCEOF", "INT", "INTERFACE", "LONG", "NATIVE", "NEW", "NULL", "ONLY", "PACKAGE", "PRIVATE", "PROTECTED", "PUBLIC", "RETURN", "SHORT", "STATIC", "SUPER", "SWITCH", "SYNCHRONIZED", "THIS", "THROW", "THROWS", "TRANSIENT", "TRUE", "TRY", "VOID", "VOLATILE", "WHILE", "COLON", "SEMI", "DOT", "LBRACKET", "RBRACKET", "AT", "LPAREN", "RPAREN", "QUOTE", "DQUOTE", "LBRACE", "RBRACE", "COMMA", "LETTER", "JavaIDDigit", "IDENTIFIER", "WS", "NEWLINE", "Tokens", "VarDecl", "NamedType", "TypeRef", "ArrayType", "Annotations", "MarkerAnnotation", "ThisExpression", "ReturnValueDeclaration", "Nothing"
    };
    public static final int ThisExpression=80;
    public static final int COMMA=67;
    public static final int CONST=12;
    public static final int PUBLIC=39;
    public static final int LONG=31;
    public static final int SYNCHRONIZED=45;
    public static final int DOUBLE=16;
    public static final int TRANSIENT=49;
    public static final int FLOAT=22;
    public static final int FALSE=19;
    public static final int THROWS=48;
    public static final int ABSTRACT=4;
    public static final int LBRACKET=58;
    public static final int GOTO=24;
    public static final int IMPORT=27;
    public static final int DQUOTE=64;
    public static final int PACKAGE=36;
    public static final int MarkerAnnotation=79;
    public static final int LBRACE=65;
    public static final int CONTINUE=13;
    public static final int NEWLINE=72;
    public static final int DOT=57;
    public static final int RBRACE=66;
    public static final int PRIVATE=37;
    public static final int PROTECTED=38;
    public static final int INT=29;
    public static final int RBRACKET=59;
    public static final int VOID=52;
    public static final int INSTANCEOF=28;
    public static final int RPAREN=62;
    public static final int LPAREN=61;
    public static final int Nothing=82;
    public static final int VarDecl=74;
    public static final int FINALLY=21;
    public static final int EXTENDS=18;
    public static final int AT=60;
    public static final int LETTER=68;
    public static final int SUPER=43;
    public static final int Annotations=78;
    public static final int DO=15;
    public static final int IMPLEMENTS=26;
    public static final int WHILE=54;
    public static final int SWITCH=44;
    public static final int WS=71;
    public static final int CHAR=10;
    public static final int ONLY=35;
    public static final int NEW=33;
    public static final int ReturnValueDeclaration=81;
    public static final int NamedType=75;
    public static final int FINAL=20;
    public static final int QUOTE=63;
    public static final int THIS=46;
    public static final int STATIC=42;
    public static final int CATCH=9;
    public static final int SEMI=56;
    public static final int CASE=8;
    public static final int JavaIDDigit=69;
    public static final int TypeRef=76;
    public static final int CLASS=11;
    public static final int INTERFACE=30;
    public static final int NATIVE=32;
    public static final int BOOLEAN=5;
    public static final int ELSE=17;
    public static final int RETURN=40;
    public static final int BYTE=7;
    public static final int VOLATILE=53;
    public static final int IF=25;
    public static final int EOF=-1;
    public static final int BREAK=6;
    public static final int NULL=34;
    public static final int FOR=23;
    public static final int ArrayType=77;
    public static final int Tokens=73;
    public static final int DEFAULT=14;
    public static final int COLON=55;
    public static final int IDENTIFIER=70;
    public static final int TRY=51;
    public static final int TRUE=50;
    public static final int THROW=47;
    public static final int SHORT=41;

    // delegates
    // delegators


        public JavaPrimitives(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public JavaPrimitives(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return JavaPrimitives.tokenNames; }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g"; }


    public static class borrowed_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "borrowed"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:24:1: borrowed : thisExpr ;
    public final JavaPrimitives.borrowed_return borrowed() throws RecognitionException {
        JavaPrimitives.borrowed_return retval = new JavaPrimitives.borrowed_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        JavaPrimitives.thisExpr_return thisExpr1 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:25:5: ( thisExpr )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:25:7: thisExpr
            {
            root_0 = (Tree)adaptor.nil();

            pushFollow(FOLLOW_thisExpr_in_borrowed109);
            thisExpr1=thisExpr();

            state._fsp--;

            adaptor.addChild(root_0, thisExpr1.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "borrowed"

    public static class unique_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unique"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:28:1: unique : ( thisExpr | returnValue | nothing );
    public final JavaPrimitives.unique_return unique() throws RecognitionException {
        JavaPrimitives.unique_return retval = new JavaPrimitives.unique_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        JavaPrimitives.thisExpr_return thisExpr2 = null;

        JavaPrimitives.returnValue_return returnValue3 = null;

        JavaPrimitives.nothing_return nothing4 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:29:5: ( thisExpr | returnValue | nothing )
            int alt1=3;
            switch ( input.LA(1) ) {
            case THIS:
                {
                alt1=1;
                }
                break;
            case RETURN:
                {
                alt1=2;
                }
                break;
            case EOF:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:29:7: thisExpr
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_thisExpr_in_unique130);
                    thisExpr2=thisExpr();

                    state._fsp--;

                    adaptor.addChild(root_0, thisExpr2.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:29:18: returnValue
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_returnValue_in_unique134);
                    returnValue3=returnValue();

                    state._fsp--;

                    adaptor.addChild(root_0, returnValue3.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:29:32: nothing
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_nothing_in_unique138);
                    nothing4=nothing();

                    state._fsp--;

                    adaptor.addChild(root_0, nothing4.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unique"

    public static class thisExpr_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "thisExpr"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:32:1: thisExpr : THIS -> ^( ThisExpression THIS ) ;
    public final JavaPrimitives.thisExpr_return thisExpr() throws RecognitionException {
        JavaPrimitives.thisExpr_return retval = new JavaPrimitives.thisExpr_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token THIS5=null;

        Tree THIS5_tree=null;
        RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:33:5: ( THIS -> ^( ThisExpression THIS ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:33:7: THIS
            {
            THIS5=(Token)match(input,THIS,FOLLOW_THIS_in_thisExpr159);  
            stream_THIS.add(THIS5);



            // AST REWRITE
            // elements: THIS
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 33:12: -> ^( ThisExpression THIS )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:33:15: ^( ThisExpression THIS )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ThisExpression, "ThisExpression"), root_1);

                adaptor.addChild(root_1, stream_THIS.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "thisExpr"

    public static class returnValue_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "returnValue"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:36:1: returnValue : RETURN -> ^( ReturnValueDeclaration RETURN ) ;
    public final JavaPrimitives.returnValue_return returnValue() throws RecognitionException {
        JavaPrimitives.returnValue_return retval = new JavaPrimitives.returnValue_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token RETURN6=null;

        Tree RETURN6_tree=null;
        RewriteRuleTokenStream stream_RETURN=new RewriteRuleTokenStream(adaptor,"token RETURN");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:37:5: ( RETURN -> ^( ReturnValueDeclaration RETURN ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:37:7: RETURN
            {
            RETURN6=(Token)match(input,RETURN,FOLLOW_RETURN_in_returnValue188);  
            stream_RETURN.add(RETURN6);



            // AST REWRITE
            // elements: RETURN
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 37:14: -> ^( ReturnValueDeclaration RETURN )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:37:17: ^( ReturnValueDeclaration RETURN )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ReturnValueDeclaration, "ReturnValueDeclaration"), root_1);

                adaptor.addChild(root_1, stream_RETURN.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "returnValue"

    public static class nothing_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nothing"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:40:1: nothing : EOF -> ^( Nothing ) ;
    public final JavaPrimitives.nothing_return nothing() throws RecognitionException {
        JavaPrimitives.nothing_return retval = new JavaPrimitives.nothing_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF7=null;

        Tree EOF7_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:41:5: ( EOF -> ^( Nothing ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:41:7: EOF
            {
            EOF7=(Token)match(input,EOF,FOLLOW_EOF_in_nothing217);  
            stream_EOF.add(EOF7);



            // AST REWRITE
            // elements: 
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 41:11: -> ^( Nothing )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:41:14: ^( Nothing )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Nothing, "Nothing"), root_1);

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "nothing"

    public static class fieldDecl_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldDecl"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:44:1: fieldDecl : annotations modifiers returnType IDENTIFIER -> ^( VarDecl annotations modifiers returnType IDENTIFIER ) ;
    public final JavaPrimitives.fieldDecl_return fieldDecl() throws RecognitionException {
        JavaPrimitives.fieldDecl_return retval = new JavaPrimitives.fieldDecl_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER11=null;
        JavaPrimitives.annotations_return annotations8 = null;

        JavaPrimitives.modifiers_return modifiers9 = null;

        JavaPrimitives.returnType_return returnType10 = null;


        Tree IDENTIFIER11_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_modifiers=new RewriteRuleSubtreeStream(adaptor,"rule modifiers");
        RewriteRuleSubtreeStream stream_returnType=new RewriteRuleSubtreeStream(adaptor,"rule returnType");
        RewriteRuleSubtreeStream stream_annotations=new RewriteRuleSubtreeStream(adaptor,"rule annotations");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:45:5: ( annotations modifiers returnType IDENTIFIER -> ^( VarDecl annotations modifiers returnType IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:45:7: annotations modifiers returnType IDENTIFIER
            {
            pushFollow(FOLLOW_annotations_in_fieldDecl240);
            annotations8=annotations();

            state._fsp--;

            stream_annotations.add(annotations8.getTree());
            pushFollow(FOLLOW_modifiers_in_fieldDecl242);
            modifiers9=modifiers();

            state._fsp--;

            stream_modifiers.add(modifiers9.getTree());
            pushFollow(FOLLOW_returnType_in_fieldDecl244);
            returnType10=returnType();

            state._fsp--;

            stream_returnType.add(returnType10.getTree());
            IDENTIFIER11=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_fieldDecl246);  
            stream_IDENTIFIER.add(IDENTIFIER11);



            // AST REWRITE
            // elements: annotations, modifiers, returnType, IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 45:51: -> ^( VarDecl annotations modifiers returnType IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:45:54: ^( VarDecl annotations modifiers returnType IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(VarDecl, "VarDecl"), root_1);

                adaptor.addChild(root_1, stream_annotations.nextTree());
                adaptor.addChild(root_1, stream_modifiers.nextTree());
                adaptor.addChild(root_1, stream_returnType.nextTree());
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldDecl"

    public static class annotations_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "annotations"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:48:1: annotations : ( annotation )* -> ^( Annotations ( annotation )* ) ;
    public final JavaPrimitives.annotations_return annotations() throws RecognitionException {
        JavaPrimitives.annotations_return retval = new JavaPrimitives.annotations_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        JavaPrimitives.annotation_return annotation12 = null;


        RewriteRuleSubtreeStream stream_annotation=new RewriteRuleSubtreeStream(adaptor,"rule annotation");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:49:5: ( ( annotation )* -> ^( Annotations ( annotation )* ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:49:7: ( annotation )*
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:49:7: ( annotation )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==AT) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:49:7: annotation
            	    {
            	    pushFollow(FOLLOW_annotation_in_annotations277);
            	    annotation12=annotation();

            	    state._fsp--;

            	    stream_annotation.add(annotation12.getTree());

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);



            // AST REWRITE
            // elements: annotation
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 49:19: -> ^( Annotations ( annotation )* )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:49:22: ^( Annotations ( annotation )* )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Annotations, "Annotations"), root_1);

                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:49:36: ( annotation )*
                while ( stream_annotation.hasNext() ) {
                    adaptor.addChild(root_1, stream_annotation.nextTree());

                }
                stream_annotation.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "annotations"

    public static class annotation_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "annotation"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:52:1: annotation : AT IDENTIFIER -> ^( MarkerAnnotation IDENTIFIER ) ;
    public final JavaPrimitives.annotation_return annotation() throws RecognitionException {
        JavaPrimitives.annotation_return retval = new JavaPrimitives.annotation_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token AT13=null;
        Token IDENTIFIER14=null;

        Tree AT13_tree=null;
        Tree IDENTIFIER14_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_AT=new RewriteRuleTokenStream(adaptor,"token AT");

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:53:5: ( AT IDENTIFIER -> ^( MarkerAnnotation IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:53:7: AT IDENTIFIER
            {
            AT13=(Token)match(input,AT,FOLLOW_AT_in_annotation304);  
            stream_AT.add(AT13);

            IDENTIFIER14=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_annotation306);  
            stream_IDENTIFIER.add(IDENTIFIER14);



            // AST REWRITE
            // elements: IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 53:21: -> ^( MarkerAnnotation IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:53:24: ^( MarkerAnnotation IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(MarkerAnnotation, "MarkerAnnotation"), root_1);

                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "annotation"

    public static class modifiers_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "modifiers"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:56:1: modifiers : ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? ( FINAL )? ;
    public final JavaPrimitives.modifiers_return modifiers() throws RecognitionException {
        JavaPrimitives.modifiers_return retval = new JavaPrimitives.modifiers_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token set15=null;
        Token STATIC16=null;
        Token FINAL17=null;

        Tree set15_tree=null;
        Tree STATIC16_tree=null;
        Tree FINAL17_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:5: ( ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? ( FINAL )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:7: ( PUBLIC | PROTECTED | PRIVATE )? ( STATIC )? ( FINAL )?
            {
            root_0 = (Tree)adaptor.nil();

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:7: ( PUBLIC | PROTECTED | PRIVATE )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( ((LA3_0>=PRIVATE && LA3_0<=PUBLIC)) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:
                    {
                    set15=(Token)input.LT(1);
                    if ( (input.LA(1)>=PRIVATE && input.LA(1)<=PUBLIC) ) {
                        input.consume();
                        adaptor.addChild(root_0, (Tree)adaptor.create(set15));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:39: ( STATIC )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==STATIC) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:39: STATIC
                    {
                    STATIC16=(Token)match(input,STATIC,FOLLOW_STATIC_in_modifiers344); 
                    STATIC16_tree = (Tree)adaptor.create(STATIC16);
                    adaptor.addChild(root_0, STATIC16_tree);


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:47: ( FINAL )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==FINAL) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:57:47: FINAL
                    {
                    FINAL17=(Token)match(input,FINAL,FOLLOW_FINAL_in_modifiers347); 
                    FINAL17_tree = (Tree)adaptor.create(FINAL17);
                    adaptor.addChild(root_0, FINAL17_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "modifiers"

    public static class returnType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "returnType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:60:1: returnType : ( VOID | type );
    public final JavaPrimitives.returnType_return returnType() throws RecognitionException {
        JavaPrimitives.returnType_return retval = new JavaPrimitives.returnType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token VOID18=null;
        JavaPrimitives.type_return type19 = null;


        Tree VOID18_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:61:5: ( VOID | type )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==VOID) ) {
                alt6=1;
            }
            else if ( (LA6_0==BOOLEAN||LA6_0==BYTE||LA6_0==CHAR||LA6_0==DOUBLE||LA6_0==FLOAT||LA6_0==INT||LA6_0==LONG||LA6_0==SHORT||LA6_0==IDENTIFIER) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:61:7: VOID
                    {
                    root_0 = (Tree)adaptor.nil();

                    VOID18=(Token)match(input,VOID,FOLLOW_VOID_in_returnType365); 
                    VOID18_tree = (Tree)adaptor.create(VOID18);
                    adaptor.addChild(root_0, VOID18_tree);


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:61:14: type
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_type_in_returnType369);
                    type19=type();

                    state._fsp--;

                    adaptor.addChild(root_0, type19.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "returnType"

    public static class type_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:64:1: type : ( arrayType | nonArrayType );
    public final JavaPrimitives.type_return type() throws RecognitionException {
        JavaPrimitives.type_return retval = new JavaPrimitives.type_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        JavaPrimitives.arrayType_return arrayType20 = null;

        JavaPrimitives.nonArrayType_return nonArrayType21 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:65:5: ( arrayType | nonArrayType )
            int alt7=2;
            alt7 = dfa7.predict(input);
            switch (alt7) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:65:7: arrayType
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_arrayType_in_type386);
                    arrayType20=arrayType();

                    state._fsp--;

                    adaptor.addChild(root_0, arrayType20.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:65:19: nonArrayType
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_nonArrayType_in_type390);
                    nonArrayType21=nonArrayType();

                    state._fsp--;

                    adaptor.addChild(root_0, nonArrayType21.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type"

    public static class nonArrayType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nonArrayType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:68:1: nonArrayType : ( primType | typeRef | namedType );
    public final JavaPrimitives.nonArrayType_return nonArrayType() throws RecognitionException {
        JavaPrimitives.nonArrayType_return retval = new JavaPrimitives.nonArrayType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        JavaPrimitives.primType_return primType22 = null;

        JavaPrimitives.typeRef_return typeRef23 = null;

        JavaPrimitives.namedType_return namedType24 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:69:5: ( primType | typeRef | namedType )
            int alt8=3;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:69:7: primType
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_primType_in_nonArrayType407);
                    primType22=primType();

                    state._fsp--;

                    adaptor.addChild(root_0, primType22.getTree());

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:70:7: typeRef
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_typeRef_in_nonArrayType416);
                    typeRef23=typeRef();

                    state._fsp--;

                    adaptor.addChild(root_0, typeRef23.getTree());

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:71:7: namedType
                    {
                    root_0 = (Tree)adaptor.nil();

                    pushFollow(FOLLOW_namedType_in_nonArrayType424);
                    namedType24=namedType();

                    state._fsp--;

                    adaptor.addChild(root_0, namedType24.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "nonArrayType"

    public static class arrayType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arrayType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:74:1: arrayType : nonArrayType ( LBRACKET RBRACKET )+ -> ^( ArrayType nonArrayType ( RBRACKET )+ ) ;
    public final JavaPrimitives.arrayType_return arrayType() throws RecognitionException {
        JavaPrimitives.arrayType_return retval = new JavaPrimitives.arrayType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token LBRACKET26=null;
        Token RBRACKET27=null;
        JavaPrimitives.nonArrayType_return nonArrayType25 = null;


        Tree LBRACKET26_tree=null;
        Tree RBRACKET27_tree=null;
        RewriteRuleTokenStream stream_LBRACKET=new RewriteRuleTokenStream(adaptor,"token LBRACKET");
        RewriteRuleTokenStream stream_RBRACKET=new RewriteRuleTokenStream(adaptor,"token RBRACKET");
        RewriteRuleSubtreeStream stream_nonArrayType=new RewriteRuleSubtreeStream(adaptor,"rule nonArrayType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:75:5: ( nonArrayType ( LBRACKET RBRACKET )+ -> ^( ArrayType nonArrayType ( RBRACKET )+ ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:75:7: nonArrayType ( LBRACKET RBRACKET )+
            {
            pushFollow(FOLLOW_nonArrayType_in_arrayType441);
            nonArrayType25=nonArrayType();

            state._fsp--;

            stream_nonArrayType.add(nonArrayType25.getTree());
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:75:20: ( LBRACKET RBRACKET )+
            int cnt9=0;
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==LBRACKET) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:75:21: LBRACKET RBRACKET
            	    {
            	    LBRACKET26=(Token)match(input,LBRACKET,FOLLOW_LBRACKET_in_arrayType444);  
            	    stream_LBRACKET.add(LBRACKET26);

            	    RBRACKET27=(Token)match(input,RBRACKET,FOLLOW_RBRACKET_in_arrayType446);  
            	    stream_RBRACKET.add(RBRACKET27);


            	    }
            	    break;

            	default :
            	    if ( cnt9 >= 1 ) break loop9;
                        EarlyExitException eee =
                            new EarlyExitException(9, input);
                        throw eee;
                }
                cnt9++;
            } while (true);



            // AST REWRITE
            // elements: nonArrayType, RBRACKET
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 75:41: -> ^( ArrayType nonArrayType ( RBRACKET )+ )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:75:44: ^( ArrayType nonArrayType ( RBRACKET )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ArrayType, "ArrayType"), root_1);

                adaptor.addChild(root_1, stream_nonArrayType.nextTree());
                if ( !(stream_RBRACKET.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_RBRACKET.hasNext() ) {
                    adaptor.addChild(root_1, stream_RBRACKET.nextNode());

                }
                stream_RBRACKET.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "arrayType"

    public static class primType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "primType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:78:1: primType : ( BOOLEAN | BYTE | CHAR | SHORT | INT | LONG | FLOAT | DOUBLE );
    public final JavaPrimitives.primType_return primType() throws RecognitionException {
        JavaPrimitives.primType_return retval = new JavaPrimitives.primType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token set28=null;

        Tree set28_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:79:5: ( BOOLEAN | BYTE | CHAR | SHORT | INT | LONG | FLOAT | DOUBLE )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:
            {
            root_0 = (Tree)adaptor.nil();

            set28=(Token)input.LT(1);
            if ( input.LA(1)==BOOLEAN||input.LA(1)==BYTE||input.LA(1)==CHAR||input.LA(1)==DOUBLE||input.LA(1)==FLOAT||input.LA(1)==INT||input.LA(1)==LONG||input.LA(1)==SHORT ) {
                input.consume();
                adaptor.addChild(root_0, (Tree)adaptor.create(set28));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "primType"

    public static class typeRef_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeRef"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:82:1: typeRef : namedType DOT IDENTIFIER typeRefExt -> ^( TypeRef namedType IDENTIFIER typeRefExt ) ;
    public final JavaPrimitives.typeRef_return typeRef() throws RecognitionException {
        JavaPrimitives.typeRef_return retval = new JavaPrimitives.typeRef_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token DOT30=null;
        Token IDENTIFIER31=null;
        JavaPrimitives.namedType_return namedType29 = null;

        JavaPrimitives.typeRefExt_return typeRefExt32 = null;


        Tree DOT30_tree=null;
        Tree IDENTIFIER31_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_typeRefExt=new RewriteRuleSubtreeStream(adaptor,"rule typeRefExt");
        RewriteRuleSubtreeStream stream_namedType=new RewriteRuleSubtreeStream(adaptor,"rule namedType");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:83:5: ( namedType DOT IDENTIFIER typeRefExt -> ^( TypeRef namedType IDENTIFIER typeRefExt ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:83:7: namedType DOT IDENTIFIER typeRefExt
            {
            pushFollow(FOLLOW_namedType_in_typeRef525);
            namedType29=namedType();

            state._fsp--;

            stream_namedType.add(namedType29.getTree());
            DOT30=(Token)match(input,DOT,FOLLOW_DOT_in_typeRef527);  
            stream_DOT.add(DOT30);

            IDENTIFIER31=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_typeRef529);  
            stream_IDENTIFIER.add(IDENTIFIER31);

            pushFollow(FOLLOW_typeRefExt_in_typeRef531);
            typeRefExt32=typeRefExt();

            state._fsp--;

            stream_typeRefExt.add(typeRefExt32.getTree());


            // AST REWRITE
            // elements: typeRefExt, namedType, IDENTIFIER
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 83:43: -> ^( TypeRef namedType IDENTIFIER typeRefExt )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:83:46: ^( TypeRef namedType IDENTIFIER typeRefExt )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeRef, "TypeRef"), root_1);

                adaptor.addChild(root_1, stream_namedType.nextTree());
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());
                adaptor.addChild(root_1, stream_typeRefExt.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeRef"

    public static class typeRefExt_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeRefExt"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:86:1: typeRefExt : ( DOT IDENTIFIER )* ;
    public final JavaPrimitives.typeRefExt_return typeRefExt() throws RecognitionException {
        JavaPrimitives.typeRefExt_return retval = new JavaPrimitives.typeRefExt_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token DOT33=null;
        Token IDENTIFIER34=null;

        Tree DOT33_tree=null;
        Tree IDENTIFIER34_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:87:5: ( ( DOT IDENTIFIER )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:87:7: ( DOT IDENTIFIER )*
            {
            root_0 = (Tree)adaptor.nil();

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:87:7: ( DOT IDENTIFIER )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==DOT) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:87:8: DOT IDENTIFIER
            	    {
            	    DOT33=(Token)match(input,DOT,FOLLOW_DOT_in_typeRefExt562); 
            	    DOT33_tree = (Tree)adaptor.create(DOT33);
            	    adaptor.addChild(root_0, DOT33_tree);

            	    IDENTIFIER34=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_typeRefExt564); 
            	    IDENTIFIER34_tree = (Tree)adaptor.create(IDENTIFIER34);
            	    adaptor.addChild(root_0, IDENTIFIER34_tree);


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeRefExt"

    public static class namedType_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "namedType"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:90:1: namedType : ( packageName COLON )? IDENTIFIER -> ^( NamedType packageName DOT IDENTIFIER ) ;
    public final JavaPrimitives.namedType_return namedType() throws RecognitionException {
        JavaPrimitives.namedType_return retval = new JavaPrimitives.namedType_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token COLON36=null;
        Token IDENTIFIER37=null;
        JavaPrimitives.packageName_return packageName35 = null;


        Tree COLON36_tree=null;
        Tree IDENTIFIER37_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_IDENTIFIER=new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");
        RewriteRuleSubtreeStream stream_packageName=new RewriteRuleSubtreeStream(adaptor,"rule packageName");
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:91:5: ( ( packageName COLON )? IDENTIFIER -> ^( NamedType packageName DOT IDENTIFIER ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:91:7: ( packageName COLON )? IDENTIFIER
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:91:7: ( packageName COLON )?
            int alt11=2;
            alt11 = dfa11.predict(input);
            switch (alt11) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:91:9: packageName COLON
                    {
                    pushFollow(FOLLOW_packageName_in_namedType585);
                    packageName35=packageName();

                    state._fsp--;

                    stream_packageName.add(packageName35.getTree());
                    COLON36=(Token)match(input,COLON,FOLLOW_COLON_in_namedType587);  
                    stream_COLON.add(COLON36);


                    }
                    break;

            }

            IDENTIFIER37=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_namedType592);  
            stream_IDENTIFIER.add(IDENTIFIER37);



            // AST REWRITE
            // elements: IDENTIFIER, packageName
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 91:41: -> ^( NamedType packageName DOT IDENTIFIER )
            {
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:91:44: ^( NamedType packageName DOT IDENTIFIER )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(NamedType, "NamedType"), root_1);

                adaptor.addChild(root_1, stream_packageName.nextTree());
                adaptor.addChild(root_1, (Tree)adaptor.create(DOT, "DOT"));
                adaptor.addChild(root_1, stream_IDENTIFIER.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "namedType"

    public static class packageName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "packageName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:94:1: packageName : qualifiedName ;
    public final JavaPrimitives.packageName_return packageName() throws RecognitionException {
        JavaPrimitives.packageName_return retval = new JavaPrimitives.packageName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        JavaPrimitives.qualifiedName_return qualifiedName38 = null;



        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:95:5: ( qualifiedName )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:95:7: qualifiedName
            {
            root_0 = (Tree)adaptor.nil();

            pushFollow(FOLLOW_qualifiedName_in_packageName623);
            qualifiedName38=qualifiedName();

            state._fsp--;

            adaptor.addChild(root_0, qualifiedName38.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "packageName"

    public static class qualifiedName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualifiedName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:98:1: qualifiedName : IDENTIFIER ( DOT IDENTIFIER )* ;
    public final JavaPrimitives.qualifiedName_return qualifiedName() throws RecognitionException {
        JavaPrimitives.qualifiedName_return retval = new JavaPrimitives.qualifiedName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER39=null;
        Token DOT40=null;
        Token IDENTIFIER41=null;

        Tree IDENTIFIER39_tree=null;
        Tree DOT40_tree=null;
        Tree IDENTIFIER41_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:99:4: ( IDENTIFIER ( DOT IDENTIFIER )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:99:6: IDENTIFIER ( DOT IDENTIFIER )*
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER39=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName646); 
            IDENTIFIER39_tree = (Tree)adaptor.create(IDENTIFIER39);
            adaptor.addChild(root_0, IDENTIFIER39_tree);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:99:17: ( DOT IDENTIFIER )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==DOT) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:99:19: DOT IDENTIFIER
            	    {
            	    DOT40=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedName650); 
            	    DOT40_tree = (Tree)adaptor.create(DOT40);
            	    adaptor.addChild(root_0, DOT40_tree);

            	    IDENTIFIER41=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_qualifiedName652); 
            	    IDENTIFIER41_tree = (Tree)adaptor.create(IDENTIFIER41);
            	    adaptor.addChild(root_0, IDENTIFIER41_tree);


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualifiedName"

    public static class simpleName_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleName"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:102:1: simpleName : IDENTIFIER ;
    public final JavaPrimitives.simpleName_return simpleName() throws RecognitionException {
        JavaPrimitives.simpleName_return retval = new JavaPrimitives.simpleName_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token IDENTIFIER42=null;

        Tree IDENTIFIER42_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:103:5: ( IDENTIFIER )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaPrimitives.g:103:7: IDENTIFIER
            {
            root_0 = (Tree)adaptor.nil();

            IDENTIFIER42=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_simpleName671); 
            IDENTIFIER42_tree = (Tree)adaptor.create(IDENTIFIER42);
            adaptor.addChild(root_0, IDENTIFIER42_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleName"

    // Delegated rules


    protected DFA7 dfa7 = new DFA7(this);
    protected DFA8 dfa8 = new DFA8(this);
    protected DFA11 dfa11 = new DFA11(this);
    static final String DFA7_eotS =
        "\17\uffff";
    static final String DFA7_eofS =
        "\17\uffff";
    static final String DFA7_minS =
        "\1\5\1\72\1\67\2\uffff\2\106\1\67\1\71\2\106\1\67\1\71\1\106\1\71";
    static final String DFA7_maxS =
        "\3\106\2\uffff\12\106";
    static final String DFA7_acceptS =
        "\3\uffff\1\2\1\1\12\uffff";
    static final String DFA7_specialS =
        "\17\uffff}>";
    static final String[] DFA7_transitionS = {
            "\1\1\1\uffff\1\1\2\uffff\1\1\5\uffff\1\1\5\uffff\1\1\6\uffff"+
            "\1\1\1\uffff\1\1\11\uffff\1\1\34\uffff\1\2",
            "\1\4\13\uffff\1\3",
            "\1\6\1\uffff\1\5\1\4\13\uffff\1\3",
            "",
            "",
            "\1\7",
            "\1\10",
            "\1\6\1\uffff\1\11\1\4\13\uffff\1\3",
            "\1\12\1\4\13\uffff\1\3",
            "\1\13",
            "\1\14",
            "\1\6\1\uffff\1\11\1\4\13\uffff\1\3",
            "\1\15\1\4\13\uffff\1\3",
            "\1\16",
            "\1\15\1\4\13\uffff\1\3"
    };

    static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
    static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
    static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
    static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
    static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
    static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
    static final short[][] DFA7_transition;

    static {
        int numStates = DFA7_transitionS.length;
        DFA7_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
        }
    }

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA7_eot;
            this.eof = DFA7_eof;
            this.min = DFA7_min;
            this.max = DFA7_max;
            this.accept = DFA7_accept;
            this.special = DFA7_special;
            this.transition = DFA7_transition;
        }
        public String getDescription() {
            return "64:1: type : ( arrayType | nonArrayType );";
        }
    }
    static final String DFA8_eotS =
        "\13\uffff";
    static final String DFA8_eofS =
        "\13\uffff";
    static final String DFA8_minS =
        "\1\5\1\uffff\1\67\2\106\1\uffff\1\67\1\71\1\106\1\uffff\1\67";
    static final String DFA8_maxS =
        "\1\106\1\uffff\3\106\1\uffff\3\106\1\uffff\1\106";
    static final String DFA8_acceptS =
        "\1\uffff\1\1\3\uffff\1\3\3\uffff\1\2\1\uffff";
    static final String DFA8_specialS =
        "\13\uffff}>";
    static final String[] DFA8_transitionS = {
            "\1\1\1\uffff\1\1\2\uffff\1\1\5\uffff\1\1\5\uffff\1\1\6\uffff"+
            "\1\1\1\uffff\1\1\11\uffff\1\1\34\uffff\1\2",
            "",
            "\1\4\1\uffff\1\3\1\5\13\uffff\1\5",
            "\1\6",
            "\1\7",
            "",
            "\1\4\1\uffff\1\10\1\11\13\uffff\1\11",
            "\1\11\1\5\13\uffff\1\5",
            "\1\12",
            "",
            "\1\4\1\uffff\1\10\1\11\13\uffff\1\11"
    };

    static final short[] DFA8_eot = DFA.unpackEncodedString(DFA8_eotS);
    static final short[] DFA8_eof = DFA.unpackEncodedString(DFA8_eofS);
    static final char[] DFA8_min = DFA.unpackEncodedStringToUnsignedChars(DFA8_minS);
    static final char[] DFA8_max = DFA.unpackEncodedStringToUnsignedChars(DFA8_maxS);
    static final short[] DFA8_accept = DFA.unpackEncodedString(DFA8_acceptS);
    static final short[] DFA8_special = DFA.unpackEncodedString(DFA8_specialS);
    static final short[][] DFA8_transition;

    static {
        int numStates = DFA8_transitionS.length;
        DFA8_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA8_transition[i] = DFA.unpackEncodedString(DFA8_transitionS[i]);
        }
    }

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = DFA8_eot;
            this.eof = DFA8_eof;
            this.min = DFA8_min;
            this.max = DFA8_max;
            this.accept = DFA8_accept;
            this.special = DFA8_special;
            this.transition = DFA8_transition;
        }
        public String getDescription() {
            return "68:1: nonArrayType : ( primType | typeRef | namedType );";
        }
    }
    static final String DFA11_eotS =
        "\10\uffff";
    static final String DFA11_eofS =
        "\10\uffff";
    static final String DFA11_minS =
        "\1\106\1\67\1\106\2\uffff\1\67\1\106\1\67";
    static final String DFA11_maxS =
        "\3\106\2\uffff\3\106";
    static final String DFA11_acceptS =
        "\3\uffff\1\1\1\2\3\uffff";
    static final String DFA11_specialS =
        "\10\uffff}>";
    static final String[] DFA11_transitionS = {
            "\1\1",
            "\1\3\1\uffff\1\2\1\4\13\uffff\1\4",
            "\1\5",
            "",
            "",
            "\1\3\1\uffff\1\6\1\4\13\uffff\1\4",
            "\1\7",
            "\1\3\1\uffff\1\6\1\4\13\uffff\1\4"
    };

    static final short[] DFA11_eot = DFA.unpackEncodedString(DFA11_eotS);
    static final short[] DFA11_eof = DFA.unpackEncodedString(DFA11_eofS);
    static final char[] DFA11_min = DFA.unpackEncodedStringToUnsignedChars(DFA11_minS);
    static final char[] DFA11_max = DFA.unpackEncodedStringToUnsignedChars(DFA11_maxS);
    static final short[] DFA11_accept = DFA.unpackEncodedString(DFA11_acceptS);
    static final short[] DFA11_special = DFA.unpackEncodedString(DFA11_specialS);
    static final short[][] DFA11_transition;

    static {
        int numStates = DFA11_transitionS.length;
        DFA11_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA11_transition[i] = DFA.unpackEncodedString(DFA11_transitionS[i]);
        }
    }

    class DFA11 extends DFA {

        public DFA11(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 11;
            this.eot = DFA11_eot;
            this.eof = DFA11_eof;
            this.min = DFA11_min;
            this.max = DFA11_max;
            this.accept = DFA11_accept;
            this.special = DFA11_special;
            this.transition = DFA11_transition;
        }
        public String getDescription() {
            return "91:7: ( packageName COLON )?";
        }
    }
 

    public static final BitSet FOLLOW_thisExpr_in_borrowed109 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_thisExpr_in_unique130 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_returnValue_in_unique134 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_nothing_in_unique138 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_THIS_in_thisExpr159 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_in_returnValue188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EOF_in_nothing217 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_annotations_in_fieldDecl240 = new BitSet(new long[]{0x001006E0A05104A0L,0x0000000000000040L});
    public static final BitSet FOLLOW_modifiers_in_fieldDecl242 = new BitSet(new long[]{0x001006E0A05104A0L,0x0000000000000040L});
    public static final BitSet FOLLOW_returnType_in_fieldDecl244 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_IDENTIFIER_in_fieldDecl246 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_annotation_in_annotations277 = new BitSet(new long[]{0x1000000000000002L});
    public static final BitSet FOLLOW_AT_in_annotation304 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_IDENTIFIER_in_annotation306 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_modifiers331 = new BitSet(new long[]{0x0000040000100002L});
    public static final BitSet FOLLOW_STATIC_in_modifiers344 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_FINAL_in_modifiers347 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VOID_in_returnType365 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_returnType369 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_arrayType_in_type386 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_nonArrayType_in_type390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_primType_in_nonArrayType407 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeRef_in_nonArrayType416 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_nonArrayType424 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_nonArrayType_in_arrayType441 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_LBRACKET_in_arrayType444 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_RBRACKET_in_arrayType446 = new BitSet(new long[]{0x0400000000000002L});
    public static final BitSet FOLLOW_set_in_primType0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_namedType_in_typeRef525 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_DOT_in_typeRef527 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_IDENTIFIER_in_typeRef529 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_typeRefExt_in_typeRef531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOT_in_typeRefExt562 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_IDENTIFIER_in_typeRefExt564 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_packageName_in_namedType585 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_COLON_in_namedType587 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_IDENTIFIER_in_namedType592 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_qualifiedName_in_packageName623 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName646 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_DOT_in_qualifiedName650 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_IDENTIFIER_in_qualifiedName652 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_simpleName671 = new BitSet(new long[]{0x0000000000000002L});

}
