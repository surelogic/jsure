// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/T.g 2008-09-25 15:48:42

package com.surelogic.parse;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class TParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "WS", "'call'", "';'"
    };
    public static final int T__7=7;
    public static final int EOF=-1;
    public static final int WS=5;
    public static final int T__6=6;
    public static final int ID=4;

    // delegates
    // delegators


        public TParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public TParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return TParser.tokenNames; }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/T.g"; }


    public static class r_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "r"
    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/T.g:12:1: r : 'call' ID ';' ;
    public final TParser.r_return r() throws RecognitionException {
        TParser.r_return retval = new TParser.r_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token string_literal1=null;
        Token ID2=null;
        Token char_literal3=null;

        Object string_literal1_tree=null;
        Object ID2_tree=null;
        Object char_literal3_tree=null;

        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/T.g:13:3: ( 'call' ID ';' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/T.g:13:5: 'call' ID ';'
            {
            root_0 = (Object)adaptor.nil();

            string_literal1=(Token)match(input,6,FOLLOW_6_in_r36); 
            string_literal1_tree = (Object)adaptor.create(string_literal1);
            root_0 = (Object)adaptor.becomeRoot(string_literal1_tree, root_0);

            ID2=(Token)match(input,ID,FOLLOW_ID_in_r39); 
            ID2_tree = (Object)adaptor.create(ID2);
            adaptor.addChild(root_0, ID2_tree);

            char_literal3=(Token)match(input,7,FOLLOW_7_in_r41); 
            char_literal3_tree = (Object)adaptor.create(char_literal3);
            adaptor.addChild(root_0, char_literal3_tree);

            System.out.println("invoke "+(ID2!=null?ID2.getText():null));

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "r"

    // Delegated rules


 

    public static final BitSet FOLLOW_6_in_r36 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_r39 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_7_in_r41 = new BitSet(new long[]{0x0000000000000002L});

}
