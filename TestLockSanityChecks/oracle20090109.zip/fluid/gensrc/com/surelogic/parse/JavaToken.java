// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g 2008-09-25 15:48:43

package com.surelogic.parse;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class JavaToken extends Lexer {
    public static final int COMMA=67;
    public static final int CONST=12;
    public static final int PUBLIC=39;
    public static final int LONG=31;
    public static final int SYNCHRONIZED=45;
    public static final int DOUBLE=16;
    public static final int TRANSIENT=49;
    public static final int FALSE=19;
    public static final int FLOAT=22;
    public static final int THROWS=48;
    public static final int ABSTRACT=4;
    public static final int LBRACKET=58;
    public static final int GOTO=24;
    public static final int DQUOTE=64;
    public static final int IMPORT=27;
    public static final int PACKAGE=36;
    public static final int LBRACE=65;
    public static final int CONTINUE=13;
    public static final int NEWLINE=72;
    public static final int DOT=57;
    public static final int RBRACE=66;
    public static final int PRIVATE=37;
    public static final int PROTECTED=38;
    public static final int INT=29;
    public static final int RBRACKET=59;
    public static final int VOID=52;
    public static final int INSTANCEOF=28;
    public static final int RPAREN=62;
    public static final int LPAREN=61;
    public static final int FINALLY=21;
    public static final int EXTENDS=18;
    public static final int AT=60;
    public static final int LETTER=68;
    public static final int SUPER=43;
    public static final int DO=15;
    public static final int IMPLEMENTS=26;
    public static final int WHILE=54;
    public static final int SWITCH=44;
    public static final int WS=71;
    public static final int CHAR=10;
    public static final int NEW=33;
    public static final int ONLY=35;
    public static final int FINAL=20;
    public static final int QUOTE=63;
    public static final int THIS=46;
    public static final int SEMI=56;
    public static final int CATCH=9;
    public static final int STATIC=42;
    public static final int JavaIDDigit=69;
    public static final int CASE=8;
    public static final int CLASS=11;
    public static final int INTERFACE=30;
    public static final int BOOLEAN=5;
    public static final int NATIVE=32;
    public static final int ELSE=17;
    public static final int RETURN=40;
    public static final int BYTE=7;
    public static final int VOLATILE=53;
    public static final int IF=25;
    public static final int EOF=-1;
    public static final int BREAK=6;
    public static final int NULL=34;
    public static final int FOR=23;
    public static final int COLON=55;
    public static final int DEFAULT=14;
    public static final int IDENTIFIER=70;
    public static final int TRY=51;
    public static final int TRUE=50;
    public static final int THROW=47;
    public static final int SHORT=41;

      /**
       * Makes it create TreeTokens, instead of CommonTokens
       */
      @Override 
      public Token emit() {
        Token t = new TreeToken(input, state.type, state.channel, state.tokenStartCharIndex, getCharIndex()-1);
        t.setLine(state.tokenStartLine);
        t.setText(state.text);
        t.setCharPositionInLine(state.tokenStartCharPositionInLine);
        emit(t);
        return t;
      }


    // delegates
    // delegators

    public JavaToken() {;} 
    public JavaToken(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public JavaToken(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g"; }

    // $ANTLR start "ABSTRACT"
    public final void mABSTRACT() throws RecognitionException {
        try {
            int _type = ABSTRACT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:24:10: ( 'abstract' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:24:12: 'abstract'
            {
            match("abstract"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ABSTRACT"

    // $ANTLR start "BOOLEAN"
    public final void mBOOLEAN() throws RecognitionException {
        try {
            int _type = BOOLEAN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:25:9: ( 'boolean' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:25:11: 'boolean'
            {
            match("boolean"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BOOLEAN"

    // $ANTLR start "BREAK"
    public final void mBREAK() throws RecognitionException {
        try {
            int _type = BREAK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:26:7: ( 'break' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:26:9: 'break'
            {
            match("break"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BREAK"

    // $ANTLR start "BYTE"
    public final void mBYTE() throws RecognitionException {
        try {
            int _type = BYTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:27:6: ( 'byte' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:27:8: 'byte'
            {
            match("byte"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BYTE"

    // $ANTLR start "CASE"
    public final void mCASE() throws RecognitionException {
        try {
            int _type = CASE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:28:6: ( 'case' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:28:8: 'case'
            {
            match("case"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CASE"

    // $ANTLR start "CATCH"
    public final void mCATCH() throws RecognitionException {
        try {
            int _type = CATCH;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:29:7: ( 'catch' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:29:9: 'catch'
            {
            match("catch"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CATCH"

    // $ANTLR start "CHAR"
    public final void mCHAR() throws RecognitionException {
        try {
            int _type = CHAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:30:6: ( 'char' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:30:8: 'char'
            {
            match("char"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CHAR"

    // $ANTLR start "CLASS"
    public final void mCLASS() throws RecognitionException {
        try {
            int _type = CLASS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:31:7: ( 'class' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:31:9: 'class'
            {
            match("class"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CLASS"

    // $ANTLR start "CONST"
    public final void mCONST() throws RecognitionException {
        try {
            int _type = CONST;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:32:7: ( 'const' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:32:9: 'const'
            {
            match("const"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CONST"

    // $ANTLR start "CONTINUE"
    public final void mCONTINUE() throws RecognitionException {
        try {
            int _type = CONTINUE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:33:10: ( 'continue' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:33:12: 'continue'
            {
            match("continue"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CONTINUE"

    // $ANTLR start "DEFAULT"
    public final void mDEFAULT() throws RecognitionException {
        try {
            int _type = DEFAULT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:34:9: ( 'default' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:34:11: 'default'
            {
            match("default"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DEFAULT"

    // $ANTLR start "DO"
    public final void mDO() throws RecognitionException {
        try {
            int _type = DO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:35:4: ( 'do' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:35:6: 'do'
            {
            match("do"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DO"

    // $ANTLR start "DOUBLE"
    public final void mDOUBLE() throws RecognitionException {
        try {
            int _type = DOUBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:36:8: ( 'double' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:36:10: 'double'
            {
            match("double"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOUBLE"

    // $ANTLR start "ELSE"
    public final void mELSE() throws RecognitionException {
        try {
            int _type = ELSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:37:6: ( 'else' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:37:8: 'else'
            {
            match("else"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ELSE"

    // $ANTLR start "EXTENDS"
    public final void mEXTENDS() throws RecognitionException {
        try {
            int _type = EXTENDS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:38:9: ( 'extends' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:38:11: 'extends'
            {
            match("extends"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EXTENDS"

    // $ANTLR start "FALSE"
    public final void mFALSE() throws RecognitionException {
        try {
            int _type = FALSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:39:7: ( 'false' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:39:9: 'false'
            {
            match("false"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FALSE"

    // $ANTLR start "FINAL"
    public final void mFINAL() throws RecognitionException {
        try {
            int _type = FINAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:40:7: ( 'final' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:40:9: 'final'
            {
            match("final"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FINAL"

    // $ANTLR start "FINALLY"
    public final void mFINALLY() throws RecognitionException {
        try {
            int _type = FINALLY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:41:9: ( 'finally' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:41:11: 'finally'
            {
            match("finally"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FINALLY"

    // $ANTLR start "FLOAT"
    public final void mFLOAT() throws RecognitionException {
        try {
            int _type = FLOAT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:42:7: ( 'float' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:42:9: 'float'
            {
            match("float"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FLOAT"

    // $ANTLR start "FOR"
    public final void mFOR() throws RecognitionException {
        try {
            int _type = FOR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:43:5: ( 'for' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:43:7: 'for'
            {
            match("for"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FOR"

    // $ANTLR start "GOTO"
    public final void mGOTO() throws RecognitionException {
        try {
            int _type = GOTO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:44:6: ( 'goto' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:44:8: 'goto'
            {
            match("goto"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "GOTO"

    // $ANTLR start "IF"
    public final void mIF() throws RecognitionException {
        try {
            int _type = IF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:45:4: ( 'if' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:45:6: 'if'
            {
            match("if"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IF"

    // $ANTLR start "IMPLEMENTS"
    public final void mIMPLEMENTS() throws RecognitionException {
        try {
            int _type = IMPLEMENTS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:46:12: ( 'implements' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:46:14: 'implements'
            {
            match("implements"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IMPLEMENTS"

    // $ANTLR start "IMPORT"
    public final void mIMPORT() throws RecognitionException {
        try {
            int _type = IMPORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:47:8: ( 'import' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:47:10: 'import'
            {
            match("import"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IMPORT"

    // $ANTLR start "INSTANCEOF"
    public final void mINSTANCEOF() throws RecognitionException {
        try {
            int _type = INSTANCEOF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:48:12: ( 'instanceof' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:48:14: 'instanceof'
            {
            match("instanceof"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INSTANCEOF"

    // $ANTLR start "INT"
    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:49:5: ( 'int' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:49:7: 'int'
            {
            match("int"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT"

    // $ANTLR start "INTERFACE"
    public final void mINTERFACE() throws RecognitionException {
        try {
            int _type = INTERFACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:50:11: ( 'interface' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:50:13: 'interface'
            {
            match("interface"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INTERFACE"

    // $ANTLR start "LONG"
    public final void mLONG() throws RecognitionException {
        try {
            int _type = LONG;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:51:6: ( 'long' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:51:8: 'long'
            {
            match("long"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LONG"

    // $ANTLR start "NATIVE"
    public final void mNATIVE() throws RecognitionException {
        try {
            int _type = NATIVE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:52:8: ( 'native' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:52:10: 'native'
            {
            match("native"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NATIVE"

    // $ANTLR start "NEW"
    public final void mNEW() throws RecognitionException {
        try {
            int _type = NEW;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:53:5: ( 'new' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:53:7: 'new'
            {
            match("new"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEW"

    // $ANTLR start "NULL"
    public final void mNULL() throws RecognitionException {
        try {
            int _type = NULL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:54:6: ( 'null' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:54:8: 'null'
            {
            match("null"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NULL"

    // $ANTLR start "ONLY"
    public final void mONLY() throws RecognitionException {
        try {
            int _type = ONLY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:55:6: ( 'only' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:55:8: 'only'
            {
            match("only"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ONLY"

    // $ANTLR start "PACKAGE"
    public final void mPACKAGE() throws RecognitionException {
        try {
            int _type = PACKAGE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:56:9: ( 'package' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:56:11: 'package'
            {
            match("package"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PACKAGE"

    // $ANTLR start "PRIVATE"
    public final void mPRIVATE() throws RecognitionException {
        try {
            int _type = PRIVATE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:57:9: ( 'private' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:57:11: 'private'
            {
            match("private"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PRIVATE"

    // $ANTLR start "PROTECTED"
    public final void mPROTECTED() throws RecognitionException {
        try {
            int _type = PROTECTED;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:58:11: ( 'protected' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:58:13: 'protected'
            {
            match("protected"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PROTECTED"

    // $ANTLR start "PUBLIC"
    public final void mPUBLIC() throws RecognitionException {
        try {
            int _type = PUBLIC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:59:8: ( 'public' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:59:10: 'public'
            {
            match("public"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PUBLIC"

    // $ANTLR start "RETURN"
    public final void mRETURN() throws RecognitionException {
        try {
            int _type = RETURN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:60:8: ( 'return' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:60:10: 'return'
            {
            match("return"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RETURN"

    // $ANTLR start "SHORT"
    public final void mSHORT() throws RecognitionException {
        try {
            int _type = SHORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:61:7: ( 'short' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:61:9: 'short'
            {
            match("short"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SHORT"

    // $ANTLR start "STATIC"
    public final void mSTATIC() throws RecognitionException {
        try {
            int _type = STATIC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:62:8: ( 'static' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:62:10: 'static'
            {
            match("static"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STATIC"

    // $ANTLR start "SUPER"
    public final void mSUPER() throws RecognitionException {
        try {
            int _type = SUPER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:63:7: ( 'super' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:63:9: 'super'
            {
            match("super"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SUPER"

    // $ANTLR start "SWITCH"
    public final void mSWITCH() throws RecognitionException {
        try {
            int _type = SWITCH;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:64:8: ( 'switch' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:64:10: 'switch'
            {
            match("switch"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SWITCH"

    // $ANTLR start "SYNCHRONIZED"
    public final void mSYNCHRONIZED() throws RecognitionException {
        try {
            int _type = SYNCHRONIZED;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:65:14: ( 'synchronized' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:65:16: 'synchronized'
            {
            match("synchronized"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SYNCHRONIZED"

    // $ANTLR start "THIS"
    public final void mTHIS() throws RecognitionException {
        try {
            int _type = THIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:66:6: ( 'this' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:66:8: 'this'
            {
            match("this"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THIS"

    // $ANTLR start "THROW"
    public final void mTHROW() throws RecognitionException {
        try {
            int _type = THROW;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:67:7: ( 'throw' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:67:9: 'throw'
            {
            match("throw"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THROW"

    // $ANTLR start "THROWS"
    public final void mTHROWS() throws RecognitionException {
        try {
            int _type = THROWS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:68:8: ( 'throws' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:68:10: 'throws'
            {
            match("throws"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THROWS"

    // $ANTLR start "TRANSIENT"
    public final void mTRANSIENT() throws RecognitionException {
        try {
            int _type = TRANSIENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:69:11: ( 'transient' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:69:13: 'transient'
            {
            match("transient"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TRANSIENT"

    // $ANTLR start "TRUE"
    public final void mTRUE() throws RecognitionException {
        try {
            int _type = TRUE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:70:6: ( 'true' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:70:8: 'true'
            {
            match("true"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TRUE"

    // $ANTLR start "TRY"
    public final void mTRY() throws RecognitionException {
        try {
            int _type = TRY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:71:5: ( 'try' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:71:7: 'try'
            {
            match("try"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "TRY"

    // $ANTLR start "VOID"
    public final void mVOID() throws RecognitionException {
        try {
            int _type = VOID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:72:6: ( 'void' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:72:8: 'void'
            {
            match("void"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "VOID"

    // $ANTLR start "VOLATILE"
    public final void mVOLATILE() throws RecognitionException {
        try {
            int _type = VOLATILE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:73:10: ( 'volatile' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:73:12: 'volatile'
            {
            match("volatile"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "VOLATILE"

    // $ANTLR start "WHILE"
    public final void mWHILE() throws RecognitionException {
        try {
            int _type = WHILE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:74:7: ( 'while' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:74:9: 'while'
            {
            match("while"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WHILE"

    // $ANTLR start "COLON"
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:76:7: ( ':' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:76:9: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLON"

    // $ANTLR start "SEMI"
    public final void mSEMI() throws RecognitionException {
        try {
            int _type = SEMI;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:77:7: ( ';' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:77:9: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SEMI"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:78:7: ( '.' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:78:9: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "LBRACKET"
    public final void mLBRACKET() throws RecognitionException {
        try {
            int _type = LBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:79:10: ( '[' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:79:12: '['
            {
            match('['); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACKET"

    // $ANTLR start "RBRACKET"
    public final void mRBRACKET() throws RecognitionException {
        try {
            int _type = RBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:80:10: ( ']' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:80:12: ']'
            {
            match(']'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACKET"

    // $ANTLR start "AT"
    public final void mAT() throws RecognitionException {
        try {
            int _type = AT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:81:4: ( '@' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:81:6: '@'
            {
            match('@'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "AT"

    // $ANTLR start "LPAREN"
    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:82:8: ( '(' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:82:10: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LPAREN"

    // $ANTLR start "RPAREN"
    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:83:8: ( ')' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:83:10: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RPAREN"

    // $ANTLR start "QUOTE"
    public final void mQUOTE() throws RecognitionException {
        try {
            int _type = QUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:84:7: ( '\\'' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:84:9: '\\''
            {
            match('\''); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "QUOTE"

    // $ANTLR start "DQUOTE"
    public final void mDQUOTE() throws RecognitionException {
        try {
            int _type = DQUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:85:8: ( '\"' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:85:10: '\"'
            {
            match('\"'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DQUOTE"

    // $ANTLR start "LBRACE"
    public final void mLBRACE() throws RecognitionException {
        try {
            int _type = LBRACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:86:8: ( '{' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:86:10: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACE"

    // $ANTLR start "RBRACE"
    public final void mRBRACE() throws RecognitionException {
        try {
            int _type = RBRACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:87:8: ( '}' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:87:10: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACE"

    // $ANTLR start "COMMA"
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:88:7: ( ',' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:88:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMA"

    // $ANTLR start "IDENTIFIER"
    public final void mIDENTIFIER() throws RecognitionException {
        try {
            int _type = IDENTIFIER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:91:5: ( LETTER ( LETTER | JavaIDDigit )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:91:7: LETTER ( LETTER | JavaIDDigit )*
            {
            mLETTER(); 
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:91:14: ( LETTER | JavaIDDigit )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0=='$'||(LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='Z')||LA1_0=='_'||(LA1_0>='a' && LA1_0<='z')||(LA1_0>='\u00C0' && LA1_0<='\u00D6')||(LA1_0>='\u00D8' && LA1_0<='\u00F6')||(LA1_0>='\u00F8' && LA1_0<='\u1FFF')||(LA1_0>='\u3040' && LA1_0<='\u318F')||(LA1_0>='\u3300' && LA1_0<='\u337F')||(LA1_0>='\u3400' && LA1_0<='\u3D2D')||(LA1_0>='\u4E00' && LA1_0<='\u9FFF')||(LA1_0>='\uF900' && LA1_0<='\uFAFF')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IDENTIFIER"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:99:5: ( '\\u0024' | '\\u0041' .. '\\u005a' | '\\u005f' | '\\u0061' .. '\\u007a' | '\\u00c0' .. '\\u00d6' | '\\u00d8' .. '\\u00f6' | '\\u00f8' .. '\\u00ff' | '\\u0100' .. '\\u1fff' | '\\u3040' .. '\\u318f' | '\\u3300' .. '\\u337f' | '\\u3400' .. '\\u3d2d' | '\\u4e00' .. '\\u9fff' | '\\uf900' .. '\\ufaff' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:
            {
            if ( input.LA(1)=='$'||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "JavaIDDigit"
    public final void mJavaIDDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:116:5: ( '\\u0030' .. '\\u0039' | '\\u0660' .. '\\u0669' | '\\u06f0' .. '\\u06f9' | '\\u0966' .. '\\u096f' | '\\u09e6' .. '\\u09ef' | '\\u0a66' .. '\\u0a6f' | '\\u0ae6' .. '\\u0aef' | '\\u0b66' .. '\\u0b6f' | '\\u0be7' .. '\\u0bef' | '\\u0c66' .. '\\u0c6f' | '\\u0ce6' .. '\\u0cef' | '\\u0d66' .. '\\u0d6f' | '\\u0e50' .. '\\u0e59' | '\\u0ed0' .. '\\u0ed9' | '\\u1040' .. '\\u1049' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='\u0660' && input.LA(1)<='\u0669')||(input.LA(1)>='\u06F0' && input.LA(1)<='\u06F9')||(input.LA(1)>='\u0966' && input.LA(1)<='\u096F')||(input.LA(1)>='\u09E6' && input.LA(1)<='\u09EF')||(input.LA(1)>='\u0A66' && input.LA(1)<='\u0A6F')||(input.LA(1)>='\u0AE6' && input.LA(1)<='\u0AEF')||(input.LA(1)>='\u0B66' && input.LA(1)<='\u0B6F')||(input.LA(1)>='\u0BE7' && input.LA(1)<='\u0BEF')||(input.LA(1)>='\u0C66' && input.LA(1)<='\u0C6F')||(input.LA(1)>='\u0CE6' && input.LA(1)<='\u0CEF')||(input.LA(1)>='\u0D66' && input.LA(1)<='\u0D6F')||(input.LA(1)>='\u0E50' && input.LA(1)<='\u0E59')||(input.LA(1)>='\u0ED0' && input.LA(1)<='\u0ED9')||(input.LA(1)>='\u1040' && input.LA(1)<='\u1049') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "JavaIDDigit"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:133:5: ( ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:133:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            skip();

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "NEWLINE"
    public final void mNEWLINE() throws RecognitionException {
        try {
            int _type = NEWLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:136:9: ( ( '\\r' )? '\\n' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:136:13: ( '\\r' )? '\\n'
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:136:13: ( '\\r' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='\r') ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:136:13: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEWLINE"

    public void mTokens() throws RecognitionException {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:8: ( ABSTRACT | BOOLEAN | BREAK | BYTE | CASE | CATCH | CHAR | CLASS | CONST | CONTINUE | DEFAULT | DO | DOUBLE | ELSE | EXTENDS | FALSE | FINAL | FINALLY | FLOAT | FOR | GOTO | IF | IMPLEMENTS | IMPORT | INSTANCEOF | INT | INTERFACE | LONG | NATIVE | NEW | NULL | ONLY | PACKAGE | PRIVATE | PROTECTED | PUBLIC | RETURN | SHORT | STATIC | SUPER | SWITCH | SYNCHRONIZED | THIS | THROW | THROWS | TRANSIENT | TRUE | TRY | VOID | VOLATILE | WHILE | COLON | SEMI | DOT | LBRACKET | RBRACKET | AT | LPAREN | RPAREN | QUOTE | DQUOTE | LBRACE | RBRACE | COMMA | IDENTIFIER | WS | NEWLINE )
        int alt3=67;
        alt3 = dfa3.predict(input);
        switch (alt3) {
            case 1 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:10: ABSTRACT
                {
                mABSTRACT(); 

                }
                break;
            case 2 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:19: BOOLEAN
                {
                mBOOLEAN(); 

                }
                break;
            case 3 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:27: BREAK
                {
                mBREAK(); 

                }
                break;
            case 4 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:33: BYTE
                {
                mBYTE(); 

                }
                break;
            case 5 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:38: CASE
                {
                mCASE(); 

                }
                break;
            case 6 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:43: CATCH
                {
                mCATCH(); 

                }
                break;
            case 7 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:49: CHAR
                {
                mCHAR(); 

                }
                break;
            case 8 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:54: CLASS
                {
                mCLASS(); 

                }
                break;
            case 9 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:60: CONST
                {
                mCONST(); 

                }
                break;
            case 10 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:66: CONTINUE
                {
                mCONTINUE(); 

                }
                break;
            case 11 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:75: DEFAULT
                {
                mDEFAULT(); 

                }
                break;
            case 12 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:83: DO
                {
                mDO(); 

                }
                break;
            case 13 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:86: DOUBLE
                {
                mDOUBLE(); 

                }
                break;
            case 14 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:93: ELSE
                {
                mELSE(); 

                }
                break;
            case 15 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:98: EXTENDS
                {
                mEXTENDS(); 

                }
                break;
            case 16 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:106: FALSE
                {
                mFALSE(); 

                }
                break;
            case 17 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:112: FINAL
                {
                mFINAL(); 

                }
                break;
            case 18 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:118: FINALLY
                {
                mFINALLY(); 

                }
                break;
            case 19 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:126: FLOAT
                {
                mFLOAT(); 

                }
                break;
            case 20 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:132: FOR
                {
                mFOR(); 

                }
                break;
            case 21 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:136: GOTO
                {
                mGOTO(); 

                }
                break;
            case 22 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:141: IF
                {
                mIF(); 

                }
                break;
            case 23 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:144: IMPLEMENTS
                {
                mIMPLEMENTS(); 

                }
                break;
            case 24 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:155: IMPORT
                {
                mIMPORT(); 

                }
                break;
            case 25 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:162: INSTANCEOF
                {
                mINSTANCEOF(); 

                }
                break;
            case 26 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:173: INT
                {
                mINT(); 

                }
                break;
            case 27 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:177: INTERFACE
                {
                mINTERFACE(); 

                }
                break;
            case 28 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:187: LONG
                {
                mLONG(); 

                }
                break;
            case 29 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:192: NATIVE
                {
                mNATIVE(); 

                }
                break;
            case 30 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:199: NEW
                {
                mNEW(); 

                }
                break;
            case 31 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:203: NULL
                {
                mNULL(); 

                }
                break;
            case 32 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:208: ONLY
                {
                mONLY(); 

                }
                break;
            case 33 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:213: PACKAGE
                {
                mPACKAGE(); 

                }
                break;
            case 34 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:221: PRIVATE
                {
                mPRIVATE(); 

                }
                break;
            case 35 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:229: PROTECTED
                {
                mPROTECTED(); 

                }
                break;
            case 36 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:239: PUBLIC
                {
                mPUBLIC(); 

                }
                break;
            case 37 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:246: RETURN
                {
                mRETURN(); 

                }
                break;
            case 38 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:253: SHORT
                {
                mSHORT(); 

                }
                break;
            case 39 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:259: STATIC
                {
                mSTATIC(); 

                }
                break;
            case 40 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:266: SUPER
                {
                mSUPER(); 

                }
                break;
            case 41 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:272: SWITCH
                {
                mSWITCH(); 

                }
                break;
            case 42 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:279: SYNCHRONIZED
                {
                mSYNCHRONIZED(); 

                }
                break;
            case 43 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:292: THIS
                {
                mTHIS(); 

                }
                break;
            case 44 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:297: THROW
                {
                mTHROW(); 

                }
                break;
            case 45 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:303: THROWS
                {
                mTHROWS(); 

                }
                break;
            case 46 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:310: TRANSIENT
                {
                mTRANSIENT(); 

                }
                break;
            case 47 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:320: TRUE
                {
                mTRUE(); 

                }
                break;
            case 48 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:325: TRY
                {
                mTRY(); 

                }
                break;
            case 49 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:329: VOID
                {
                mVOID(); 

                }
                break;
            case 50 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:334: VOLATILE
                {
                mVOLATILE(); 

                }
                break;
            case 51 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:343: WHILE
                {
                mWHILE(); 

                }
                break;
            case 52 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:349: COLON
                {
                mCOLON(); 

                }
                break;
            case 53 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:355: SEMI
                {
                mSEMI(); 

                }
                break;
            case 54 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:360: DOT
                {
                mDOT(); 

                }
                break;
            case 55 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:364: LBRACKET
                {
                mLBRACKET(); 

                }
                break;
            case 56 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:373: RBRACKET
                {
                mRBRACKET(); 

                }
                break;
            case 57 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:382: AT
                {
                mAT(); 

                }
                break;
            case 58 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:385: LPAREN
                {
                mLPAREN(); 

                }
                break;
            case 59 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:392: RPAREN
                {
                mRPAREN(); 

                }
                break;
            case 60 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:399: QUOTE
                {
                mQUOTE(); 

                }
                break;
            case 61 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:405: DQUOTE
                {
                mDQUOTE(); 

                }
                break;
            case 62 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:412: LBRACE
                {
                mLBRACE(); 

                }
                break;
            case 63 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:419: RBRACE
                {
                mRBRACE(); 

                }
                break;
            case 64 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:426: COMMA
                {
                mCOMMA(); 

                }
                break;
            case 65 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:432: IDENTIFIER
                {
                mIDENTIFIER(); 

                }
                break;
            case 66 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:443: WS
                {
                mWS(); 

                }
                break;
            case 67 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/parse/JavaToken.g:1:446: NEWLINE
                {
                mNEWLINE(); 

                }
                break;

        }

    }


    protected DFA3 dfa3 = new DFA3(this);
    static final String DFA3_eotS =
        "\1\uffff\21\37\16\uffff\1\42\2\uffff\11\37\1\125\7\37\1\135\24\37"+
        "\1\uffff\13\37\1\uffff\5\37\1\u0089\1\37\1\uffff\2\37\1\u008f\2"+
        "\37\1\u0092\20\37\1\u00a3\6\37\1\u00aa\1\u00ab\1\37\1\u00ad\5\37"+
        "\1\u00b3\4\37\1\uffff\1\u00b8\4\37\1\uffff\1\u00bd\1\37\1\uffff"+
        "\1\u00bf\1\u00c0\12\37\1\u00cb\2\37\1\u00ce\1\uffff\1\u00cf\4\37"+
        "\1\u00d4\2\uffff\1\u00d5\1\uffff\1\u00d6\1\u00d7\3\37\1\uffff\1"+
        "\37\1\u00dc\1\u00de\1\u00df\1\uffff\4\37\1\uffff\1\37\2\uffff\5"+
        "\37\1\u00ea\1\37\1\u00ec\2\37\1\uffff\1\u00f0\1\37\2\uffff\1\37"+
        "\1\u00f3\2\37\4\uffff\2\37\1\u00f8\1\37\1\uffff\1\37\2\uffff\1\37"+
        "\1\u00fc\2\37\1\u00ff\3\37\1\u0103\1\u0104\1\uffff\1\u0105\1\uffff"+
        "\1\u0106\1\37\1\u0108\1\uffff\2\37\1\uffff\1\37\1\u010c\1\37\1\u010e"+
        "\1\uffff\1\u010f\1\u0110\1\37\1\uffff\2\37\1\uffff\1\u0114\1\u0115"+
        "\1\37\4\uffff\1\37\1\uffff\2\37\1\u011a\1\uffff\1\u011b\3\uffff"+
        "\3\37\2\uffff\3\37\1\u0122\2\uffff\2\37\1\u0125\1\u0126\1\37\1\u0128"+
        "\1\uffff\1\u0129\1\u012a\2\uffff\1\37\3\uffff\1\37\1\u012d\1\uffff";
    static final String DFA3_eofS =
        "\u012e\uffff";
    static final String DFA3_minS =
        "\1\11\1\142\1\157\1\141\1\145\1\154\1\141\1\157\1\146\1\157\1\141"+
        "\1\156\1\141\1\145\2\150\1\157\1\150\16\uffff\1\12\2\uffff\1\163"+
        "\1\157\1\145\1\164\1\163\2\141\1\156\1\146\1\44\1\163\1\164\1\154"+
        "\1\156\1\157\1\162\1\164\1\44\1\160\1\163\1\156\1\164\1\167\2\154"+
        "\1\143\1\151\1\142\1\164\1\157\1\141\1\160\1\151\1\156\1\151\1\141"+
        "\2\151\1\uffff\1\164\1\154\1\141\2\145\1\143\1\162\2\163\1\141\1"+
        "\142\1\uffff\2\145\1\163\2\141\1\44\1\157\1\uffff\1\154\1\164\1"+
        "\44\1\147\1\151\1\44\1\154\1\171\1\153\1\166\1\164\1\154\1\165\1"+
        "\162\1\164\1\145\1\164\1\143\1\163\1\157\1\156\1\145\1\44\1\144"+
        "\1\141\1\154\1\162\1\145\1\153\2\44\1\150\1\44\1\163\1\164\1\151"+
        "\1\165\1\154\1\44\1\156\1\145\1\154\1\164\1\uffff\1\44\1\145\1\162"+
        "\1\141\1\162\1\uffff\1\44\1\166\1\uffff\2\44\2\141\1\145\1\151\1"+
        "\162\1\164\1\151\1\162\1\143\1\150\1\44\1\167\1\163\1\44\1\uffff"+
        "\1\44\1\164\1\145\2\141\1\44\2\uffff\1\44\1\uffff\2\44\1\156\1\154"+
        "\1\145\1\uffff\1\144\3\44\1\uffff\1\155\1\164\1\156\1\146\1\uffff"+
        "\1\145\2\uffff\1\147\1\164\2\143\1\156\1\44\1\143\1\44\1\150\1\162"+
        "\1\uffff\1\44\1\151\2\uffff\1\151\1\44\1\143\1\156\4\uffff\1\165"+
        "\1\164\1\44\1\163\1\uffff\1\171\2\uffff\1\145\1\44\1\143\1\141\1"+
        "\44\2\145\1\164\2\44\1\uffff\1\44\1\uffff\1\44\1\157\1\44\1\uffff"+
        "\1\145\1\154\1\uffff\1\164\1\44\1\145\1\44\1\uffff\2\44\1\156\1"+
        "\uffff\1\145\1\143\1\uffff\2\44\1\145\4\uffff\1\156\1\uffff\1\156"+
        "\1\145\1\44\1\uffff\1\44\3\uffff\1\164\1\157\1\145\2\uffff\1\144"+
        "\1\151\1\164\1\44\2\uffff\1\163\1\146\2\44\1\172\1\44\1\uffff\2"+
        "\44\2\uffff\1\145\3\uffff\1\144\1\44\1\uffff";
    static final String DFA3_maxS =
        "\1\ufaff\1\142\1\171\2\157\1\170\2\157\1\156\1\157\1\165\1\156\1"+
        "\165\1\145\1\171\1\162\1\157\1\150\16\uffff\1\12\2\uffff\1\163\1"+
        "\157\1\145\2\164\2\141\1\156\1\146\1\ufaff\1\163\1\164\1\154\1\156"+
        "\1\157\1\162\1\164\1\ufaff\1\160\1\164\1\156\1\164\1\167\2\154\1"+
        "\143\1\157\1\142\1\164\1\157\1\141\1\160\1\151\1\156\1\162\1\171"+
        "\1\154\1\151\1\uffff\1\164\1\154\1\141\2\145\1\143\1\162\1\163\1"+
        "\164\1\141\1\142\1\uffff\2\145\1\163\2\141\1\ufaff\1\157\1\uffff"+
        "\1\157\1\164\1\ufaff\1\147\1\151\1\ufaff\1\154\1\171\1\153\1\166"+
        "\1\164\1\154\1\165\1\162\1\164\1\145\1\164\1\143\1\163\1\157\1\156"+
        "\1\145\1\ufaff\1\144\1\141\1\154\1\162\1\145\1\153\2\ufaff\1\150"+
        "\1\ufaff\1\163\1\164\1\151\1\165\1\154\1\ufaff\1\156\1\145\1\154"+
        "\1\164\1\uffff\1\ufaff\1\145\1\162\1\141\1\162\1\uffff\1\ufaff\1"+
        "\166\1\uffff\2\ufaff\2\141\1\145\1\151\1\162\1\164\1\151\1\162\1"+
        "\143\1\150\1\ufaff\1\167\1\163\1\ufaff\1\uffff\1\ufaff\1\164\1\145"+
        "\2\141\1\ufaff\2\uffff\1\ufaff\1\uffff\2\ufaff\1\156\1\154\1\145"+
        "\1\uffff\1\144\3\ufaff\1\uffff\1\155\1\164\1\156\1\146\1\uffff\1"+
        "\145\2\uffff\1\147\1\164\2\143\1\156\1\ufaff\1\143\1\ufaff\1\150"+
        "\1\162\1\uffff\1\ufaff\1\151\2\uffff\1\151\1\ufaff\1\143\1\156\4"+
        "\uffff\1\165\1\164\1\ufaff\1\163\1\uffff\1\171\2\uffff\1\145\1\ufaff"+
        "\1\143\1\141\1\ufaff\2\145\1\164\2\ufaff\1\uffff\1\ufaff\1\uffff"+
        "\1\ufaff\1\157\1\ufaff\1\uffff\1\145\1\154\1\uffff\1\164\1\ufaff"+
        "\1\145\1\ufaff\1\uffff\2\ufaff\1\156\1\uffff\1\145\1\143\1\uffff"+
        "\2\ufaff\1\145\4\uffff\1\156\1\uffff\1\156\1\145\1\ufaff\1\uffff"+
        "\1\ufaff\3\uffff\1\164\1\157\1\145\2\uffff\1\144\1\151\1\164\1\ufaff"+
        "\2\uffff\1\163\1\146\2\ufaff\1\172\1\ufaff\1\uffff\2\ufaff\2\uffff"+
        "\1\145\3\uffff\1\144\1\ufaff\1\uffff";
    static final String DFA3_acceptS =
        "\22\uffff\1\64\1\65\1\66\1\67\1\70\1\71\1\72\1\73\1\74\1\75\1\76"+
        "\1\77\1\100\1\101\1\uffff\2\102\46\uffff\1\103\13\uffff\1\14\7\uffff"+
        "\1\26\53\uffff\1\24\5\uffff\1\32\2\uffff\1\36\20\uffff\1\60\6\uffff"+
        "\1\4\1\5\1\uffff\1\7\5\uffff\1\16\4\uffff\1\25\4\uffff\1\34\1\uffff"+
        "\1\37\1\40\12\uffff\1\53\2\uffff\1\57\1\61\4\uffff\1\3\1\6\1\10"+
        "\1\11\4\uffff\1\20\1\uffff\1\21\1\23\12\uffff\1\46\1\uffff\1\50"+
        "\3\uffff\1\54\2\uffff\1\63\4\uffff\1\15\3\uffff\1\30\2\uffff\1\35"+
        "\3\uffff\1\44\1\45\1\47\1\51\1\uffff\1\55\3\uffff\1\2\1\uffff\1"+
        "\13\1\17\1\22\3\uffff\1\41\1\42\4\uffff\1\1\1\12\6\uffff\1\62\2"+
        "\uffff\1\33\1\43\1\uffff\1\56\1\27\1\31\2\uffff\1\52";
    static final String DFA3_specialS =
        "\u012e\uffff}>";
    static final String[] DFA3_transitionS = {
            "\1\42\1\41\1\uffff\1\42\1\40\22\uffff\1\42\1\uffff\1\33\1\uffff"+
            "\1\37\2\uffff\1\32\1\30\1\31\2\uffff\1\36\1\uffff\1\24\13\uffff"+
            "\1\22\1\23\4\uffff\1\27\32\37\1\25\1\uffff\1\26\1\uffff\1\37"+
            "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\37\1\10\2\37\1\11\1\37"+
            "\1\12\1\13\1\14\1\37\1\15\1\16\1\17\1\37\1\20\1\21\3\37\1\34"+
            "\1\uffff\1\35\102\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37"+
            "\u1040\uffff\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e"+
            "\37\u10d2\uffff\u5200\37\u5900\uffff\u0200\37",
            "\1\43",
            "\1\44\2\uffff\1\45\6\uffff\1\46",
            "\1\47\6\uffff\1\50\3\uffff\1\51\2\uffff\1\52",
            "\1\53\11\uffff\1\54",
            "\1\55\13\uffff\1\56",
            "\1\57\7\uffff\1\60\2\uffff\1\61\2\uffff\1\62",
            "\1\63",
            "\1\64\6\uffff\1\65\1\66",
            "\1\67",
            "\1\70\3\uffff\1\71\17\uffff\1\72",
            "\1\73",
            "\1\74\20\uffff\1\75\2\uffff\1\76",
            "\1\77",
            "\1\100\13\uffff\1\101\1\102\1\uffff\1\103\1\uffff\1\104",
            "\1\105\11\uffff\1\106",
            "\1\107",
            "\1\110",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\111",
            "",
            "",
            "\1\112",
            "\1\113",
            "\1\114",
            "\1\115",
            "\1\116\1\117",
            "\1\120",
            "\1\121",
            "\1\122",
            "\1\123",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\24"+
            "\37\1\124\5\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37"+
            "\u1040\uffff\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e"+
            "\37\u10d2\uffff\u5200\37\u5900\uffff\u0200\37",
            "\1\126",
            "\1\127",
            "\1\130",
            "\1\131",
            "\1\132",
            "\1\133",
            "\1\134",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\136",
            "\1\137\1\140",
            "\1\141",
            "\1\142",
            "\1\143",
            "\1\144",
            "\1\145",
            "\1\146",
            "\1\147\5\uffff\1\150",
            "\1\151",
            "\1\152",
            "\1\153",
            "\1\154",
            "\1\155",
            "\1\156",
            "\1\157",
            "\1\160\10\uffff\1\161",
            "\1\162\23\uffff\1\163\3\uffff\1\164",
            "\1\165\2\uffff\1\166",
            "\1\167",
            "",
            "\1\170",
            "\1\171",
            "\1\172",
            "\1\173",
            "\1\174",
            "\1\175",
            "\1\176",
            "\1\177",
            "\1\u0080\1\u0081",
            "\1\u0082",
            "\1\u0083",
            "",
            "\1\u0084",
            "\1\u0085",
            "\1\u0086",
            "\1\u0087",
            "\1\u0088",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u008a",
            "",
            "\1\u008b\2\uffff\1\u008c",
            "\1\u008d",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\4\37"+
            "\1\u008e\25\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37"+
            "\u1040\uffff\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e"+
            "\37\u10d2\uffff\u5200\37\u5900\uffff\u0200\37",
            "\1\u0090",
            "\1\u0091",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u0093",
            "\1\u0094",
            "\1\u0095",
            "\1\u0096",
            "\1\u0097",
            "\1\u0098",
            "\1\u0099",
            "\1\u009a",
            "\1\u009b",
            "\1\u009c",
            "\1\u009d",
            "\1\u009e",
            "\1\u009f",
            "\1\u00a0",
            "\1\u00a1",
            "\1\u00a2",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00a4",
            "\1\u00a5",
            "\1\u00a6",
            "\1\u00a7",
            "\1\u00a8",
            "\1\u00a9",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00ac",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00ae",
            "\1\u00af",
            "\1\u00b0",
            "\1\u00b1",
            "\1\u00b2",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00b4",
            "\1\u00b5",
            "\1\u00b6",
            "\1\u00b7",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00b9",
            "\1\u00ba",
            "\1\u00bb",
            "\1\u00bc",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00be",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00c1",
            "\1\u00c2",
            "\1\u00c3",
            "\1\u00c4",
            "\1\u00c5",
            "\1\u00c6",
            "\1\u00c7",
            "\1\u00c8",
            "\1\u00c9",
            "\1\u00ca",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00cc",
            "\1\u00cd",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00d0",
            "\1\u00d1",
            "\1\u00d2",
            "\1\u00d3",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00d8",
            "\1\u00d9",
            "\1\u00da",
            "",
            "\1\u00db",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\13"+
            "\37\1\u00dd\16\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08"+
            "\37\u1040\uffff\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e"+
            "\37\u10d2\uffff\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\u00e0",
            "\1\u00e1",
            "\1\u00e2",
            "\1\u00e3",
            "",
            "\1\u00e4",
            "",
            "",
            "\1\u00e5",
            "\1\u00e6",
            "\1\u00e7",
            "\1\u00e8",
            "\1\u00e9",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00eb",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00ed",
            "\1\u00ee",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\22"+
            "\37\1\u00ef\7\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08"+
            "\37\u1040\uffff\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e"+
            "\37\u10d2\uffff\u5200\37\u5900\uffff\u0200\37",
            "\1\u00f1",
            "",
            "",
            "\1\u00f2",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00f4",
            "\1\u00f5",
            "",
            "",
            "",
            "",
            "\1\u00f6",
            "\1\u00f7",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00f9",
            "",
            "\1\u00fa",
            "",
            "",
            "\1\u00fb",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u00fd",
            "\1\u00fe",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u0100",
            "\1\u0101",
            "\1\u0102",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u0107",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\u0109",
            "\1\u010a",
            "",
            "\1\u010b",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u010d",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u0111",
            "",
            "\1\u0112",
            "\1\u0113",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u0116",
            "",
            "",
            "",
            "",
            "\1\u0117",
            "",
            "\1\u0118",
            "\1\u0119",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "",
            "",
            "\1\u011c",
            "\1\u011d",
            "\1\u011e",
            "",
            "",
            "\1\u011f",
            "\1\u0120",
            "\1\u0121",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "",
            "\1\u0123",
            "\1\u0124",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\u0127",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            "",
            "",
            "\1\u012b",
            "",
            "",
            "",
            "\1\u012c",
            "\1\37\13\uffff\12\37\7\uffff\32\37\4\uffff\1\37\1\uffff\32"+
            "\37\105\uffff\27\37\1\uffff\37\37\1\uffff\u1f08\37\u1040\uffff"+
            "\u0150\37\u0170\uffff\u0080\37\u0080\uffff\u092e\37\u10d2\uffff"+
            "\u5200\37\u5900\uffff\u0200\37",
            ""
    };

    static final short[] DFA3_eot = DFA.unpackEncodedString(DFA3_eotS);
    static final short[] DFA3_eof = DFA.unpackEncodedString(DFA3_eofS);
    static final char[] DFA3_min = DFA.unpackEncodedStringToUnsignedChars(DFA3_minS);
    static final char[] DFA3_max = DFA.unpackEncodedStringToUnsignedChars(DFA3_maxS);
    static final short[] DFA3_accept = DFA.unpackEncodedString(DFA3_acceptS);
    static final short[] DFA3_special = DFA.unpackEncodedString(DFA3_specialS);
    static final short[][] DFA3_transition;

    static {
        int numStates = DFA3_transitionS.length;
        DFA3_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA3_transition[i] = DFA.unpackEncodedString(DFA3_transitionS[i]);
        }
    }

    class DFA3 extends DFA {

        public DFA3(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 3;
            this.eot = DFA3_eot;
            this.eof = DFA3_eof;
            this.min = DFA3_min;
            this.max = DFA3_max;
            this.accept = DFA3_accept;
            this.special = DFA3_special;
            this.transition = DFA3_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( ABSTRACT | BOOLEAN | BREAK | BYTE | CASE | CATCH | CHAR | CLASS | CONST | CONTINUE | DEFAULT | DO | DOUBLE | ELSE | EXTENDS | FALSE | FINAL | FINALLY | FLOAT | FOR | GOTO | IF | IMPLEMENTS | IMPORT | INSTANCEOF | INT | INTERFACE | LONG | NATIVE | NEW | NULL | ONLY | PACKAGE | PRIVATE | PROTECTED | PUBLIC | RETURN | SHORT | STATIC | SUPER | SWITCH | SYNCHRONIZED | THIS | THROW | THROWS | TRANSIENT | TRUE | TRY | VOID | VOLATILE | WHILE | COLON | SEMI | DOT | LBRACKET | RBRACKET | AT | LPAREN | RPAREN | QUOTE | DQUOTE | LBRACE | RBRACE | COMMA | IDENTIFIER | WS | NEWLINE );";
        }
    }
 

}
