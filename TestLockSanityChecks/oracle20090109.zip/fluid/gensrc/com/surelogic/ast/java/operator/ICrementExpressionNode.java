// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Prefix and Postfix Increment and Decrement expressions.
 * Warning: the CFG depends on the first child being the executed child.
 * 
 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    op : IExpressionNode
 * 
 */
public interface ICrementExpressionNode extends IArithUnopExpressionNode, IAssignmentNode { 
  public BaseNodeType getNodeType();
}

