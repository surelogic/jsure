// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Import color declarations and renames from some other place.
 * 
 * Syntax:
 *    "colorImport"
 *    item : IImportNameNode
 *    <>
 *    ";"
 * 
 */
public interface IColorImportNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IImportNameNode getItem();
}

