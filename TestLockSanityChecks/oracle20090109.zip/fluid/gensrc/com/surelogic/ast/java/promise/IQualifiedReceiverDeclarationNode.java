// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * An explicit declaration of the receiver for outer classes
 * @see MethodDeclaration
 * @see ClassBody
 * @see ConstructorDeclaration
 * 
 * Syntax:
 *    base : IClassTypeNode
 *    <>
 *    "."
 *    <>
 *    "this"
 * 
 */
public interface IQualifiedReceiverDeclarationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IClassTypeNode getBase();
}

