// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.*;
import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A specification of a region.
 * @see RegionName
 * @see QualifiedRegionName
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 * Binds this name to IRegionBinding
 */
public interface IRegionSpecificationNode extends IFieldRegionSpecificationNode, IHasBinding { 
  public PromiseNodeType getNodeType();
  public boolean bindingExists();

  public IRegionBinding resolveBinding();

  /**
   * @return A possibly-null String
   */
  public String getId();
}

