// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "if"
 *    "("
 *    <paren>
 *    cond : IExpressionNode
 *    </paren>
 *    ")"
 *    <then>
 *    thenPart : IStatementNode
 *    </then>
 *    elsePart : IOptElseClauseNode
 * 
 */
public interface IIfStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getCond();
  /**
   * @return A non-null node
   */
  public IStatementNode getThenPart();
  /**
   * @return A node, or null
   */
  public IElseClauseNode getElsePart();
}

