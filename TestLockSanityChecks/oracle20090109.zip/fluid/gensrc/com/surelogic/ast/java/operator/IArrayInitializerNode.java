// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "{"
 *    Zero or more of:
 *      initList : List<IInitializerNode>
 *    Separated by:
 *      ","
 *    "}"
 * 
 */
public interface IArrayInitializerNode extends IInitializerNode, IOptArrayInitializerNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IInitializerNode> getInitList();
}

