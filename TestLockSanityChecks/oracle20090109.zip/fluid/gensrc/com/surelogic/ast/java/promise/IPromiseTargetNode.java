// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    "all"
 * 
 */
public interface IPromiseTargetNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

