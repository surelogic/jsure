// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    pkg : Comment (String)
 *    type : Info (String)
 *    "."
 * 
 */
public interface ITypeQualifierPatternNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null String
   */
  public String getPkg();
  /**
   * @return A non-null String
   */
  public String getType();
}

