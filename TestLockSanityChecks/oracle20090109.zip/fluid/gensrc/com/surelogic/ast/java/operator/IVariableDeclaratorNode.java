// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * A variable or field declaration.  In general this may be one of several
 * declarators within a larger declaration, e.g. one of x,y,z in the following:
 * -
 * int x,y,z;
 * -
 * We do not handle the case of [] appended to the end of the name.
 * <br>
 * VariableDeclaratorNode represents what we think of as a standard variable
 *        declaration. It has an optional initialization child node.
 *        (e.g., int x = 4;). Another AST node, VariableDeclarationNode
 *        is actually the supertype of several different types of variable
 *        declaration, including VariableDeclarator node.
 * 
 * Syntax:
 *    id : Info (String)
 *    dims : DimInfo (int)
 *    init : IOptInitializationNode
 * 
 * Contains unknown property 'dims'
 * 
 * Binds to the type represented by ITypeBinding
 */
public interface IVariableDeclaratorNode extends IVariableDeclarationNode, IVariableBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the VariableDeclarator
   */
  public IType resolveType();

  /**
   * Already taken into account by the resolved type binding
   * @return A non-null int
   */
  public int getDims();
  /**
   * @return A node, or null
   */
  public IInitializationNode getInit();
}

