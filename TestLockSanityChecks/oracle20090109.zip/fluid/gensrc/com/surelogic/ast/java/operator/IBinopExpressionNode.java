// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    op1 : IExpressionNode
 *    op2 : IExpressionNode
 * 
 */
public interface IBinopExpressionNode extends IExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp1();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp2();
}

