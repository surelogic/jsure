// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * A common interface for lists of VariableDeclarators
 * (e.g., FieldDeclaration and DeclStatement)
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    type : ITypeNode
 *    varsList : List<IVariableDeclaratorNode>
 * 
 */
public interface IVariableDeclListNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
  public boolean isFinal();
  /**
   * @return A non-null node
   */
  public ITypeNode getType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IVariableDeclaratorNode> getVarsList();
}

