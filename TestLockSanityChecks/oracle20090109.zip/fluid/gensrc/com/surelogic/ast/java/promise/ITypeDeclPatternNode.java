// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.*;
import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "type"
 *    mods : Modifiers (int)
 *    pkg : Comment (String)
 *    type : Info (String)
 * 
 * Binds to the type represented by Iseq:SourceRefTypeBinding
 */
public interface ITypeDeclPatternNode extends IPromiseTargetNode, IHasTypeSeq { 
  public PromiseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the TypeDeclPattern
   */
  public Iterable<ISourceRefType> resolveType();

  /**
   * @return A non-null int
   */
  public int getMods();
  /**
   * @return A non-null String
   */
  public String getPkg();
  /**
   * @return A non-null String
   */
  public String getType();
}

