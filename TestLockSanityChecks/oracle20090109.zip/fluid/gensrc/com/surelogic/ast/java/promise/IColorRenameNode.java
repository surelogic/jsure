// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Rename a colorSpec expression.
 * 
 * Syntax:
 *    "colorRename"
 *    color : IColorNameNode
 *    "for"
 *    cSpec : IColorSpecNode
 * 
 */
public interface IColorRenameNode extends IColoringAnnotationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IColorNameNode getColor();
  /**
   * @return A non-null node
   */
  public IColorSpecNode getCSpec();
}

