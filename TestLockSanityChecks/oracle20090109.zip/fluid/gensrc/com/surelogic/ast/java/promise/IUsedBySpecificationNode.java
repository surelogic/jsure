// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * A usedBy declaration
 * 
 * Syntax:
 *    Zero or more of:
 *      typesList : List<INamedTypeNode>
 *    Separated by:
 *      ","
 * 
 */
public interface IUsedBySpecificationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<INamedTypeNode> getTypesList();
}

