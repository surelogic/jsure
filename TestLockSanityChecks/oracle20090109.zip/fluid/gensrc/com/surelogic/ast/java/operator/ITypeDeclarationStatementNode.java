// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    typedec : ITypeDeclarationNode
 * 
 */
public interface ITypeDeclarationStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ITypeDeclarationNode getTypedec();
}

