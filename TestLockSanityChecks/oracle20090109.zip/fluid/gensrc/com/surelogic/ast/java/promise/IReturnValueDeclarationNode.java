// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * An explicit declaration of the return value.
 * @see MethodDeclaration
 * 
 * Syntax:
 *    "?"
 *    "return"
 * 
 */
public interface IReturnValueDeclarationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

