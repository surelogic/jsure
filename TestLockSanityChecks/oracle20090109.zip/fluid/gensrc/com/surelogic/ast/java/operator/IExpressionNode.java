// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * The class of all Java expression operators.
 * 
 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 */
public interface IExpressionNode extends IInitializerNode, IHasType { 
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the Expression
   */
  public IType resolveType();

}

