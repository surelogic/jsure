// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * A starts declaration
 * 
 * Syntax:
 *    "nothing"
 * 
 * Is the root of its AST, but can bridge to an AST of type IRNode
 */
public interface IStartsSpecificationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  public IIRNodeBridge getBridge();

  public void setBridge(IIRNodeBridge b);

}

