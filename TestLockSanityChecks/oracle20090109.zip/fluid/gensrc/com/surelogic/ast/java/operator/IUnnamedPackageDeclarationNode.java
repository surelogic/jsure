// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 * 
 * Computes the value of the 'id' attribute
 */
public interface IUnnamedPackageDeclarationNode extends IPackageDeclarationNode { 
  public BaseNodeType getNodeType();
}

