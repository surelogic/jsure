// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Used to map a number of fields into a region
 * 
 * Syntax:
 *    fieldsList : List<IRegionSpecificationNode>
 *    "into"
 *    to : IRegionSpecificationNode
 * 
 */
public interface IFieldMappingsNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IRegionSpecificationNode> getFieldsList();
  /**
   * @return A non-null node
   */
  public IRegionSpecificationNode getTo();
}

