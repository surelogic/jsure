// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "case"
 *    expr : IExpressionNode
 *    <>
 *    ":"
 * 
 */
public interface IConstantLabelNode extends ISwitchLabelNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getExpr();
}

