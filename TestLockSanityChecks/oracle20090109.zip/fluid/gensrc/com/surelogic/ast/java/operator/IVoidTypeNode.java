// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "void"
 * 
 * Binds to the type represented by IVoidTypeBinding
 */
public interface IVoidTypeNode extends IReturnTypeNode, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the VoidType
   */
  public IVoidType resolveType();

}

