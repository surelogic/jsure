// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    type : ITypeNode
 *    id : Info (String)
 * 
 * 
 * Binds to the type represented by ITypeBinding
 */
public interface IParameterDeclarationNode extends IVariableDeclarationNode, IVariableBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the ParameterDeclaration
   */
  public IType resolveType();

  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
  public boolean isFinal();
  /**
   * @return A non-null node
   */
  public ITypeNode getType();
}

