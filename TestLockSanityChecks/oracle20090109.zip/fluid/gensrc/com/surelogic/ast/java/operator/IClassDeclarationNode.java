// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    "class"
 *    id : Info (String)
 *    typesList : List<ITypeFormalNode>
 *    <?>
 *    "extends"
 *    extension : IClassTypeNode
 *    </?>
 *    implsList : List<IClassTypeNode>
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * 
 */
public interface IClassDeclarationNode extends ITypeDeclarationNode, IDeclaredType { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IAnnotationNode> getAnnosList();
  public boolean isAbstract();
  public boolean isPublic();
  public boolean isFinal();
  public boolean isStrictfp();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeFormalNode> getTypesList();
  /**
   * @return A non-null node
   */
  public IClassTypeNode getExtension();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassTypeNode> getImplsList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassBodyDeclarationNode> getBodyList();
}

