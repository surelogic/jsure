// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * An explicit declaration of the initialization method for instances.
 * @see ClassDeclaration
 * 
 * Syntax:
 *    "<init>"
 * 
 */
public interface IInitDeclarationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

