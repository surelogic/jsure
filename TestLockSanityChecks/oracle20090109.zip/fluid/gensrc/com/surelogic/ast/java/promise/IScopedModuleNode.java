// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * The leaf targets should all be TypeDeclPatterns,
 * and they are interpreted as the compilation units
 * they are in
 * 
 * Syntax:
 *    id : Info (String)
 *    "for"
 *    targets : IPromiseTargetNode
 * 
 */
public interface IScopedModuleNode extends IModuleNode, ITargetedAnnotationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IPromiseTargetNode getTargets();
}

