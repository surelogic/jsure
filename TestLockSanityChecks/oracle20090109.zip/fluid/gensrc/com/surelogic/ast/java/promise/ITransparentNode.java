// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Note that ColorIn == ColorOut and that any color will do.
 * 
 * Syntax:
 *    "transparent"
 * 
 */
public interface ITransparentNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

