// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    typeArgsList : List<IReferenceTypeNode> or null
 *    type : IClassTypeNode
 *    argsList : List<IExpressionNode>
 * 
 */
public interface INewExpressionNode extends IAllocationCallExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IReferenceTypeNode> getTypeArgsList();
  /**
   * @return A non-null node
   */
  public IClassTypeNode getType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IExpressionNode> getArgsList();
}

