// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Return some instance of the given class nondeterministically.
 * Not legal in java programs, used only in effects specifications.
 * @see EffectSpecification
 * 
 * Syntax:
 *    "any"
 *    "("
 *    type : INamedTypeNode
 *    ")"
 * 
 */
public interface IAnyInstanceExpressionNode extends IExpressionNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public INamedTypeNode getType();
}

