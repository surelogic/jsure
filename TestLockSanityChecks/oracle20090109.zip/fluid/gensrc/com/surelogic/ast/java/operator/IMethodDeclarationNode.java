// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    modifiers : Modifiers (int)
 *    typesList : List<ITypeFormalNode>
 *    returnType : IReturnTypeNode
 *    id : Info (String)
 *    <>
 *    paramsList : List<IParameterDeclarationNode>
 *    dims : DimInfo (int)
 *    exceptionsList : List<IClassTypeNode>
 *    body : IOptMethodBodyNode
 * 
 * Contains unknown property 'dims'
 * Binds to the type represented by ITypeBinding
 * 
 */
public interface IMethodDeclarationNode extends ISomeFunctionDeclarationNode, IMethodBinding, IHasType { 
  public BaseNodeType getNodeType();
  /**
   * Gets the 'super-implementation' (a la Eclipse) for the method
   */
  public IMethodDeclarationNode getOverriddenMethod();

  /**
   * Gets all of immediately overridden methods from super-classes and -interfaces
   */
  public List<IMethodDeclarationNode> getAllOverriddenMethods();

  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the MethodDeclaration
   */
  public IType resolveType();

  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isAbstract();
  public boolean isFinal();
  public boolean isStatic();
  public boolean isNative();
  /**
   * @return A non-null node
   */
  public IReturnTypeNode getReturnType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IParameterDeclarationNode> getParamsList();
  /**
   * Already taken into account by the resolved type binding
   * @return A non-null int
   */
  public int getDims();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassTypeNode> getExceptionsList();
  /**
   * @return A non-null node
   */
  public IOptMethodBodyNode getBody();
}

