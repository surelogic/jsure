// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "method"
 *    mods : Modifiers (int)
 *    rtype : ITypeNode
 *    type : ITypeQualifierPatternNode
 *    name : Info (String)
 *    sigList : List<ITypeNode>
 *    throwsCList : List<ITypeNode>
 * 
 */
public interface IMethodDeclPatternNode extends IPromiseTargetNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null int
   */
  public int getMods();
  /**
   * @return A non-null node
   */
  public ITypeNode getRtype();
  /**
   * @return A non-null node
   */
  public ITypeQualifierPatternNode getType();
  /**
   * @return A non-null String
   */
  public String getName();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeNode> getSigList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeNode> getThrowsCList();
}

