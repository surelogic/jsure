// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * The type of things that can be allocated.
 * 
 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 */
public interface IClassTypeNode extends IReferenceTypeNode, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the ClassType
   */
  public ISourceRefType resolveType();

}

