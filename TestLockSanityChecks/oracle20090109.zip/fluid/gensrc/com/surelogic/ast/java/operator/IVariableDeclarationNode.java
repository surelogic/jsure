// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * VariableDeclaration is a supertype that is the parent to several different
 *        kinds of 'variable declarations.' This includes 'standard' variable
 *        decarations, as well as other kinds of declarations such as
 *        method parameters, enum constants and more. If you are looking for the
 *        variable declarations, you should probably look at VariableDeclarator.
 * 
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 * 
 * Binds to the type represented by ITypeBinding
 */
public interface IVariableDeclarationNode extends IDeclarationNode, IVariableBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the VariableDeclaration
   */
  public IType resolveType();

}

