// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A node with this operator expresses an effect for a method.
 * The effect has three parts: <ol>
 * <li> a bit indicating whether it is a read or write effect
 * <li> an expression indicating what the region is defined in.
 *      This expression may either be an object or a class.
 *      The former is used for instance regions, the latter for
 *      static regions.  We use special expression nodes to
 * <li> The name of the region. </ol>
 * @see AnyInstanceExpression
 * 
 * Syntax:
 *    isWrite : IsWrite (boolean)
 *    context : IExpressionNode
 *    <>
 *    "."
 *    <>
 *    region : IRegionSpecificationNode
 * 
 */
public interface IEffectSpecificationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null boolean
   */
  public boolean getIsWrite();
  /**
   * @return A non-null node
   */
  public IExpressionNode getContext();
  /**
   * @return A non-null node
   */
  public IRegionSpecificationNode getRegion();
}

