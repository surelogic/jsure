// $ANTLR 3.1 /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g 2008-09-25 15:48:53

package com.surelogic.annotation.parse;

import com.surelogic.parse.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class ScopedPromisesLexer extends Lexer {
    public static final int COMMA=85;
    public static final int HexDigit=86;
    public static final int DOUBLE=63;
    public static final int Throws=38;
    public static final int START_IMAGINARY=4;
    public static final int FieldRef=22;
    public static final int ABSTRACT=72;
    public static final int IntType=10;
    public static final int NamedTypePattern=36;
    public static final int INSTANCE=46;
    public static final int DQUOTE=82;
    public static final int NEWLINE=103;
    public static final int DOT=51;
    public static final int PRIVATE=68;
    public static final int AndTarget=29;
    public static final int RBRACKET=77;
    public static final int FieldDeclPattern=34;
    public static final int RPAREN=80;
    public static final int WildcardIdentifier=65;
    public static final int ID2=101;
    public static final int VariableUseExpression=24;
    public static final int FloatTypeSuffix=92;
    public static final int AT=78;
    public static final int MethodDeclPattern=33;
    public static final int IntegerTypeSuffix=87;
    public static final int ClassExpression=25;
    public static final int InPattern=39;
    public static final int ConstructorDeclPattern=32;
    public static final int WS=102;
    public static final int CHAR=59;
    public static final int SuperExpression=20;
    public static final int WildcardTypeQualifierPattern=44;
    public static final int ReturnValueDeclaration=21;
    public static final int QualifiedThisExpression=5;
    public static final int FINAL=73;
    public static final int NamedType=14;
    public static final int MUTABLE=47;
    public static final int InOrPattern=42;
    public static final int TypeDeclPattern=35;
    public static final int STATIC=69;
    public static final int SEMI=75;
    public static final int FloatType=11;
    public static final int UnicodeEscape=96;
    public static final int HexLiteral=88;
    public static final int OrTarget=30;
    public static final int BOOLEAN=57;
    public static final int DecimalLiteral=89;
    public static final int DoubleType=12;
    public static final int ScopedPromise=27;
    public static final int COLON=74;
    public static final int Parameters=37;
    public static final int TypeQualifierPattern=17;
    public static final int IDENTIFIER=53;
    public static final int SHORT=60;
    public static final int ThisExpression=19;
    public static final int PUBLIC=66;
    public static final int LONG=64;
    public static final int TypeExpression=23;
    public static final int OctalLiteral=90;
    public static final int PromiseStringLiteral=49;
    public static final int FLOAT=62;
    public static final int LBRACKET=76;
    public static final int T__104=104;
    public static final int T__107=107;
    public static final int DSTAR=55;
    public static final int LBRACE=83;
    public static final int T__106=106;
    public static final int RBRACE=84;
    public static final int PROTECTED=67;
    public static final int NotTarget=31;
    public static final int BooleanType=6;
    public static final int EscapeSequence=94;
    public static final int INT=61;
    public static final int VOID=56;
    public static final int InPackagePattern=40;
    public static final int LPAREN=79;
    public static final int Nothing=26;
    public static final int InNotPattern=43;
    public static final int FloatingPointLiteral=93;
    public static final int ID=100;
    public static final int ByteType=7;
    public static final int LETTER=98;
    public static final int Exponent=91;
    public static final int Annotations=18;
    public static final int CharType=8;
    public static final int END_IMAGINARY=45;
    public static final int CharacterLiteral=95;
    public static final int AnyTarget=28;
    public static final int StringLiteral=50;
    public static final int QUOTE=81;
    public static final int THIS=71;
    public static final int InAndPattern=41;
    public static final int IN=52;
    public static final int ShortType=9;
    public static final int JavaIDDigit=99;
    public static final int CLASS=70;
    public static final int TypeRef=15;
    public static final int BYTE=58;
    public static final int T__105=105;
    public static final int EOF=-1;
    public static final int FOR=48;
    public static final int ArrayType=16;
    public static final int OctalEscape=97;
    public static final int STAR=54;
    public static final int LongType=13;

      /**
       * Makes it create TreeTokens, instead of CommonTokens
       */
      @Override 
      public Token emit() {
        Token t = new TreeToken(input, state.type, state.channel, state.tokenStartCharIndex, getCharIndex()-1);
        t.setLine(state.tokenStartLine);
        t.setText(state.text);
        t.setCharPositionInLine(state.tokenStartCharPositionInLine);
        emit(t);
        return t;
      }


    // delegates
    // delegators

    public ScopedPromisesLexer() {;} 
    public ScopedPromisesLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public ScopedPromisesLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "/Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g"; }

    // $ANTLR start "T__104"
    public final void mT__104() throws RecognitionException {
        try {
            int _type = T__104;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:27:8: ( '|' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:27:10: '|'
            {
            match('|'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__104"

    // $ANTLR start "T__105"
    public final void mT__105() throws RecognitionException {
        try {
            int _type = T__105;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:28:8: ( '&' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:28:10: '&'
            {
            match('&'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__105"

    // $ANTLR start "T__106"
    public final void mT__106() throws RecognitionException {
        try {
            int _type = T__106;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:29:8: ( '!' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:29:10: '!'
            {
            match('!'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__106"

    // $ANTLR start "T__107"
    public final void mT__107() throws RecognitionException {
        try {
            int _type = T__107;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:30:8: ( 'new' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:30:10: 'new'
            {
            match("new"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__107"

    // $ANTLR start "ABSTRACT"
    public final void mABSTRACT() throws RecognitionException {
        try {
            int _type = ABSTRACT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:418:10: ( 'abstract' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:418:12: 'abstract'
            {
            match("abstract"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ABSTRACT"

    // $ANTLR start "CLASS"
    public final void mCLASS() throws RecognitionException {
        try {
            int _type = CLASS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:419:7: ( 'class' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:419:9: 'class'
            {
            match("class"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CLASS"

    // $ANTLR start "FINAL"
    public final void mFINAL() throws RecognitionException {
        try {
            int _type = FINAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:420:7: ( 'final' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:420:9: 'final'
            {
            match("final"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FINAL"

    // $ANTLR start "FOR"
    public final void mFOR() throws RecognitionException {
        try {
            int _type = FOR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:421:5: ( 'for' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:421:7: 'for'
            {
            match("for"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FOR"

    // $ANTLR start "PRIVATE"
    public final void mPRIVATE() throws RecognitionException {
        try {
            int _type = PRIVATE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:422:9: ( 'private' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:422:11: 'private'
            {
            match("private"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PRIVATE"

    // $ANTLR start "PROTECTED"
    public final void mPROTECTED() throws RecognitionException {
        try {
            int _type = PROTECTED;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:423:11: ( 'protected' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:423:13: 'protected'
            {
            match("protected"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PROTECTED"

    // $ANTLR start "PUBLIC"
    public final void mPUBLIC() throws RecognitionException {
        try {
            int _type = PUBLIC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:424:8: ( 'public' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:424:10: 'public'
            {
            match("public"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PUBLIC"

    // $ANTLR start "STATIC"
    public final void mSTATIC() throws RecognitionException {
        try {
            int _type = STATIC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:425:8: ( 'static' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:425:10: 'static'
            {
            match("static"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STATIC"

    // $ANTLR start "THIS"
    public final void mTHIS() throws RecognitionException {
        try {
            int _type = THIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:426:6: ( 'this' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:426:8: 'this'
            {
            match("this"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "THIS"

    // $ANTLR start "VOID"
    public final void mVOID() throws RecognitionException {
        try {
            int _type = VOID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:427:6: ( 'void' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:427:8: 'void'
            {
            match("void"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "VOID"

    // $ANTLR start "BOOLEAN"
    public final void mBOOLEAN() throws RecognitionException {
        try {
            int _type = BOOLEAN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:428:9: ( 'boolean' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:428:11: 'boolean'
            {
            match("boolean"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BOOLEAN"

    // $ANTLR start "BYTE"
    public final void mBYTE() throws RecognitionException {
        try {
            int _type = BYTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:429:6: ( 'byte' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:429:8: 'byte'
            {
            match("byte"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BYTE"

    // $ANTLR start "CHAR"
    public final void mCHAR() throws RecognitionException {
        try {
            int _type = CHAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:430:6: ( 'char' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:430:8: 'char'
            {
            match("char"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CHAR"

    // $ANTLR start "SHORT"
    public final void mSHORT() throws RecognitionException {
        try {
            int _type = SHORT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:431:7: ( 'short' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:431:9: 'short'
            {
            match("short"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SHORT"

    // $ANTLR start "INT"
    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:432:5: ( 'int' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:432:7: 'int'
            {
            match("int"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT"

    // $ANTLR start "FLOAT"
    public final void mFLOAT() throws RecognitionException {
        try {
            int _type = FLOAT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:433:7: ( 'float' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:433:9: 'float'
            {
            match("float"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FLOAT"

    // $ANTLR start "DOUBLE"
    public final void mDOUBLE() throws RecognitionException {
        try {
            int _type = DOUBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:434:8: ( 'double' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:434:10: 'double'
            {
            match("double"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOUBLE"

    // $ANTLR start "LONG"
    public final void mLONG() throws RecognitionException {
        try {
            int _type = LONG;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:435:6: ( 'long' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:435:8: 'long'
            {
            match("long"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LONG"

    // $ANTLR start "COLON"
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:437:7: ( ':' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:437:9: ':'
            {
            match(':'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLON"

    // $ANTLR start "SEMI"
    public final void mSEMI() throws RecognitionException {
        try {
            int _type = SEMI;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:438:7: ( ';' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:438:9: ';'
            {
            match(';'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SEMI"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:439:7: ( '.' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:439:9: '.'
            {
            match('.'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "LBRACKET"
    public final void mLBRACKET() throws RecognitionException {
        try {
            int _type = LBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:440:10: ( '[' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:440:12: '['
            {
            match('['); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACKET"

    // $ANTLR start "RBRACKET"
    public final void mRBRACKET() throws RecognitionException {
        try {
            int _type = RBRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:441:10: ( ']' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:441:12: ']'
            {
            match(']'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACKET"

    // $ANTLR start "AT"
    public final void mAT() throws RecognitionException {
        try {
            int _type = AT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:442:4: ( '@' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:442:6: '@'
            {
            match('@'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "AT"

    // $ANTLR start "LPAREN"
    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:443:8: ( '(' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:443:10: '('
            {
            match('('); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LPAREN"

    // $ANTLR start "RPAREN"
    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:444:8: ( ')' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:444:10: ')'
            {
            match(')'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RPAREN"

    // $ANTLR start "QUOTE"
    public final void mQUOTE() throws RecognitionException {
        try {
            int _type = QUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:445:7: ( '\\'' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:445:9: '\\''
            {
            match('\''); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "QUOTE"

    // $ANTLR start "DQUOTE"
    public final void mDQUOTE() throws RecognitionException {
        try {
            int _type = DQUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:446:8: ( '\"' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:446:10: '\"'
            {
            match('\"'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DQUOTE"

    // $ANTLR start "LBRACE"
    public final void mLBRACE() throws RecognitionException {
        try {
            int _type = LBRACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:447:8: ( '{' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:447:10: '{'
            {
            match('{'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LBRACE"

    // $ANTLR start "RBRACE"
    public final void mRBRACE() throws RecognitionException {
        try {
            int _type = RBRACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:448:8: ( '}' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:448:10: '}'
            {
            match('}'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RBRACE"

    // $ANTLR start "COMMA"
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:449:7: ( ',' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:449:9: ','
            {
            match(','); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMA"

    // $ANTLR start "STAR"
    public final void mSTAR() throws RecognitionException {
        try {
            int _type = STAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:450:7: ( '*' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:450:9: '*'
            {
            match('*'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STAR"

    // $ANTLR start "DSTAR"
    public final void mDSTAR() throws RecognitionException {
        try {
            int _type = DSTAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:451:7: ( '**' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:451:9: '**'
            {
            match("**"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DSTAR"

    // $ANTLR start "IN"
    public final void mIN() throws RecognitionException {
        try {
            int _type = IN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:452:7: ( 'in' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:452:9: 'in'
            {
            match("in"); if (state.failed) return ;


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IN"

    // $ANTLR start "HexLiteral"
    public final void mHexLiteral() throws RecognitionException {
        try {
            int _type = HexLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:454:12: ( '0' ( 'x' | 'X' ) ( HexDigit )+ ( IntegerTypeSuffix )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:454:14: '0' ( 'x' | 'X' ) ( HexDigit )+ ( IntegerTypeSuffix )?
            {
            match('0'); if (state.failed) return ;
            if ( input.LA(1)=='X'||input.LA(1)=='x' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:454:28: ( HexDigit )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='F')||(LA1_0>='a' && LA1_0<='f')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:454:28: HexDigit
            	    {
            	    mHexDigit(); if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:454:38: ( IntegerTypeSuffix )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='L'||LA2_0=='l') ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:454:38: IntegerTypeSuffix
                    {
                    mIntegerTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "HexLiteral"

    // $ANTLR start "DecimalLiteral"
    public final void mDecimalLiteral() throws RecognitionException {
        try {
            int _type = DecimalLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:16: ( ( '0' | '1' .. '9' ( '0' .. '9' )* ) ( IntegerTypeSuffix )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:18: ( '0' | '1' .. '9' ( '0' .. '9' )* ) ( IntegerTypeSuffix )?
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:18: ( '0' | '1' .. '9' ( '0' .. '9' )* )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0=='0') ) {
                alt4=1;
            }
            else if ( ((LA4_0>='1' && LA4_0<='9')) ) {
                alt4=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:19: '0'
                    {
                    match('0'); if (state.failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:25: '1' .. '9' ( '0' .. '9' )*
                    {
                    matchRange('1','9'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:34: ( '0' .. '9' )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( ((LA3_0>='0' && LA3_0<='9')) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:34: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:45: ( IntegerTypeSuffix )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0=='L'||LA5_0=='l') ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:456:45: IntegerTypeSuffix
                    {
                    mIntegerTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DecimalLiteral"

    // $ANTLR start "OctalLiteral"
    public final void mOctalLiteral() throws RecognitionException {
        try {
            int _type = OctalLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:458:14: ( '0' ( '0' .. '7' )+ ( IntegerTypeSuffix )? )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:458:16: '0' ( '0' .. '7' )+ ( IntegerTypeSuffix )?
            {
            match('0'); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:458:20: ( '0' .. '7' )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='0' && LA6_0<='7')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:458:21: '0' .. '7'
            	    {
            	    matchRange('0','7'); if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:458:32: ( IntegerTypeSuffix )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0=='L'||LA7_0=='l') ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:458:32: IntegerTypeSuffix
                    {
                    mIntegerTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "OctalLiteral"

    // $ANTLR start "HexDigit"
    public final void mHexDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:461:10: ( ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:461:12: ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' )
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='F')||(input.LA(1)>='a' && input.LA(1)<='f') ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "HexDigit"

    // $ANTLR start "IntegerTypeSuffix"
    public final void mIntegerTypeSuffix() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:464:19: ( ( 'l' | 'L' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:464:21: ( 'l' | 'L' )
            {
            if ( input.LA(1)=='L'||input.LA(1)=='l' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "IntegerTypeSuffix"

    // $ANTLR start "FloatingPointLiteral"
    public final void mFloatingPointLiteral() throws RecognitionException {
        try {
            int _type = FloatingPointLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:5: ( ( ( '0' .. '9' )+ '.' )=> ( '0' .. '9' ) '.' ( '0' .. '9' )* ( Exponent )? ( FloatTypeSuffix )? | '.' ( '0' .. '9' )+ ( Exponent )? ( FloatTypeSuffix )? | ( ( '0' .. '9' )+ Exponent )=> ( '0' .. '9' )+ Exponent ( FloatTypeSuffix )? | ( '0' .. '9' )+ ( Exponent )? FloatTypeSuffix )
            int alt18=4;
            alt18 = dfa18.predict(input);
            switch (alt18) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:9: ( ( '0' .. '9' )+ '.' )=> ( '0' .. '9' ) '.' ( '0' .. '9' )* ( Exponent )? ( FloatTypeSuffix )?
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:30: ( '0' .. '9' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:31: '0' .. '9'
                    {
                    matchRange('0','9'); if (state.failed) return ;

                    }

                    match('.'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:45: ( '0' .. '9' )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:46: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:57: ( Exponent )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0=='E'||LA9_0=='e') ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:57: Exponent
                            {
                            mExponent(); if (state.failed) return ;

                            }
                            break;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:67: ( FloatTypeSuffix )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0=='D'||LA10_0=='F'||LA10_0=='d'||LA10_0=='f') ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:67: FloatTypeSuffix
                            {
                            mFloatTypeSuffix(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:9: '.' ( '0' .. '9' )+ ( Exponent )? ( FloatTypeSuffix )?
                    {
                    match('.'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:13: ( '0' .. '9' )+
                    int cnt11=0;
                    loop11:
                    do {
                        int alt11=2;
                        int LA11_0 = input.LA(1);

                        if ( ((LA11_0>='0' && LA11_0<='9')) ) {
                            alt11=1;
                        }


                        switch (alt11) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:14: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt11 >= 1 ) break loop11;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(11, input);
                                throw eee;
                        }
                        cnt11++;
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:25: ( Exponent )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0=='E'||LA12_0=='e') ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:25: Exponent
                            {
                            mExponent(); if (state.failed) return ;

                            }
                            break;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:35: ( FloatTypeSuffix )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0=='D'||LA13_0=='F'||LA13_0=='d'||LA13_0=='f') ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:468:35: FloatTypeSuffix
                            {
                            mFloatTypeSuffix(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:9: ( ( '0' .. '9' )+ Exponent )=> ( '0' .. '9' )+ Exponent ( FloatTypeSuffix )?
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:36: ( '0' .. '9' )+
                    int cnt14=0;
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( ((LA14_0>='0' && LA14_0<='9')) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:37: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt14 >= 1 ) break loop14;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(14, input);
                                throw eee;
                        }
                        cnt14++;
                    } while (true);

                    mExponent(); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:57: ( FloatTypeSuffix )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0=='D'||LA15_0=='F'||LA15_0=='d'||LA15_0=='f') ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:57: FloatTypeSuffix
                            {
                            mFloatTypeSuffix(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:470:9: ( '0' .. '9' )+ ( Exponent )? FloatTypeSuffix
                    {
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:470:9: ( '0' .. '9' )+
                    int cnt16=0;
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( ((LA16_0>='0' && LA16_0<='9')) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:470:10: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt16 >= 1 ) break loop16;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(16, input);
                                throw eee;
                        }
                        cnt16++;
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:470:21: ( Exponent )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0=='E'||LA17_0=='e') ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:470:21: Exponent
                            {
                            mExponent(); if (state.failed) return ;

                            }
                            break;

                    }

                    mFloatTypeSuffix(); if (state.failed) return ;

                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FloatingPointLiteral"

    // $ANTLR start "Exponent"
    public final void mExponent() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:474:10: ( ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:474:12: ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:474:22: ( '+' | '-' )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0=='+'||LA19_0=='-') ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();
                    state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return ;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:474:33: ( '0' .. '9' )+
            int cnt20=0;
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>='0' && LA20_0<='9')) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:474:34: '0' .. '9'
            	    {
            	    matchRange('0','9'); if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    if ( cnt20 >= 1 ) break loop20;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(20, input);
                        throw eee;
                }
                cnt20++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "Exponent"

    // $ANTLR start "FloatTypeSuffix"
    public final void mFloatTypeSuffix() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:477:17: ( ( 'f' | 'F' | 'd' | 'D' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:477:19: ( 'f' | 'F' | 'd' | 'D' )
            {
            if ( input.LA(1)=='D'||input.LA(1)=='F'||input.LA(1)=='d'||input.LA(1)=='f' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "FloatTypeSuffix"

    // $ANTLR start "CharacterLiteral"
    public final void mCharacterLiteral() throws RecognitionException {
        try {
            int _type = CharacterLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:480:5: ( '\\'' ( EscapeSequence | ~ ( '\\'' | '\\\\' ) ) '\\'' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:480:9: '\\'' ( EscapeSequence | ~ ( '\\'' | '\\\\' ) ) '\\''
            {
            match('\''); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:480:14: ( EscapeSequence | ~ ( '\\'' | '\\\\' ) )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0=='\\') ) {
                alt21=1;
            }
            else if ( ((LA21_0>='\u0000' && LA21_0<='&')||(LA21_0>='(' && LA21_0<='[')||(LA21_0>=']' && LA21_0<='\uFFFE')) ) {
                alt21=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:480:16: EscapeSequence
                    {
                    mEscapeSequence(); if (state.failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:480:33: ~ ( '\\'' | '\\\\' )
                    {
                    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
                        input.consume();
                    state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return ;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            match('\''); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "CharacterLiteral"

    // $ANTLR start "StringLiteral"
    public final void mStringLiteral() throws RecognitionException {
        try {
            int _type = StringLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:484:5: ( '\"' ( EscapeSequence | ~ ( '\\\\' | '\"' ) )* '\"' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:484:8: '\"' ( EscapeSequence | ~ ( '\\\\' | '\"' ) )* '\"'
            {
            match('\"'); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:484:12: ( EscapeSequence | ~ ( '\\\\' | '\"' ) )*
            loop22:
            do {
                int alt22=3;
                int LA22_0 = input.LA(1);

                if ( (LA22_0=='\\') ) {
                    alt22=1;
                }
                else if ( ((LA22_0>='\u0000' && LA22_0<='!')||(LA22_0>='#' && LA22_0<='[')||(LA22_0>=']' && LA22_0<='\uFFFE')) ) {
                    alt22=2;
                }


                switch (alt22) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:484:14: EscapeSequence
            	    {
            	    mEscapeSequence(); if (state.failed) return ;

            	    }
            	    break;
            	case 2 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:484:31: ~ ( '\\\\' | '\"' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();
            	    state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return ;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            match('\"'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "StringLiteral"

    // $ANTLR start "EscapeSequence"
    public final void mEscapeSequence() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:489:5: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | UnicodeEscape | OctalEscape )
            int alt23=3;
            int LA23_0 = input.LA(1);

            if ( (LA23_0=='\\') ) {
                switch ( input.LA(2) ) {
                case '\"':
                case '\'':
                case '\\':
                case 'b':
                case 'f':
                case 'n':
                case 'r':
                case 't':
                    {
                    alt23=1;
                    }
                    break;
                case 'u':
                    {
                    alt23=2;
                    }
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                    {
                    alt23=3;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 1, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:489:9: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' )
                    {
                    match('\\'); if (state.failed) return ;
                    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                        input.consume();
                    state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return ;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:490:9: UnicodeEscape
                    {
                    mUnicodeEscape(); if (state.failed) return ;

                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:491:9: OctalEscape
                    {
                    mOctalEscape(); if (state.failed) return ;

                    }
                    break;

            }
        }
        finally {
        }
    }
    // $ANTLR end "EscapeSequence"

    // $ANTLR start "OctalEscape"
    public final void mOctalEscape() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:5: ( '\\\\' ( '0' .. '3' ) ( '0' .. '7' ) ( '0' .. '7' ) | '\\\\' ( '0' .. '7' ) ( '0' .. '7' ) | '\\\\' ( '0' .. '7' ) )
            int alt24=3;
            int LA24_0 = input.LA(1);

            if ( (LA24_0=='\\') ) {
                int LA24_1 = input.LA(2);

                if ( ((LA24_1>='0' && LA24_1<='3')) ) {
                    int LA24_2 = input.LA(3);

                    if ( ((LA24_2>='0' && LA24_2<='7')) ) {
                        int LA24_4 = input.LA(4);

                        if ( ((LA24_4>='0' && LA24_4<='7')) ) {
                            alt24=1;
                        }
                        else {
                            alt24=2;}
                    }
                    else {
                        alt24=3;}
                }
                else if ( ((LA24_1>='4' && LA24_1<='7')) ) {
                    int LA24_3 = input.LA(3);

                    if ( ((LA24_3>='0' && LA24_3<='7')) ) {
                        alt24=2;
                    }
                    else {
                        alt24=3;}
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 24, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:9: '\\\\' ( '0' .. '3' ) ( '0' .. '7' ) ( '0' .. '7' )
                    {
                    match('\\'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:14: ( '0' .. '3' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:15: '0' .. '3'
                    {
                    matchRange('0','3'); if (state.failed) return ;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:25: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:26: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:36: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:496:37: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }


                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:497:9: '\\\\' ( '0' .. '7' ) ( '0' .. '7' )
                    {
                    match('\\'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:497:14: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:497:15: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:497:25: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:497:26: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }


                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:498:9: '\\\\' ( '0' .. '7' )
                    {
                    match('\\'); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:498:14: ( '0' .. '7' )
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:498:15: '0' .. '7'
                    {
                    matchRange('0','7'); if (state.failed) return ;

                    }


                    }
                    break;

            }
        }
        finally {
        }
    }
    // $ANTLR end "OctalEscape"

    // $ANTLR start "UnicodeEscape"
    public final void mUnicodeEscape() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:503:5: ( '\\\\' 'u' HexDigit HexDigit HexDigit HexDigit )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:503:9: '\\\\' 'u' HexDigit HexDigit HexDigit HexDigit
            {
            match('\\'); if (state.failed) return ;
            match('u'); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;
            mHexDigit(); if (state.failed) return ;

            }

        }
        finally {
        }
    }
    // $ANTLR end "UnicodeEscape"

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:508:5: ( LETTER ( LETTER | JavaIDDigit )* )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:508:7: LETTER ( LETTER | JavaIDDigit )*
            {
            mLETTER(); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:508:14: ( LETTER | JavaIDDigit )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0=='$'||(LA25_0>='0' && LA25_0<='9')||(LA25_0>='A' && LA25_0<='Z')||LA25_0=='_'||(LA25_0>='a' && LA25_0<='z')||(LA25_0>='\u00C0' && LA25_0<='\u00D6')||(LA25_0>='\u00D8' && LA25_0<='\u00F6')||(LA25_0>='\u00F8' && LA25_0<='\u1FFF')||(LA25_0>='\u3040' && LA25_0<='\u318F')||(LA25_0>='\u3300' && LA25_0<='\u337F')||(LA25_0>='\u3400' && LA25_0<='\u3D2D')||(LA25_0>='\u4E00' && LA25_0<='\u9FFF')||(LA25_0>='\uF900' && LA25_0<='\uFAFF')) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
            	        input.consume();
            	    state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return ;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "ID2"
    public final void mID2() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:513:5: ( ( LETTER | JavaIDDigit )+ )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:513:7: ( LETTER | JavaIDDigit )+
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:513:7: ( LETTER | JavaIDDigit )+
            int cnt26=0;
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0=='$'||(LA26_0>='0' && LA26_0<='9')||(LA26_0>='A' && LA26_0<='Z')||LA26_0=='_'||(LA26_0>='a' && LA26_0<='z')||(LA26_0>='\u00C0' && LA26_0<='\u00D6')||(LA26_0>='\u00D8' && LA26_0<='\u00F6')||(LA26_0>='\u00F8' && LA26_0<='\u1FFF')||(LA26_0>='\u3040' && LA26_0<='\u318F')||(LA26_0>='\u3300' && LA26_0<='\u337F')||(LA26_0>='\u3400' && LA26_0<='\u3D2D')||(LA26_0>='\u4E00' && LA26_0<='\u9FFF')||(LA26_0>='\uF900' && LA26_0<='\uFAFF')) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
            	        input.consume();
            	    state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return ;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt26 >= 1 ) break loop26;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(26, input);
                        throw eee;
                }
                cnt26++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "ID2"

    // $ANTLR start "WildcardIdentifier"
    public final void mWildcardIdentifier() throws RecognitionException {
        try {
            int _type = WildcardIdentifier;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:517:5: ( ID ( STAR ID2 )* STAR | STAR ID2 ( STAR ID2 )* ( STAR )? | ID ( STAR ID2 )+ )
            int alt31=3;
            alt31 = dfa31.predict(input);
            switch (alt31) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:517:7: ID ( STAR ID2 )* STAR
                    {
                    mID(); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:517:10: ( STAR ID2 )*
                    loop27:
                    do {
                        int alt27=2;
                        int LA27_0 = input.LA(1);

                        if ( (LA27_0=='*') ) {
                            int LA27_1 = input.LA(2);

                            if ( (LA27_1=='$'||(LA27_1>='0' && LA27_1<='9')||(LA27_1>='A' && LA27_1<='Z')||LA27_1=='_'||(LA27_1>='a' && LA27_1<='z')||(LA27_1>='\u00C0' && LA27_1<='\u00D6')||(LA27_1>='\u00D8' && LA27_1<='\u00F6')||(LA27_1>='\u00F8' && LA27_1<='\u1FFF')||(LA27_1>='\u3040' && LA27_1<='\u318F')||(LA27_1>='\u3300' && LA27_1<='\u337F')||(LA27_1>='\u3400' && LA27_1<='\u3D2D')||(LA27_1>='\u4E00' && LA27_1<='\u9FFF')||(LA27_1>='\uF900' && LA27_1<='\uFAFF')) ) {
                                alt27=1;
                            }


                        }


                        switch (alt27) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:517:11: STAR ID2
                    	    {
                    	    mSTAR(); if (state.failed) return ;
                    	    mID2(); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop27;
                        }
                    } while (true);

                    mSTAR(); if (state.failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:518:7: STAR ID2 ( STAR ID2 )* ( STAR )?
                    {
                    mSTAR(); if (state.failed) return ;
                    mID2(); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:518:16: ( STAR ID2 )*
                    loop28:
                    do {
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0=='*') ) {
                            int LA28_1 = input.LA(2);

                            if ( (LA28_1=='$'||(LA28_1>='0' && LA28_1<='9')||(LA28_1>='A' && LA28_1<='Z')||LA28_1=='_'||(LA28_1>='a' && LA28_1<='z')||(LA28_1>='\u00C0' && LA28_1<='\u00D6')||(LA28_1>='\u00D8' && LA28_1<='\u00F6')||(LA28_1>='\u00F8' && LA28_1<='\u1FFF')||(LA28_1>='\u3040' && LA28_1<='\u318F')||(LA28_1>='\u3300' && LA28_1<='\u337F')||(LA28_1>='\u3400' && LA28_1<='\u3D2D')||(LA28_1>='\u4E00' && LA28_1<='\u9FFF')||(LA28_1>='\uF900' && LA28_1<='\uFAFF')) ) {
                                alt28=1;
                            }


                        }


                        switch (alt28) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:518:17: STAR ID2
                    	    {
                    	    mSTAR(); if (state.failed) return ;
                    	    mID2(); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop28;
                        }
                    } while (true);

                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:518:28: ( STAR )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0=='*') ) {
                        alt29=1;
                    }
                    switch (alt29) {
                        case 1 :
                            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:518:28: STAR
                            {
                            mSTAR(); if (state.failed) return ;

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:519:7: ID ( STAR ID2 )+
                    {
                    mID(); if (state.failed) return ;
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:519:10: ( STAR ID2 )+
                    int cnt30=0;
                    loop30:
                    do {
                        int alt30=2;
                        int LA30_0 = input.LA(1);

                        if ( (LA30_0=='*') ) {
                            alt30=1;
                        }


                        switch (alt30) {
                    	case 1 :
                    	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:519:11: STAR ID2
                    	    {
                    	    mSTAR(); if (state.failed) return ;
                    	    mID2(); if (state.failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt30 >= 1 ) break loop30;
                    	    if (state.backtracking>0) {state.failed=true; return ;}
                                EarlyExitException eee =
                                    new EarlyExitException(30, input);
                                throw eee;
                        }
                        cnt30++;
                    } while (true);


                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WildcardIdentifier"

    // $ANTLR start "IDENTIFIER"
    public final void mIDENTIFIER() throws RecognitionException {
        try {
            int _type = IDENTIFIER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:523:5: ( ID )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:523:7: ID
            {
            mID(); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IDENTIFIER"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:531:5: ( '\\u0024' | '\\u0041' .. '\\u005a' | '\\u005f' | '\\u0061' .. '\\u007a' | '\\u00c0' .. '\\u00d6' | '\\u00d8' .. '\\u00f6' | '\\u00f8' .. '\\u00ff' | '\\u0100' .. '\\u1fff' | '\\u3040' .. '\\u318f' | '\\u3300' .. '\\u337f' | '\\u3400' .. '\\u3d2d' | '\\u4e00' .. '\\u9fff' | '\\uf900' .. '\\ufaff' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
            {
            if ( input.LA(1)=='$'||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u3040' && input.LA(1)<='\u318F')||(input.LA(1)>='\u3300' && input.LA(1)<='\u337F')||(input.LA(1)>='\u3400' && input.LA(1)<='\u3D2D')||(input.LA(1)>='\u4E00' && input.LA(1)<='\u9FFF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFAFF') ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "JavaIDDigit"
    public final void mJavaIDDigit() throws RecognitionException {
        try {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:548:5: ( '\\u0030' .. '\\u0039' | '\\u0660' .. '\\u0669' | '\\u06f0' .. '\\u06f9' | '\\u0966' .. '\\u096f' | '\\u09e6' .. '\\u09ef' | '\\u0a66' .. '\\u0a6f' | '\\u0ae6' .. '\\u0aef' | '\\u0b66' .. '\\u0b6f' | '\\u0be7' .. '\\u0bef' | '\\u0c66' .. '\\u0c6f' | '\\u0ce6' .. '\\u0cef' | '\\u0d66' .. '\\u0d6f' | '\\u0e50' .. '\\u0e59' | '\\u0ed0' .. '\\u0ed9' | '\\u1040' .. '\\u1049' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='\u0660' && input.LA(1)<='\u0669')||(input.LA(1)>='\u06F0' && input.LA(1)<='\u06F9')||(input.LA(1)>='\u0966' && input.LA(1)<='\u096F')||(input.LA(1)>='\u09E6' && input.LA(1)<='\u09EF')||(input.LA(1)>='\u0A66' && input.LA(1)<='\u0A6F')||(input.LA(1)>='\u0AE6' && input.LA(1)<='\u0AEF')||(input.LA(1)>='\u0B66' && input.LA(1)<='\u0B6F')||(input.LA(1)>='\u0BE7' && input.LA(1)<='\u0BEF')||(input.LA(1)>='\u0C66' && input.LA(1)<='\u0C6F')||(input.LA(1)>='\u0CE6' && input.LA(1)<='\u0CEF')||(input.LA(1)>='\u0D66' && input.LA(1)<='\u0D6F')||(input.LA(1)>='\u0E50' && input.LA(1)<='\u0E59')||(input.LA(1)>='\u0ED0' && input.LA(1)<='\u0ED9')||(input.LA(1)>='\u1040' && input.LA(1)<='\u1049') ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "JavaIDDigit"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:565:5: ( ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' ) )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:565:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
                input.consume();
            state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            if ( state.backtracking==0 ) {
              skip();
            }

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "NEWLINE"
    public final void mNEWLINE() throws RecognitionException {
        try {
            int _type = NEWLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:568:9: ( ( '\\r' )? '\\n' )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:568:13: ( '\\r' )? '\\n'
            {
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:568:13: ( '\\r' )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0=='\r') ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:568:13: '\\r'
                    {
                    match('\r'); if (state.failed) return ;

                    }
                    break;

            }

            match('\n'); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NEWLINE"

    // $ANTLR start "PromiseStringLiteral"
    public final void mPromiseStringLiteral() throws RecognitionException {
        try {
            int _type = PromiseStringLiteral;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:573:3: ( QUOTE ( 'I' | ~ QUOTE )* QUOTE )
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:573:5: QUOTE ( 'I' | ~ QUOTE )* QUOTE
            {
            mQUOTE(); if (state.failed) return ;
            // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:573:11: ( 'I' | ~ QUOTE )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( ((LA33_0>='\u0000' && LA33_0<='&')||(LA33_0>='(' && LA33_0<='\uFFFE')) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();
            	    state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return ;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            mQUOTE(); if (state.failed) return ;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PromiseStringLiteral"

    public void mTokens() throws RecognitionException {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:8: ( T__104 | T__105 | T__106 | T__107 | ABSTRACT | CLASS | FINAL | FOR | PRIVATE | PROTECTED | PUBLIC | STATIC | THIS | VOID | BOOLEAN | BYTE | CHAR | SHORT | INT | FLOAT | DOUBLE | LONG | COLON | SEMI | DOT | LBRACKET | RBRACKET | AT | LPAREN | RPAREN | QUOTE | DQUOTE | LBRACE | RBRACE | COMMA | STAR | DSTAR | IN | HexLiteral | DecimalLiteral | OctalLiteral | FloatingPointLiteral | CharacterLiteral | StringLiteral | WildcardIdentifier | IDENTIFIER | WS | NEWLINE | PromiseStringLiteral )
        int alt34=49;
        alt34 = dfa34.predict(input);
        switch (alt34) {
            case 1 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:10: T__104
                {
                mT__104(); if (state.failed) return ;

                }
                break;
            case 2 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:17: T__105
                {
                mT__105(); if (state.failed) return ;

                }
                break;
            case 3 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:24: T__106
                {
                mT__106(); if (state.failed) return ;

                }
                break;
            case 4 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:31: T__107
                {
                mT__107(); if (state.failed) return ;

                }
                break;
            case 5 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:38: ABSTRACT
                {
                mABSTRACT(); if (state.failed) return ;

                }
                break;
            case 6 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:47: CLASS
                {
                mCLASS(); if (state.failed) return ;

                }
                break;
            case 7 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:53: FINAL
                {
                mFINAL(); if (state.failed) return ;

                }
                break;
            case 8 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:59: FOR
                {
                mFOR(); if (state.failed) return ;

                }
                break;
            case 9 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:63: PRIVATE
                {
                mPRIVATE(); if (state.failed) return ;

                }
                break;
            case 10 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:71: PROTECTED
                {
                mPROTECTED(); if (state.failed) return ;

                }
                break;
            case 11 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:81: PUBLIC
                {
                mPUBLIC(); if (state.failed) return ;

                }
                break;
            case 12 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:88: STATIC
                {
                mSTATIC(); if (state.failed) return ;

                }
                break;
            case 13 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:95: THIS
                {
                mTHIS(); if (state.failed) return ;

                }
                break;
            case 14 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:100: VOID
                {
                mVOID(); if (state.failed) return ;

                }
                break;
            case 15 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:105: BOOLEAN
                {
                mBOOLEAN(); if (state.failed) return ;

                }
                break;
            case 16 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:113: BYTE
                {
                mBYTE(); if (state.failed) return ;

                }
                break;
            case 17 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:118: CHAR
                {
                mCHAR(); if (state.failed) return ;

                }
                break;
            case 18 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:123: SHORT
                {
                mSHORT(); if (state.failed) return ;

                }
                break;
            case 19 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:129: INT
                {
                mINT(); if (state.failed) return ;

                }
                break;
            case 20 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:133: FLOAT
                {
                mFLOAT(); if (state.failed) return ;

                }
                break;
            case 21 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:139: DOUBLE
                {
                mDOUBLE(); if (state.failed) return ;

                }
                break;
            case 22 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:146: LONG
                {
                mLONG(); if (state.failed) return ;

                }
                break;
            case 23 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:151: COLON
                {
                mCOLON(); if (state.failed) return ;

                }
                break;
            case 24 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:157: SEMI
                {
                mSEMI(); if (state.failed) return ;

                }
                break;
            case 25 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:162: DOT
                {
                mDOT(); if (state.failed) return ;

                }
                break;
            case 26 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:166: LBRACKET
                {
                mLBRACKET(); if (state.failed) return ;

                }
                break;
            case 27 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:175: RBRACKET
                {
                mRBRACKET(); if (state.failed) return ;

                }
                break;
            case 28 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:184: AT
                {
                mAT(); if (state.failed) return ;

                }
                break;
            case 29 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:187: LPAREN
                {
                mLPAREN(); if (state.failed) return ;

                }
                break;
            case 30 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:194: RPAREN
                {
                mRPAREN(); if (state.failed) return ;

                }
                break;
            case 31 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:201: QUOTE
                {
                mQUOTE(); if (state.failed) return ;

                }
                break;
            case 32 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:207: DQUOTE
                {
                mDQUOTE(); if (state.failed) return ;

                }
                break;
            case 33 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:214: LBRACE
                {
                mLBRACE(); if (state.failed) return ;

                }
                break;
            case 34 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:221: RBRACE
                {
                mRBRACE(); if (state.failed) return ;

                }
                break;
            case 35 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:228: COMMA
                {
                mCOMMA(); if (state.failed) return ;

                }
                break;
            case 36 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:234: STAR
                {
                mSTAR(); if (state.failed) return ;

                }
                break;
            case 37 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:239: DSTAR
                {
                mDSTAR(); if (state.failed) return ;

                }
                break;
            case 38 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:245: IN
                {
                mIN(); if (state.failed) return ;

                }
                break;
            case 39 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:248: HexLiteral
                {
                mHexLiteral(); if (state.failed) return ;

                }
                break;
            case 40 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:259: DecimalLiteral
                {
                mDecimalLiteral(); if (state.failed) return ;

                }
                break;
            case 41 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:274: OctalLiteral
                {
                mOctalLiteral(); if (state.failed) return ;

                }
                break;
            case 42 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:287: FloatingPointLiteral
                {
                mFloatingPointLiteral(); if (state.failed) return ;

                }
                break;
            case 43 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:308: CharacterLiteral
                {
                mCharacterLiteral(); if (state.failed) return ;

                }
                break;
            case 44 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:325: StringLiteral
                {
                mStringLiteral(); if (state.failed) return ;

                }
                break;
            case 45 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:339: WildcardIdentifier
                {
                mWildcardIdentifier(); if (state.failed) return ;

                }
                break;
            case 46 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:358: IDENTIFIER
                {
                mIDENTIFIER(); if (state.failed) return ;

                }
                break;
            case 47 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:369: WS
                {
                mWS(); if (state.failed) return ;

                }
                break;
            case 48 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:372: NEWLINE
                {
                mNEWLINE(); if (state.failed) return ;

                }
                break;
            case 49 :
                // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:1:380: PromiseStringLiteral
                {
                mPromiseStringLiteral(); if (state.failed) return ;

                }
                break;

        }

    }

    // $ANTLR start synpred1_ScopedPromises
    public final void synpred1_ScopedPromises_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:9: ( ( '0' .. '9' )+ '.' )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:10: ( '0' .. '9' )+ '.'
        {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:10: ( '0' .. '9' )+
        int cnt35=0;
        loop35:
        do {
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( ((LA35_0>='0' && LA35_0<='9')) ) {
                alt35=1;
            }


            switch (alt35) {
        	case 1 :
        	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:467:11: '0' .. '9'
        	    {
        	    matchRange('0','9'); if (state.failed) return ;

        	    }
        	    break;

        	default :
        	    if ( cnt35 >= 1 ) break loop35;
        	    if (state.backtracking>0) {state.failed=true; return ;}
                    EarlyExitException eee =
                        new EarlyExitException(35, input);
                    throw eee;
            }
            cnt35++;
        } while (true);

        match('.'); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_ScopedPromises

    // $ANTLR start synpred2_ScopedPromises
    public final void synpred2_ScopedPromises_fragment() throws RecognitionException {   
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:9: ( ( '0' .. '9' )+ Exponent )
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:10: ( '0' .. '9' )+ Exponent
        {
        // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:10: ( '0' .. '9' )+
        int cnt36=0;
        loop36:
        do {
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( ((LA36_0>='0' && LA36_0<='9')) ) {
                alt36=1;
            }


            switch (alt36) {
        	case 1 :
        	    // /Users/aarong/Work/Eclipse Workspaces/Eclipse 3.3/Fluid Runtime Workspace/fluid/src/com/surelogic/annotation/parse/ScopedPromises.g:469:11: '0' .. '9'
        	    {
        	    matchRange('0','9'); if (state.failed) return ;

        	    }
        	    break;

        	default :
        	    if ( cnt36 >= 1 ) break loop36;
        	    if (state.backtracking>0) {state.failed=true; return ;}
                    EarlyExitException eee =
                        new EarlyExitException(36, input);
                    throw eee;
            }
            cnt36++;
        } while (true);

        mExponent(); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_ScopedPromises

    public final boolean synpred1_ScopedPromises() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_ScopedPromises_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_ScopedPromises() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_ScopedPromises_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA18 dfa18 = new DFA18(this);
    protected DFA31 dfa31 = new DFA31(this);
    protected DFA34 dfa34 = new DFA34(this);
    static final String DFA18_eotS =
        "\10\uffff\1\11\2\uffff";
    static final String DFA18_eofS =
        "\13\uffff";
    static final String DFA18_minS =
        "\2\56\2\uffff\1\53\1\uffff\3\60\1\uffff\1\0";
    static final String DFA18_maxS =
        "\1\71\1\146\2\uffff\1\71\1\uffff\1\146\1\71\1\146\1\uffff\1\0";
    static final String DFA18_acceptS =
        "\2\uffff\1\2\1\1\1\uffff\1\4\3\uffff\1\3\1\uffff";
    static final String DFA18_specialS =
        "\1\uffff\1\0\6\uffff\1\2\1\uffff\1\1}>";
    static final String[] DFA18_transitionS = {
            "\1\2\1\uffff\12\1",
            "\1\3\1\uffff\12\6\12\uffff\1\5\1\4\1\5\35\uffff\1\5\1\4\1\5",
            "",
            "",
            "\1\7\1\uffff\1\7\2\uffff\12\10",
            "",
            "\12\6\12\uffff\1\5\1\4\1\5\35\uffff\1\5\1\4\1\5",
            "\12\10",
            "\12\10\12\uffff\1\12\1\uffff\1\12\35\uffff\1\12\1\uffff\1\12",
            "",
            "\1\uffff"
    };

    static final short[] DFA18_eot = DFA.unpackEncodedString(DFA18_eotS);
    static final short[] DFA18_eof = DFA.unpackEncodedString(DFA18_eofS);
    static final char[] DFA18_min = DFA.unpackEncodedStringToUnsignedChars(DFA18_minS);
    static final char[] DFA18_max = DFA.unpackEncodedStringToUnsignedChars(DFA18_maxS);
    static final short[] DFA18_accept = DFA.unpackEncodedString(DFA18_acceptS);
    static final short[] DFA18_special = DFA.unpackEncodedString(DFA18_specialS);
    static final short[][] DFA18_transition;

    static {
        int numStates = DFA18_transitionS.length;
        DFA18_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA18_transition[i] = DFA.unpackEncodedString(DFA18_transitionS[i]);
        }
    }

    class DFA18 extends DFA {

        public DFA18(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 18;
            this.eot = DFA18_eot;
            this.eof = DFA18_eof;
            this.min = DFA18_min;
            this.max = DFA18_max;
            this.accept = DFA18_accept;
            this.special = DFA18_special;
            this.transition = DFA18_transition;
        }
        public String getDescription() {
            return "466:1: FloatingPointLiteral : ( ( ( '0' .. '9' )+ '.' )=> ( '0' .. '9' ) '.' ( '0' .. '9' )* ( Exponent )? ( FloatTypeSuffix )? | '.' ( '0' .. '9' )+ ( Exponent )? ( FloatTypeSuffix )? | ( ( '0' .. '9' )+ Exponent )=> ( '0' .. '9' )+ Exponent ( FloatTypeSuffix )? | ( '0' .. '9' )+ ( Exponent )? FloatTypeSuffix );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA18_1 = input.LA(1);

                         
                        int index18_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA18_1=='.') && (synpred1_ScopedPromises())) {s = 3;}

                        else if ( (LA18_1=='E'||LA18_1=='e') ) {s = 4;}

                        else if ( (LA18_1=='D'||LA18_1=='F'||LA18_1=='d'||LA18_1=='f') ) {s = 5;}

                        else if ( ((LA18_1>='0' && LA18_1<='9')) ) {s = 6;}

                         
                        input.seek(index18_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA18_10 = input.LA(1);

                         
                        int index18_10 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred2_ScopedPromises()) ) {s = 9;}

                        else if ( (true) ) {s = 5;}

                         
                        input.seek(index18_10);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA18_8 = input.LA(1);

                         
                        int index18_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA18_8=='D'||LA18_8=='F'||LA18_8=='d'||LA18_8=='f') ) {s = 10;}

                        else if ( ((LA18_8>='0' && LA18_8<='9')) ) {s = 8;}

                        else s = 9;

                         
                        input.seek(index18_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 18, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA31_eotS =
        "\4\uffff\1\5\1\uffff\1\7\1\uffff";
    static final String DFA31_eofS =
        "\10\uffff";
    static final String DFA31_minS =
        "\2\44\1\uffff\2\44\1\uffff\1\44\1\uffff";
    static final String DFA31_maxS =
        "\2\ufaff\1\uffff\2\ufaff\1\uffff\1\ufaff\1\uffff";
    static final String DFA31_acceptS =
        "\2\uffff\1\2\2\uffff\1\1\1\uffff\1\3";
    static final String DFA31_specialS =
        "\10\uffff}>";
    static final String[] DFA31_transitionS = {
            "\1\1\5\uffff\1\2\26\uffff\32\1\4\uffff\1\1\1\uffff\32\1\105"+
            "\uffff\27\1\1\uffff\37\1\1\uffff\u1f08\1\u1040\uffff\u0150\1"+
            "\u0170\uffff\u0080\1\u0080\uffff\u092e\1\u10d2\uffff\u5200\1"+
            "\u5900\uffff\u0200\1",
            "\1\3\5\uffff\1\4\5\uffff\12\3\7\uffff\32\3\4\uffff\1\3\1\uffff"+
            "\32\3\105\uffff\27\3\1\uffff\37\3\1\uffff\u1f08\3\u1040\uffff"+
            "\u0150\3\u0170\uffff\u0080\3\u0080\uffff\u092e\3\u10d2\uffff"+
            "\u5200\3\u5900\uffff\u0200\3",
            "",
            "\1\3\5\uffff\1\4\5\uffff\12\3\7\uffff\32\3\4\uffff\1\3\1\uffff"+
            "\32\3\105\uffff\27\3\1\uffff\37\3\1\uffff\u1f08\3\u1040\uffff"+
            "\u0150\3\u0170\uffff\u0080\3\u0080\uffff\u092e\3\u10d2\uffff"+
            "\u5200\3\u5900\uffff\u0200\3",
            "\1\6\13\uffff\12\6\7\uffff\32\6\4\uffff\1\6\1\uffff\32\6\105"+
            "\uffff\27\6\1\uffff\37\6\1\uffff\u1f08\6\u1040\uffff\u0150\6"+
            "\u0170\uffff\u0080\6\u0080\uffff\u092e\6\u10d2\uffff\u5200\6"+
            "\u5900\uffff\u0200\6",
            "",
            "\1\6\5\uffff\1\4\5\uffff\12\6\7\uffff\32\6\4\uffff\1\6\1\uffff"+
            "\32\6\105\uffff\27\6\1\uffff\37\6\1\uffff\u1f08\6\u1040\uffff"+
            "\u0150\6\u0170\uffff\u0080\6\u0080\uffff\u092e\6\u10d2\uffff"+
            "\u5200\6\u5900\uffff\u0200\6",
            ""
    };

    static final short[] DFA31_eot = DFA.unpackEncodedString(DFA31_eotS);
    static final short[] DFA31_eof = DFA.unpackEncodedString(DFA31_eofS);
    static final char[] DFA31_min = DFA.unpackEncodedStringToUnsignedChars(DFA31_minS);
    static final char[] DFA31_max = DFA.unpackEncodedStringToUnsignedChars(DFA31_maxS);
    static final short[] DFA31_accept = DFA.unpackEncodedString(DFA31_acceptS);
    static final short[] DFA31_special = DFA.unpackEncodedString(DFA31_specialS);
    static final short[][] DFA31_transition;

    static {
        int numStates = DFA31_transitionS.length;
        DFA31_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA31_transition[i] = DFA.unpackEncodedString(DFA31_transitionS[i]);
        }
    }

    class DFA31 extends DFA {

        public DFA31(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 31;
            this.eot = DFA31_eot;
            this.eof = DFA31_eof;
            this.min = DFA31_min;
            this.max = DFA31_max;
            this.accept = DFA31_accept;
            this.special = DFA31_special;
            this.transition = DFA31_transition;
        }
        public String getDescription() {
            return "516:1: WildcardIdentifier : ( ID ( STAR ID2 )* STAR | STAR ID2 ( STAR ID2 )* ( STAR )? | ID ( STAR ID2 )+ );";
        }
    }
    static final String DFA34_eotS =
        "\4\uffff\14\45\2\uffff\1\72\5\uffff\1\73\1\100\3\uffff\1\102\2\105"+
        "\1\45\1\43\2\uffff\1\45\1\uffff\1\45\1\uffff\16\45\1\131\2\45\13"+
        "\uffff\1\142\1\uffff\1\105\1\uffff\1\143\4\45\1\150\12\45\1\163"+
        "\1\uffff\2\45\1\75\7\uffff\2\45\1\174\1\45\1\uffff\6\45\1\u0084"+
        "\1\u0085\1\45\1\u0087\1\uffff\1\45\1\u0089\4\uffff\1\45\1\u008d"+
        "\1\uffff\1\u008e\1\u008f\4\45\1\u0094\2\uffff\1\45\1\uffff\1\45"+
        "\3\uffff\1\45\3\uffff\2\45\1\u009b\1\u009c\1\uffff\1\45\1\u009e"+
        "\1\uffff\1\45\1\u00a1\1\45\2\uffff\1\u00a3\2\uffff\1\u00a4\1\uffff"+
        "\1\45\2\uffff\1\u00a6\1\uffff";
    static final String DFA34_eofS =
        "\u00a7\uffff";
    static final String DFA34_minS =
        "\1\11\3\uffff\14\44\2\uffff\1\60\5\uffff\2\0\3\uffff\1\44\2\56\1"+
        "\44\1\12\2\uffff\1\44\1\uffff\1\44\1\uffff\21\44\3\uffff\1\0\1\uffff"+
        "\1\0\5\uffff\1\60\1\uffff\1\60\1\uffff\21\44\1\uffff\2\44\1\47\4"+
        "\0\3\uffff\4\44\1\uffff\12\44\1\uffff\2\44\1\uffff\3\0\2\44\1\uffff"+
        "\7\44\2\uffff\1\44\1\uffff\1\44\1\uffff\2\0\1\44\3\uffff\4\44\1"+
        "\uffff\2\44\1\0\3\44\2\uffff\1\44\1\uffff\1\0\1\44\1\uffff\1\44"+
        "\2\uffff\1\44\1\uffff";
    static final String DFA34_maxS =
        "\1\ufaff\3\uffff\14\ufaff\2\uffff\1\71\5\uffff\2\ufffe\3\uffff\1"+
        "\ufaff\1\170\1\146\1\ufaff\1\12\2\uffff\1\ufaff\1\uffff\1\ufaff"+
        "\1\uffff\21\ufaff\3\uffff\1\ufffe\1\uffff\1\ufffe\5\uffff\1\146"+
        "\1\uffff\1\146\1\uffff\21\ufaff\1\uffff\2\ufaff\1\47\4\ufffe\3\uffff"+
        "\4\ufaff\1\uffff\12\ufaff\1\uffff\2\ufaff\1\uffff\3\ufffe\2\ufaff"+
        "\1\uffff\7\ufaff\2\uffff\1\ufaff\1\uffff\1\ufaff\1\uffff\2\ufffe"+
        "\1\ufaff\3\uffff\4\ufaff\1\uffff\2\ufaff\1\ufffe\3\ufaff\2\uffff"+
        "\1\ufaff\1\uffff\1\ufffe\1\ufaff\1\uffff\1\ufaff\2\uffff\1\ufaff"+
        "\1\uffff";
    static final String DFA34_acceptS =
        "\1\uffff\1\1\1\2\1\3\14\uffff\1\27\1\30\1\uffff\1\32\1\33\1\34\1"+
        "\35\1\36\2\uffff\1\41\1\42\1\43\5\uffff\2\57\1\uffff\1\56\1\uffff"+
        "\1\55\21\uffff\1\52\1\31\1\37\1\uffff\1\61\1\uffff\1\54\1\40\1\45"+
        "\1\44\1\47\1\uffff\1\50\1\uffff\1\60\21\uffff\1\46\7\uffff\1\53"+
        "\1\51\1\4\4\uffff\1\10\12\uffff\1\23\2\uffff\1\53\5\uffff\1\21\7"+
        "\uffff\1\15\1\16\1\uffff\1\20\1\uffff\1\26\3\uffff\1\6\1\7\1\24"+
        "\4\uffff\1\22\6\uffff\1\13\1\14\1\uffff\1\25\2\uffff\1\11\1\uffff"+
        "\1\17\1\5\1\uffff\1\12";
    static final String DFA34_specialS =
        "\u00a7\uffff}>";
    static final String[] DFA34_transitionS = {
            "\1\43\1\42\1\uffff\1\43\1\41\22\uffff\1\43\1\3\1\31\1\uffff"+
            "\1\40\1\uffff\1\2\1\30\1\26\1\27\1\35\1\uffff\1\34\1\uffff\1"+
            "\22\1\uffff\1\36\11\37\1\20\1\21\4\uffff\1\25\32\40\1\23\1\uffff"+
            "\1\24\1\uffff\1\40\1\uffff\1\5\1\14\1\6\1\16\1\40\1\7\2\40\1"+
            "\15\2\40\1\17\1\40\1\4\1\40\1\10\2\40\1\11\1\12\1\40\1\13\4"+
            "\40\1\32\1\1\1\33\102\uffff\27\40\1\uffff\37\40\1\uffff\u1f08"+
            "\40\u1040\uffff\u0150\40\u0170\uffff\u0080\40\u0080\uffff\u092e"+
            "\40\u10d2\uffff\u5200\40\u5900\uffff\u0200\40",
            "",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\44\25\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\46\1\50\30\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\7\46\1\52\3\46\1\51\16\46\105\uffff\27\46\1\uffff\37"+
            "\46\1\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080"+
            "\46\u0080\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200"+
            "\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\10\46\1\53\2\46\1\55\2\46\1\54\13\46\105\uffff\27\46"+
            "\1\uffff\37\46\1\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff"+
            "\u0080\46\u0080\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff"+
            "\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\21\46\1\56\2\46\1\57\5\46\105\uffff\27\46\1\uffff\37"+
            "\46\1\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080"+
            "\46\u0080\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200"+
            "\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\7\46\1\61\13\46\1\60\6\46\105\uffff\27\46\1\uffff\37"+
            "\46\1\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080"+
            "\46\u0080\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200"+
            "\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\7\46\1\62\22\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\63\13\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\64\11\46\1\65\1\46\105\uffff\27\46\1\uffff"+
            "\37\46\1\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080"+
            "\46\u0080\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200"+
            "\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\15\46\1\66\14\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\67\13\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\70\13\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "",
            "\12\71",
            "",
            "",
            "",
            "",
            "",
            "\47\76\1\75\64\76\1\74\uffa2\76",
            "\uffff\77",
            "",
            "",
            "",
            "\1\47\5\uffff\1\101\5\uffff\12\47\7\uffff\32\47\4\uffff\1\47"+
            "\1\uffff\32\47\105\uffff\27\47\1\uffff\37\47\1\uffff\u1f08\47"+
            "\u1040\uffff\u0150\47\u0170\uffff\u0080\47\u0080\uffff\u092e"+
            "\47\u10d2\uffff\u5200\47\u5900\uffff\u0200\47",
            "\1\71\1\uffff\10\104\2\71\12\uffff\3\71\21\uffff\1\103\13\uffff"+
            "\3\71\21\uffff\1\103",
            "\1\71\1\uffff\12\106\12\uffff\3\71\35\uffff\3\71",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\107",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\26\46\1\110\3\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\22\46\1\111\7\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\112\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08"+
            "\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\113\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08"+
            "\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\15\46\1\114\14\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\21\46\1\115\10\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\116\13\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\10\46\1\117\5\46\1\120\13\46\105\uffff\27\46\1\uffff"+
            "\37\46\1\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080"+
            "\46\u0080\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200"+
            "\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\46\1\121\30\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\122\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08"+
            "\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\123\13\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\10\46\1\124\21\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\10\46\1\125\21\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\16\46\1\126\13\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\127\6\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\130\6\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\24\46\1\132\5\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\15\46\1\133\14\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "",
            "",
            "\42\75\1\137\4\75\1\134\10\75\4\136\4\140\44\75\1\137\5\75"+
            "\1\137\3\75\1\137\7\75\1\137\3\75\1\137\1\75\1\137\1\135\uff89"+
            "\75",
            "",
            "\47\75\1\141\uffd7\75",
            "",
            "",
            "",
            "",
            "",
            "\10\104\2\71\12\uffff\3\71\35\uffff\3\71",
            "",
            "\12\106\12\uffff\3\71\35\uffff\3\71",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\144\6\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\22\46\1\145\7\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\21\46\1\146\10\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\147\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08"+
            "\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\151\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08"+
            "\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\25\46\1\152\4\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\153\6\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\13\46\1\154\16\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\155\6\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\21\46\1\156\10\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\22\46\1\157\7\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\3\46\1\160\26\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\13\46\1\161\16\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\162\25\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\46\1\164\30\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\6\46\1\165\23\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\166",
            "\60\75\12\167\7\75\6\167\32\75\6\167\uff98\75",
            "\47\75\1\141\10\75\10\170\uffc7\75",
            "\47\75\1\141\uffd7\75",
            "\47\75\1\141\10\75\10\171\uffc7\75",
            "",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\21\46\1\172\10\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\22\46\1\173\7\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\13\46\1\175\16\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\176\6\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\177\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08"+
            "\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\u0080\25\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\10\46\1\u0081\21\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\10\46\1\u0082\21\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\u0083\6\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\u0086\25\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\13\46\1\u0088\16\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\60\75\12\u008a\7\75\6\u008a\32\75\6\u008a\uff98\75",
            "\47\75\1\141\10\75\10\u008b\uffc7\75",
            "\47\75\1\141\uffd7\75",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\u008c\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\u0090\6\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\2\46\1\u0091\27\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\2\46\1\u0092\27\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\2\46\1\u0093\27\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\1\u0095\31\46\105\uffff\27\46\1\uffff\37\46\1\uffff"+
            "\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff"+
            "\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\u0096\25\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\60\75\12\u0097\7\75\6\u0097\32\75\6\u0097\uff98\75",
            "\47\75\1\141\uffd7\75",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\2\46\1\u0098\27\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\u0099\25\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\u009a\6\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\15\46\1\u009d\14\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\60\75\12\u009f\7\75\6\u009f\32\75\6\u009f\uff98\75",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\23\46\1\u00a0\6\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\4\46\1\u00a2\25\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\47\75\1\141\uffd7\75",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\3\46\1\u00a5\26\46\105\uffff\27\46\1\uffff\37\46\1"+
            "\uffff\u1f08\46\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080"+
            "\uffff\u092e\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            "",
            "",
            "\1\46\5\uffff\1\47\5\uffff\12\46\7\uffff\32\46\4\uffff\1\46"+
            "\1\uffff\32\46\105\uffff\27\46\1\uffff\37\46\1\uffff\u1f08\46"+
            "\u1040\uffff\u0150\46\u0170\uffff\u0080\46\u0080\uffff\u092e"+
            "\46\u10d2\uffff\u5200\46\u5900\uffff\u0200\46",
            ""
    };

    static final short[] DFA34_eot = DFA.unpackEncodedString(DFA34_eotS);
    static final short[] DFA34_eof = DFA.unpackEncodedString(DFA34_eofS);
    static final char[] DFA34_min = DFA.unpackEncodedStringToUnsignedChars(DFA34_minS);
    static final char[] DFA34_max = DFA.unpackEncodedStringToUnsignedChars(DFA34_maxS);
    static final short[] DFA34_accept = DFA.unpackEncodedString(DFA34_acceptS);
    static final short[] DFA34_special = DFA.unpackEncodedString(DFA34_specialS);
    static final short[][] DFA34_transition;

    static {
        int numStates = DFA34_transitionS.length;
        DFA34_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA34_transition[i] = DFA.unpackEncodedString(DFA34_transitionS[i]);
        }
    }

    class DFA34 extends DFA {

        public DFA34(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 34;
            this.eot = DFA34_eot;
            this.eof = DFA34_eof;
            this.min = DFA34_min;
            this.max = DFA34_max;
            this.accept = DFA34_accept;
            this.special = DFA34_special;
            this.transition = DFA34_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__104 | T__105 | T__106 | T__107 | ABSTRACT | CLASS | FINAL | FOR | PRIVATE | PROTECTED | PUBLIC | STATIC | THIS | VOID | BOOLEAN | BYTE | CHAR | SHORT | INT | FLOAT | DOUBLE | LONG | COLON | SEMI | DOT | LBRACKET | RBRACKET | AT | LPAREN | RPAREN | QUOTE | DQUOTE | LBRACE | RBRACE | COMMA | STAR | DSTAR | IN | HexLiteral | DecimalLiteral | OctalLiteral | FloatingPointLiteral | CharacterLiteral | StringLiteral | WildcardIdentifier | IDENTIFIER | WS | NEWLINE | PromiseStringLiteral );";
        }
    }
 

}
