// Generated code.  Do *NOT* edit!
package edu.cmu.cs.crystal.java.operator;

import com.surelogic.parse.*;
import java.util.*;
import com.surelogic.ast.java.operator.*;
import edu.cmu.cs.fluid.java.*;
import edu.cmu.cs.crystal.java.operator.*;

public abstract class AllocationExpressionNode extends PrimaryExpressionNode implements IAllocationExpressionNode  { 
  // Constructors
  /**
   * Lists passed in as arguments must be @unique
   */
  public AllocationExpressionNode(int offset) {
    super(offset);
  }

  @Override
  public BaseNodeType getNodeType() {
    return BaseNodeType.ALLOCATION_EXPR;
  }

}

