// Generated code.  Do *NOT* edit!
package edu.cmu.cs.crystal.java.operator;

import com.surelogic.ast.*;
import com.surelogic.parse.*;
import java.util.*;
import com.surelogic.ast.java.operator.*;
import edu.cmu.cs.fluid.java.*;
import edu.cmu.cs.crystal.java.operator.*;

public abstract class AllocationCallExpressionNode extends AllocationExpressionNode implements IAllocationCallExpressionNode  { 
  // Fields

  // Constructors
  /**
   * Lists passed in as arguments must be @unique
   */
  public AllocationCallExpressionNode(int offset) {
    super(offset);
  }

  @Override
  public BaseNodeType getNodeType() {
    return BaseNodeType.ALLOCATION_CALL_EXPR;
  }

  public boolean bindingExists() {
    return JavaBinder.getBaseBinder().isResolvable(this);
  }

  public IConstructorBinding resolveBinding() {
    return JavaBinder.getBaseBinder().resolve(this);
  }

}

