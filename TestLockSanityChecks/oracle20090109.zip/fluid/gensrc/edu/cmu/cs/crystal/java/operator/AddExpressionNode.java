// Generated code.  Do *NOT* edit!
package edu.cmu.cs.crystal.java.operator;

import com.surelogic.parse.*;
import java.util.*;
import com.surelogic.ast.java.operator.*;
import edu.cmu.cs.fluid.java.*;
import edu.cmu.cs.crystal.java.operator.*;

public class AddExpressionNode extends ArithBinopExpressionNode implements IAddExpressionNode  { 
  // Fields
  private final IExpressionNode op1;
  private final IExpressionNode op2;

  public static final AbstractSingleNodeFactory factory =
    new AbstractSingleNodeFactory("AddExpression") {
      @SuppressWarnings("unchecked")
      public IJavaOperatorNode create(String _token, int _start, int _stop,
                                      int _mods, String _id, int _dims, List<IJavaOperatorNode> _kids) {
        IExpressionNode op1 =  (IExpressionNode) _kids.get(0);
        IExpressionNode op2 =  (IExpressionNode) _kids.get(1);
        return new AddExpressionNode (_start,
          op1,
          op2        );
      }
    };

  // Constructors
  /**
   * Lists passed in as arguments must be @unique
   */
  public AddExpressionNode(int offset,
                           IExpressionNode op1,
                           IExpressionNode op2) {
    super(offset);
    if (op1 == null) { throw new IllegalArgumentException("op1 is null"); }
    ((JavaOperatorNode) op1).setParent(this);
    this.op1 = op1;
    if (op2 == null) { throw new IllegalArgumentException("op2 is null"); }
    ((JavaOperatorNode) op2).setParent(this);
    this.op2 = op2;
  }

  public String unparse(boolean debug, int indent) {
    StringBuilder sb = new StringBuilder();
    indent(sb, indent);
    sb.append("AddExpression\n");
    sb.append(getOp1().unparse(debug, indent+2));
    sb.append(getOp2().unparse(debug, indent+2));
    return sb.toString();
  }

  @Override
  public BaseNodeType getNodeType() {
    return BaseNodeType.ADD_EXPR;
  }

  /**
   * @return A non-null node
   */
  public IExpressionNode getOp1() {
    return op1;
  }
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp2() {
    return op2;
  }
  public <T> T accept(INodeVisitor<T> visitor) {
    IBaseNodeVisitor<T> v = (IBaseNodeVisitor<T>) visitor;
    return v.visit(this);
  }
}

