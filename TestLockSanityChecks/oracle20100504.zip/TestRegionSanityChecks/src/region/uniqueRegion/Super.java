package region.uniqueRegion;

import com.surelogic.Region;

@Region("SuperRegion")
public class Super {

}
