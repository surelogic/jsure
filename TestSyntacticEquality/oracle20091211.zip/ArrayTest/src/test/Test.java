package test;

public class Test {
  static final int SIZE = 1;
  public static void main(String[] args) {
    final boolean[] zarray = new boolean[SIZE];
    final byte[] barray = new byte[SIZE];
    final char[] carray = new char[SIZE];
    final short[] sarray = new short[SIZE];
    final int[] iarray = new int[SIZE];
    final long[] larray = new long[SIZE];
    final float[] farray = new float[SIZE];
    final double[] darray = new double[SIZE];
    final Object[] oarray = new Object[SIZE];
    
    for (int i = 0; i < SIZE; i++) {
      zarray[i] = false;
      barray[i] = 0;
      carray[i] = 0;
      sarray[i] = 0;
      iarray[i] = 0;
      larray[i] = 0;
      farray[i] = 0.0f;
      darray[i] = 0.0;
      oarray[i] = null;
    }
    
    for (int i = 0; i < SIZE; i++) {
      final boolean z = zarray[i];
      final byte b = barray[i];
      final char c = carray[i];
      final short s = sarray[i];
      final int ii = iarray[i];
      final long l = larray[i];
      final float f = farray[i];
      final double d = darray[i];
      final Object o = oarray[i];
    }
  }
}
