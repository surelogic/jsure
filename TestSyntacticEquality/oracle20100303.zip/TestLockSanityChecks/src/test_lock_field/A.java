package test_lock_field;

public class A {
  final Object fieldFromA = new Object();
  Object badFieldFromA = new Object();
}
