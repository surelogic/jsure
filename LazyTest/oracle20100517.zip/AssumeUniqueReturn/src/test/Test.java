package test;

import com.surelogic.Assume;
import com.surelogic.RegionLock;
import com.surelogic.Unique;

@RegionLock("L is this protects Instance")
@Assume("@Unique(return) for new() in Other")
public class Test extends Other {
  private int x;

  @Unique("return")
  public Test() {
    super();
    x = 10;
  }

  public synchronized int get() {
    return x;
  }
}

class Other {
  public Other() {
    super();
  }
}
