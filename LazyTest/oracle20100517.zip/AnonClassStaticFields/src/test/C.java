package test;

import com.surelogic.RegionLock;

@RegionLock("L is this protects Instance")
public class C {
	private int v;
	
	public Runnable getRunnable() {
		return new Runnable() {
			private static final int CONST = 10;
			
			private int out;
			
			public void run() {
				out = v * CONST;
			}
		};
	}
}
