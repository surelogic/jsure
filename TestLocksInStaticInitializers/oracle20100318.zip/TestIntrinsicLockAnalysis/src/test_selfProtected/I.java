package test_selfProtected;

import com.surelogic.ThreadSafe;

@ThreadSafe
public interface I {

}
