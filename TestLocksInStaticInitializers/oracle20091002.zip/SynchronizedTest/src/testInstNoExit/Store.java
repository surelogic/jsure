package testInstNoExit;

class Store {
  public static void beforeStart(final Object o, final boolean a, final boolean b, Phantom c, int l) {}
  public static void afterStart(final Object o, Phantom c, int l) {}
  public static void afterEnd(final Object o, Phantom c, int l) {}
}
