
public interface Bar {
	public void destroy() ;

	public boolean isDestroyed();
	
	public static final Thread THREAD = new Thread();
}
