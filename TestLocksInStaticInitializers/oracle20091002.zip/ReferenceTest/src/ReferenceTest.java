import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;




/*
 * Extracted from StringInterner in the Azureus project.
 */
public class ReferenceTest {

	private static final int SCHEDULED_CLEANUP_INTERVAL = 60*1000;
	
	private static final boolean TRACE_CLEANUP = false;
	private static final boolean TRACE_MULTIHITS = false;
	
	
	private static final int IMMEDIATE_CLEANUP_TRIGGER = 2000;
	private static final int IMMEDIATE_CLEANUP_GOAL = 1500;
	private static final int SCHEDULED_CLEANUP_TRIGGER = 1500;
	private static final int SCHEDULED_CLEANUP_GOAL = 1000;	
	private static final int SCHEDULED_AGING_THRESHOLD = 750;
	
	
	public static List<WeakReference<String>> lst = new ArrayList<WeakReference<String>>();
	private static final ReferenceQueue<String> managedRefQueue = new ReferenceQueue<String>();
	private static final LightHashSet managedInterningSet = new LightHashSet();
	
	
	private final static Comparator	savingsComp	= new Comparator()
	{
		public int compare(Object o1, Object o2) {
			WeakWeightedEntry w1 = (WeakWeightedEntry) o1;
			WeakWeightedEntry w2 = (WeakWeightedEntry) o2;
			return w1.hits * w1.size - w2.hits * w2.size;
		}
	};

	
	public static void main(String[] args) {
		System.out.println(addReferences());
		System.gc();
		sanitize(true);
	}
	
	private static String addReferences() {
		
		String s = new String("abcd");
		for(int i = 0; i < 5; i++) {
			intern(s);
			s = new String("abcd");
		}
		return s;
	}
	
	private static class WeakStringEntry extends WeakWeightedEntry {
		public WeakStringEntry(String entry)
		{
			// string object with 2 fields, char-array object
			super(entry, entry.hashCode(), 16 + 8 + entry.length() * 2);
		}

		public String getString() {
			return (String) get();
		}

		public String toString() {
			return super.toString() + " " + getString();
		}
	}
	private static abstract class WeakWeightedEntry extends WeakEntry<String> implements Bar {
		final short	size;
		short		hits;

		public WeakWeightedEntry(String o, int hash, int size)
		{
			super(o, managedRefQueue,hash);
			this.size = (short) (size & 0x7FFF);
		}

		public void incHits() {
			if (hits < Short.MAX_VALUE)
				hits++;
		}

		public void decHits() {
			if (hits > 0)
				hits--;
		}

		public String toString() {
			return this.getClass().getName().replaceAll("^.*\\..\\w+$", "") + " h=" + (int) hits + ";s=" + (int) size;
		}

		public void destroy() {
			hits = -1;
		}

		public boolean isDestroyed() {
			return hits == -1;
		}
	}
	private static class WeakEntry<T> extends WeakReference<T> {
		private final int	hash;

		protected WeakEntry(T o, ReferenceQueue<T> q, int hash)
		{
			super(o, q);
			this.hash = hash;
		}

		public WeakEntry(T o, ReferenceQueue<T> q)
		{
			super(o, q);
			this.hash = o.hashCode();
		}

		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj instanceof WeakEntry)
			{
				Object myObj = get();
				Object otherObj = ((WeakEntry<?>) obj).get();
				return myObj == null ? false : myObj.equals(otherObj);
			}
			return false;
		}

		public final int hashCode() {
			return hash;
		}
	}
	public static String intern(String toIntern) {
		
		if(toIntern == null)
			return null;
		
		String internedString;
		
		WeakStringEntry checkEntry = new WeakStringEntry(toIntern);
		
		synchronized( managedInterningSet ){

			sanitize(false);

			WeakStringEntry internedEntry = (WeakStringEntry) managedInterningSet.get(checkEntry);

			if (internedEntry == null || (internedString = internedEntry.getString()) == null)
			{
				internedString = toIntern;
				if(!managedInterningSet.add(checkEntry))
					System.out.println("unexpected modification");  // should not happen
			} else
			{
				internedEntry.incHits();
				checkEntry.destroy();
				if(TRACE_MULTIHITS && internedEntry.hits % 10 == 0)
					System.out.println("multihit "+internedEntry);
			}

		}
		// should not happen
		if(!toIntern.equals(internedString))
			System.err.println("mismatch");
		
		return internedString;
	}
	
	private static void sanitize(boolean scheduled)
	{
		synchronized( managedInterningSet ){
			
			WeakWeightedEntry ref;
			while((ref = (WeakWeightedEntry)(managedRefQueue.poll())) != null)
			{
				if(!ref.isDestroyed())
				{
					managedInterningSet.remove(ref);
					if(TRACE_CLEANUP && ref.hits > 30)
						System.out.println("queue remove:"+ref);
				} else
				{// should not happen
					System.err.println("double removal "+ref);					
				}
			}
				
			
			int currentSetSize = managedInterningSet.size();
			
			aging:
			{
				cleanup:
				{
					// unscheduled cleanup/aging only in case of emergency
					if (currentSetSize < IMMEDIATE_CLEANUP_TRIGGER && !scheduled)
						break aging;
					
					if (TRACE_CLEANUP)
						System.out.println("Doing cleanup " + currentSetSize);
					
					ArrayList remaining = new ArrayList();
					
					// remove objects that aren't shared by multiple holders first (interning is useless)
					for (Iterator it = managedInterningSet.iterator(); it.hasNext();)
					{
						if (managedInterningSet.size() < IMMEDIATE_CLEANUP_GOAL && !scheduled)
							break aging;
						WeakWeightedEntry entry = (WeakWeightedEntry) it.next();
						if (entry.hits == 0)
						{
							if (TRACE_CLEANUP)
								System.out.println("0-remove: " + entry);
							it.remove();
						} else
							remaining.add(entry);
					}
					
					currentSetSize = managedInterningSet.size();
					if (currentSetSize < SCHEDULED_CLEANUP_TRIGGER && scheduled)
						break cleanup;
					if (currentSetSize < IMMEDIATE_CLEANUP_GOAL && !scheduled)
						break aging;
					
					Collections.sort(remaining, savingsComp);
					// remove those objects that saved the least amount first
					weightedRemove: for (int i = 0; i < remaining.size(); i++)
					{
						currentSetSize = managedInterningSet.size();
						if (currentSetSize < SCHEDULED_CLEANUP_GOAL && scheduled)
							break weightedRemove;
						if (currentSetSize < IMMEDIATE_CLEANUP_GOAL && !scheduled)
							break aging;
						WeakWeightedEntry entry = (WeakWeightedEntry) remaining.get(i);
						if (TRACE_CLEANUP)
							System.out.println("weighted remove: " + entry);
						managedInterningSet.remove(entry);
					}
				}
			
			
				currentSetSize = managedInterningSet.size();
				if (currentSetSize < SCHEDULED_AGING_THRESHOLD && scheduled)
					break aging;
				if (currentSetSize < IMMEDIATE_CLEANUP_GOAL && !scheduled)
					break aging;
				for (Iterator it = managedInterningSet.iterator(); it.hasNext();)
					((WeakWeightedEntry) it.next()).decHits();
			}
			
			if(TRACE_CLEANUP && scheduled)
			{
				List weightTraceSorted = new ArrayList(managedInterningSet);
				Collections.sort(weightTraceSorted,savingsComp);
				System.out.println("Remaining elements after cleanup:");
				for(Iterator it = weightTraceSorted.iterator();it.hasNext();)
					System.out.println("\t"+it.next());
			}
			
				
		}
	}

}
