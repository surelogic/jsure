package edu.afit.planetbaron.protocol;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import edu.afit.planetbaron.util.Common;

public final class GameStateUpdate extends ServerResponse {

  private final List<Report> f_reports = new LinkedList<Report>();

  public GameStateUpdate(List<Report> reports) {
    assert reports != null;
    f_reports.addAll(reports);
    for (Report r : f_reports)
      r.setParent(this);
  }

  public List<Report> getReports() {
    return Collections.unmodifiableList(f_reports);
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    if (v.visit(this)) {
      for (Report r : f_reports)
        r.accept(v);
    }
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    StringBuilder r = new StringBuilder();
    for (Report rp : f_reports)
      r.append(rp + Common.NL);
    return r.toString() + "OK";
  }
}
