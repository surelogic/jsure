package edu.afit.planetbaron.protocol;

import edu.afit.planetbaron.game.Location;
import edu.afit.planetbaron.game.Ship;

public final class ShipReport extends Report {

  private final StringLiteral f_name;

  private final LocationLiteral f_location;

  /**
   * Will be <code>null</code> if the ship is not moving.
   */
  private final LocationLiteral f_destination;

  private final int f_turnsMoving;

  public ShipReport(StringLiteral name, LocationLiteral location,
      LocationLiteral destination, int turnsMoving) {
    assert name != null && location != null;
    f_name = name;
    f_name.setParent(this);
    f_location = location;
    f_location.setParent(this);
    f_destination = destination;
    if (f_destination != null)
      f_destination.setParent(this);
    f_turnsMoving = turnsMoving;
  }

  public ShipReport(String name, Location location, Location destination,
      int turnsMoving) {
    this(new StringLiteral(name), new LocationLiteral(location),
        (destination == null ? null : new LocationLiteral(destination)),
        turnsMoving);
  }

  public ShipReport(StringLiteral name, LocationLiteral location) {
    this(name, location, null, 0);
  }

  public ShipReport(String name, Location location) {
    this(new StringLiteral(name), new LocationLiteral(location));
  }

  public ShipReport(Ship ship) {
    this(ship.getName(), ship.getLocation(), (ship.isMoving() ? ship
        .getDestination() : null), ship.getTurnsMoving());
  }

  public String getName() {
    return f_name.getValue();
  }

  public Location getLocation() {
    return f_location.getLocation();
  }

  public boolean isMoving() {
    return f_destination != null;
  }

  /**
   * 
   * @return the destination location or <code>null</code> if the ship is not
   *         moving.
   */
  public Location getDestination() {
    return isMoving() ? f_destination.getLocation() : null;
  }

  public int getTurnsMoving() {
    return f_turnsMoving;
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    if (v.visit(this)) {
      f_name.accept(v);
      f_location.accept(v);
      if (f_destination != null)
        f_destination.accept(v);
    }
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return "ship "
        + f_name
        + " "
        + f_location
        + (isMoving() ? " moving to " + f_destination
            + (f_turnsMoving > 0 ? " for " + f_turnsMoving + " turns" : "")
            : "");
  }
}
