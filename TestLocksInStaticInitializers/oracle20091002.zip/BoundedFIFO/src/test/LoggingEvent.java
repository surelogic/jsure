package test;

public class LoggingEvent {
  // This class is not interesting
}
