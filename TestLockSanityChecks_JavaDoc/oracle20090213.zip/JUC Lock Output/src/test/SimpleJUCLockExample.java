package test;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;

@RegionLock("L1 is lock protects Instance")
public class SimpleJUCLockExample {
  public final Lock lock = new ReentrantLock(); 
  private int f;
  private int g;
  
  public int getF() {
    lock.lock();
    try {
      // Good
      return f;
    } finally {
      lock.unlock();
    }
  }
  
  public boolean setF(final int v) {
    if (lock.tryLock()) {
      try {
        f = v;
      } finally {
        lock.unlock();
      }
      return true;
    } else {
      return false;
    }
  }
  
  @RequiresLock("L1")
  public void doStuff() {
    // Good
    f = 0;
  }
  
  public int getG() {
    // Bad
    return g;
  }
}
