package x.y.z;

public class C1 {
  public static void main(String[] args) {
    // do nothing
  }
}
