package test.p2;

import test.p1.C;

public class D extends C {
  public int g;
  
  public void doStuff() {
    f = 1;
    g = 2;
  }
}
