package test;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.surelogic.RegionEffects;
import com.surelogic.RegionLock;

@RegionLock("L is lock protects f")
public class D {
  public final Lock lock = new ReentrantLock();
  public int f;
  
  public class S {
  }
  
  @RegionEffects("none")
  public void stuff2(final D other) {
    other.lock.lock();
    try {
      final S s = other. new S() {
        {
          D.this.f = 10; // Lock "held as" other
        }
      };
    } finally {
      other.lock.unlock();
    }
  }
}
