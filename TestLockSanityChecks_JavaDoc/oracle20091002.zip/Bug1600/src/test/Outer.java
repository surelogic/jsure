package test;

public class Outer {
	static enum E {
		FOO {
			static final String s = "fred";
			
			@Override
			public String method() {
				return s;
			}
		};
		
		public abstract String method();
	}
}
