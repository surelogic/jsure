package edu.afit.planetbaron.protocol;

public abstract class ConsoleOnlyCommand extends ServerCommand {
}
