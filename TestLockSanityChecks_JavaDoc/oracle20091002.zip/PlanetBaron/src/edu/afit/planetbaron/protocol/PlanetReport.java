package edu.afit.planetbaron.protocol;

import edu.afit.planetbaron.game.Location;
import edu.afit.planetbaron.game.Planet;

public final class PlanetReport extends Report {

  private final StringLiteral f_name;

  private final LocationLiteral f_location;

  /**
   * Will be <code>null</code> if the planet is not owned.
   */
  private final StringLiteral f_owner;

  public PlanetReport(StringLiteral name, LocationLiteral location,
      StringLiteral owner) {
    assert name != null && location != null;
    f_name = name;
    f_name.setParent(this);
    f_location = location;
    f_location.setParent(this);
    f_owner = owner;
    if (f_owner != null)
      f_owner.setParent(this);
  }

  public PlanetReport(String name, Location location, String owner) {
    this(new StringLiteral(name), new LocationLiteral(location),
        (owner == null ? null : new StringLiteral(owner)));
  }

  public PlanetReport(StringLiteral name, LocationLiteral location) {
    this(name, location, null);
  }

  public PlanetReport(String name, Location location) {
    this(new StringLiteral(name), new LocationLiteral(location));
  }

  public PlanetReport(Planet planet) {
    this(planet.getName(), planet.getLocation(),
        (planet.getOwner() == null ? null : planet.getOwner().getName()));
  }

  public String getName() {
    return f_name.getValue();
  }

  public Location getLocation() {
    return f_location.getLocation();
  }

  public boolean hasOwner() {
    return f_owner != null;
  }

  public String getOwnerName() {
    return hasOwner() ? f_owner.getValue() : "";
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    if (v.visit(this)) {
      f_name.accept(v);
      f_location.accept(v);
      if (f_owner != null)
        f_owner.accept(v);
    }
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return "planet " + f_name + " " + f_location
        + (hasOwner() ? " owned by " + f_owner : "");
  }
}
