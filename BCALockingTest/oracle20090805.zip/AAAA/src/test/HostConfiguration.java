/*
 * $Header: /home/jerenkrantz/tmp/commons/commons-convert/cvs/home/cvs/jakarta-commons//httpclient/src/java/org/apache/commons/httpclient/HostConfiguration.java,v 1.23 2005/01/14 21:16:40 olegk Exp $
 * $Revision: 510585 $
 * $Date: 2007-02-22 17:52:16 +0100 (Thu, 22 Feb 2007) $
 *
 * ====================================================================
 *
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 *
 */

package test;

import com.surelogic.Borrowed;
import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.RegionLock;
import com.surelogic.SingleThreaded;

import java.net.InetAddress;

@Region("private Region")
@RegionLock("Lock is this protects Region"/*is INCONSISTENT*/)
public class HostConfiguration implements Cloneable {

	/**
	 * A value to represent any host configuration, instead of using something
	 * like <code>null</code>. This value should be treated as immutable and
	 * only used in lookups and other such places to represent "any" host
	 * config.
	 */
	public static final HostConfiguration ANY_HOST_CONFIGURATION = new HostConfiguration();

	/** The host to use. */
	@InRegion("Region")
	private Object host;

	/** The host name of the proxy server */
	@InRegion("Region")
	private Object proxyHost;

	/**
	 * The local address to use when creating the socket, or null to use the
	 * default
	 */
	@InRegion("Region")
	private InetAddress localAddress;


	/**
	 * Constructor for HostConfiguration.
	 */
	@SingleThreaded
	@Borrowed("this"/*is CONSISTENT*/)
	public HostConfiguration() {
		super();
	}

	
	public synchronized boolean equals(final Object o) {
		if (o instanceof HostConfiguration) {
			// shortcut if we're comparing with ourselves
			if (o == this) {
				return true;
			}
			HostConfiguration that = (HostConfiguration) o;
			synchronized (that) {
				return LangUtils.equals(this.host, that.host);
//						&& LangUtils.equals(this.proxyHost, that.proxyHost)
//						&& LangUtils.equals(this.localAddress,
//								that.localAddress);
			}
		} else {
			return false;
		}

	}
}
