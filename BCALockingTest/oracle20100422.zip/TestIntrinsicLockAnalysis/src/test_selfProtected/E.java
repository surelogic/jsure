package test_selfProtected;

/**
 * Is self-protected because D is
 */
public class E extends D {

}
