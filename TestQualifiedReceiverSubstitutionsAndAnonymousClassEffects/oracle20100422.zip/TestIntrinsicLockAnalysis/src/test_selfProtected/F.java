package test_selfProtected;

/**
 * Still says nothing about being self protected, but gets it from
 * interface I
 */
public class F extends C implements I {

}
