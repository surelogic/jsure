package test;

import com.surelogic.RegionEffects;
import com.surelogic.RegionLock;

@RegionLock("L is this protects f")
public class C {
  public int f;
  
  public class S {
  }
  
  @RegionEffects("none")
  public void stuff2(final C other) {
    synchronized (other) {
      final S s = other. new S() {
        {
          C.this.f = 10; // Lock "held as" other
        }
      };
    }
  }
}
