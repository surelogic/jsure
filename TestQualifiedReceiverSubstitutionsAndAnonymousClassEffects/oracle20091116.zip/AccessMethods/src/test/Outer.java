package test;

public class Outer {
  public int pubField;
  protected int protField;
  int defField;
  private int privField;
  
  public void doStuff() {
    pubField = 1;
    protField = 2;
    defField = 3;
    privField = 4;
  }
  
  private void privateMethod(final int v) {
    privField = v;
  }
  
  private class Inner {
    public void doStuff() {
      pubField = 10;
      protField = 20;
      defField = 30;
      privField = 40;
      privateMethod(50);
    }
  }
  
  public static void main(final String[] args) {
    final Outer o = new Outer();
    o.doStuff();
    final Inner i = o. new Inner();
    i.doStuff();    
  }
}
