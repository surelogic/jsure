package common;

public final class Common {
  private Common() {
    // nothing
  }
  
  public static final int START = 25000; //2500000;
  
  
  public static void staticMethod(int v) {}
  
  public static void callsStaticMethod() {
    staticMethod(1);
    staticMethod(2);
    staticMethod(3);
  }
}
