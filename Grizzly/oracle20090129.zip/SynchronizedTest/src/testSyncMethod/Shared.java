package testSyncMethod;

class Shared {
  private boolean hasForB = false;
  private int fromAforB;
  
  private boolean hasForA = false;
  private int fromBforA;
  
  public synchronized void forB(final int v) {
    fromAforB = v;
    hasForB = true;
    this.notifyAll();
  }

  public synchronized void forA(final int v) {
    fromBforA = v;
    hasForA = true;
    this.notifyAll();
  }

  public synchronized int fromB() throws InterruptedException {
    while (!hasForA) {
      this.wait();
    }
    hasForA = false;
    return fromBforA;
  }

  public synchronized int fromA() throws InterruptedException {
    while (!hasForB) {
      this.wait();
    }
    hasForB = false;
    return fromAforB;
  }
}
