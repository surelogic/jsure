package com.surelogic.common.export;

/**
 * 
 */
public interface ITableExporter {

	/**
	 * Exports the table data.
	 */
	void export() throws Exception;
}
