// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

/**
 */
@SuppressWarnings("deprecation")
public class DescendingPromiseVisitor<T> extends DescendingBaseVisitor<T> implements IPromiseNodeVisitor<T> {
  public DescendingPromiseVisitor(T defaultVal) {
    super(defaultVal);
  }

  public DescendingPromiseVisitor() {
    super(null);
  }

  public T visit(IColorRenameNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getColor()));
    rv = combineResults(rv, doAccept(n.getCSpec()));
    return rv;
  }
  public T visit(IColorRequireNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCSpec()));
    return rv;
  }
  public T visit(IColorCardNNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorAndParenNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAndElemsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IQualifiedRegionNameNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(IInitDeclarationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IEnclosingModuleNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getModulesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ITaintedNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IStartsSpecificationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IAndTargetNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTarget1()));
    rv = combineResults(rv, doAccept(n.getTarget2()));
    return rv;
  }
  public T visit(IColorNameNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorDeclarationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getColorList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IConstructorDeclPatternNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getSigList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getThrowsCList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IReturnValueDeclarationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorCard1Node n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorAndNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getAndElemsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IInvariantDeclarationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCond()));
    return rv;
  }
  public T visit(IScopedModuleNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTargets()));
    return rv;
  }
  public T visit(IColorExprNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IModuleNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(ITransparentNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IAPINode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorIncompatibleNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getColorList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IRegionMappingNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getFrom()));
    rv = combineResults(rv, doAccept(n.getTo()));
    return rv;
  }
  public T visit(IColorRevokeNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getColorList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ISubtypedBySpecificationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(INotTaintedNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IEffectSpecificationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getContext()));
    rv = combineResults(rv, doAccept(n.getRegion()));
    return rv;
  }
  public T visit(IColorOrParenNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getOrElemsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IIntOrNNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IFieldDeclPatternNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getFtype()));
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(IColorConstrainedRegionsNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCSpec()));
    for(IJavaOperatorNode c : n.getCRegionsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IEffectsSpecificationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getEffectList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IMethodDeclPatternNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getRtype()));
    rv = combineResults(rv, doAccept(n.getType()));
    for(IJavaOperatorNode c : n.getSigList()) {
      rv = combineResults(rv, doAccept(c));
    }
    for(IJavaOperatorNode c : n.getThrowsCList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IColorOrNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getOrElemsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(ITypeDeclPatternNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorImportNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getItem()));
    return rv;
  }
  public T visit(IUsedBySpecificationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getTypesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IOrTargetNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTarget1()));
    rv = combineResults(rv, doAccept(n.getTarget2()));
    return rv;
  }
  public T visit(IAnyInstanceExpressionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getType()));
    return rv;
  }
  public T visit(INewRegionDeclarationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getParent()));
    return rv;
  }
  public T visit(IScopedPromiseNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTargets()));
    return rv;
  }
  public T visit(ITypeQualifierPatternNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IColorGrantNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getColorList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IColorContextNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCSpec()));
    return rv;
  }
  public T visit(IColorCardinalityNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getColor()));
    rv = combineResults(rv, doAccept(n.getCard()));
    return rv;
  }
  public T visit(IClassInitDeclarationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(INotTargetNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTarget()));
    return rv;
  }
  public T visit(IColorNoteNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getCnamesList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IRegionNameNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IFieldMappingsNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getFieldsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    rv = combineResults(rv, doAccept(n.getTo()));
    return rv;
  }
  public T visit(IConditionNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getCond()));
    return rv;
  }
  public T visit(IColorNotNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getTarget()));
    return rv;
  }
  public T visit(IColorizedRegionNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getCRegionsList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IReceiverDeclarationNode n) {
    T rv = defaultValue;
    return rv;
  }
  public T visit(IMappedRegionSpecificationNode n) {
    T rv = defaultValue;
    for(IJavaOperatorNode c : n.getMappingList()) {
      rv = combineResults(rv, doAccept(c));
    }
    return rv;
  }
  public T visit(IQualifiedReceiverDeclarationNode n) {
    T rv = defaultValue;
    rv = combineResults(rv, doAccept(n.getBase()));
    return rv;
  }
}
