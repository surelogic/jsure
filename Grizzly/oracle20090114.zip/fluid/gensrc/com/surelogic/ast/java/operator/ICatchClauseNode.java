// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "catch"
 *    "("
 *    <paren>
 *    param : IParameterDeclarationNode
 *    </paren>
 *    ")"
 *    <catch>
 *    body : IBlockStatementNode
 *    </catch>
 * 
 */
public interface ICatchClauseNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IParameterDeclarationNode getParam();
  /**
   * @return A non-null node
   */
  public IBlockStatementNode getBody();
}

