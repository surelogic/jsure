// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    cond : IExpressionNode
 *    "?"
 *    iftrue : IExpressionNode
 *    ":"
 *    iffalse : IExpressionNode
 * 
 */
public interface IConditionalExpressionNode extends IExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getCond();
  /**
   * @return A non-null node
   */
  public IExpressionNode getIftrue();
  /**
   * @return A non-null node
   */
  public IExpressionNode getIffalse();
}

