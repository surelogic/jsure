// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    type : ITypeNode
 *    varsList : List<IVariableDeclaratorNode>
 *    <>
 *    ";"
 * 
 * Computes the value of the 'id' attribute
 * 
 */
public interface IFieldDeclarationNode extends IVariableDeclListNode, IClassBodyDeclarationNode, IBinding { 
  public BaseNodeType getNodeType();
  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isStatic();
  public boolean isFinal();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IVariableDeclaratorNode> getVarsList();
}

