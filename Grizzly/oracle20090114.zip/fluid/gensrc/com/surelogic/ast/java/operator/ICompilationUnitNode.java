// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    pkg : IPackageDeclarationNode
 *    impsList : List<IImportDeclarationNode>
 *    declsList : List<ITypeDeclarationNode>
 * 
 */
public interface ICompilationUnitNode extends IJavaOperatorNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IPackageDeclarationNode getPkg();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IImportDeclarationNode> getImpsList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<ITypeDeclarationNode> getDeclsList();
}

