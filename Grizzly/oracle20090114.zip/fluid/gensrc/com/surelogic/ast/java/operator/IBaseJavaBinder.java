// Generated code.  Do *NOT* edit!
/**
 * Interface for resolving Java bindings and the like
 * <p>
 * Contains one resolve() method for each kind of name/call
 */
package com.surelogic.ast.java.operator;

import java.util.*;
import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

public interface IBaseJavaBinder extends IJavaBinder {
  public ISourceRefType resolveExtendsBound(ITypeFormalNode tf);

  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(ISomeFunctionCallNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IFunctionBinding resolve(ISomeFunctionCallNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IConstructorCallNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IConstructorBinding resolve(IConstructorCallNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(ISomeThisExpressionNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVariableBinding resolve(ISomeThisExpressionNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(ISomeThisExpressionNode node);

  /**
   * Gets the binding corresponding to the type of the SomeThisExpression
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public ISourceRefType resolveType(ISomeThisExpressionNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IClassTypeNode node);

  /**
   * Gets the binding corresponding to the type of the ClassType
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public ISourceRefType resolveType(IClassTypeNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IReturnTypeNode node);

  /**
   * Gets the binding corresponding to the type of the ReturnType
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IReturnTypeNode e);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IFieldRefNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVariableBinding resolve(IFieldRefNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IAllocationCallExpressionNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IConstructorBinding resolve(IAllocationCallExpressionNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(INullLiteralNode node);

  /**
   * Gets the binding corresponding to the type of the NullLiteral
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public INullType resolveType(INullLiteralNode e);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IThisExpressionNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVariableBinding resolve(IThisExpressionNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IThisExpressionNode node);

  /**
   * Gets the binding corresponding to the type of the ThisExpression
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public ISourceRefType resolveType(IThisExpressionNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IEnumConstantDeclarationNode node);

  /**
   * Gets the binding corresponding to the type of the EnumConstantDeclaration
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IEnumConstantDeclarationNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IVariableDeclaratorNode node);

  /**
   * Gets the binding corresponding to the type of the VariableDeclarator
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IVariableDeclaratorNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IParameterDeclarationNode node);

  /**
   * Gets the binding corresponding to the type of the ParameterDeclaration
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IParameterDeclarationNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IExpressionNode node);

  /**
   * Gets the binding corresponding to the type of the Expression
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IExpressionNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IEnumConstantClassDeclarationNode node);

  /**
   * Gets the binding corresponding to the type of the EnumConstantClassDeclaration
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IEnumConstantClassDeclarationNode e);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IReturnStatementNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVariableBinding resolve(IReturnStatementNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IReferenceTypeNode node);

  /**
   * Gets the binding corresponding to the type of the ReferenceType
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IReferenceType resolveType(IReferenceTypeNode e);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IAnnotationNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IAnnotationBinding resolve(IAnnotationNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IVariableUseExpressionNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVariableBinding resolve(IVariableUseExpressionNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IQualifiedThisExpressionNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVariableBinding resolve(IQualifiedThisExpressionNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IQualifiedThisExpressionNode node);

  /**
   * Gets the binding corresponding to the type of the QualifiedThisExpression
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public ISourceRefType resolveType(IQualifiedThisExpressionNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(INamedTypeNode node);

  /**
   * Gets the binding corresponding to the type of the NamedType
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public ISourceRefType resolveType(INamedTypeNode e);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(ICallNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IFunctionBinding resolve(ICallNode node);
  /**
   * @return true if there is a binding that corresponds
   * to the AST node
   */
  public boolean isResolvable(IMethodCallNode node);

  /**
   * @return A binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IMethodBinding resolve(IMethodCallNode node);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IPrimitiveTypeNode node);

  /**
   * Gets the binding corresponding to the type of the PrimitiveType
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IPrimitiveType resolveType(IPrimitiveTypeNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IVariableDeclarationNode node);

  /**
   * Gets the binding corresponding to the type of the VariableDeclaration
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IVariableDeclarationNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IMethodDeclarationNode node);

  /**
   * Gets the binding corresponding to the type of the MethodDeclaration
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IType resolveType(IMethodDeclarationNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(ITypeRefNode node);

  /**
   * Gets the binding corresponding to the type of the TypeRef
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public ISourceRefType resolveType(ITypeRefNode e);
  /**
   * @return true if there is a type that corresponds
   * to the AST node
   */
  public boolean isResolvableToType(IVoidTypeNode node);

  /**
   * Gets the binding corresponding to the type of the VoidType
   * @return A type binding object that contains the concrete declaration,
   * as well as any type context information required by Java 5 generics
   */
  public IVoidType resolveType(IVoidTypeNode e);
}
