// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * The class of expressions legal to start a constructor call.
 * The only legal things are "this" or "super".
 * 
 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 * This is an abstract node (i.e., never instantiated)

 */
public interface IConstructionObjectNode extends IPrimaryExpressionNode { 
  public BaseNodeType getNodeType();
}

