package com.surelogic.annotation.parse;

import com.surelogic.aast.java.*;
import com.surelogic.aast.promise.*;
import com.surelogic.parse.*;

public class FactoryRefs {
  public static void register(IASTFactory f) {
    TestResultNode.factory.register(f);
    LockDeclarationNode.factory.register(f);
    PolicyLockDeclarationNode.factory.register(f);
    QualifiedLockNameNode.factory.register(f);
    RegionNameNode.factory.register(f);
    QualifiedRegionNameNode.factory.register(f);
    QualifiedClassLockExpressionNode.factory.register(f);
    QualifiedThisExpressionNode.factory.register(f);
    ImplicitClassLockExpressionNode.factory.register(f);
    EffectSpecificationNode.factory.register(f);
    RequiresLockNode.factory.register(f);
    ReturnsLockNode.factory.register(f);
    InRegionNode.factory.register(f);
    AggregateNode.factory.register(f);
    IsLockNode.factory.register(f);
    BooleanTypeNode.factory.register(f);
    ByteTypeNode.factory.register(f);
    CharTypeNode.factory.register(f);
    ShortTypeNode.factory.register(f);
    IntTypeNode.factory.register(f);
    FloatTypeNode.factory.register(f);
    DoubleTypeNode.factory.register(f);
    LongTypeNode.factory.register(f);
    NamedTypeNode.factory.register(f);
    TypeRefNode.factory.register(f);
    ArrayTypeNode.factory.register(f);
    TypeQualifierPatternNode.factory.register(f);
    ThisExpressionNode.factory.register(f);
    SuperExpressionNode.factory.register(f);
    ReturnValueDeclarationNode.factory.register(f);
    FieldRefNode.factory.register(f);
    TypeExpressionNode.factory.register(f);
    VariableUseExpressionNode.factory.register(f);
    AnyInstanceExpressionNode.factory.register(f);
    ClassExpressionNode.factory.register(f);
    SimpleLockNameNode.factory.register(f);
    StartsSpecificationNode.factory.register(f);
    MappedRegionSpecificationNode.factory.register(f);
    RegionMappingNode.factory.register(f);
    NewRegionDeclarationNode.factory.register(f);
    ReadLockNode.factory.register(f);
    WriteLockNode.factory.register(f);
    ScopedPromiseNode.factory.register(f);
    AndTargetNode.factory.register(f);
    OrTargetNode.factory.register(f);
    NotTargetNode.factory.register(f);
    ConstructorDeclPatternNode.factory.register(f);
    MethodDeclPatternNode.factory.register(f);
    FieldDeclPatternNode.factory.register(f);
    TypeDeclPatternNode.factory.register(f);
    NamedTypePatternNode.factory.register(f);
  }
}
