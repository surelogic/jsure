package region.parentMustExist;

import com.surelogic.Region;

@Region("SuperRegion")
public class Super {

}
