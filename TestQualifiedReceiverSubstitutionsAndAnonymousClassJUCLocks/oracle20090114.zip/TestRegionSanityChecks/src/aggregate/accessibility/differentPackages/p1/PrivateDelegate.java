package aggregate.accessibility.differentPackages.p1;

import com.surelogic.Region;

@Region("private PrivateAgg")
public class PrivateDelegate {
}
