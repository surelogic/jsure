package test_selfProtected;

import com.surelogic.ThreadSafe;

@ThreadSafe
public class D extends C {

}
