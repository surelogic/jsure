package test;

public class Outer {
//	{
//		Object x = 10;
//
//	}
//
//	{
//		Object y = 100;
//	}
//
//	private Outer() {
//		super();
//	}
//
//	private Outer(Object v) {
//		Object z = 1000;
//	}
//
//	public void m() {
//		class Local {
//			{
//				Object l1 = 2;
//			}
//
//			{
//				Object l2 = 3;
//			}
//		}
//	}

	public void n() {
		Object n1 = null;

		new Object() {
			{
				Object a1 = null;
			}

			{
				Object a2 = null;
			}
		};

		Object n2 = null;
	}
}
