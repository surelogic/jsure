package twoLocksOneRegion.unrelatedClasses;

import com.surelogic.RegionLock;

@RegionLock("L is this protects Instance")
public class Test {

}
