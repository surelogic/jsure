package test;

import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.Regions;

@Regions({
  @Region("public E extends A"),
  @Region("public static S3 extends S1")
})
public class C3 extends C1 {
  @InRegion("S3")
  protected static int static2;
  
  @InRegion("D")
  protected int g;
  
  @InRegion("E")
  protected int h;
}
