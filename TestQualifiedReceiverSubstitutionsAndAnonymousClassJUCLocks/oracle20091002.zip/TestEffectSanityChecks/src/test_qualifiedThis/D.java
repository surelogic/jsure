package test_qualifiedThis;

import com.surelogic.Region;

@Region("public RegionFromD")
public class D {

}
