package testInstNoExit;

class Shared {
  private static final Phantom withinClass = new Phantom();
  
  private boolean hasForB = false;
  private int fromAforB;
  
  private boolean hasForA = false;
  private int fromBforA;
  
  public void forB(final int v) {
    forB_impl(this, v);
  }

  private void forB_impl(final Object lock, final int v) {
    final Object lockObj = lock;
    Store.beforeStart(lockObj, lockObj == this, lockObj == Shared.class, withinClass, 250);
    synchronized (lock) {
      Store.afterStart(lockObj, withinClass, 250);
      fromAforB = v;
      hasForB = true;
      lock.notifyAll();
    }
  }
  
  public void forA(final int v) {
    forA_impl(this, v);
  }

  private void forA_impl(final Object lock, final int v) {
    final Object lockObj = lock;
    Store.beforeStart(lockObj, lockObj == this, lockObj == Shared.class, withinClass, 250);
    synchronized (lock) {
      Store.afterStart(lockObj, withinClass, 250);
      fromBforA = v;
      hasForA = true;
      lock.notifyAll();
    }
  }
  
  public int fromB() throws InterruptedException {
    return fromB_impl(this);
  }

  private int fromB_impl(final Object lock) throws InterruptedException {
    final Object lockObj = lock;
    Store.beforeStart(lockObj, lockObj == this, lockObj == Shared.class, withinClass, 250);
    synchronized (lock) {
      Store.afterStart(lockObj, withinClass, 250);
      while (!hasForA) {
        lock.wait();
      }
      hasForA = false;
      return fromBforA;
    }
  }
  
  public int fromA() throws InterruptedException {
    return fromA_impl(this);
  }

  private int fromA_impl(final Object lock) throws InterruptedException {
    final Object lockObj = lock;
    Store.beforeStart(lockObj, lockObj == this, lockObj == Shared.class, withinClass, 250);
    synchronized (lock) {
      Store.afterStart(lockObj, withinClass, 250);
      while (!hasForB) {
        lock.wait();
      }
      hasForB = false;
      return fromAforB;
    }
  }
}

