package test;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Main {
  public void testWithLock() throws InterruptedException {
    final Lock lock = new ReentrantLock();
    
    lock.lock();
    lock.lockInterruptibly();
    
    lock.tryLock();
    lock.tryLock(10L, TimeUnit.MICROSECONDS);
    
    lock.unlock();
  }

  public void testWithReentrantLock() throws InterruptedException {
    final ReentrantLock lock = new ReentrantLock();
    
    lock.lock();
    lock.lockInterruptibly();
    
    lock.tryLock();
    lock.tryLock(10L, TimeUnit.MICROSECONDS);
    
    lock.unlock();
  }
  
  public static void main(String[] args) {
    System.out.println("test");
  }
}
