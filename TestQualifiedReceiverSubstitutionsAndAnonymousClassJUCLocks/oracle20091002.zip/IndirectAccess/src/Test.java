
public class Test {
  public static void main(String[] args) {
    final String[] copy = new String[args.length];
    Util.copy(args, copy);
    Util.process(copy);
  }
}
