package test;

import com.surelogic.RegionEffects;

/**
 * This is a simple class that exists only to show off the 
 * assurance results the Effects Assurance can produce.
 */
public class EffectsExample {
  private int f1;

  private int f2;

  private int f3;

  @RegionEffects("writes java.lang.Object:All")
  private int doesAnything() {
    return 0;
  }

  @RegionEffects("none")
  public EffectsExample(final int x, final int y, final int z) {
    f1 = x;
    f2 = y;
    f3 = z;
  }

  @RegionEffects("reads Instance")
  public int getSum() {
    return f1 + f2 + f3;
  }

  @RegionEffects("writes Instance")
  public void update() {
    final int sum = getSum();
    f1 += sum;
    f2 += sum;
    f3 += sum;
  }

  /**
   * Indirectly bad!
   */
  @RegionEffects("reads Instance")
  public int indirectlyBad() {
    return bad();
  }

  /**
   * Missing effects!
   */
  @RegionEffects("reads Instance")
  public int bad() {
    return getSum() + doesAnything();
  }

}
