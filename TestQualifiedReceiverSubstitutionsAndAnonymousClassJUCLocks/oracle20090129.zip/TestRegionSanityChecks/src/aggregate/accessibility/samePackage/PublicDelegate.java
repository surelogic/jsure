package aggregate.accessibility.samePackage;

import com.surelogic.Region;

@Region("public PublicAgg")
public class PublicDelegate {
}
