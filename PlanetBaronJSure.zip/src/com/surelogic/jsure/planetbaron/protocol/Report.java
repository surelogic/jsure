package com.surelogic.jsure.planetbaron.protocol;

public abstract class Report extends ASTNode {
}
