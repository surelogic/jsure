package test;

import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;

@RegionLock("L is this protects Instance")
public class RedundantLockExample {
  @SuppressWarnings("unused")
  private int f;
  
  // not redundant
  public synchronized void m() {
    f = 1;
    // redundant
    synchronized (this) {
      f = 2;
    }
  }
  
  public void n() {
    // not redundant
    synchronized (this) {
      f = 3;
      
      // redundant
      synchronized (this) {
        f = 4;
      }
    }
  }
  
  // Not redundant 
  @RequiresLock("L")
  public void o() {
    f = 5;
    
    // redundant for L, but not for MUTEX
    synchronized (this) {
      f = 6;
    }
  }
}
