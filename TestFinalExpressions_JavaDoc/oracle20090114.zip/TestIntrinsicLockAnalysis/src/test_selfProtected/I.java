package test_selfProtected;

import com.surelogic.SelfProtected;

@SelfProtected
public interface I {

}
