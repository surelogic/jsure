package wacky;

public class T {
  private final Object lock = new Object();
  
  public int m(int v, final boolean f, final boolean g) {
    synchronized (lock) {
      if (f) {
        try {
          return v;
        } finally {
          v--;
        }
      }
      if (g) {
        throw new RuntimeException();
      }
      
      v += 1;
      return v;
    }
  }

  public synchronized int m2(int v, final boolean f, final boolean g) {
    if (f) {
      try {
        return v;
      } finally {
        v--;
      }
    }
    if (g) {
      throw new RuntimeException();
    }
    
    v += 1;
    return v;
  }

  public void simple() {
    int i = 0;
    synchronized (lock) { i++; }
  }
  
  public void simplest() {
    synchronized (lock) {}
  }
}
