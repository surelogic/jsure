package test_explicitThis;

import com.surelogic.Region;

@Region("public static RegionFromD")
public class D {

}
