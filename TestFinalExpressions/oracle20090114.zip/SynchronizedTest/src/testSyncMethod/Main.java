package testSyncMethod;

import common.Common;

public class Main {
  public static void main(final String[] args) {
    System.out.println("Main (Synchronized methods)");

    final Shared s = new Shared();
    final Thread threadA = new Thread(new A(s));
    final Thread threadB = new Thread(new B(s));
    
    final long startTime = System.currentTimeMillis();
    threadA.start();
    threadB.start();
    
    while (threadA.isAlive() && threadB.isAlive()) {
      try {
        threadA.join();
        threadB.join();
      } catch (final InterruptedException e) {
        // won't happen
      }
    }
    
    final long endTime = System.currentTimeMillis();
    final long time = endTime - startTime;
    System.out.println("Done in " + time + "ms (" + ((time/1000.0)/60.0) + " minutes)");
  }
}

class A implements Runnable {
  private Shared s;
  
  public A(final Shared s) {
    this.s = s;
    s.forB(Common.START);
  }
  
  public void run() {
    while (true) {
      try {
        final int v = s.fromB();
        if (v <= 0) {
          s.forB(v);
          break;
        }
        s.forB(v+1);
      } catch(final InterruptedException e) {
        // won't happen
      }
    }
  }
}

class B implements Runnable {
  private Shared s;
  
  public B(final Shared s) {
    this.s = s;
  }
  
  public void run() {
    while (true) {
      try {
        final int v = s.fromA();
        if (v <= 0) {
          s.forA(v);
          break;
        }
        s.forA(v-2);
      } catch (final InterruptedException e) {
        // won't happen
      }
    }
  }
}
