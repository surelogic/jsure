/* Created on Jun 12, 2005
 */
package inherited_region.good;

/**
 * Declares region R, but doesn't put anything in it.  Subclasses
 * can protect Instance, can protect R
 * @TestRegion is VALID
 * @Region public R 
 */
public class GoodRoot {
  
}
