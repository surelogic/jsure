package test;

import com.surelogic.Aggregate;
import com.surelogic.AggregateInRegion;
import com.surelogic.RegionLock;
import com.surelogic.Unique;

@RegionLock("Lock is this protects Instance")
public class Rectangle {
	@Unique
//	@Aggregate("Instance into Instance")
	@AggregateInRegion("Instance")
	private final Point topLeft;

	@Unique
//	@Aggregate("Instance into Instance")
	@AggregateInRegion("Instance")
	private final Point bottomRight;


 
	public Rectangle(final int x, final int y, final int w, final int h) {
		topLeft = new Point(x, y);
		bottomRight = new Point(x+w, y+h);
	}
	
	public synchronized int getWidth() {
		return bottomRight.x - topLeft.x;
	}
	
	public synchronized int getHeight() {
		return bottomRight.y - topLeft.y;
	}
}
