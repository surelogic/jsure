package test;

import com.surelogic.Borrowed;
import com.surelogic.RegionLock;
import com.surelogic.RequiresLock;
import com.surelogic.SingleThreaded;

@RegionLock("L2 is this protects Instance")
public class ConstructorExample {
  private int f = 100;
  @SuppressWarnings("unused")
  private int g = f + 10;
  @SuppressWarnings("unused")
  private int h;
  
  private final Aux aux = new Aux();
  @SuppressWarnings("unused")
  private final int bad = aux.doStuff();
  
  public ConstructorExample(final int a) {
    // bad
    h = a;
  }

  @SingleThreaded
  @Borrowed("this")
  // good constructor
  public ConstructorExample(final int a, final int b) {
    // good
    h = a;
    // good
    f += b;
  }
  
  @SingleThreaded
  // bad constructor
  public ConstructorExample() {
    h = 10;
  }
  
  @RegionLock("AuxLock is this protects Instance")
  static class Aux {
    private int x;
    
    @RequiresLock("AuxLock")
    public int doStuff() {
      return x; 
    }
  }
}
