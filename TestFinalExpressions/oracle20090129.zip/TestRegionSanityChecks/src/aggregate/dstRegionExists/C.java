package aggregate.dstRegionExists;

public class C {
  // do nothing
}
