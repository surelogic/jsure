package region.parentMustExist;

import com.surelogic.Region;

@Region("ChildRegion")
public class Child extends Test {

}
