package t;

public class B extends A {

}
