package requiresLock;

public class Spy {
  public static volatile int value = 0;
}
