package com.surelogic.annotation.parse;

import com.surelogic.aast.java.*;
import com.surelogic.aast.promise.*;
import com.surelogic.parse.*;

public class ColorFactoryRefs {
  public static void register(IASTFactory f) {
    TestResultNode.factory.register(f);
    QualifiedRegionNameNode.factory.register(f);
    RegionNameNode.factory.register(f);
    NamedTypeNode.factory.register(f);
    ColorNameNode.factory.register(f);
    ColorDeclarationNode.factory.register(f);
    ColorGrantNode.factory.register(f);
    ColorRevokeNode.factory.register(f);
    ColorIncompatibleNode.factory.register(f);
    ColorNotNode.factory.register(f);
    ColorAndNode.factory.register(f);
    ColorOrNode.factory.register(f);
    ColorExprNode.factory.register(f);
    ColorImportNode.factory.register(f);
    ColorRenameNode.factory.register(f);
    ColorCardSpecNode.factory.register(f);
    ColorizedRegionNode.factory.register(f);
    ColorCRNode.factory.register(f);
    ColorConstraintNode.factory.register(f);
    ColorNode.factory.register(f);
    TransparentNode.factory.register(f);
    ModulePromiseNode.factory.register(f);
    ModuleWrapperNode.factory.register(f);
    ModuleChoiceNode.factory.register(f);
    VisClauseNode.factory.register(f);
    NoVisClauseNode.factory.register(f);
    ExportNode.factory.register(f);
    BlockImportNode.factory.register(f);
    ExportToNode.factory.register(f);
    OfNamesClauseNode.factory.register(f);
  }
}
