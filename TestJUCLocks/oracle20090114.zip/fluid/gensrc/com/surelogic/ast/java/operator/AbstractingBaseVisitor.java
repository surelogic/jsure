// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

/**
 * Has each visit() method in INodeVisitor call the
 * corresponding method for its superinterface
 */
@SuppressWarnings("deprecation")
public class AbstractingBaseVisitor<T> implements IBaseNodeVisitor<T> {
  protected final T defaultValue;

  public AbstractingBaseVisitor(T defaultVal) {
    defaultValue = defaultVal;
  }

  public AbstractingBaseVisitor() {
    this(null);
  }

  public T doAccept(IJavaOperatorNode node) {
    if (node == null) { return defaultValue; }
    return node.accept(this);
  }

  public T visit(IJavaOperatorNode node) { return defaultValue; }
  public T visit(ISomeFunctionCallNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(ILabeledBreakStatementNode n) {
    return visit((ISomeBreakStatementNode) n);
  }
  public T visit(IConstructorCallNode n) {
    return visit((ISomeFunctionCallNode) n);
  }
  public T visit(IAssignExpressionNode n) {
    return visit((IAssignmentExpressionNode) n);
  }
  public T visit(IUnsignedRightShiftExpressionNode n) {
    return visit((IShiftExpressionNode) n);
  }
  public T visit(ISomeThisExpressionNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IParameterizedTypeNode n) {
    return visit((IClassTypeNode) n);
  }
  public T visit(IWildcardExtendsTypeNode n) {
    return visit((IWildcardTypeNode) n);
  }
  public T visit(IUnnamedPackageDeclarationNode n) {
    return visit((IPackageDeclarationNode) n);
  }
  public T visit(IBoxExpressionNode n) {
    return visit((IUnopExpressionNode) n);
  }
  public T visit(IAndExpressionNode n) {
    return visit((ILogBinopExpressionNode) n);
  }
  public T visit(IClassTypeNode n) {
    return visit((IReferenceTypeNode) n);
  }
  public T visit(IReturnTypeNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IFieldRefNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IFloatLiteralNode n) {
    return visit((IPrimLiteralNode) n);
  }
  public T visit(ITypeDeclarationNode n) {
    return visit((IDeclarationNode) n);
  }
  public T visit(IRefLiteralNode n) {
    return visit((ILiteralExpressionNode) n);
  }
  public T visit(IDivRemExpressionNode n) {
    return visit((IArithBinopExpressionNode) n);
  }
  public T visit(IElementValuePairNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ITypedDemandNameNode n) {
    return visit((IImportNameNode) n);
  }
  public T visit(IStaticDemandNameNode n) {
    return visit((IImportNameNode) n);
  }
  public T visit(ISubExpressionNode n) {
    return visit((IArithBinopExpressionNode) n);
  }
  public T visit(IDemandNameNode n) {
    return visit((IImportNameNode) n);
  }
  public T visit(IAssertMessageStatementNode n) {
    return visit((ISomeAssertStatementNode) n);
  }
  public T visit(IArrayCreationExpressionNode n) {
    return visit((IAllocationExpressionNode) n);
  }
  public T visit(INotExpressionNode n) {
    return visit((IUnopExpressionNode) n);
  }
  public T visit(ILiteralExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(IOptInitializationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IAllocationCallExpressionNode n) {
    return visit((IAllocationExpressionNode) n);
  }
  public T visit(ISuperRootNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IInterfaceDeclarationNode n) {
    return visit((ITypeDeclarationNode) n);
  }
  public T visit(IDoStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(ICompareExpressionNode n) {
    return visit((IRelopExpressionNode) n);
  }
  public T visit(IBreakStatementNode n) {
    return visit((ISomeBreakStatementNode) n);
  }
  public T visit(ICharLiteralNode n) {
    return visit((IPrimLiteralNode) n);
  }
  public T visit(IVarArgsExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(ISuperExpressionNode n) {
    return visit((IConstructionObjectNode) n);
  }
  public T visit(INullLiteralNode n) {
    return visit((IRefLiteralNode) n);
  }
  public T visit(IWhileStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(ICompilationUnitNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ILabeledStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IExprStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IRelopExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(IFloatTypeNode n) {
    return visit((IFloatingPointTypeNode) n);
  }
  public T visit(IInitializerNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ISimpleEnumConstantDeclarationNode n) {
    return visit((IEnumConstantDeclarationNode) n);
  }
  public T visit(IPrimLiteralNode n) {
    return visit((ILiteralExpressionNode) n);
  }
  public T visit(IMulExpressionNode n) {
    return visit((IArithBinopExpressionNode) n);
  }
  public T visit(ICastExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(INoMethodBodyNode n) {
    return visit((IOptMethodBodyNode) n);
  }
  public T visit(INotEqExpressionNode n) {
    return visit((IEqualityExpressionNode) n);
  }
  public T visit(ILogUnopExpressionNode n) {
    return visit((IUnopExpressionNode) n);
  }
  public T visit(ICatchClauseNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IThisExpressionNode n) {
    return visit((IConstructionObjectNode) n);
  }
  public T visit(IIntLiteralNode n) {
    return visit((IPrimLiteralNode) n);
  }
  public T visit(IAddExpressionNode n) {
    return visit((IArithBinopExpressionNode) n);
  }
  public T visit(IStatementNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IVariableDeclListNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IAnnotationDeclarationNode n) {
    return visit((ITypeDeclarationNode) n);
  }
  public T visit(IAssertStatementNode n) {
    return visit((ISomeAssertStatementNode) n);
  }
  public T visit(IMarkerAnnotationNode n) {
    return visit((IAnnotationNode) n);
  }
  public T visit(ISomeBreakStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IPolymorphicMethodCallNode n) {
    return visit((IMethodCallNode) n);
  }
  public T visit(IOpAssignExpressionNode n) {
    return visit((IAssignmentExpressionNode) n);
  }
  public T visit(IEnumConstantDeclarationNode n) {
    return visit((IVariableDeclarationNode) n);
  }
  public T visit(IPolymorphicNewExpressionNode n) {
    return visit((INewExpressionNode) n);
  }
  public T visit(IElseClauseNode n) {
    return visit((IOptElseClauseNode) n);
  }
  public T visit(IBinopExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(IAssignmentExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(ISwitchLabelNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IElementValueArrayInitializerNode n) {
    return visit((IElementValueNode) n);
  }
  public T visit(ISwitchElementNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(INestedInterfaceDeclarationNode n) {
    return visit((IInterfaceDeclarationNode) n);
  }
  public T visit(IEnumBodyDeclarationNode n) {
    return visit((IClassBodyDeclarationNode) n);
  }
  public T visit(IPackageRootNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IVoidReturnStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IQualifiedSuperExpressionNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(ILogBinopExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(INamedPackageDeclarationNode n) {
    return visit((IPackageDeclarationNode) n);
  }
  public T visit(IAnnotationElementNode n) {
    return visit((IClassBodyDeclarationNode) n);
  }
  public T visit(IFieldDeclarationNode n) {
    return visit((IVariableDeclListNode) n);
  }
  public T visit(INewExpressionNode n) {
    return visit((IAllocationCallExpressionNode) n);
  }
  public T visit(IPrimaryExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(IBlockStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(ISwitchBlockNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IMethodBodyNode n) {
    return visit((IOptMethodBodyNode) n);
  }
  public T visit(ITypeDeclarationStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IShortTypeNode n) {
    return visit((IIntegralTypeNode) n);
  }
  public T visit(IWildcardSuperTypeNode n) {
    return visit((IWildcardTypeNode) n);
  }
  public T visit(IClassInitializerNode n) {
    return visit((IClassBodyDeclarationNode) n);
  }
  public T visit(IUnopExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(IXorExpressionNode n) {
    return visit((ILogBinopExpressionNode) n);
  }
  public T visit(IAnonClassExpressionNode n) {
    return visit((IAllocationCallExpressionNode) n);
  }
  public T visit(IAllocationExpressionNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IForStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IOptFinallyNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IVariableDeclaratorNode n) {
    return visit((IVariableDeclarationNode) n);
  }
  public T visit(IEmptyStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IParameterDeclarationNode n) {
    return visit((IVariableDeclarationNode) n);
  }
  public T visit(IExpressionNode n) {
    return visit((IInitializerNode) n);
  }
  public T visit(IEnumConstantClassDeclarationNode n) {
    return visit((IEnumConstantDeclarationNode) n);
  }
  public T visit(IOptArrayInitializerNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ILongTypeNode n) {
    return visit((IIntegralTypeNode) n);
  }
  public T visit(IPostIncrementExpressionNode n) {
    return visit((ICrementExpressionNode) n);
  }
  public T visit(IUnboxExpressionNode n) {
    return visit((IUnopExpressionNode) n);
  }
  public T visit(ICrementExpressionNode n) {
    return visit((IArithUnopExpressionNode) n);
  }
  public T visit(ISwitchStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IImportNameNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ISynchronizedStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(INumericTypeNode n) {
    return visit((IPrimitiveTypeNode) n);
  }
  public T visit(IMinusExpressionNode n) {
    return visit((IArithUnopExpressionNode) n);
  }
  public T visit(IReturnStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IStatementExpressionListNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ILessThanExpressionNode n) {
    return visit((ICompareExpressionNode) n);
  }
  public T visit(IReferenceTypeNode n) {
    return visit((ITypeNode) n);
  }
  public T visit(ITrueExpressionNode n) {
    return visit((IBooleanLiteralNode) n);
  }
  public T visit(IIntTypeNode n) {
    return visit((IIntegralTypeNode) n);
  }
  public T visit(IOuterObjectSpecifierNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IGreaterThanEqualExpressionNode n) {
    return visit((ICompareExpressionNode) n);
  }
  public T visit(IComplementExpressionNode n) {
    return visit((ILogUnopExpressionNode) n);
  }
  public T visit(IDivExpressionNode n) {
    return visit((IDivRemExpressionNode) n);
  }
  public T visit(INestedEnumDeclarationNode n) {
    return visit((IEnumDeclarationNode) n);
  }
  public T visit(IDeclStatementNode n) {
    return visit((IVariableDeclListNode) n);
  }
  public T visit(IOrExpressionNode n) {
    return visit((ILogBinopExpressionNode) n);
  }
  public T visit(INormalAnnotationNode n) {
    return visit((IAnnotationNode) n);
  }
  public T visit(IEnumDeclarationNode n) {
    return visit((ITypeDeclarationNode) n);
  }
  public T visit(IPostDecrementExpressionNode n) {
    return visit((ICrementExpressionNode) n);
  }
  public T visit(IForEachStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IPolymorphicConstructorCallNode n) {
    return visit((IConstructorCallNode) n);
  }
  public T visit(IArrayRefExpressionNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(INonPolymorphicConstructorCallNode n) {
    return visit((IConstructorCallNode) n);
  }
  public T visit(IFloatingPointTypeNode n) {
    return visit((INumericTypeNode) n);
  }
  public T visit(IContinueStatementNode n) {
    return visit((ISomeContinueStatementNode) n);
  }
  public T visit(IAnnotationNode n) {
    return visit((IElementValueNode) n);
  }
  public T visit(IVariableUseExpressionNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IShiftExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(IOptElseClauseNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ITypeNode n) {
    return visit((IReturnTypeNode) n);
  }
  public T visit(IConstructionObjectNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IClassExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(IStatementExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(ILeftShiftExpressionNode n) {
    return visit((IShiftExpressionNode) n);
  }
  public T visit(ICompiledMethodBodyNode n) {
    return visit((IOptMethodBodyNode) n);
  }
  public T visit(ILabeledContinueStatementNode n) {
    return visit((ISomeContinueStatementNode) n);
  }
  public T visit(IForInitNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ICaptureTypeNode n) {
    return visit((IReferenceTypeNode) n);
  }
  public T visit(IConditionalExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(IInitializationNode n) {
    return visit((IOptInitializationNode) n);
  }
  public T visit(IQualifiedThisExpressionNode n) {
    return visit((ISomeThisExpressionNode) n);
  }
  public T visit(INamedTypeNode n) {
    return visit((IClassTypeNode) n);
  }
  public T visit(IPlusExpressionNode n) {
    return visit((IArithUnopExpressionNode) n);
  }
  public T visit(IRemExpressionNode n) {
    return visit((IDivRemExpressionNode) n);
  }
  public T visit(IEqExpressionNode n) {
    return visit((IEqualityExpressionNode) n);
  }
  public T visit(IConstructorDeclarationNode n) {
    return visit((ISomeFunctionDeclarationNode) n);
  }
  public T visit(IBooleanLiteralNode n) {
    return visit((IPrimLiteralNode) n);
  }
  public T visit(ICallNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IRightShiftExpressionNode n) {
    return visit((IShiftExpressionNode) n);
  }
  public T visit(INonPolymorphicNewExpressionNode n) {
    return visit((INewExpressionNode) n);
  }
  public T visit(IDoubleTypeNode n) {
    return visit((IFloatingPointTypeNode) n);
  }
  public T visit(IArithUnopExpressionNode n) {
    return visit((IUnopExpressionNode) n);
  }
  public T visit(IIfStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IGreaterThanExpressionNode n) {
    return visit((ICompareExpressionNode) n);
  }
  public T visit(IPreDecrementExpressionNode n) {
    return visit((ICrementExpressionNode) n);
  }
  public T visit(IOptDefaultValueNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(ITypeExpressionNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(ITryStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(INestedClassDeclarationNode n) {
    return visit((IClassDeclarationNode) n);
  }
  public T visit(IConditionalAndExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(ISingleElementAnnotationNode n) {
    return visit((IAnnotationNode) n);
  }
  public T visit(IMethodCallNode n) {
    return visit((ISomeFunctionCallNode) n);
  }
  public T visit(ITypeFormalNode n) {
    return visit((ITypeDeclarationNode) n);
  }
  public T visit(IFinallyNode n) {
    return visit((IOptFinallyNode) n);
  }
  public T visit(IFalseExpressionNode n) {
    return visit((IBooleanLiteralNode) n);
  }
  public T visit(INestedTypeDeclarationNode n) {
    return visit((IClassBodyDeclarationNode) n);
  }
  public T visit(IBooleanTypeNode n) {
    return visit((IPrimitiveTypeNode) n);
  }
  public T visit(IPrimitiveTypeNode n) {
    return visit((ITypeNode) n);
  }
  public T visit(ISomeAssertStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IAssignmentNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IThrowStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IVariableDeclarationNode n) {
    return visit((IDeclarationNode) n);
  }
  public T visit(IDefaultValueNode n) {
    return visit((IOptDefaultValueNode) n);
  }
  public T visit(IPreIncrementExpressionNode n) {
    return visit((ICrementExpressionNode) n);
  }
  public T visit(IStaticImportNode n) {
    return visit((IImportNameNode) n);
  }
  public T visit(INonPolymorphicMethodCallNode n) {
    return visit((IMethodCallNode) n);
  }
  public T visit(IDefaultLabelNode n) {
    return visit((ISwitchLabelNode) n);
  }
  public T visit(IImportDeclarationNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IWildcardTypeNode n) {
    return visit((IReferenceTypeNode) n);
  }
  public T visit(IMethodDeclarationNode n) {
    return visit((ISomeFunctionDeclarationNode) n);
  }
  public T visit(IArrayInitializerNode n) {
    return visit((IInitializerNode) n);
  }
  public T visit(IVarArgsTypeNode n) {
    return visit((IReferenceTypeNode) n);
  }
  public T visit(IByteTypeNode n) {
    return visit((IIntegralTypeNode) n);
  }
  public T visit(IElementValueNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IOmittedMethodBodyNode n) {
    return visit((IOptMethodBodyNode) n);
  }
  public T visit(ICharTypeNode n) {
    return visit((IIntegralTypeNode) n);
  }
  public T visit(IClassDeclarationNode n) {
    return visit((ITypeDeclarationNode) n);
  }
  public T visit(IStringLiteralNode n) {
    return visit((IRefLiteralNode) n);
  }
  public T visit(IStringConcatNode n) {
    return visit((IArithBinopExpressionNode) n);
  }
  public T visit(IArithBinopExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(IClassBodyDeclarationNode n) {
    return visit((IDeclarationNode) n);
  }
  public T visit(IInstanceOfExpressionNode n) {
    return visit((IExpressionNode) n);
  }
  public T visit(ILessThanEqualExpressionNode n) {
    return visit((ICompareExpressionNode) n);
  }
  public T visit(ISomeFunctionDeclarationNode n) {
    return visit((IClassBodyDeclarationNode) n);
  }
  public T visit(ITypeRefNode n) {
    return visit((IClassTypeNode) n);
  }
  public T visit(IVoidTypeNode n) {
    return visit((IReturnTypeNode) n);
  }
  public T visit(ISomeContinueStatementNode n) {
    return visit((IStatementNode) n);
  }
  public T visit(IOptMethodBodyNode n) {
    return visit((IJavaOperatorNode) n);
  }
  public T visit(IIntegralTypeNode n) {
    return visit((INumericTypeNode) n);
  }
  public T visit(IArrayTypeNode n) {
    return visit((IReferenceTypeNode) n);
  }
  public T visit(IArrayLengthNode n) {
    return visit((IPrimaryExpressionNode) n);
  }
  public T visit(IConstantLabelNode n) {
    return visit((ISwitchLabelNode) n);
  }
  public T visit(IConditionalOrExpressionNode n) {
    return visit((IBinopExpressionNode) n);
  }
  public T visit(IEqualityExpressionNode n) {
    return visit((IRelopExpressionNode) n);
  }
  public T visit(IPackageDeclarationNode n) {
    return visit((IDeclarationNode) n);
  }
}
