// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    object : IExpressionNode
 *    <>
 *    "."
 *    <>
 *    "length"
 * 
 */
public interface IArrayLengthNode extends IPrimaryExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getObject();
}

