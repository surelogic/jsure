// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * A reference to a nested type: a named type inside of
 * a class or interface.
 * 
 * Syntax:
 *    base : IClassTypeNode
 *    "."
 *    id : Info (String)
 * 
 * Binds to the type represented by ISourceRefTypeBinding
 */
public interface ITypeRefNode extends IClassTypeNode, IImportNameNode, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the TypeRef
   */
  public ISourceRefType resolveType();

  /**
   * @return A non-null node
   */
  public IClassTypeNode getBase();
  /**
   * @return A non-null String
   */
  public String getId();
}

