// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.java.promise.*;

@SuppressWarnings("deprecation")
public interface IPromiseNodeVisitor<T> extends IBaseNodeVisitor<T> {
  public T visit(IColorRenameNode node);
  public T visit(IColorRequireNode node);
  public T visit(IColorCardNNode node);
  public T visit(IColorAndParenNode node);
  public T visit(IQualifiedRegionNameNode node);
  public T visit(IInitDeclarationNode node);
  public T visit(IEnclosingModuleNode node);
  public T visit(ITaintedNode node);
  public T visit(IStartsSpecificationNode node);
  public T visit(IAndTargetNode node);
  public T visit(IColorNameNode node);
  public T visit(IColorDeclarationNode node);
  public T visit(IConstructorDeclPatternNode node);
  public T visit(IReturnValueDeclarationNode node);
  public T visit(IColorCard1Node node);
  public T visit(IColorAndNode node);
  public T visit(IInvariantDeclarationNode node);
  public T visit(IScopedModuleNode node);
  public T visit(IColorExprNode node);
  public T visit(IModuleNode node);
  public T visit(ITransparentNode node);
  public T visit(IAPINode node);
  public T visit(IColorIncompatibleNode node);
  public T visit(IRegionMappingNode node);
  public T visit(IColorRevokeNode node);
  public T visit(ISubtypedBySpecificationNode node);
  public T visit(INotTaintedNode node);
  public T visit(IEffectSpecificationNode node);
  public T visit(IColorOrParenNode node);
  public T visit(IIntOrNNode node);
  public T visit(IFieldDeclPatternNode node);
  public T visit(IColorConstrainedRegionsNode node);
  public T visit(IEffectsSpecificationNode node);
  public T visit(IMethodDeclPatternNode node);
  public T visit(IColorOrNode node);
  public T visit(ITypeDeclPatternNode node);
  public T visit(IColorImportNode node);
  public T visit(IUsedBySpecificationNode node);
  public T visit(IOrTargetNode node);
  public T visit(IAnyInstanceExpressionNode node);
  public T visit(INewRegionDeclarationNode node);
  public T visit(IScopedPromiseNode node);
  public T visit(ITypeQualifierPatternNode node);
  public T visit(IColorGrantNode node);
  public T visit(IColorContextNode node);
  public T visit(IColorCardinalityNode node);
  public T visit(IClassInitDeclarationNode node);
  public T visit(INotTargetNode node);
  public T visit(IColorNoteNode node);
  public T visit(IRegionNameNode node);
  public T visit(IFieldMappingsNode node);
  public T visit(IConditionNode node);
  public T visit(IColorNotNode node);
  public T visit(IColorizedRegionNode node);
  public T visit(IReceiverDeclarationNode node);
  public T visit(IMappedRegionSpecificationNode node);
  public T visit(IQualifiedReceiverDeclarationNode node);
}
