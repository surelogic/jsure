// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    op1 : IExpressionNode
 *    "^"
 *    op2 : IExpressionNode
 * 
 */
public interface IXorExpressionNode extends ILogBinopExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp1();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp2();
}

