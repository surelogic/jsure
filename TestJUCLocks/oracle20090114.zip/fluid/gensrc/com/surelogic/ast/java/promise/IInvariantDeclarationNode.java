// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * A class invariant has a name, modifiers, and a condition.
 * 
 * Syntax:
 *    mods : Modifiers (int)
 *    "invariant"
 *    id : Info (String)
 *    "="
 *    cond : IConditionNode
 * 
 */
public interface IInvariantDeclarationNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null int
   */
  public int getMods();
  /**
   * @return A non-null String
   */
  public String getId();
  /**
   * @return A non-null node
   */
  public IConditionNode getCond();
}

