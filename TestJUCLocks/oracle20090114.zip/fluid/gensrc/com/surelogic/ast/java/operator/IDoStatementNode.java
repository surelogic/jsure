// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "do"
 *    loop : IStatementNode
 *    "while"
 *    "("
 *    <paren>
 *    cond : IExpressionNode
 *    </paren>
 *    ")"
 *    <>
 *    ";"
 * 
 */
public interface IDoStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IStatementNode getLoop();
  /**
   * @return A non-null node
   */
  public IExpressionNode getCond();
}

