// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "?"
 *    "super"
 *    upper : ITypeNode
 * 
 */
public interface IWildcardSuperTypeNode extends IWildcardTypeNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public ITypeNode getUpper();
}

