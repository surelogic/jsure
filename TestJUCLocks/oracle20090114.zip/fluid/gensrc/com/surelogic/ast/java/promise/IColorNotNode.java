// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    "!"
 *    target : IColorNameNode
 * 
 */
public interface IColorNotNode extends IJavaOperatorNode, IColorSpecNode, IColorOrElemNode, IColorAndElemNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IColorNameNode getTarget();
}

