// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import java.util.List;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    Zero or more of:
 *      mappingList : List<IRegionMappingNode>
 *    Separated by:
 *      ","
 * 
 */
public interface IMappedRegionSpecificationNode extends IFieldRegionSpecificationNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IRegionMappingNode> getMappingList();
}

