// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * An AssignExpressionNodes represents what we normally think of as an
 *        assignment. This is in contrast to an AssignmentNode which is the
 *        supertype of several differnt assignment types
 *        (e.g. assignment, post-increment, pre-decrement).
 * 
 * Syntax:
 *    op1 : IExpressionNode
 *    "="
 *    op2 : IExpressionNode
 * 
 */
public interface IAssignExpressionNode extends IAssignmentExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp1();
  /**
   * @return A non-null node
   */
  public IExpressionNode getOp2();
}

