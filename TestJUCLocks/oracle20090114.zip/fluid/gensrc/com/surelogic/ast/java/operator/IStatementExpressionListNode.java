// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.java.operator.*;

/**
 * Comma separated expressions used in for loops.
 * It permits an empty list.
 * 
 * Syntax:
 *    Zero or more of:
 *      exprList : List<IStatementExpressionNode>
 *    Separated by:
 *      <>
 *      ","
 * 
 */
public interface IStatementExpressionListNode extends IJavaOperatorNode, IForInitNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IStatementExpressionNode> getExprList();
}

