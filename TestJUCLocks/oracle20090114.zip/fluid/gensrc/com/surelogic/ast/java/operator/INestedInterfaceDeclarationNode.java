// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    mods : Modifiers (int)
 *    "interface"
 *    id : Info (String)
 *    typesList : List<ITypeFormalNode>
 *    extensionsList : List<IClassTypeNode>
 *    bodyList : List<IClassBodyDeclarationNode>
 * 
 * 
 */
public interface INestedInterfaceDeclarationNode extends IInterfaceDeclarationNode, IClassBodyDeclarationNode, INestedTypeDeclarationNode, IDeclaredType { 
  public BaseNodeType getNodeType();
  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isAbstract();
}

