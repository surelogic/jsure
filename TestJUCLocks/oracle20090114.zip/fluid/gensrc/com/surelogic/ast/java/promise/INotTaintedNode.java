// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.operator.*;

/**
 * Mark a value as being Not Tainted
 * 
 * Syntax:
 *    "notTainted"
 * 
 */
public interface INotTaintedNode extends IJavaOperatorNode { 
  public PromiseNodeType getNodeType();
}

