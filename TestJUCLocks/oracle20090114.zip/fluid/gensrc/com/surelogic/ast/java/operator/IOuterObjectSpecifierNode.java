// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    <?>
 *    object : IPrimaryExpressionNode
 *    "."
 *    </?>
 *    call : IPrimaryExpressionNode
 * 
 */
public interface IOuterObjectSpecifierNode extends IPrimaryExpressionNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IPrimaryExpressionNode getObject();
  /**
   * @return A non-null node
   */
  public IPrimaryExpressionNode getCall();
}

