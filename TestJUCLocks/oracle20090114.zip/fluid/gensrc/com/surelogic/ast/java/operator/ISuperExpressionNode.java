// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * Java's super.
 * This expression is legal in only a few situations:
 * <ul>
 *   <li> as the object in method calls.
 *   <li> as the object for field references.
 *   <li> as the object in constructor calls.
 * </ul>
 * 
 * Syntax:
 *    "super"
 * 
 */
public interface ISuperExpressionNode extends IConstructionObjectNode { 
  public BaseNodeType getNodeType();
}

