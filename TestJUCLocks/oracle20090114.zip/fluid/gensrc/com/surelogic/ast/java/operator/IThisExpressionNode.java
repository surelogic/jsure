// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Java's "this" expression.
 * 
 * Syntax:
 *    "this"
 * 
 * Binds to the type represented by ISourceRefTypeBinding
 * Binds this name to IVariableBinding
 */
public interface IThisExpressionNode extends IConstructionObjectNode, ISomeThisExpressionNode, IHasBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IVariableBinding resolveBinding();

  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the ThisExpression
   */
  public ISourceRefType resolveType();

}

