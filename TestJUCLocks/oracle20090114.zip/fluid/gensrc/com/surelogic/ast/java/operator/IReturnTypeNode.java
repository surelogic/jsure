// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 */
public interface IReturnTypeNode extends IJavaOperatorNode, IHasType { 
  public BaseNodeType getNodeType();
  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the ReturnType
   */
  public IType resolveType();

}

