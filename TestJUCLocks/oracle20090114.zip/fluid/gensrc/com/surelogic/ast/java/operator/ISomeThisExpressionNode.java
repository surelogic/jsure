// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    type : IClassTypeNode
 * 
 * Binds to the type represented by ISourceRefTypeBinding
 * Binds this name to IVariableBinding
 */
public interface ISomeThisExpressionNode extends IPrimaryExpressionNode, IHasBinding, IHasType { 
  public BaseNodeType getNodeType();
  public boolean bindingExists();

  public IVariableBinding resolveBinding();

  public boolean typeExists();

  /**
   * Gets the binding corresponding to the type of the SomeThisExpression
   */
  public ISourceRefType resolveType();

  /**
   * @return A node, or null
   */
  public IClassTypeNode getType();
}

