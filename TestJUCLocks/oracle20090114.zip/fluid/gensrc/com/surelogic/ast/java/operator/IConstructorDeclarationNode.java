// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import java.util.List;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    annosList : List<IAnnotationNode>
 *    modifiers : Modifiers (int)
 *    typesList : List<ITypeFormalNode>
 *    id : Info (String)
 *    paramsList : List<IParameterDeclarationNode>
 *    exceptionsList : List<IClassTypeNode>
 *    body : IOptMethodBodyNode
 * 
 * 
 */
public interface IConstructorDeclarationNode extends ISomeFunctionDeclarationNode, IConstructorBinding { 
  public BaseNodeType getNodeType();
  /**
   * Gets the 'super-implementation' (a la Eclipse) for the constructor
   */
  public IConstructorDeclarationNode getSuperConstructor();

  public boolean isPublic();
  public boolean isProtected();
  public boolean isPrivate();
  public boolean isNative();
  public boolean isStrictfp();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IParameterDeclarationNode> getParamsList();
  /**
   * @return A non-null, but possibly empty list of nodes
   */
  public List<IClassTypeNode> getExceptionsList();
  /**
   * @return A non-null node
   */
  public IOptMethodBodyNode getBody();
}

