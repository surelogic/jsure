// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.*;
import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 * Is extendable across node extensions (e.g. by promises)
 * 
 */
public interface IDeclarationNode extends IJavaOperatorNode, IBinding { 
  /**
   * @return A possibly-null String
   */
  public String getId();
}

