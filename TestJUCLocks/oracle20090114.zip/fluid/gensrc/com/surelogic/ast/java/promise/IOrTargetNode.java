// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.promise;

import com.surelogic.ast.java.promise.*;
import com.surelogic.ast.java.operator.*;

/**
 * Syntax:
 *    target1 : IPromiseTargetNode
 *    "||"
 *    target2 : IPromiseTargetNode
 * 
 */
public interface IOrTargetNode extends IComplexTargetNode { 
  public PromiseNodeType getNodeType();
  /**
   * @return A non-null node
   */
  public IPromiseTargetNode getTarget1();
  /**
   * @return A non-null node
   */
  public IPromiseTargetNode getTarget2();
}

