// Generated code.  Do *NOT* edit!
package com.surelogic.ast.java.operator;

import com.surelogic.ast.java.operator.*;

/**
 * This is an abstract node (i.e., never instantiated)

 * Syntax:
 *    id : Info (String)
 * 
 */
public interface ISomeBreakStatementNode extends IStatementNode { 
  public BaseNodeType getNodeType();
  /**
   * @return A possibly-null String
   */
  public String getId();
}

