package testInstNoExit;

public class Phantom {
  public Phantom() {}
}
