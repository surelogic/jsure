package test_lock_region;

/**
 * @Region static StaticRegionFromOther
 */
public class Other {
  protected static final Object staticFieldFromOther = new Object();
}
