package test_selfProtected;

/**
 * Says nothing about being "self protected"
 */
public class C {
  public void m() {
    // do nothing
  }
}
