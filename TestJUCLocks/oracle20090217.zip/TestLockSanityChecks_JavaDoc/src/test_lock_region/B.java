package test_lock_region;

/**
 * @Region static StaticRegionFromB
 */
public class B {
  protected static final Object staticFieldFromB = new Object();
}
