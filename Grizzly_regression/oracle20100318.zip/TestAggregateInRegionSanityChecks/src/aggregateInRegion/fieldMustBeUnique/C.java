package aggregateInRegion.fieldMustBeUnique;

public class C {
  // Do nothing
}
