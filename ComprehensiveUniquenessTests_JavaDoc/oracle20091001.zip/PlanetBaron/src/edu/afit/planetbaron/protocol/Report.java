package edu.afit.planetbaron.protocol;

public abstract class Report extends ASTNode {
}
