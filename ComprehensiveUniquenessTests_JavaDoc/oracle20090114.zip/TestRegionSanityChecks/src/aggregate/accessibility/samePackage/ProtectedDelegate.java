package aggregate.accessibility.samePackage;

import com.surelogic.Region;

@Region("protected ProtectedAgg")
public class ProtectedDelegate {
}
