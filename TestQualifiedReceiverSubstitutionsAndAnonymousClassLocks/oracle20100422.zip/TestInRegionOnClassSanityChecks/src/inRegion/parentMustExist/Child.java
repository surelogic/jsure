package inRegion.parentMustExist;

import com.surelogic.Region;

@Region("ChildRegion")
public class Child extends Test {

}
