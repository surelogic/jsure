package test_selfProtected;

/**
 * @SelfProtected
 */
public interface I {

}
