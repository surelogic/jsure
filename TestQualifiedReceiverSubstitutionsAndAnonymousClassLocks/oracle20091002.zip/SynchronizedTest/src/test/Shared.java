package test;

class Shared {
  private boolean hasForB = false;
  private int fromAforB;
  
  private boolean hasForA = false;
  private int fromBforA;
  
  public void forB(final int v) {
    forB_impl(this, v);
  }

  private void forB_impl(final Object lock, final int v) {
    synchronized (lock) {
      fromAforB = v;
      hasForB = true;
      lock.notifyAll();
    }
  }
  
  public void forA(final int v) {
    forA_impl(this, v);
  }

  private void forA_impl(final Object lock, final int v) {
    synchronized (lock) {
      fromBforA = v;
      hasForA = true;
      lock.notifyAll();
    }
  }
  
  public int fromB() throws InterruptedException {
    return fromB_impl(this);
  }

  private int fromB_impl(final Object lock) throws InterruptedException {
    synchronized (lock) {
      while (!hasForA) {
        lock.wait();
      }
      hasForA = false;
      return fromBforA;
    }
  }
  
  public int fromA() throws InterruptedException {
    return fromA_impl(this);
  }

  private int fromA_impl(final Object lock) throws InterruptedException {
    synchronized (lock) {
      while (!hasForB) {
        lock.wait();
      }
      hasForB = false;
      return fromAforB;
    }
  }
}
