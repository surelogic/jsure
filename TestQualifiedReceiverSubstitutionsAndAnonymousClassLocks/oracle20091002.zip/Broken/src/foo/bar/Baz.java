package foo.bar;

public class Baz {
  static Integer foo;

  static {
    foo = Integer.parseInt("18");
  }

  public static void main(String[] args) {
    for (int i = 0; i < 5; i++) {
      new Thread() {

        @Override
        public void run() {
          while (true) {
            synchronized (Baz.class) {
              if (foo == null) {
                foo = 0;
              }
              foo++;
            }
          }
        }

      }.start();
    }
    new Quux();
    try {
      Thread.sleep(500);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    synchronized (Baz.class) {
      System.out.println(foo);
    }
    System.exit(0);
  }

  static class Quux {
    int x;

    Quux() {
      new Thread() {
        @Override
        public void run() {
          for (int i = 0; i < 500; i++) {
            x++;
          }
        }
      }.start();
      try {
        Thread.sleep(100);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      x++;
    }
  }
}
