package aggregate.dstRegionExists;

import com.surelogic.Borrowed;

public class C {
  // do nothing
	
	@Borrowed("this")
	public C() {
		super();
	}
}
