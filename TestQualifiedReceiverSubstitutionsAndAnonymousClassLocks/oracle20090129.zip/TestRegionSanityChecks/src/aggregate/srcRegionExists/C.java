package aggregate.srcRegionExists;

import com.surelogic.Region;

@Region("public FromC")
public class C {
  protected int fromC;
  // Do nothing
}
