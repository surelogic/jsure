package test;

import com.surelogic.Aggregate;
import com.surelogic.Borrowed;
import com.surelogic.InRegion;
import com.surelogic.Region;
import com.surelogic.RegionEffects;
import com.surelogic.RegionLock;
import com.surelogic.RegionLocks;
import com.surelogic.Regions;
import com.surelogic.Unique;

@Regions({
  @Region("private Array1"),
  @Region("private Array2")
})
@RegionLocks({
  @RegionLock("L1 is this protects Array1"),
  @RegionLock("L2 is lock protects Array2")
})
public class HeldWhenInvoking {
  private final Object lock = new Object();
  
  @InRegion("Array1")
  @Unique
  @Aggregate("Instance into Array1")
  private int[] data1;
    
  @Unique
  @Aggregate("Instance into Array2")
  private final int[] data2 = new int[] { 10, 9, 8, 7, 6 };
  
  
  
  @RegionEffects("reads a:Instance")
  private static int sum(final @Borrowed int[] a) {
    int sum = 0;
    for (int v : a) {
      sum += v;
    }
    return sum;
  }
  
  
  
  public int purelyLocal() {
    int[] localArray = new int[] { 1, 2, 3, 4, 5 };
    return sum(localArray);
  }
  
  public int touchesIndirectState_bad() {
    synchronized (this) {
      data1 = new int[] { 1, 2, 3, 4, 5 };
    }
    return sum(data1) +
      sum(data2);
  }
  
  public synchronized int touchesIndirectState_good() {
    data1 = new int[] { 1, 2, 3, 4, 5 };
    synchronized (lock) {
      return sum(data1) +
        sum(data2);
    }
  }
}
